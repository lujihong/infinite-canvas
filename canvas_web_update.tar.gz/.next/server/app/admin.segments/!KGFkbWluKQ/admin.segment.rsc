1:"$Sreact.fragment"
2:I[73833,[],"ClientSegmentRoot"]
3:I[45930,["430","static/chunks/430-2d70e5351b3545b5.js","777","static/chunks/777-eb7c0783ce15ff74.js","9853","static/chunks/9853-0424136b1fd6e366.js","4155","static/chunks/4155-f1aa6a55e02f5daa.js","344","static/chunks/344-1d873287aa59fa58.js","3458","static/chunks/3458-3f22dc6c18bdc2d8.js","4758","static/chunks/4758-546fc7356fb01ce4.js","5499","static/chunks/5499-e9b4924518f017ee.js","145","static/chunks/145-f467218cec495bb8.js","1788","static/chunks/1788-ee926502c73d3627.js","5938","static/chunks/5938-348ad2688a9fb202.js","9977","static/chunks/9977-7145290cfb6a9089.js","9625","static/chunks/9625-eb13d3ade1a975cc.js","8888","static/chunks/8888-cd7577927fe8e909.js","4757","static/chunks/4757-f37a5d943f7ebe05.js","2388","static/chunks/app/(admin)/admin/layout-74240a6d33b9ea00.js"],"default"]
4:I[23506,[],""]
5:I[89536,[],""]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"n9yp7owNpJYzhZ_3Rxeq4"}
6:"$0:rsc:props:children:1:props:serverProvidedParams:params"
