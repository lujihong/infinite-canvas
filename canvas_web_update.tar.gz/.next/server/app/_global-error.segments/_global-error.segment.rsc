1:"$Sreact.fragment"
2:I[23506,[],""]
3:I[89536,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"n9yp7owNpJYzhZ_3Rxeq4"}
