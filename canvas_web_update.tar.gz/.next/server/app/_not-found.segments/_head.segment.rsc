1:"$Sreact.fragment"
2:I[23387,[],"ViewportBoundary"]
3:I[23387,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[87138,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"鑫元宝视频创作工作台"}],["$","meta","1",{"name":"description","content":"鑫元宝视频创作工作台 - 专为高质量 AI 图像与视频创作打造的智能工作台"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?5eab2164f9753042","type":"image/x-icon","sizes":"32x32"}],["$","$L5","3",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"n9yp7owNpJYzhZ_3Rxeq4"}
