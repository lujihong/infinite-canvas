:HL["/_next/static/css/26a91b16a6731130.css","style"]
:HL["/_next/static/css/45d7a8533b52b5bb.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"(user)","param":null,"prefetchHints":0,"slots":{"children":{"name":"canvas","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}},"staleTime":300,"buildId":"n9yp7owNpJYzhZ_3Rxeq4"}
