1:"$Sreact.fragment"
2:I[23506,[],""]
3:I[52526,["430","static/chunks/430-2d70e5351b3545b5.js","5000","static/chunks/app/(user)/editor/error-335c29adca520b1b.js"],"default"]
4:I[89536,[],""]
5:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$3","errorStyles":[],"errorScripts":[],"template":["$","$L4",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"n9yp7owNpJYzhZ_3Rxeq4"}
