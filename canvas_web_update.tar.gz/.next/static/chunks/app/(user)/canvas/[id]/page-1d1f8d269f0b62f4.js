(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[387,1009,3390,8872,8888,9822],{2025:(e,t,a)=>{"use strict";a.d(t,{b:()=>d});var o=a(80020),n=a(83252),i=a(72344),r=a(76047),s=a(98888),l=a(58573);function d({config:e,model:t,value:a,onChange:c,enabled:u=!0}){let m=(0,i.useRef)(e),p=(0,l.k)(e=>e.token),[g,h]=(0,i.useState)([]),[f,x]=(0,i.useState)(!1),[v,y]=(0,i.useState)(""),[b,w]=(0,i.useState)(0);m.current=e;let k={...e,model:t,audioModel:t},j=(0,s.channelIdForActiveModel)(k),C=(0,s.localChannelForActiveModel)(k),N=`${e.channelMode}|${j}|${t}|${C?.baseUrl||e.baseUrl}|${p}`;(0,i.useEffect)(()=>{if(!u)return;let e=!0;return x(!0),y(""),(0,r.Ye)(m.current,t).then(t=>{e&&h(t)}).catch(t=>{e&&y(t instanceof Error?t.message:"音色读取失败")}).finally(()=>{e&&x(!1)}),()=>{e=!1}},[u,t,b,N]);let I=g.map(e=>({value:e.voice_id,label:e.name||e.voice_id}));return a&&!I.some(e=>e.value===a)&&I.unshift({value:a,label:a}),(0,o.jsx)(n.A,{className:"w-full",value:a||"eve",options:I,loading:f,showSearch:!0,optionFilterProp:"label",notFoundContent:f?"正在读取音色…":v||"暂无可用音色",onOpenChange:e=>{e&&v&&w(e=>e+1)},onChange:c})}},2817:(e,t,a)=>{Promise.resolve().then(a.bind(a,7713))},7713:(e,t,a)=>{"use strict";a.d(t,{default:()=>i$});var o=a(80020),n=a(72344),i=a(58409),r=a(92664),s=a(35658),l=a(41667),d=a(23537),c=a(4224),u=a(62476),m=a(48628),p=a(15168),g=a(91641),h=a(51312),f=a(89863),x=a(9792),v=a(18208),y=a(47194),b=a(92024),w=a(17539),k=a(7017),j=a(37534),C=a(26280),N=a(20957),I=a(17465),S=a(84948),A=a(98670),M=a(2319),_=a(42553),T=a(93735),z=a(38439),P=a(58555),E=a(13689),D=a(46528),R=a(80416),$=a(76047),L=a(33639),F=a(98888),V=a(80387),U=a(58960),K=a(70556),W=a(62598),O=a(73889),B=a(34757),q=a(96228),G=a(19822),H=a(33676),X=a(58573),Y=a(48967);async function J(e,t){let a=await ei(e);if(t)return ea(a,Math.floor(t.x*a.width),Math.floor(t.y*a.height),Math.ceil(t.width*a.width),Math.ceil(t.height*a.height));let o=Math.min(a.width,a.height),n=Math.max(0,Math.floor((a.width-o)/2)),i=Math.max(0,Math.floor((a.height-o)/2));return ea(a,n,i,o,o)}async function Q(e,t){let a=await ei(e),o=Z(t.verticalLines,a.width),n=Z(t.horizontalLines,a.height),i=[];for(let e=0;e<n.length-1;e+=1){let t=n[e],r=n[e+1]-t;for(let n=0;n<o.length-1;n+=1){let s=o[n],l=o[n+1]-s;i.push({row:e,column:n,dataUrl:ea(a,s,t,l,r)})}}return i}function Z(e,t){return[0,...e.map(e=>Math.round(e*t)).filter(e=>e>0&&e<t).sort((e,t)=>e-t),t]}async function ee(e,t){let a=await ei(e),{width:o,height:n}=et(a.width,a.height,t.targetLongEdge);return"high"===t.algorithm?function(e,t,a){let o=e,n=e.width,i=e.height;for(;2*n<t&&2*i<a;){let e=2*n,t=2*i;o=en(o,n,i,e,t,"high"),n=e,i=t}return eo(o,n,i,t,a,"high")}(a,o,n):eo(a,a.width,a.height,o,n,t.algorithm)}function et(e,t,a){let o=Math.min(4096,Math.max(1,Math.round(a)))/Math.max(1,e,t);return{width:Math.max(1,Math.round(e*o)),height:Math.max(1,Math.round(t*o))}}function ea(e,t,a,o,n){let i=document.createElement("canvas");i.width=Math.max(1,o),i.height=Math.max(1,n);let r=i.getContext("2d");return r?(r.drawImage(e,t,a,o,n,0,0,i.width,i.height),i.toDataURL("image/png")):e.src}function eo(e,t,a,o,n,i){return en(e,t,a,o,n,i).toDataURL("image/png")}function en(e,t,a,o,n,i){let r=document.createElement("canvas");r.width=o,r.height=n;let s=r.getContext("2d");return s&&(s.imageSmoothingEnabled="nearest"!==i,s.imageSmoothingQuality="bilinear"===i?"medium":"high",s.drawImage(e,0,0,t,a,0,0,o,n)),r}function ei(e){return new Promise((t,a)=>{let o=new Image,n=e;e.startsWith("http")&&(n=(0,V.getProxyUrl)(e),o.crossOrigin="anonymous"),o.onload=()=>t(o),o.onerror=e=>a(e),o.src=n})}function er(e,t,a=640,o=640){let n=Math.max(1,e),i=Math.max(1,t),r=Math.min(1,a/n,o/i);return{width:n*r,height:i*r}}function es(e,t,a){let o=e?.match(/^(\d+)(?:x|:)(\d+)/);if(!o)return null;let n=Number(o[1])/Math.max(1,Number(o[2]));return n<.25||n>4?{width:t,height:a}:n>=t/a?{width:t,height:t/n}:{width:a*n,height:a}}async function el(e,t,a){let o=document.createElement("video");o.crossOrigin="anonymous",o.muted=!0,o.playsInline=!0,o.preload="auto";try{let n=ed(o,"loadedmetadata");o.src=e,o.load(),await n;let i=Math.max(0,o.duration-.001),r="first"===t?0:"last"===t?i:Math.min(a,i);if(r){let e=ed(o,"seeked");o.currentTime=r,await e}else o.readyState<HTMLMediaElement.HAVE_CURRENT_DATA&&await ed(o,"loadeddata");let s=document.createElement("canvas");return s.width=o.videoWidth,s.height=o.videoHeight,s.getContext("2d").drawImage(o,0,0),await new Promise((e,t)=>s.toBlob(a=>a?e(a):t(Error("Failed to capture video frame")),"image/png"))}finally{o.removeAttribute("src"),o.load()}}function ed(e,t){return new Promise((a,o)=>{let n=()=>{e.removeEventListener(t,n),e.removeEventListener("error",i),a()},i=()=>{e.removeEventListener(t,n),e.removeEventListener("error",i),o(Error("Failed to read video frame"))};e.addEventListener(t,n),e.addEventListener("error",i)})}var ec=a(87465);let eu=[{id:"panavision_dxl2",label:"Panavision DXL2",zhName:"潘那维申 DXL2",shortTag:"Panavision DXL2",profilePrompt:"shot on Panavision DXL2 with Panavision DXL color science, large-format Monstro 8K VV sensor, signature organic highlight rolloff, rich filmic texture, premium modern cinema look",bodyColor:"#2a2a2a",accentColor:"#e2a84f",description:"好莱坞顶级院线电影机，8K 大画幅传感器，质感油润。",useCase:"剧情长片、奢华广告、顶级商业片"},{id:"arri_alexa_mini_lf",label:"ARRI Alexa Mini LF",zhName:"阿莱 Mini LF",shortTag:"ARRI Alexa Mini LF",profilePrompt:"shot on ARRI Alexa Mini LF with ARRI Wide Gamut color science, ALEV III large-format sensor, gorgeous skin-tone rendering, buttery highlight rolloff, industry-standard feature-film look",bodyColor:"#3a3a3a",accentColor:"#d4d4d4",description:"行业基准院线电影机，肤色渲染公认最佳。",useCase:"剧情片、人像叙事、品牌广告"},{id:"red_komodo_6k",label:"RED Komodo 6K",zhName:"RED 科莫多 6K",shortTag:"RED Komodo 6K",profilePrompt:"shot on RED Komodo 6K with RED IPP2 color pipeline, Super35 global-shutter sensor, crisp modern digital detail, clean shadows, crisp action-movie look",bodyColor:"#8b2b2b",accentColor:"#ff3b3b",description:"紧凑全局快门 6K，无果冻效应，动作片首选。",useCase:"动作片、FPV、穿越机、无人机"},{id:"red_v_raptor_8k",label:"RED V-Raptor 8K",zhName:"RED V-Raptor 8K",shortTag:"RED V-Raptor 8K",profilePrompt:"shot on RED V-Raptor 8K VV, RED IPP2 color pipeline, 8K Vista Vision sensor, razor-sharp resolution, vivid yet natural color",bodyColor:"#701f1f",accentColor:"#ff5555",description:"RED 旗舰 8K Vista Vision，极致清晰度。",useCase:"科幻大片、高分辨率 VFX 场景"},{id:"sony_venice_2",label:"Sony Venice 2",zhName:"索尼 Venice 2",shortTag:"Sony Venice 2",profilePrompt:"shot on Sony Venice 2 with Sony S-Gamut3.Cine / S-Log3, dual native ISO full-frame cinema sensor, clean shadows, highly refined modern color science",bodyColor:"#2d3a4d",accentColor:"#4d90d0",description:"全画幅双原生 ISO，弱光表现极佳。",useCase:"高端广告、纪录片、夜景戏剧"},{id:"sony_fx6",label:"Sony FX6",zhName:"索尼 FX6",shortTag:"Sony FX6",profilePrompt:"shot on Sony FX6, Sony Venice-derived color science, full-frame cinema sensor, clean low-light performance, documentary-friendly modern look",bodyColor:"#2d2d36",accentColor:"#ff9000",description:"轻量全画幅 Cinema Line，手持纪录片常用。",useCase:"纪录片、单兵采访、轻量剧情"},{id:"blackmagic_ursa_12k",label:"Blackmagic URSA 12K",zhName:"黑魔法 URSA 12K",shortTag:"Blackmagic URSA 12K",profilePrompt:"shot on Blackmagic URSA Cine 12K with Blackmagic Generation 5 color science, Super35 12K sensor, rich filmic tones, indie-cinema aesthetic",bodyColor:"#2e2e2e",accentColor:"#ffb820",description:"独立电影人宠儿，12K 高分辨率性价比机。",useCase:"独立电影、音乐短片、实验影像"},{id:"canon_c500_mk2",label:"Canon C500 Mk II",zhName:"佳能 C500 Mk II",shortTag:"Canon C500 Mk II",profilePrompt:"shot on Canon C500 Mark II with Canon Cinema Gamut, full-frame cinema sensor, warm natural skin tones, premium broadcast and feature-film character",bodyColor:"#332a22",accentColor:"#e8c070",description:"佳能色彩科学，暖调肤色，广播级电影机。",useCase:"广告、电视剧、婚礼电影"}],em=[{id:"arri_signature_prime",label:"ARRI Signature Prime",zhName:"阿莱大师定焦",shortTag:"ARRI Signature Prime",profilePrompt:"ARRI Signature Prime lens, large-format coverage, creamy organic bokeh, gentle contrast, smooth highlight rolloff, soft flattering flares",lensColor:"#2a2a2a",ringColor:"#c4a060",description:"顶级大画幅定焦头，奶油虚化，温润对比。",useCase:"人物叙事、顶级商业片"},{id:"cooke_s7i",label:"Cooke S7/i",zhName:"库克 S7/i",shortTag:"Cooke S7/i",profilePrompt:'Cooke S7/i lens, legendary "Cooke Look", warm color bias, gentle contrast, soft rounded bokeh, classic flattering skin rendering',lensColor:"#26231d",ringColor:"#d0a060",description:"传奇「Cooke Look」，暖调偏红，讨喜肤色。",useCase:"古典人像、时代感叙事"},{id:"zeiss_supreme_prime",label:"Zeiss Supreme Prime",zhName:"蔡司至尊定焦",shortTag:"Zeiss Supreme Prime",profilePrompt:"Zeiss Supreme Prime lens, neutral modern color, high micro-contrast, sharp yet refined detail, clean bokeh with subtle cat-eye near edges",lensColor:"#1e1e22",ringColor:"#4d90d0",description:"中性现代色彩，微反差锐利而不硬。",useCase:"科技感广告、现代剧情"},{id:"canon_sumire_prime",label:"Canon Sumire Prime",zhName:"佳能 Sumire 定焦",shortTag:"Canon Sumire Prime",profilePrompt:"Canon Sumire Prime lens, soft organic character, warm gentle color rendering, dreamy rounded bokeh, cinematic softness for portraits",lensColor:"#2c241c",ringColor:"#e0b070",description:"柔和梦幻肤色镜，暖调柔焦。",useCase:"爱情片、梦境、人物特写"},{id:"anamorphic_cooke",label:"Anamorphic (Cooke)",zhName:"Cooke 变形宽银幕",shortTag:"Cooke Anamorphic",profilePrompt:"Cooke anamorphic lens, oval bokeh, horizontal blue streaks for flares, wide cinematic framing, subtle focus roll-off, 2.39:1 anamorphic cinematic feel",lensColor:"#1a1a24",ringColor:"#6a9ed6",description:"宽银幕变形镜，椭圆虚化 + 水平蓝色光晕。",useCase:"科幻大片、太空戏、夜戏"},{id:"anamorphic_atlas",label:"Anamorphic (Atlas)",zhName:"Atlas Orion 变形",shortTag:"Atlas Orion Anamorphic",profilePrompt:"Atlas Orion anamorphic lens, oval bokeh, cyan horizontal flares, modern anamorphic look with clean center and subtle edge blur",lensColor:"#1b2228",ringColor:"#40c0e0",description:"现代变形镜，青色光晕，中心清晰边缘柔。",useCase:"音乐 MV、风格化广告"},{id:"vintage_leica_r",label:"Vintage Leica R",zhName:"徕卡 R 老镜",shortTag:"Vintage Leica R",profilePrompt:"vintage Leica R prime lens, rich color saturation, slight glow on highlights, slightly soft edges, nostalgic 1970s-80s cinema character",lensColor:"#3a2f1f",ringColor:"#d04040",description:"上世纪老镜，高光微透溢，复古怀旧味。",useCase:"年代戏、怀旧 MV、文艺片"},{id:"macro_100mm",label:"Macro 100mm",zhName:"100mm 微距",shortTag:"Macro 100mm",profilePrompt:"macro 100mm prime lens, extremely shallow depth of field, razor-thin focus plane, smooth creamy bokeh, detail-rich close-up rendering",lensColor:"#1f1f1f",ringColor:"#60d090",description:"微距特写专用，细节惊人，景深极浅。",useCase:"美食广告、珠宝、昆虫、细节"}],ep=[14,18,24,35,40,50,65,85,100,135,200],eg=[1.2,1.4,1.8,2,2.8,4,5.6,8,11,16],eh={14:{zhName:"超广角",description:"14mm 极致广角，空间被极度拉伸",useCase:"建筑内景、风景全景、沉浸视角"},18:{zhName:"超广角",description:"18mm 超广角，强烈空间纵深",useCase:"街头摄影、室内、建筑"},24:{zhName:"广角",description:"24mm 广角，环境感强烈",useCase:"风光、大场面、新闻纪实"},35:{zhName:"小广角",description:"35mm 经典叙事焦段，接近人眼",useCase:"纪实、人物环境叙事"},40:{zhName:"准标准",description:"40mm 准标准，构图平衡",useCase:"人像叙事、文艺片"},50:{zhName:"标准",description:"50mm 标准，空间感自然",useCase:"人像、日常、街拍"},65:{zhName:"中焦",description:"65mm 中焦，轻微压缩，讨喜肤色",useCase:"半身人像、对话戏"},85:{zhName:"中长焦",description:"85mm 经典人像焦段",useCase:"特写人像、婚礼"},100:{zhName:"长焦",description:"100mm 长焦，背景压缩明显",useCase:"特写、微距、体育"},135:{zhName:"长焦",description:"135mm 电影专用长焦",useCase:"剧情特写、舞台"},200:{zhName:"超长焦",description:"200mm 超长焦，极致背景压缩",useCase:"体育、野生动物、戏剧感特写"}},ef={1.2:{zhName:"大光圈",description:"f/1.2 虚化极致，景深刀削般薄",useCase:"梦幻人像、高光溢出效果"},1.4:{zhName:"大光圈",description:"f/1.4 强烈虚化，电影感十足",useCase:"夜景人像、暗光"},1.8:{zhName:"大光圈",description:"f/1.8 明显背景虚化",useCase:"半身人像、街头弱光"},2:{zhName:"大光圈",description:"f/2 柔和虚化与充足锐度",useCase:"人像、文艺日常"},2.8:{zhName:"大光圈",description:"f/2.8 景深适中、虚化柔和",useCase:"群像、叙事"},4:{zhName:"中光圈",description:"f/4 主体清晰，背景有轻微虚化",useCase:"群像、婚礼、电视剧"},5.6:{zhName:"中光圈",description:"f/5.6 背景可辨，环境感强",useCase:"纪实、日常、小品"},8:{zhName:"小光圈",description:"f/8 画质最佳区，前后皆清晰",useCase:"风光、建筑、全景"},11:{zhName:"小光圈",description:"f/11 超大景深，几乎全清晰",useCase:"大场景、产品摆拍"},16:{zhName:"小光圈",description:"f/16 星芒出现，需高光源",useCase:"日光风光、星芒特效"}};function ex(e,t){var a,o;if(!t?.enabled)return e;let n=eu.find(e=>e.id===t.camera)??eu[0],i=em.find(e=>e.id===t.lens)??em[0],r=["the following parameters describe the virtual camera, lens, and exposure used to render this image — they are camera direction, NOT objects to add inside the frame, do not add any physical camera, lens, tripod, viewfinder, or photography equipment into the image",n.profilePrompt,i.profilePrompt,(a=t.focalLength)<=16?`${a}mm ultra-wide-angle perspective, strong spatial depth, pronounced edge distortion, immersive wide coverage`:a<=24?`${a}mm wide-angle perspective, exaggerated depth, strong foreground/background separation, environment-forward framing`:a<=35?`${a}mm slight-wide cinematic perspective, natural environmental context, balanced depth, classic story-telling framing`:a<=50?`${a}mm standard/normal perspective, close to natural human eye perspective, neutral spatial compression, flattering portrait framing`:a<=85?`${a}mm short-telephoto portrait perspective, mild background compression, flattering facial rendering, subject isolation`:a<=135?`${a}mm telephoto perspective, moderate compression, strong subject isolation from background, cinematic close-up`:`${a}mm long-telephoto perspective, strong background compression, highly isolated subject on compressed flat background, powerful dramatic framing`,(o=t.aperture)<=1.4?`shot wide open at f/${o}, extremely shallow depth of field, strong creamy bokeh, razor-thin focus plane, dreamy background separation`:o<=2?`shot at f/${o}, very shallow depth of field, smooth cinematic bokeh, clear subject-from-background separation`:o<=2.8?`shot at f/${o}, shallow depth of field, soft bokeh, natural subject isolation`:o<=4?`shot at f/${o}, moderate depth of field, gentle falloff, clean background blur without over-smoothing`:o<=5.6?`shot at f/${o}, balanced depth of field, background retains context while subject remains clearly in focus`:o<=8?`shot at f/${o}, wide depth of field, environment and subject both sharp, documentary / landscape style`:`shot at f/${o}, very wide depth of field, extensive sharpness from foreground to background, wide-open environmental feel`,"keep the subjects, scene, and action unchanged — apply these as optical and sensor characteristics only","[camera body: "+n.shortTag+" \xb7 lens: "+i.shortTag+" \xb7 focal: "+t.focalLength+"mm \xb7 aperture: f/"+t.aperture+"]"].join(", ");return e?e+", "+r:r}var ev=a(26750);function ey(e){return e.reduce((e,t)=>({left:Math.min(e.left,t.position.x),top:Math.min(e.top,t.position.y),right:Math.max(e.right,t.position.x+t.width),bottom:Math.max(e.bottom,t.position.y+t.height)}),{left:1/0,top:1/0,right:-1/0,bottom:-1/0})}function eb(e,t){if(t.some(t=>e.has(t.id)&&t.type===ev.p.Group))return null;let a=t.filter(t=>e.has(t.id)&&t.type!==ev.p.Group);return[...t].reverse().find(t=>!(t.type!==ev.p.Group||e.has(t.id))&&a.some(e=>{let a=e.position.x+e.width/2,o=e.position.y+e.height/2;return a>=t.position.x&&a<=t.position.x+t.width&&o>=t.position.y&&o<=t.position.y+t.height}))||null}var ew=a(20978),ek=a(10306),ej=a(10430),eC=a(2526),eN=a(76533),eI=a(61863),eS=a(37530),eA=a(32118),eM=a(74662),e_=a(68465);let eT={[ev.p.Image]:{width:340,height:240,title:"图片"},[ev.p.Panorama]:{...ec.D9,title:"全景图"},[ev.p.Text]:{width:340,height:240,title:"文本"},[ev.p.Config]:{width:440,height:240,title:"生成配置"},[ev.p.Video]:{width:420,height:236,title:"视频"},[ev.p.Audio]:{width:340,height:160,title:"音频"},[ev.p.Director]:{width:360,height:320,title:"导演台"},[ev.p.Group]:{width:760,height:480,title:"组"}},ez={[ev.p.Image]:{...eT[ev.p.Image],metadata:{content:"",status:"idle"}},[ev.p.Panorama]:{...eT[ev.p.Panorama],metadata:{content:"",status:"idle",size:ec.A9,panoramaSourcePrompt:""}},[ev.p.Text]:{...eT[ev.p.Text],metadata:{content:"",status:"idle",fontSize:14}},[ev.p.Config]:{...eT[ev.p.Config],metadata:{content:"",status:"idle",generationMode:"image"}},[ev.p.Video]:{...eT[ev.p.Video],metadata:{content:"",status:"idle"}},[ev.p.Audio]:{...eT[ev.p.Audio],metadata:{content:"",status:"idle"}},[ev.p.Director]:{...eT[ev.p.Director],metadata:{status:"idle"}},[ev.p.Group]:{...eT[ev.p.Group],metadata:{status:"idle"}}};var eP=a(9940);function eE({connection:e,from:t,to:a,active:n,onSelect:i,onContextMenu:r}){let s=O.$[(0,H.C)(e=>e.theme)],l=t.position.x+t.width,d=t.position.y+t.height/2,c=a.position.x,u=a.position.y+a.height/2,m=Math.max(.5*Math.abs(c-l),50),p=`M ${l} ${d} C ${l+m} ${d}, ${c-m} ${u}, ${c} ${u}`;return(0,o.jsxs)("g",{children:[(0,o.jsx)("path",{"data-connection-id":e.id,d:p,stroke:"transparent",strokeWidth:"16",fill:"none",style:{cursor:"pointer",pointerEvents:"stroke"},onClick:e=>{e.stopPropagation(),i()},onContextMenu:e=>{e.preventDefault(),e.stopPropagation(),r?.(e)}}),(0,o.jsx)("path",{d:p,stroke:n?s.node.activeStroke:s.node.muted,strokeWidth:n?3:2,strokeOpacity:n?1:.82,fill:"none",style:{filter:n?`drop-shadow(0 0 8px ${s.node.activeStroke}66)`:void 0,pointerEvents:"none"}})]})}function eD({node:e,handle:t,mouseWorld:a,target:n}){let i=O.$[(0,H.C)(e=>e.theme)];if(!e)return null;let r="source"===t.handleType?e.position.x+e.width:a.x,s="source"===t.handleType?e.position.y+e.height/2:a.y,l="source"===t.handleType?a.x:e.position.x,d="source"===t.handleType?a.y:e.position.y+e.height/2,c="target"===t.handleType&&n?n.position.x+n.width:r,u="target"===t.handleType&&n?n.position.y+n.height/2:s,m="source"===t.handleType&&n?n.position.x:l,p="source"===t.handleType&&n?n.position.y+n.height/2:d,g=Math.abs(m-c),h=`M ${c} ${u} C ${c+.5*g} ${u}, ${m-.5*g} ${p}, ${m} ${p}`;return(0,o.jsx)("path",{d:h,stroke:i.node.activeStroke,strokeWidth:"2",fill:"none",strokeDasharray:"5,5"})}var eR=a(62147),e$=a(67486);let eL=/@\[node:([^\]]+)\]/g;function eF({value:e,inputs:t,onChange:a,onClose:i}){let r=O.$[(0,H.C)(e=>e.theme)],s=(0,n.useRef)(null),l=(0,n.useRef)(!1),[d,c]=(0,n.useState)(null),[u,m]=(0,n.useState)(0),[p,g]=(0,n.useState)(null),h=(0,n.useMemo)(()=>(function(e){let t=[],a=0;for(let o of e.matchAll(eL))void 0!==o.index&&(o.index>a&&t.push({type:"text",value:e.slice(a,o.index)}),t.push({type:"reference",nodeId:o[1]}),a=o.index+o[0].length);return a<e.length&&t.push({type:"text",value:e.slice(a)}),t})(e),[e]),f=(0,n.useMemo)(()=>new Map(t.map(e=>[e.nodeId,e])),[t]),x=(0,n.useMemo)(()=>{if(!d)return[];let e=(d.query||"").trim().toLowerCase();return e?t.filter(a=>`${eq(a,t)} ${a.title} ${a.text||""}`.toLowerCase().includes(e)):t},[t,d]);(0,n.useEffect)(()=>{if(document.activeElement===s.current)return;let e=s.current;e&&(e.textContent="",h.forEach(a=>{if("text"===a.type)return void e.append(document.createTextNode(a.value));let o=f.get(a.nodeId);o&&e.append(eK(o,t,r,g))}))},[t,f,r,h]);let y=()=>{let e=s.current;e&&(a(eW(e)),b())},b=()=>{let e=eB(),a=/@([^\s@]*)$/.exec(e);if(!a||!t.length)return void w();let o=window.getSelection(),n=o?.rangeCount?o.getRangeAt(0):null,i=s.current?.parentElement,r=i?.getBoundingClientRect(),l=n?.getBoundingClientRect();i&&r&&l&&(i.style.setProperty("--mention-left",`${l.left-r.left}px`),i.style.setProperty("--mention-top",`${l.bottom-r.top+6}px`)),c({query:a[1]||""}),m(0)},w=()=>{c(null),m(0)},k=e=>{var o;let n,i,l=s.current;if(!l)return;!function(){let e=window.getSelection();if(!e?.rangeCount)return;let t=e.getRangeAt(0),a=eB(),o=/@([^\s@]*)$/.exec(a);o&&(t.setStart(t.startContainer,Math.max(0,t.startOffset-(o[1]||"").length-1)),t.deleteContents())}();let d=eK(e,t,r,g),c=document.createTextNode(" "),u=document.createTextNode(" "),m=window.getSelection(),p=m?.rangeCount?m.getRangeAt(0):null;p?(p.insertNode(u),p.insertNode(d),p.insertNode(c),p.setStartAfter(u),p.collapse(!0),m?.removeAllRanges(),m?.addRange(p)):(l.append(c,d,u),o=l,(n=document.createRange()).selectNodeContents(o),n.collapse(!1),i=window.getSelection(),i?.removeAllRanges(),i?.addRange(n)),w(),a(eW(l))},j=e=>e.stopPropagation();return(0,o.jsxs)("div",{"data-canvas-no-zoom":!0,className:"rounded-2xl border p-3 shadow-2xl backdrop-blur",style:{background:r.toolbar.panel,borderColor:r.toolbar.border,color:r.node.text},onMouseDown:j,onPointerDown:j,onWheel:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"mb-2 flex items-center justify-between gap-2",children:[(0,o.jsxs)("div",{className:"flex min-w-0 items-baseline gap-2",children:[(0,o.jsx)("div",{className:"shrink-0 text-xs font-semibold",children:"组装提示词"}),(0,o.jsx)("div",{className:"truncate text-[11px] opacity-55",children:"@ 引用已连接素材，发送前按当前连接重新编号"})]}),(0,o.jsx)(ej.Ay,{size:"small",type:"text",className:"!h-7 !w-7 !min-w-7 !p-0",icon:(0,o.jsx)(v.A,{className:"size-3.5"}),onClick:i})]}),(0,o.jsxs)("div",{className:"relative rounded-xl",style:{background:"transparent"},children:[e.trim()?null:(0,o.jsx)("div",{className:"pointer-events-none absolute left-3 top-2 text-sm leading-7",style:{color:r.node.placeholder},children:"输入提示词，按 @ 引用连接的图片或文本"}),(0,o.jsx)("div",{ref:s,contentEditable:!0,suppressContentEditableWarning:!0,className:"thin-scrollbar h-64 w-full cursor-text overflow-y-auto whitespace-pre-wrap break-words px-3 py-2 text-sm leading-7 outline-none",style:{color:r.node.text},onInput:()=>{l.current||y()},onPaste:e=>{let t=e.clipboardData.getData("text/plain");if(!t)return;e.preventDefault();let a=window.getSelection(),o=a?.rangeCount?a.getRangeAt(0):null;if(!o)return;o.deleteContents();let n=document.createTextNode(t);o.insertNode(n),o.setStartAfter(n),o.collapse(!0),a?.removeAllRanges(),a?.addRange(o),y()},onCompositionStart:()=>{l.current=!0},onCompositionEnd:()=>{l.current=!1,y()},onKeyDown:e=>{if(e.stopPropagation(),d&&x.length){if("ArrowDown"===e.key){e.preventDefault(),m(e=>(e+1)%x.length);return}if("ArrowUp"===e.key){e.preventDefault(),m(e=>(e-1+x.length)%x.length);return}if("Enter"===e.key){e.preventDefault(),k(x[Math.min(u,x.length-1)]);return}if("Escape"===e.key){e.preventDefault(),w();return}}if(("Backspace"===e.key||"Delete"===e.key)&&function(e){let t=window.getSelection();if(!t?.rangeCount||!t.isCollapsed)return!1;let a=t.getRangeAt(0),o=function(e,t){let a=e.startContainer,o=e.startOffset,n="Backspace"===t;if(a.nodeType===Node.TEXT_NODE){let e=a.textContent||"";return n&&o>0||!n&&o<e.length?null:eO(a,n)}return eO(Array.from(a.childNodes)[n?o-1:o]||a,n,!0)}(a,e);if(!o)return!1;let n=document.createTextNode("");return o.replaceWith(n),a.setStart(n,0),a.collapse(!0),t.removeAllRanges(),t.addRange(a),!0}(e.key)){e.preventDefault(),requestAnimationFrame(y);return}requestAnimationFrame(b)},onBlur:()=>window.setTimeout(w,120)}),d&&x.length?(0,o.jsx)(eV,{inputs:x,allInputs:t,activeIndex:Math.min(u,x.length-1),theme:r,onSelect:k}):null]}),p?(0,o.jsx)(eR.A,{src:p,alt:"引用图片预览",style:{display:"none"},preview:{visible:!0,src:p,onVisibleChange:e=>!e&&g(null)}}):null]})}function eV({inputs:e,allInputs:t,activeIndex:a,theme:i,onSelect:r}){let s=(0,n.useRef)(!1);return(0,o.jsx)("div",{className:"absolute z-[90] max-h-56 w-64 overflow-y-auto rounded-xl border p-1 shadow-2xl",style:{left:"var(--mention-left)",top:"var(--mention-top)",background:i.toolbar.panel,borderColor:i.toolbar.border},children:e.map((e,n)=>(0,o.jsxs)("button",{type:"button",className:"flex w-full min-w-0 items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs transition",style:{background:n===a?i.toolbar.activeBg:"transparent",color:n===a?i.toolbar.activeText:i.node.text},onMouseDown:t=>{t.preventDefault(),t.stopPropagation(),s.current||(s.current=!0,r(e))},children:[(0,o.jsx)(eU,{input:e}),(0,o.jsxs)("span",{className:"min-w-0 flex-1",children:[(0,o.jsx)("span",{className:"block font-medium",children:eq(e,t)}),(0,o.jsx)("span",{className:"block truncate opacity-65",children:e.text||e.title})]})]},e.nodeId))})}function eU({input:e}){if("image"===e.type&&e.image)return(0,o.jsx)("img",{src:e.image.dataUrl,alt:"",className:"size-9 rounded-md object-cover"});if("video"===e.type&&e.video)return(0,o.jsx)("video",{src:e.video.url,className:"size-9 rounded-md bg-black object-cover",muted:!0,preload:"metadata"});let t="audio"===e.type?c.A:"video"===e.type?d.A:"image"===e.type?l.A:e$.A;return(0,o.jsx)("span",{className:"grid size-9 shrink-0 place-items-center rounded-md bg-black/10",children:(0,o.jsx)(t,{className:"size-4"})})}function eK(e,t,a,o){var n;let i=document.createElement("span");if(i.contentEditable="false",i.dataset.referenceNodeId=e.nodeId,i.className="mx-px inline-flex h-7 max-w-40 items-center justify-center overflow-hidden rounded-md border px-1 text-xs leading-none align-middle",Object.assign(i.style,{background:(n=a).toolbar.panel,borderColor:n.node.stroke,color:n.node.text}),"image"===e.type&&e.image){let t=document.createElement("img");t.src=e.image.dataUrl,t.alt=e.title,t.className="size-6 rounded object-cover",i.className="mx-px inline-flex size-6 items-center justify-center overflow-hidden rounded align-middle",i.appendChild(t),i.addEventListener("click",t=>{t.preventDefault(),t.stopPropagation(),o(e.image?.dataUrl||"")})}else{i.title=e.text||e.title;let t=document.createElement("span");t.className="block truncate",t.textContent="text"===e.type&&e.text||e.title,i.appendChild(t)}return i}function eW(e){return(function e(t){let a="";return t.forEach(t=>{if(t.nodeType===Node.TEXT_NODE){a+=t.textContent||"";return}if(!(t instanceof HTMLElement))return;if("BR"===t.tagName){a+="\n";return}let o=t.dataset.referenceNodeId;if(o){a+=`@[node:${o}]`;return}let n=e(t.childNodes),i="DIV"===t.tagName||"P"===t.tagName;i&&a&&!a.endsWith("\n")&&(a+="\n"),a+=n,i&&!n&&(a+="\n")}),a})(e.childNodes).replace(/\uFEFF/g,"")}function eO(e,t,a=!1){let o=a?e:t?e.previousSibling:e.nextSibling;for(;o&&o.nodeType===Node.TEXT_NODE&&!(o.textContent||"").trim();)o=t?o.previousSibling:o.nextSibling;return o instanceof HTMLElement&&o.dataset.referenceNodeId?o:null}function eB(){var e;let t,a=window.getSelection();if(!a?.rangeCount)return"";let o=a.getRangeAt(0).cloneRange(),n=(t=(e=o.startContainer)instanceof Element?e:e.parentElement,t?.closest("[contenteditable='true']")||null);return n?(o.setStart(n,0),o.toString()):""}function eq(e,t){let a=Math.max(0,t.filter(t=>t.type===e.type).findIndex(t=>t.nodeId===e.nodeId));return"image"===e.type?`图片${a+1}`:"video"===e.type?`视频${a+1}`:"audio"===e.type?`音频${a+1}`:`文本${a+1}`}var eG=a(77481),eH=a(55686),eX=a(53140),eY=a(22858),eJ=a(62844),eQ=a(89978),eZ=a(761),e0=a(36359),e1=a(67199),e2=a(28280),e5=a(96702),e4=a(39853);let e3={enabled:!1,camera:eu[0].id,lens:em[0].id,focalLength:50,aperture:4},e6=eu.map(e=>e.id),e8=em.map(e=>e.id);function e7({value:e,onChange:t,buttonClassName:a}){let i=O.$[(0,H.C)(e=>e.theme)],r=(0,n.useRef)(null),s=(0,n.useRef)(null),[l,d]=(0,n.useState)(!1),[c,u]=(0,n.useState)(null),m=e||e3,p=eu.find(e=>e.id===m.camera)||eu[0],g=em.find(e=>e.id===m.lens)||em[0],h=eh[m.focalLength],f=ef[m.aperture],x=e=>t({...m,...e});(0,n.useEffect)(()=>{if(!l)return;let e=r.current,t=e?.closest("[data-node-id]"),a=t?.parentElement;if(!e||!t||!a)return;let o=()=>{let t=e.getBoundingClientRect();u(e=>e&&e.left===t.left&&e.top===t.top&&e.width===t.width&&e.height===t.height?e:t)},n=e=>{let t=e.target;!(t instanceof Node)||r.current?.contains(t)||s.current?.contains(t)||d(!1)},i=new MutationObserver(o);return i.observe(t,{attributes:!0,attributeFilter:["style"]}),i.observe(a,{attributes:!0,attributeFilter:["style"]}),o(),window.addEventListener("resize",o),window.addEventListener("scroll",o,!0),window.addEventListener("pointerdown",n,!0),()=>{i.disconnect(),window.removeEventListener("resize",o),window.removeEventListener("scroll",o,!0),window.removeEventListener("pointerdown",n,!0)}},[l]);let y=c?{position:"fixed",zIndex:1200,width:900,left:c.left+c.width/2,bottom:window.innerHeight-c.top+8,transform:"translateX(-50%) scale(0.75)",transformOrigin:"center bottom",overflowY:"auto",background:i.toolbar.panel,border:"1px solid "+i.toolbar.border,borderRadius:18,boxShadow:"0 18px 54px rgba(28, 25, 23, 0.16)",color:i.node.text}:void 0;return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("span",{ref:r,className:"inline-flex min-w-0 shrink-0",onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(e0.A,{className:"size-3.5"}),className:a||"!h-10 !min-w-[84px] !justify-start !rounded-full !px-2.5",style:{background:e?.enabled?i.toolbar.activeBg:i.node.fill,borderColor:e?.enabled?i.node.activeStroke:i.node.stroke,color:e?.enabled?i.toolbar.activeText:i.node.text},"aria-expanded":l,onClick:()=>d(e=>!e),children:"摄像机"})}),l&&c&&y?(0,eZ.createPortal)((0,o.jsxs)("div",{ref:s,style:y,onPointerDown:e=>e.stopPropagation(),onMouseDown:e=>e.stopPropagation(),onClick:e=>e.stopPropagation(),onWheel:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"flex items-center justify-between border-b px-6 py-4",style:{borderColor:i.toolbar.border},children:[(0,o.jsx)("h2",{className:"text-base font-semibold",children:"摄像机"}),(0,o.jsx)("button",{type:"button",className:"grid size-8 place-items-center rounded-lg transition hover:opacity-70",style:{color:i.node.muted},"aria-label":"关闭",onClick:()=>d(!1),children:(0,o.jsx)(v.A,{className:"size-5"})})]}),(0,o.jsxs)("div",{className:"px-6 py-5",children:[(0,o.jsx)("div",{className:"overflow-x-auto",children:(0,o.jsxs)("div",{className:"grid min-w-[840px] grid-cols-4",children:[(0,o.jsx)(e9,{theme:i,label:"相机",tooltipTitle:p.zhName+" \xb7 "+p.label,tooltipDesc:p.description,tooltipUseCase:p.useCase,visual:(0,o.jsx)(te,{profile:p,theme:i}),caption:p.label,onPrevious:m.camera===e6[0]?void 0:()=>x({camera:ta(e6,m.camera,-1)}),onNext:m.camera===e6[e6.length-1]?void 0:()=>x({camera:ta(e6,m.camera,1)})}),(0,o.jsx)(e9,{theme:i,separator:!0,label:"镜头",tooltipTitle:g.zhName+" \xb7 "+g.label,tooltipDesc:g.description,tooltipUseCase:g.useCase,visual:(0,o.jsx)(tt,{profile:g,theme:i}),caption:g.label,onPrevious:m.lens===e8[0]?void 0:()=>x({lens:ta(e8,m.lens,-1)}),onNext:m.lens===e8[e8.length-1]?void 0:()=>x({lens:ta(e8,m.lens,1)})}),(0,o.jsx)(e9,{theme:i,separator:!0,label:"焦距",tooltipTitle:m.focalLength+"mm \xb7 "+(h?.zhName||""),tooltipDesc:h?.description,tooltipUseCase:h?.useCase,badge:h?.zhName,visual:(0,o.jsxs)("div",{className:"flex flex-col items-center",children:[(0,o.jsx)("div",{className:"text-5xl font-light leading-none",style:{color:i.node.text},children:m.focalLength}),(0,o.jsx)("div",{className:"mt-2 text-xs tracking-wider",style:{color:i.node.faint},children:"mm"})]}),caption:"mm",onPrevious:m.focalLength===ep[0]?void 0:()=>x({focalLength:ta(ep,m.focalLength,-1)}),onNext:m.focalLength===ep[ep.length-1]?void 0:()=>x({focalLength:ta(ep,m.focalLength,1)})}),(0,o.jsx)(e9,{theme:i,separator:!0,label:"光圈",tooltipTitle:"f/"+m.aperture+" \xb7 "+(f?.zhName||""),tooltipDesc:f?.description,tooltipUseCase:f?.useCase,badge:f?.zhName,visual:(0,o.jsxs)("div",{className:"flex items-baseline",children:[(0,o.jsx)("span",{className:"text-2xl font-light",style:{color:i.node.muted},children:"f/"}),(0,o.jsx)("span",{className:"text-5xl font-light leading-none",style:{color:i.node.text},children:m.aperture})]}),caption:"f/"+m.aperture,onPrevious:m.aperture===eg[0]?void 0:()=>x({aperture:ta(eg,m.aperture,-1)}),onNext:m.aperture===eg[eg.length-1]?void 0:()=>x({aperture:ta(eg,m.aperture,1)})})]})}),(0,o.jsxs)("div",{className:"mt-6 flex items-center justify-end gap-2",children:[(0,o.jsx)("span",{className:"text-sm",style:{color:m.enabled?i.node.text:i.node.muted},children:m.enabled?"开启":"关闭"}),(0,o.jsx)(e5.A,{size:"small",checked:m.enabled,"aria-label":"摄像机控制",onChange:e=>x({enabled:e})})]})]})]}),document.body):null]})}function e9({theme:e,separator:t,label:a,tooltipTitle:n,tooltipDesc:i,tooltipUseCase:r,badge:s,visual:l,caption:d,onPrevious:c,onNext:u}){let m=(0,o.jsxs)("div",{className:"max-w-64",children:[(0,o.jsx)("div",{className:"font-medium",children:n}),i?(0,o.jsx)("div",{className:"mt-1 text-xs opacity-80",children:i}):null,r?(0,o.jsxs)("div",{className:"mt-2 text-xs opacity-70",children:["使用场景：",r]}):null]});return(0,o.jsxs)("div",{className:"flex flex-col items-center px-5",style:{borderLeft:t?"1px solid "+e.node.stroke:void 0},children:[(0,o.jsx)(ej.Ay,{type:"text",disabled:!c,className:"group !h-8 !w-full !p-0 hover:!bg-transparent",style:{color:e.node.faint},icon:(0,o.jsx)(e1.A,{className:"h-5 w-8 rounded-md p-0.5 transition-colors group-hover:bg-foreground/5 group-hover:text-foreground/80"}),"aria-label":"上一项"+a,onClick:c}),(0,o.jsx)(e4.A,{title:m,mouseEnterDelay:.7,color:e.node.panel,zIndex:1300,children:(0,o.jsxs)("div",{className:"relative flex h-[180px] w-full max-w-[180px] cursor-help flex-col items-center justify-between rounded-2xl border px-4 py-3 transition-colors",style:{background:e.node.fill,borderColor:e.node.stroke},children:[(0,o.jsx)("span",{className:"text-sm font-medium",style:{color:e.node.muted},children:a}),(0,o.jsx)("div",{className:"flex flex-1 items-center justify-center",children:l}),s?(0,o.jsx)("span",{className:"absolute right-2 top-2.5 rounded-md px-2 py-0.5 text-xs font-medium",style:{background:e.toolbar.activeBg,color:e.toolbar.activeText},children:s}):null]})}),(0,o.jsx)(ej.Ay,{type:"text",disabled:!u,className:"group !h-8 !w-full !p-0 hover:!bg-transparent",style:{color:e.node.faint},icon:(0,o.jsx)(e2.A,{className:"h-5 w-8 rounded-md p-0.5 transition-colors group-hover:bg-foreground/5 group-hover:text-foreground/80"}),"aria-label":"下一项"+a,onClick:u}),(0,o.jsx)("span",{className:"max-w-full truncate text-center text-sm",style:{color:e.node.muted},children:d})]})}function te({profile:e,theme:t}){let a=e.bodyColor,n=e.accentColor,i=t.canvas.background,r=t.node.panel,s=t.node.muted,l=e=>(0,o.jsx)("svg",{viewBox:"0 0 72 52",className:"h-20 w-full",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",children:e});switch(e.id){case"panavision_dxl2":return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"18",y:"8",width:"30",height:"32",rx:"3",fill:a,stroke:n}),(0,o.jsx)("rect",{x:"10",y:"12",width:"12",height:"24",rx:"2",fill:r,stroke:n}),(0,o.jsx)("rect",{x:"48",y:"14",width:"16",height:"20",rx:"2",fill:r,stroke:n}),(0,o.jsx)("circle",{cx:"56",cy:"24",r:"6",fill:i,stroke:n}),(0,o.jsx)("rect",{x:"26",y:"3",width:"14",height:"6",rx:"1",fill:a}),(0,o.jsx)("rect",{x:"20",y:"42",width:"26",height:"4",rx:"1",fill:n,opacity:"0.6"})]}));case"arri_alexa_mini_lf":return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"14",y:"12",width:"38",height:"28",rx:"4",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:"52",cy:"26",r:"10",fill:i,stroke:n}),(0,o.jsx)("circle",{cx:"52",cy:"26",r:"6",fill:r,stroke:s}),(0,o.jsx)("rect",{x:"20",y:"6",width:"18",height:"8",rx:"1.5",fill:a}),(0,o.jsx)("rect",{x:"18",y:"18",width:"8",height:"6",rx:"1",fill:n,opacity:"0.3"})]}));case"red_komodo_6k":case"red_v_raptor_8k":{let t="red_v_raptor_8k"===e.id;return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"18",y:"14",width:t?32:28,height:"26",rx:"2",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:t?50:46,cy:"27",r:"9",fill:i,stroke:n}),(0,o.jsx)("circle",{cx:t?50:46,cy:"27",r:"5",fill:r,stroke:s}),(0,o.jsx)("rect",{x:"20",y:"8",width:"8",height:"7",rx:"1",fill:n,opacity:"0.85"}),(0,o.jsx)("text",{x:"22",y:"36",fontSize:"6",fill:s,fontWeight:"bold",children:"RED"})]}))}case"sony_venice_2":case"sony_fx6":return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"14",y:"14",width:"36",height:"26",rx:"3",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:"52",cy:"27",r:"9",fill:i,stroke:n}),(0,o.jsx)("rect",{x:"16",y:"18",width:"6",height:"6",rx:"1",fill:n,opacity:"0.5"}),(0,o.jsx)("rect",{x:"22",y:"8",width:"16",height:"8",rx:"1.5",fill:a}),(0,o.jsx)("text",{x:"22",y:"36",fontSize:"5.5",fill:s,children:"SONY"})]}));case"blackmagic_ursa_12k":return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"16",y:"12",width:"32",height:"28",rx:"2",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:"50",cy:"26",r:"10",fill:i,stroke:n}),(0,o.jsx)("circle",{cx:"50",cy:"26",r:"6",fill:r,stroke:s}),(0,o.jsx)("rect",{x:"24",y:"5",width:"12",height:"8",rx:"1",fill:a}),(0,o.jsx)("text",{x:"18",y:"35",fontSize:"5",fill:n,fontWeight:"bold",children:"URSA"})]}));case"canon_c500_mk2":return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"16",y:"12",width:"34",height:"28",rx:"3",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:"50",cy:"26",r:"9",fill:i,stroke:n}),(0,o.jsx)("rect",{x:"18",y:"16",width:"10",height:"5",rx:"1",fill:n,opacity:"0.7"}),(0,o.jsx)("text",{x:"20",y:"36",fontSize:"5.5",fill:s,children:"Canon"})]}));default:return l((0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("rect",{x:"16",y:"14",width:"36",height:"26",rx:"3",fill:a,stroke:n}),(0,o.jsx)("circle",{cx:"52",cy:"27",r:"9",fill:i,stroke:n})]}))}}function tt({profile:e,theme:t}){let a=e.id.startsWith("anamorphic")?4:3;return(0,o.jsxs)("svg",{viewBox:"0 0 88 56",className:"h-20 w-full",xmlns:"http://www.w3.org/2000/svg","aria-hidden":"true",children:[(0,o.jsx)("rect",{x:"8",y:"17",width:"68",height:"24",rx:"5",fill:e.lensColor,stroke:t.node.faint}),Array.from({length:a}).map((t,a)=>(0,o.jsx)("rect",{x:18+14*a,y:"17",width:"5",height:"24",fill:e.ringColor,opacity:"0.65"},a)),(0,o.jsx)("circle",{cx:"72",cy:"29",r:"10",fill:t.canvas.background,stroke:e.ringColor,strokeWidth:"2"}),(0,o.jsx)("circle",{cx:"72",cy:"29",r:"5",fill:t.node.panel,stroke:t.node.faint}),e.id.startsWith("anamorphic")?(0,o.jsx)("ellipse",{cx:"72",cy:"29",rx:"10",ry:"4",fill:"none",stroke:e.ringColor,opacity:"0.75"}):null]})}function ta(e,t,a){let o=e.indexOf(t);return e[Math.min(Math.max(o+a,0),e.length-1)]}var to=a(83252),tn=a(2025),ti=a(23126),tr=a(39230);let ts=["0.75","1","1.25","1.5"];function tl({config:e,onConfigChange:t,theme:a,showTitle:n=!0,className:i="w-[320px] space-y-4 rounded-2xl px-1 py-0.5"}){let r=e.model||e.audioModel||"",s=(0,eA.DW)(e,r),l=(0,eM.MP)(r)&&(0,eM.Uh)(e,r);return(0,o.jsx)(ti.q4,{theme:a,children:(0,o.jsxs)("div",{className:i,style:{color:a.node.text},onMouseDown:e=>e.stopPropagation(),children:[n?(0,o.jsx)("div",{className:"text-lg font-semibold",children:"音频设置"}):null,l?(0,o.jsx)(td,{config:e,onConfigChange:t,theme:a}):(0,eI.Ht)(r)?(0,o.jsx)(tc,{config:e,model:r,onConfigChange:t,theme:a}):(0,o.jsx)(tu,{config:e,model:r,glm:(0,eS.vI)(r),grok:s,onConfigChange:t,theme:a})]})})}function td({config:e,onConfigChange:t,theme:a}){return(0,o.jsx)(tp,{title:"声音",color:a.node.muted,children:(0,o.jsx)(to.A,{className:"w-full",showSearch:!0,optionFilterProp:"label",value:(0,tr.sE)(e.geminiTtsVoice),options:tr.Z$,onChange:e=>t("geminiTtsVoice",e)})})}function tc({config:e,model:t,onConfigChange:a,theme:n}){let i=(0,eI.AN)(e.mimoTtsFormat);return(0,o.jsxs)(o.Fragment,{children:[(0,eI.c0)(t)?(0,o.jsx)(tp,{title:"声音",color:n.node.muted,children:(0,o.jsx)("div",{className:"grid grid-cols-4 gap-2.5",children:eI.Kk.map(t=>(0,o.jsx)(tm,{selected:(0,eI.De)(e.mimoTtsVoice)===t.value,theme:n,onClick:()=>a("mimoTtsVoice",t.value),children:t.label},t.value))})}):null,(0,eI.Cb)(t)?(0,o.jsx)(tp,{title:"音色描述",color:n.node.muted,children:(0,o.jsx)("textarea",{value:e.mimoVoiceDesignPrompt||"",placeholder:"例如：年轻女性，声音清亮自然，有亲和力。",className:"thin-scrollbar h-24 w-full resize-none rounded-xl border bg-transparent px-3 py-2 text-sm leading-5 outline-none",style:{borderColor:n.node.stroke,color:n.node.text},onChange:e=>a("mimoVoiceDesignPrompt",e.target.value),onMouseDown:e=>e.stopPropagation()})}):null,(0,o.jsx)(tp,{title:"格式",color:n.node.muted,children:(0,o.jsx)("div",{className:"grid grid-cols-3 gap-2.5",children:eI.Jz.map(e=>(0,o.jsx)(tm,{selected:i===e.value,theme:n,onClick:()=>a("mimoTtsFormat",e.value),children:e.label},e.value))})}),(0,eI.c0)(t)||(0,eI.TR)(t)?(0,o.jsx)(tp,{title:"声音指令",color:n.node.muted,children:(0,o.jsx)("textarea",{value:e.audioInstructions||"",placeholder:"例如：语速轻快，语气兴奋，结尾略微上扬。",className:"thin-scrollbar h-20 w-full resize-none rounded-xl border bg-transparent px-3 py-2 text-sm leading-5 outline-none",style:{borderColor:n.node.stroke,color:n.node.text},onChange:e=>a("audioInstructions",e.target.value),onMouseDown:e=>e.stopPropagation()})}):null]})}function tu({config:e,model:t,glm:a,grok:n,onConfigChange:i,theme:r}){let s=a?(0,eS.Zv)(e.glmTtsVoice):n?e.grokTtsVoice||"eve":(0,eS.Dn)(e.audioVoice),l=a?(0,eS.C_)(e.glmTtsFormat):n?(0,eA.zu)(e.grokTtsFormat):(0,eS.O5)(e.audioFormat),d=a?(0,eS.OL)(e.glmTtsSpeed):n?(0,eA.nY)(e.grokTtsSpeed):(0,eS.s)(e.audioSpeed),c=a?eS.Gp:eS.HP,u=a?eS.zL:n?eA._L:eS.Qf,m=a?"glmTtsVoice":"audioVoice",p=a?"glmTtsFormat":n?"grokTtsFormat":"audioFormat",g=a?"glmTtsSpeed":n?"grokTtsSpeed":"audioSpeed";return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(tp,{title:"声音",color:r.node.muted,children:n?(0,o.jsx)(tn.b,{config:e,model:t,value:s,onChange:e=>i("grokTtsVoice",e)}):(0,o.jsx)("div",{className:"grid grid-cols-3 gap-2.5",children:c.map(e=>(0,o.jsx)(tm,{selected:s===e.value,theme:r,onClick:()=>i(m,e.value),children:e.label},e.value))})}),n?(0,o.jsx)(tp,{title:"语言",color:r.node.muted,children:(0,o.jsx)(to.A,{className:"w-full",value:(0,eA.SF)(e.grokTtsLanguage),options:eA.H3,showSearch:!0,optionFilterProp:"label",onChange:e=>i("grokTtsLanguage",e)})}):null,(0,o.jsx)(tp,{title:"格式",color:r.node.muted,children:(0,o.jsx)("div",{className:"grid grid-cols-3 gap-2.5",children:u.map(e=>(0,o.jsx)(tm,{selected:l===e.value,theme:r,onClick:()=>i(p,e.value),children:e.label},e.value))})}),(0,o.jsxs)(tp,{title:"语速",color:r.node.muted,children:[(0,o.jsx)("div",{className:"grid grid-cols-4 gap-2.5",children:ts.map(e=>(0,o.jsx)(tm,{selected:d===e,theme:r,onClick:()=>i(g,e),children:(0,eS.cU)(e)},e))}),(0,o.jsx)("input",{type:"number",min:a?.5:n?.7:.25,max:a?2:n?1.5:4,step:.05,className:"h-9 w-full rounded-full border bg-transparent px-3 text-center text-sm outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none",style:{borderColor:r.node.stroke,color:r.node.text,WebkitTextFillColor:r.node.text},value:(a?e.glmTtsSpeed:n?e.grokTtsSpeed:e.audioSpeed)||"1",onChange:e=>i(g,e.target.value),onBlur:e=>i(g,a?(0,eS.OL)(e.target.value):n?(0,eA.nY)(e.target.value):(0,eS.s)(e.target.value)),onMouseDown:e=>e.stopPropagation()})]}),a||n?null:(0,o.jsx)(tp,{title:"声音指令",color:r.node.muted,children:(0,o.jsx)("textarea",{value:e.audioInstructions||"",placeholder:"例如：自然、温暖、适合旁白。",className:"thin-scrollbar h-20 w-full resize-none rounded-xl border bg-transparent px-3 py-2 text-sm leading-5 outline-none",style:{borderColor:r.node.stroke,color:r.node.text},onChange:e=>i("audioInstructions",e.target.value),onMouseDown:e=>e.stopPropagation()})})]})}function tm({selected:e,theme:t,onClick:a,children:n}){return(0,o.jsx)("button",{type:"button",className:"h-9 cursor-pointer rounded-full border px-2 text-sm transition hover:opacity-80",style:{background:"transparent",borderColor:e?t.node.text:t.node.stroke,color:t.node.text},onMouseDown:e=>e.stopPropagation(),onClick:a,children:n})}function tp({title:e,color:t,children:a}){return(0,o.jsxs)("div",{className:"space-y-2.5",children:[(0,o.jsx)("div",{className:"text-xs font-medium",style:{color:t},children:e}),a]})}var tg=a(60252);function th({config:e,onConfigChange:t,resourceOptions:a=[],metadata:i,onMetadataChange:r,buttonClassName:s,placement:l="topLeft"}){var d,c;let u=O.$[(0,H.C)(e=>e.theme)],m=(0,n.useRef)(null),g=(0,n.useRef)(null),[h,f]=(0,n.useState)(!1),[x,v]=(0,n.useState)(null);(0,n.useEffect)(()=>{if(!h)return;let e=()=>v(m.current?.getBoundingClientRect()||null),t=e=>{let t=e.target;!(t instanceof Node)||m.current?.contains(t)||g.current?.contains(t)||f(!1)};return e(),window.addEventListener("resize",e),window.addEventListener("scroll",e,!0),window.addEventListener("pointerdown",t,!0),()=>{window.removeEventListener("resize",e),window.removeEventListener("scroll",e,!0),window.removeEventListener("pointerdown",t,!0)}},[h]);let y=(0,n.useMemo)(()=>a.filter(e=>"audio"===e.kind),[a]),b=(d=i?.mimoVoiceCloneAudioNodeId,c=y,d&&c.some(e=>e.nodeId===d)?d:1===c.length?c[0].nodeId:""),w=h&&x?(0,o.jsx)(tf,{buttonRect:x,panelRef:g,placement:l,theme:u,config:e,onConfigChange:t,audioOptions:y,cloneAudioNodeId:b,onMetadataChange:r}):null;return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("span",{ref:m,className:"inline-flex min-w-0",children:(0,o.jsx)(ej.Ay,{size:"small",type:"text",className:s||"!h-8 !max-w-[170px] !justify-start !rounded-full !px-2.5",style:{background:u.node.fill,color:u.node.text},icon:(0,o.jsx)(p.A,{className:"size-3.5"}),onClick:()=>f(e=>!e),children:(0,o.jsx)("span",{className:"truncate",children:function(e,t,a){let o=e.model||e.audioModel||"";if((0,eM.MP)(o)&&(0,eM.Uh)(e,o))return(0,tr.sE)(e.geminiTtsVoice);if((0,eS.vI)(o))return`${(0,eS.Sn)(e.glmTtsVoice)} \xb7 ${(0,eS.C_)(e.glmTtsFormat).toUpperCase()} \xb7 ${(0,eS.OL)(e.glmTtsSpeed)}x`;if((0,eA.DW)(e,o))return`${e.grokTtsVoice||"eve"} \xb7 ${(0,eA.SF)(e.grokTtsLanguage)} \xb7 ${(0,eA.zu)(e.grokTtsFormat).toUpperCase()} \xb7 ${(0,eA.nY)(e.grokTtsSpeed)}x`;if(!(0,eI.Ht)(o))return`${(0,eS.dI)(e.audioVoice)} \xb7 ${(0,eS.W_)(e.audioFormat)} \xb7 ${(0,eS.cU)(e.audioSpeed)}`;let n=(0,eI.AN)(e.mimoTtsFormat).toUpperCase();return(0,eI.c0)(o)?`${(0,eI.qA)(e.mimoTtsVoice)} \xb7 ${n}`:(0,eI.Cb)(o)?`音色设计 \xb7 ${n}`:(0,eI.TR)(o)?`${a.find(e=>e.nodeId===t)?.label||"参考音频"} \xb7 ${n}`:n}(e,b,y)})})}),w]})}function tf({buttonRect:e,panelRef:t,placement:a,theme:n,config:i,onConfigChange:r,audioOptions:s,cloneAudioNodeId:l,onMetadataChange:d}){let c=a?.endsWith("Right"),u="top"===a||"bottom"===a?e.left+e.width/2-178:c?e.right-356:e.left,m=a?.startsWith("top"),p={position:"fixed",zIndex:1200,width:356,left:Math.max(12,Math.min(window.innerWidth-356-12,u)),...m?{bottom:window.innerHeight-e.top+8,maxHeight:Math.max(260,e.top-24)}:{top:e.bottom+8,maxHeight:Math.max(260,window.innerHeight-e.bottom-24)},background:n.toolbar.panel,borderRadius:18,boxShadow:"0 18px 54px rgba(28, 25, 23, 0.16)",padding:18,overflowY:"auto",color:n.node.text},g=i.model||i.audioModel||"";return(0,eZ.createPortal)((0,o.jsx)("div",{ref:t,className:"canvas-image-settings-popover",style:p,onPointerDown:e=>e.stopPropagation(),onMouseDown:e=>e.stopPropagation(),onClick:e=>e.stopPropagation(),children:(0,o.jsxs)("div",{className:"space-y-4",children:[(0,o.jsx)("div",{className:"text-lg font-semibold",children:"音频设置"}),(0,eI.TR)(g)?(0,o.jsx)(tg.B,{label:"参考音频",value:l,options:s,placeholder:"请选择音频节点",emptyText:s.length?"请选择已连接音频":"暂无已连接音频节点",theme:n,onChange:e=>d?.({mimoVoiceCloneAudioNodeId:e||void 0})}):null,(0,o.jsx)(tl,{config:i,onConfigChange:r,theme:n,showTitle:!1,className:"space-y-4"})]})}),document.body)}function tx({node:e,isRunning:t,inputSummary:a,videoFrameOptions:n=[],videoResourceOptions:i=[],onConfigChange:r,onGenerate:s,onComposerToggle:u}){var m,g,h,f,x;let v,y,w,k,j,C,N,I,S=(0,F.useEffectiveConfig)(),A=(0,F.useConfigStore)(e=>e.publicSettings?.modelChannel.modelCosts),M=(0,F.useConfigStore)(e=>e.openConfigDialog),_=O.$[(0,H.C)(e=>e.theme)],T=e.metadata?.generationMode||"image",z=(m=S,g=e,v="image"===(h=T)?m.imageModel:"video"===h?m.videoModel:"audio"===h?m.audioModel:m.textModel,y=g.metadata?.channelId||"",w="image"===h&&y||m.imageChannelId,k="video"===h&&y||m.videoChannelId,j="text"===h&&y||m.textChannelId,C="audio"===h&&y||m.audioChannelId,N="image"===h?w:"video"===h?k:"text"===h?j:"audio"===h&&C||m.activeChannelId,I=g.metadata?.model||v||("audio"===h?F.defaultConfig.audioModel:m.model||F.defaultConfig.model),{...m,model:I,..."video"===h?{videoModel:I}:{},..."image"===h?{imageModel:I}:{},..."audio"===h?{audioModel:I}:{},..."text"===h?{textModel:I}:{},activeChannelId:N,imageChannelId:w,videoChannelId:k,textChannelId:j,audioChannelId:C,quality:g.metadata?.quality||m.quality||F.defaultConfig.quality,size:g.metadata?.size||("video"===h?m.videoSize||F.defaultConfig.videoSize:m.size||F.defaultConfig.size),videoSeconds:g.metadata?.seconds||m.videoSeconds||F.defaultConfig.videoSeconds,vquality:g.metadata?.vquality||m.vquality||F.defaultConfig.vquality,videoMode:g.metadata?.mode||m.videoMode||F.defaultConfig.videoMode,videoNegativePrompt:g.metadata?.negativePrompt||m.videoNegativePrompt||F.defaultConfig.videoNegativePrompt,videoMultiShot:g.metadata?.multiShot||m.videoMultiShot||F.defaultConfig.videoMultiShot,videoShotType:g.metadata?.shotType||m.videoShotType||F.defaultConfig.videoShotType,videoGenerateAudio:g.metadata?.generateAudio||m.videoGenerateAudio||F.defaultConfig.videoGenerateAudio,videoCharacterOrientation:g.metadata?.characterOrientation||m.videoCharacterOrientation||F.defaultConfig.videoCharacterOrientation,videoWatermark:g.metadata?.watermark||m.videoWatermark||F.defaultConfig.videoWatermark,audioVoice:g.metadata?.audioVoice||m.audioVoice||F.defaultConfig.audioVoice,audioFormat:g.metadata?.audioFormat||m.audioFormat||F.defaultConfig.audioFormat,audioSpeed:g.metadata?.audioSpeed||m.audioSpeed||F.defaultConfig.audioSpeed,audioInstructions:g.metadata?.audioInstructions||m.audioInstructions||F.defaultConfig.audioInstructions,grokTtsVoice:g.metadata?.grokTtsVoice||m.grokTtsVoice||F.defaultConfig.grokTtsVoice,grokTtsLanguage:g.metadata?.grokTtsLanguage||m.grokTtsLanguage||F.defaultConfig.grokTtsLanguage,grokTtsFormat:g.metadata?.grokTtsFormat||m.grokTtsFormat||F.defaultConfig.grokTtsFormat,grokTtsSpeed:g.metadata?.grokTtsSpeed||m.grokTtsSpeed||F.defaultConfig.grokTtsSpeed,glmTtsVoice:g.metadata?.glmTtsVoice||m.glmTtsVoice||F.defaultConfig.glmTtsVoice,glmTtsFormat:g.metadata?.glmTtsFormat||m.glmTtsFormat||F.defaultConfig.glmTtsFormat,glmTtsSpeed:g.metadata?.glmTtsSpeed||m.glmTtsSpeed||F.defaultConfig.glmTtsSpeed,mimoTtsVoice:g.metadata?.mimoTtsVoice||m.mimoTtsVoice||F.defaultConfig.mimoTtsVoice,mimoTtsFormat:g.metadata?.mimoTtsFormat||m.mimoTtsFormat||F.defaultConfig.mimoTtsFormat,mimoVoiceDesignPrompt:g.metadata?.mimoVoiceDesignPrompt||m.mimoVoiceDesignPrompt||F.defaultConfig.mimoVoiceDesignPrompt,geminiTtsVoice:g.metadata?.geminiTtsVoice||m.geminiTtsVoice||F.defaultConfig.geminiTtsVoice,count:String(g.metadata?.count||"image"===h&&m.canvasImageCount||m.count||F.defaultConfig.count)}),P=Math.max(1,Math.min(15,Math.floor(Math.abs(Number(z.count))||1)));(0,eJ.Gd)({channelMode:z.channelMode,modelCosts:A,model:z.model,count:"image"===T?P:1,mode:T});let E={background:_.node.fill,borderColor:_.node.stroke,color:_.node.text},D=!!(a.textCount||a.imageCount||a.videoCount||a.audioCount),R=!!(e.metadata?.composerContent??e.metadata?.prompt??"").trim()||("audio"===T?a.textCount>0:D);return(0,o.jsxs)("div",{className:"flex h-full w-full cursor-move flex-col px-3 pb-3 pt-7 text-sm",style:{color:_.node.text},onWheel:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"mb-2 flex items-center justify-between gap-3",children:[(0,o.jsx)("div",{className:"shrink-0 text-sm font-semibold",children:"生成配置"}),(0,o.jsx)("div",{className:"cursor-default",onMouseDown:e=>e.stopPropagation(),children:(0,o.jsx)(eX.A,{size:"small",className:"canvas-config-mode !rounded-md !p-0.5",value:T,onChange:t=>{var a,o;return r(e.id,(a=S,"image"===(o=t)?{generationMode:o,model:a.imageModel,channelId:a.imageChannelId}:"video"===o?{generationMode:o,model:a.videoModel,channelId:a.videoChannelId}:"text"===o?{generationMode:o,model:a.textModel,channelId:a.textChannelId}:{generationMode:o,model:a.audioModel,channelId:a.audioChannelId||a.activeChannelId}))},options:[{value:"image",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1",children:[(0,o.jsx)(l.A,{className:"size-3.5"}),"生图"]})},{value:"text",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1",children:[(0,o.jsx)(eG.A,{className:"size-3.5"}),"文本"]})},{value:"video",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1",children:[(0,o.jsx)(d.A,{className:"size-3.5"}),"视频"]})},{value:"audio",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1",children:[(0,o.jsx)(c.A,{className:"size-3.5"}),"音频"]})}]})})]}),(0,o.jsxs)("div",{className:"mb-2 flex flex-wrap gap-1.5",children:[(0,o.jsx)(tv,{label:"提示词",value:`${a.textCount} 个`,style:E}),(0,o.jsx)(tv,{label:"参考图",value:`${a.imageCount} 张`,style:E}),(0,o.jsx)(tv,{label:"参考视频",value:`${a.videoCount} 个`,style:E}),(0,o.jsx)(tv,{label:"参考音频",value:`${a.audioCount} 个`,style:E}),(0,o.jsxs)("button",{type:"button",className:"inline-flex h-7 cursor-pointer items-center gap-1 rounded-md border px-2 text-[11px]",style:E,onMouseDown:e=>e.stopPropagation(),onClick:u,children:[(0,o.jsx)(p.A,{className:"size-3.5"}),"组装提示词"]})]}),(0,o.jsxs)("div",{className:`mb-2 grid min-w-0 cursor-default items-center gap-2 ${"image"===T||"video"===T?"grid-cols-[minmax(0,1fr)_148px_92px]":"audio"===T?"grid-cols-[minmax(0,1fr)_148px]":"grid-cols-1"}`,onMouseDown:e=>e.stopPropagation(),children:[(0,o.jsx)(eY.Y,{className:"canvas-compact-control h-10",config:z,value:z.model,channelId:(f=z,"image"===(x=T)?f.imageChannelId:"video"===x?f.videoChannelId:"text"===x?f.textChannelId:f.audioChannelId||f.activeChannelId),onChange:(t,a)=>r(e.id,{model:t,channelId:a}),capability:T,onMissingConfig:()=>M(!0),fullWidth:!0}),"video"===T?(0,o.jsx)(tg.Y,{config:z,placement:"topRight",buttonClassName:"canvas-compact-control !h-10 !w-full !justify-start !rounded-lg !px-2",frameOptions:n,resourceOptions:i,metadata:e.metadata,firstFrameNodeId:e.metadata?.firstFrameNodeId,lastFrameNodeId:e.metadata?.lastFrameNodeId,onFrameChange:t=>r(e.id,t),onMetadataChange:t=>r(e.id,t),onConfigChange:(t,a)=>{var o,n;return r(e.id,(o=t,n=a,"videoSeconds"===o?{seconds:n}:"videoMode"===o?{mode:n}:"videoNegativePrompt"===o?{negativePrompt:n}:"videoMultiShot"===o?{multiShot:n}:"videoShotType"===o?{shotType:n}:"videoGenerateAudio"===o?{generateAudio:n}:"videoCharacterOrientation"===o?{characterOrientation:n}:"videoWatermark"===o?{watermark:n}:{[o]:n}))}}):"image"===T?(0,o.jsx)(eQ.o,{config:z,placement:"topRight",autoAdjustOverflow:!1,buttonClassName:"canvas-compact-control !h-10 !w-full !justify-start !rounded-lg !px-2",onConfigChange:(t,a)=>r(e.id,"count"===t?{count:Number(a)||1}:{[t]:a})}):"audio"===T?(0,o.jsx)(th,{config:z,resourceOptions:i,metadata:e.metadata,onMetadataChange:t=>r(e.id,t),placement:"topRight",buttonClassName:"canvas-compact-control !h-10 !w-full !justify-start !rounded-lg !px-2",onConfigChange:(t,a)=>r(e.id,{[t]:a})}):null,"image"===T||"video"===T?(0,o.jsx)(e7,{value:e.metadata?.cameraControl,onChange:t=>r(e.id,{cameraControl:t}),buttonClassName:"canvas-compact-control !h-10 !w-full !justify-start !rounded-lg !px-2"}):null]}),(0,o.jsx)(ej.Ay,{type:"primary",className:"mt-auto !h-9 !w-full !cursor-pointer !rounded-lg",disabled:t||!R,onMouseDown:e=>e.stopPropagation(),onClick:()=>s(e.id),children:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1.5 font-medium",children:[(0,o.jsxs)("span",{className:"inline-flex items-center gap-1 rounded bg-black/15 px-1.5 py-0.5 text-xs font-semibold dark:bg-white/15",children:[(0,o.jsx)(eJ.kz,{}),(0,o.jsx)("span",{children:(0,eJ._f)({model:z.model,mode:T,count:P,seconds:z.videoSeconds,resolution:z.vquality||z.size,modelCosts:A})})]}),t?(0,o.jsx)(eH.A,{className:"size-4 animate-spin"}):(0,o.jsx)(b.A,{className:"size-4"}),(0,o.jsx)("span",{children:"开始生成"})]})})]})}function tv({label:e,value:t,style:a}){return(0,o.jsxs)("div",{className:"inline-flex h-7 items-center gap-1 rounded-md border px-2 text-[11px]",style:a,children:[(0,o.jsx)("span",{children:e}),(0,o.jsx)("span",{className:"font-medium",children:t})]})}function ty({nodeId:e,project:t,panoramas:a,theme:i,onClose:r,onProjectChange:s,onPanoramaRemoved:l,onCapturesSent:d,onVideoSent:c}){let u=(0,n.useRef)(null),m=(0,n.useRef)(t),p=(0,n.useRef)(i),g=(0,n.useRef)(!1),[h,f]=(0,n.useState)(!1);(0,n.useEffect)(()=>{m.current=t},[t]),(0,n.useEffect)(()=>{p.current=i},[i]);let x=(0,n.useCallback)((e,t)=>{u.current?.contentWindow?.postMessage({type:e,payload:t},window.location.origin)},[]);return(0,n.useEffect)(()=>{function t(t){if(t.origin!==window.location.origin||t.source!==u.current?.contentWindow)return;let a=t.data?.type;if("storyai:director-ready"===a)return void f(!0);if("storyai:director-close"===a)return void r();if("storyai:director-project-changed"===a){let e=t.data?.payload?.project;e&&"object"==typeof e&&!Array.isArray(e)&&s(e);return}if("storyai:director-panorama-removed"===a){let e="string"==typeof t.data?.payload?.edgeId?t.data.payload.edgeId.trim():"",a="string"==typeof t.data?.payload?.sourceNodeId?t.data.payload.sourceNodeId.trim():"";e&&a&&l({edgeId:e,sourceNodeId:a});return}if("storyai:director-captures-sent"===a){let a=Array.isArray(t.data?.payload?.captures)?t.data.payload.captures.filter(e=>"string"==typeof e?.dataUrl&&e.dataUrl.startsWith("data:image/")).map((e,t)=>({dataUrl:e.dataUrl,fileName:"string"==typeof e.fileName&&e.fileName.trim()?e.fileName.trim():"导演台截图-"+(t+1)+".png"})):[];a.length&&d(e,a);return}if("storyai:director-video-sent"===a){let a=t.data?.payload?.blob;if(!(a instanceof Blob)||!a.size||!a.type.startsWith("video/mp4"))return;let o="string"==typeof t.data?.payload?.fileName&&t.data.payload.fileName.trim()?t.data.payload.fileName.trim():"导演台视频.mp4",n=Number(t.data?.payload?.width),i=Number(t.data?.payload?.height),r=Number(t.data?.payload?.durationSeconds);c(e,{blob:a,fileName:o,width:Number.isFinite(n)&&n>0?n:1280,height:Number.isFinite(i)&&i>0?i:720,durationSeconds:Number.isFinite(r)?r:0});return}}return window.addEventListener("message",t),()=>window.removeEventListener("message",t)},[e,d,r,l,s,c]),(0,n.useEffect)(()=>{h&&!g.current&&(g.current=!0,x("storyai:director-session",{instanceId:e,theme:p.current,project:m.current}))},[e,x,h]),(0,n.useEffect)(()=>{h&&g.current&&x("storyai:director-panoramas",{panoramas:a})},[a,x,h]),(0,o.jsx)("div",{className:"fixed inset-0 z-[2000]",children:(0,o.jsx)("iframe",{ref:u,title:"3D导演台",src:"/director/index.html",className:"block h-full w-full border-0"})})}function tb({onOpen:e}){let t=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsxs)("div",{className:"flex h-full w-full flex-col items-center justify-center gap-6 px-8 text-center",style:{color:t.node.text},children:[(0,o.jsx)(m.A,{className:"size-11",strokeWidth:1.8,style:{color:t.node.muted}}),(0,o.jsx)("p",{className:"m-0 text-[17px] font-medium leading-7",style:{color:t.node.placeholder},children:"在3D空间中搭建场景并进行多视角截图"}),(0,o.jsx)("button",{type:"button",className:"rounded-xl border px-6 py-2 text-lg font-medium transition",style:{background:t.toolbar.itemHover,borderColor:t.node.stroke,color:t.node.text},onMouseDown:e=>e.stopPropagation(),onClick:t=>{t.stopPropagation(),e()},children:"打开导演台"})]})}var tw=a(54264),tk=a(91988),tj=a(57251),tC=a(6501),tN=a(37985),tI=a(96505),tS=a(50328),tA=a(86084),tM=a(93446);let t_=["正在创建图片","马上就好了","再等等","正在整理细节"];function tT({className:e,label:t,compact:a=!1}){let[i,r]=(0,n.useState)(0);(0,n.useEffect)(()=>{let e=window.setInterval(()=>r(e=>e+1),1e3);return()=>window.clearInterval(e)},[]);let s=Math.floor(i/2)%t_.length,l=Math.min(98,10+(1-Math.exp(-i/28))*88);return(0,o.jsxs)("div",{className:(0,tM.cn)("relative overflow-hidden bg-stone-100 dark:bg-white/10",a?"min-h-24":"aspect-[4/3]",e),children:[(0,o.jsx)("div",{className:"absolute inset-0 opacity-60",style:{backgroundImage:"radial-gradient(circle, rgba(120,113,108,0.35) 1.4px, transparent 1.6px)",backgroundSize:"16px 16px",maskImage:"radial-gradient(ellipse at 38% 68%, black 0%, black 28%, transparent 60%)"}}),(0,o.jsxs)("div",{className:"absolute left-4 top-4 flex items-center gap-2 text-[15px] font-medium text-stone-500 dark:text-stone-300",children:[(0,o.jsx)(eH.A,{className:"size-4 animate-spin"}),(0,o.jsx)("span",{children:t||t_[s]})]}),(0,o.jsxs)("div",{className:"absolute bottom-4 left-4 right-4",children:[(0,o.jsxs)("div",{className:"mb-2 flex items-center justify-between text-xs text-stone-500 dark:text-stone-400",children:[(0,o.jsx)("span",{children:(0,W.a3)(1e3*i)}),(0,o.jsxs)("span",{children:[Math.floor(l),"%"]})]}),(0,o.jsx)("div",{className:"h-1.5 rounded-full bg-stone-300/70 dark:bg-white/12",children:(0,o.jsx)("div",{className:"h-full rounded-full bg-stone-900 dark:bg-stone-100",style:{width:`${l}%`}})})]})]})}var tz=a(66629),tP=a(85173),tE=a(78771);let tD=new Map,tR=new TextEncoder;function t$(e,t,a){if(!a||a<=0)return;let o=tV(t);if(!o)return;let n=Math.min(4,Math.max(1.08,a/o*1.08));tD.set(e,Math.max(tD.get(e)||0,n))}function tL(e){return e.reduce((e,t)=>{var a;return e+("assistant"===(a=t).role?a.responseItems?.length?tU(JSON.stringify(a.responseItems))+8:tU(a.content||"")+tU(a.reasoningContent||"")+tU(JSON.stringify(a.toolCalls||[]))+8:"tool"===a.role?tU(a.name)+tU(a.content)+8:tU(tK(a.content))+("string"==typeof a.content?8:1024*a.content.filter(e=>"image_url"===e.type).length+8))},0)}async function tF(e){var t;let a,o,n,i,r,{fixedMessages:s,completedRounds:l,unfinishedRound:d}=(t=e.protocolMessages,a=[],o=[],n=[],t.forEach(e=>{var t;"user"!==(t=e).role||tK(t.content).startsWith("工具执行结果（只可依据这些真实结果继续）：")?n.length?n.push(e):a.push(e):(n.length&&o.push(n),n=[e])}),n.length&&o.push(n),i=[],r=[],o.forEach((e,t)=>{e.some((t,a)=>{let o;return"assistant"===t.role&&!t.toolCalls?.length&&(o=e[a+1],!(o?.role==="user"&&tK(o.content).startsWith("工具执行结果（只可依据这些真实结果继续）：")))})||t<o.length-1?i.push(e):r=e}),{fixedMessages:a,completedRounds:i,unfinishedRound:r}),c=[],u=[],m=0;for(let e=l.length-1;e>=0;e-=1){let t=l[e],a=tL(t);m+a<=64e3?(c.unshift(t),m+=a):u.unshift(t)}let p=u.flat();if(!p.length)return{compacted:!1,contextCheckpoint:e.contextCheckpoint,protocolMessages:e.protocolMessages};let g=await e.createCheckpoint(e.contextCheckpoint,p);return(g.trim()||(g=await e.createCheckpoint(e.contextCheckpoint,p)),g.trim())?{compacted:!0,contextCheckpoint:function(e){if(16e3>=tU(e))return e;let t=0,a=e.length;for(;t<a;){let o=Math.ceil((t+a)/2);16e3>=tU(e.slice(0,o))?t=o:a=o-1}return e.slice(0,t).replace(/[\uD800-\uDBFF]$/,"")}(g.trim()),protocolMessages:[...s,...c.flat(),...d]}:{compacted:!1,contextCheckpoint:e.contextCheckpoint,protocolMessages:e.protocolMessages}}function tV(e){return tU(e.systemPrompt)+tU(JSON.stringify(e.tools))+tL(e.messages)+6*e.messages.length+10*e.tools.length}function tU(e){return e?Math.ceil(tR.encode(e).length/3):0}function tK(e){return"string"==typeof e?e:e.map(e=>"text"===e.type?e.text:"[媒体引用]").join("\n")}class tW extends Error{constructor(e,t,a){super(e),this.name="CanvasAgentRequestError",this.status=t,this.code=a}}async function tO(e){let t,a={...e.config,model:e.config.textModel||e.config.model,activeChannelId:e.config.textChannelId||e.config.activeChannelId,textChannelId:e.config.textChannelId},o=tB(a,e.systemPrompt),n=e.messages,i=e.allowTools?e.tools:[],r=!e.allowTools;for(let d=0;d<3;d++)try{return{...await tG(a,o,n,i,e.signal),usedJsonFallback:r}}catch(e){var s,l;if(t=e,t5(e))throw e;if(n.some(e=>("user"===e.role||"system"===e.role)&&Array.isArray(e.content)&&e.content.some(e=>"image_url"===e.type))&&(s=e)instanceof tW&&/image_url|image input|vision|multimodal|content.*array|unsupported.*image|不支持.*图片|图像输入/i.test(s.message)){n=n.map(e=>("user"===e.role||"system"===e.role)&&Array.isArray(e.content)?{role:e.role,content:e.content.filter(e=>"text"===e.type)}:e);continue}if("responses"!==a.apiMode&&i.length&&(l=e)instanceof tW&&(400===l.status||422===l.status||/tools?|tool_choice|function.?call|unknown field|unsupported|not support|不支持|未知字段/i.test(l.message))){i=[],r=!0;continue}throw e}throw t}function tB(e,t){let a=(e.systemPrompts.text||e.systemPrompt).trim();return a?a+"\n\n"+t:t}async function tq(e){return(await tO({config:e.config,systemPrompt:"你负责生成画布 Agent 的长期对话检查点。仅保留用户长期目标与偏好、已确认方案、不可改变要求、否决方向、未解决事项、重要节点 ID 的职责线索，以及当前 Skill 和阶段线索。节点是否存在、节点正文、任务状态必须以之后注入的真实画布和工具结果为准；不得声称工具或媒体已成功，不得保存 Base64。直接输出检查点正文，控制在 16000 Token 以内。",messages:[{role:"user",content:`【旧检查点】
${e.previousCheckpoint||"无"}

【本次归档的完整旧轮次】
${JSON.stringify(e.messages)}`}],tools:[],allowTools:!1,signal:e.signal})).content.trim()}async function tG(e,t,a,o,n){if("responses"===e.apiMode)return tH(e,t,a,o,n);if((0,eM.Uh)(e))return tX(e,t,a,o,n);let i={model:e.model,messages:[{role:"system",content:t},...a.map(tY)],stream:!1};o.length&&(i.tools=o,i.tool_choice="auto");let r=await fetch((0,R.gE)(e,"/chat/completions"),{method:"POST",headers:(0,R.HQ)(e,"application/json"),body:JSON.stringify(i),signal:n}),{payload:s,rawText:l}=await t1(r),d=s.choices?.[0]?.message||s.data?.choices?.[0]?.message;if(!r.ok||"number"==typeof s.code&&0!==s.code||"string"==typeof s.code&&"0"!==s.code&&!d)throw new tW(tZ(s,r.status,l),r.status,t0(s));if(!d)throw new tW(tZ(s,r.status)||"文本模型没有返回内容",r.status);let c=e.model.trim().toLowerCase(),u=(c.startsWith("glm-")||eI.gq.some(e=>e===c))&&"string"==typeof d.reasoning_content?d.reasoning_content:void 0,m=s.usage?.prompt_tokens||s.data?.usage?.prompt_tokens;return t$(t2(e),{systemPrompt:t,messages:a,tools:o},m),(0,R.XL)(e),{content:"string"==typeof d.content?d.content:"",...void 0!==u?{reasoningContent:u}:{},toolCalls:(d.tool_calls||[]).flatMap((e,t)=>{let a=e.function?.name?.trim();return a?[{id:e.id||"tool-call-"+t,name:a,arguments:tQ(e.function?.arguments)}]:[]})}}async function tH(e,t,a,o,n){let i={model:e.model,instructions:t,input:a.flatMap(tJ),store:!1,include:["reasoning.encrypted_content"]};o.length&&(i.tools=o.map(e=>({type:"function",...e.function})),i.tool_choice="auto");let r=await fetch((0,R.gE)(e,"/responses"),{method:"POST",headers:(0,R.HQ)(e,"application/json"),body:JSON.stringify(i),signal:n}),{payload:s,rawText:l}=await t1(r),d=s.output?s:s.data;if(!r.ok||"number"==typeof s.code&&0!==s.code||"string"==typeof s.code&&"0"!==s.code&&!d)throw new tW(tZ(s,r.status,l),r.status,t0(s));if(!d)throw new tW(tZ(s,r.status)||"文本模型没有返回内容",r.status);let c=d.output||[],u=d.usage?.input_tokens;return t$(t2(e),{systemPrompt:t,messages:a,tools:o},u),(0,R.XL)(e),{content:"string"==typeof d.output_text?d.output_text:c.flatMap(e=>"message"===e.type&&e.content||[]).map(e=>"output_text"===e.type&&"string"==typeof e.text?e.text:"").join(""),responseItems:c,toolCalls:c.flatMap((e,t)=>"function_call"===e.type&&"string"==typeof e.name?[{id:e.call_id||e.id||`response-tool-${t}`,name:e.name,arguments:tQ(e.arguments)}]:[])}}async function tX(e,t,a,o,n){let i=await Promise.all(a.filter(e=>"system"!==e.role).map(async e=>"assistant"===e.role?{role:"model",parts:[...e.content?[{text:e.content}]:[],...(e.toolCalls||[]).map(e=>({functionCall:{name:e.name,args:e.arguments}}))]}:"tool"===e.role?{role:"user",parts:[{functionResponse:{name:e.name,response:function(e){try{let t=JSON.parse(e);return t&&"object"==typeof t?t:{result:t}}catch{return{result:e}}}(e.content)}}]}:{role:"user",parts:await Promise.all(("string"==typeof e.content?[{type:"text",text:e.content}]:e.content).map(async e=>"text"===e.type?{text:e.text}:(0,eM.FQ)(await (0,V.imageToDataUrl)({dataUrl:e.image_url.url,url:e.image_url.url}))))})),r=a.flatMap(e=>"system"!==e.role?[]:"string"==typeof e.content?[{text:e.content}]:e.content.flatMap(e=>"text"===e.type?[{text:e.text}]:[])),s={model:e.model,stream:!1,systemInstruction:{parts:[{text:t},...r]},contents:i,...o.length?{tools:[{functionDeclarations:o.map(e=>e.function)}]}:{}},l=!!(0,R.gE)(e,"/chat/completions").startsWith("/api/"),d=(0,F.localChannelForActiveModel)(e),{model:c,stream:u,...m}=s,p=await fetch(l?(0,R.gE)(e,"/chat/completions"):(0,eM.Bk)(d?.baseUrl||e.baseUrl,e.model,"generateContent"),{method:"POST",headers:l?(0,R.HQ)(e,"application/json"):(0,eM.Lq)(e),body:JSON.stringify(l?s:m),signal:n}),{payload:g,rawText:h}=await t1(p);if(!p.ok){var f;let e;throw new tW((0,eM.lJ)(g,h||"文本模型请求失败"),p.status,"string"==typeof(e=(f=g).error&&"object"==typeof f.error?f.error:{}).code?e.code:"string"==typeof e.status?e.status:void 0)}let x=(Array.isArray(g.candidates)?g.candidates:[]).flatMap(e=>{let t=e.content&&"object"==typeof e.content?e.content:{};return Array.isArray(t.parts)?t.parts:[]});if(!x.length)throw new tW((0,eM.lJ)(g,"文本模型没有返回内容"),p.status);let v=g.usageMetadata&&"object"==typeof g.usageMetadata?g.usageMetadata:{},y="number"==typeof v.promptTokenCount?v.promptTokenCount:void 0;return t$(t2(e),{systemPrompt:t,messages:a,tools:o},y),(0,R.XL)(e),{content:x.map(e=>"string"==typeof e.text?e.text:"").join(""),toolCalls:x.flatMap((e,t)=>{let a=e.functionCall&&"object"==typeof e.functionCall?e.functionCall:null,o="string"==typeof a?.name?a.name.trim():"";return o?[{id:`gemini-tool-${t}`,name:o,arguments:a?.args&&"object"==typeof a.args?a.args:{}}]:[]})}}function tY(e){return"assistant"===e.role?{role:"assistant",content:e.content||null,...void 0!==e.reasoningContent?{reasoning_content:e.reasoningContent}:{},...e.toolCalls?.length?{tool_calls:e.toolCalls.map(e=>({id:e.id,type:"function",function:{name:e.name,arguments:JSON.stringify(e.arguments)}}))}:{}}:"tool"===e.role?{role:"tool",content:e.content,tool_call_id:e.toolCallId,name:e.name}:{role:e.role,content:e.content}}function tJ(e){return"assistant"===e.role?e.responseItems?.length?e.responseItems:[...e.content?[{role:"assistant",content:e.content}]:[],...(e.toolCalls||[]).map(e=>({type:"function_call",call_id:e.id,name:e.name,arguments:JSON.stringify(e.arguments)}))]:"tool"===e.role?[{type:"function_call_output",call_id:e.toolCallId,output:e.content}]:[{role:e.role,content:"string"==typeof e.content?e.content:e.content.map(e=>"text"===e.type?{type:"input_text",text:e.text}:{type:"input_image",image_url:e.image_url.url})}]}function tQ(e){if(!e)return{};if("object"==typeof e)return e;try{let t=JSON.parse(e);return t&&"object"==typeof t&&!Array.isArray(t)?t:{}}catch{return{}}}function tZ(e,t,a=""){return e.error?.message||e.msg||a||(t?"文本模型请求失败："+t:"文本模型请求失败")}function t0(e){return e.error?.code||e.error?.type||("string"==typeof e.code?e.code:void 0)}async function t1(e){let t=await e.text();try{return{payload:t?JSON.parse(t):{},rawText:t}}catch{return{payload:{},rawText:t}}}function t2(e){return`${e.apiMode}:${(0,eM.Uh)(e)?"gemini":"openai"}:${e.baseUrl}:${e.model}`}function t5(e){return e instanceof tW&&/context_length_exceeded|maximum context|context window|prompt too long|token limit|上下文长度|上下文超限|输入过长/i.test(`${e.code||""} ${e.message}`)}function t4(e){let t=e.metadata?.content||"",a=e.type===ev.p.Text,o=a||!t||t.startsWith("data:")?void 0:t;return{id:e.id,type:e.type,title:e.title,text:a&&t?t.slice(0,4e3):void 0,mediaUrl:o,hasMedia:a?void 0:!!t,status:e.metadata?.status,prompt:e.metadata?.prompt?.slice(0,4e3),model:e.metadata?.model,size:e.metadata?.size,seconds:e.metadata?.seconds,generateAudio:e.metadata?.generateAudio,taskId:t3(e)||void 0,error:e.metadata?.errorDetails,groupId:e.metadata?.groupId}}function t3(e){return e.type===ev.p.Video?e.metadata?.videoTaskId||"":e.type===ev.p.Audio?e.metadata?.audioTaskId||"":(e.type===ev.p.Image||e.type===ev.p.Panorama)&&e.metadata?.imageTaskId||""}let t6=String.raw`
【声音 Skill｜角色音色、旁白音色与独立最终朗读】

## 1. 边界

本 Skill 只创建独立 audio 节点：

- 角色可复用音色样本。
- 旁白/VO 可复用音色样本。
- 用户明确需要的最终独立对白。
- 用户明确需要的最终独立旁白/VO。
- 需要下载、复用或作为后续视频音频参考的声音。

视频生成阶段的对白、环境声、动作音效和音乐，如果由视频模型直接写进 MP4 音轨，属于 generate_video.generateAudio，不在这里创建额外音频节点。

两个判断互相独立：

- 已有角色音色，不代表某个视频必然启用原生声音。
- 视频已经带声音，也不代表已经拥有可复用的角色音色或独立最终对白节点。

## 2. generate_audio 字段契约

- prompt：音频模型实际朗读的文字，是最终语音正文。
- instructions：声音设计与演绎说明，包括年龄、性别表达、音色、音域、语速、节奏、口音、情绪、停顿、力度和距离感。
- voice：默认读取全局 audioVoice；只有用户明确指定本次 voice 时才覆盖。
- sourceNodeIds：角色图片/设定、剧本、镜头、声音设计文本或其他真实作者来源，并建立连线。
- title：清楚区分“音色样本”和“最终对白/旁白”。

硬规则：

- 不把音色说明塞进 prompt 让模型朗读。
- 不把需要朗读的正文只放进 instructions。
- 用户已确认的最终对白/旁白逐字复制，不翻译、不润色、不删减、不增加称呼。
- 音频提示词不负责人物外观；外观由角色/文本来源提供语境。

## 3. 模式 1：角色可复用音色样本

触发：

- “给这个角色设计声音。”
- “听听他/她会怎么说话。”
- “为所有说话角色做音色。”
- 剧本拆解需要为每个 speaker 建立声音锚点。

目标来源：

- 优先使用真实角色四视图、角色图片或角色设定文本。
- 任何成功 image 节点都可以提供角色语境；根据真实节点内容、标题、提示词和来源判断角色。
- 角色来自剧本时，同时连接剧本或对应角色设定文本。

instructions 写声音本身：

“[年龄段] [性别表达]，[音色与质感]，[音域]，[语速与节奏]，[口音/地域特征]。[情绪底色、呼吸、力度或发声状态]。”

正确：

- “50 岁左右男性，低沉有颗粒感的男中音，语速克制，轻微沙哑，疲惫但稳定。”
- “年轻女性，明亮温暖的女中音，语速偏快、咬字有弹性，轻微南方口音，亲近但不甜腻。”

错误：

- “侦探莫里斯的声音。”——只有名字，没有可生成的声音属性。
- “很有电影感的声音。”——没有音色、音域和节奏。

prompt：

- 使用 1–3 句符合角色身份的短样本，建议不超过约 200 个中文字符。
- 样本用于暴露音色、节奏和情绪，不是把整个剧本全部念完。
- 保留角色语言和说话习惯，但不要擅自把样本文字当成后续镜头正式台词。

执行：

- 每个角色一个独立 generate_audio。
- title：“角色音色｜角色名”。
- sourceNodeIds 连接角色参考与剧本/角色设定。
- 多个互不依赖的角色音色可以同一纯媒体轮并行生成。

## 4. 模式 2：旁白/VO 可复用音色样本

触发：先确定旁白人格、品牌 VO、纪录片讲述者或匿名 narrator 声音。

- prompt 使用一小段代表性样本，不默认朗读完整旁白。
- instructions 描述可信度、年龄感、音色、速度、节奏、距离感、情绪、停顿和品牌气质。
- title：“旁白音色｜项目名”或“VO 音色｜名称”。
- sourceNodeIds 连接剧本、宣传片 Brief 或旁白需求文本。
- 旁白不是角色时不强行连接无关角色图片。

## 5. 模式 3：最终独立对白

触发：用户明确要求独立对白成品、下载复用、后期使用或作为后续视频最终音频参考。

- prompt 逐字复制已确认对白。
- instructions 只描述说话方式和表演，不改正文。
- title：“最终对白｜角色名｜镜头 01”。
- sourceNodeIds 连接角色、剧本和对应镜头。
- 一段音频默认只属于一个说话人；多角色对话分别生成，除非当前音频模型和用户明确要求单文件多人表演。

后续视频使用：

“使用音频N的文字、节奏、语气和音色，台词保持不变。”

此时音频节点 prompt 是最终文字事实源。

## 6. 模式 4：最终独立旁白/VO

- prompt 逐字复制用户确认的旁白全文或当前片段。
- 内容过长时按自然段和后续镜头用途拆成多个音频节点，不在句中任意切断。
- instructions 只控制音色、节奏、停顿、情绪和距离感。
- title：“最终旁白｜段落名”或“最终 VO｜镜头 01”。
- sourceNodeIds 连接正式剧本和对应镜头/段落。

## 7. 剧本批量声音规划

- 每个说话角色一个可复用音色样本。
- 有旁白/VO 时，一个独立 narrator 音色样本。
- 不默认把剧本每句对白都生成独立音频；具体视频台词可以由视频原生声音按文字生成。
- 只有用户需要独立后期资产、精确朗读、下载复用或音频参考时，才生成最终对白/旁白。
- 角色基础音色之间可以并行；最终朗读依赖已确认文本和声音选择时必须等待确认。

## 8. 结果与下游解释

成功后：

- 使用工具返回的真实 audio nodeId。
- 音色样本可写入 set_agent_state.referenceNodeIds，供后续视频使用。
- loading 音频不能立即提交依赖它的视频。
- 区分节点职责：音色样本只锚定 timbre；最终朗读同时锚定文字、时序、语气和声音。
- 视频提示词绑定说话人与音频编号，不能让 A 角色使用 B 音色。

## 9. 失败与修正

- 模型未配置：提示用户完成全局音频模型配置。
- 音色不符合：保持 prompt 正文，具体调整 instructions 的音色、音域、语速、口音、情绪或停顿。
- 朗读内容错误：检查 prompt 是否逐字正确；不要用 instructions 补正文。
- 多角色混在一起：拆为每个角色一个音频节点。
- 模型/接口不支持期望控制：如实说明限制，保留声音设计文本，不声称生成成功。
- 不自动无限重试；保留失败节点供用户查看。

完成后只推荐：审核当前音色、制作下一个缺失说话人、生成匹配对白/旁白，或把成功音频用于对应视频。
`.trim(),t8=String.raw`
【画布创作 Agent 公共执行手册】

## 1. 身份、语气与工作目标

- 你是当前网页画布里的影视创作合作者，同时承担创意策划、编剧、导演、摄影、剪辑思维和画布执行。
- 像在片场与用户协作：回复具体、短、能执行。用户没有要求展开时，普通回复尽量控制在约 120 个中文字符或一个短段落内。
- 用户描述想制作的内容时，先提出 3–5 个叙事节拍或创作方向，等待用户意见后再扩写；不要在方向未确认时一次预制整部作品的所有分镜和媒体。
- 用户已给出完整剧本、明确镜头或明确生成命令时，直接从真实起点继续，不强迫重走创意阶段。
- 只汇报画布中真实发生的操作和真实结果；普通文字回复不等于创建节点、连线、分组或生成媒体。

## 2. 唯一事实来源

事实来源按可靠性排序：

1. 当前工具刚返回的真实结果，包括 nodeId、connectionId、groupId、taskId、status、code 和 message。
2. 当前系统提示词附带的真实画布上下文，包括 nodes、connections、selectedNodeIds、agentState、generation 和 tasks。
3. 读取工具获得的最新节点、上下游、任务和全局配置。
4. 当前会话已确认的计划、正式参考和用户明确引用。

硬规则：

- 只能使用真实存在的节点 ID、连线 ID、任务 ID、分组 ID 和模型配置。
- 不得虚构节点已经创建、媒体已经生成、任务已经完成或连线已经存在。
- 每个写工具执行后，只使用工具返回的真实 ID 继续；下一步依赖最新状态时重新读取，不长期依赖旧快照。
- 媒体节点处于 loading 时，只能说明任务已提交，不能把它当成可用成品或后续正式参考。
- error、failed、取消或找不到的结果不推进创作阶段。
- 用户刷新页面后，从 agentState、真实节点和任务状态恢复；不得重复提交已有 taskId 的任务。

## 3. Skill 路由

按用户意图和当前阶段加载并遵循对应规则：

- 故事、概念、剧本、宣传片、多镜头成片或“下一步做什么”：总创作流程优先。
- 写作、改写、捕获、拆镜头、角色/产品/场景/声音提取：剧情与剧本 Skill。
- 角色、产品、地点、图片编辑、变体、关键帧、分镜和其他视觉锚点：图片 Skill。
- 视频角色一致性设定：视频角色四视图参考规则。
- 分镜拼图：分镜拼图参考规则。
- 文生视频、图生视频、视频参考、声音参考、广告/MV/多镜头：视频 Skill，再按意图加载单镜头或多镜头规则。
- 视频续写、前传或连续链：视频续写规则。
- 视频重绘、局部修改、替换或动作改写：视频编辑规则。
- 角色音色、独立对白、旁白和最终朗读：声音 Skill。
- 场景组、角色/产品参考集、章节和语义整理：分组整理 Skill。

当前 Skill 负责创作规则与工具策略；真正执行只允许调用系统提供的白名单工具。

## 4. 上下文选择

使用成本最低但可靠的上下文：

- 用户说“这个、选中的、刚才那个”时，优先 get_selected_nodes；只有一个明确选中节点时直接使用。
- 用户说“它的来源、上一步、基于什么”时，使用 get_upstream_nodes。
- 用户说“由它生成了什么、后续结果”时，使用 get_downstream_nodes。
- 用户说“相关内容、上下游”时，使用 get_connected_nodes。
- 用户给出明确节点 ID 时，使用 get_node。
- 默认上下文中没有目标节点且不知道其 ID 时，先用 query_canvas_nodes 按 ID、标题、正文、提示词或类型查找，再用 get_node 读取命中节点详情。
- 用户问当前画布、已有内容或整体进度时，使用 get_canvas_summary。
- 用户问模型、比例、图片尺寸、视频尺寸、时长、声音或模型能力时，使用 get_generation_config。
- 用户问生成进度或准备依赖某媒体时，使用 get_media_task_status 或 get_generation_task。
- 当前上下文已经完整且没有歧义时，不为形式重复调用读取工具。
- 不要只看标题猜测图片、视频或音频内容。图片确实需要视觉判断且本轮提供了可视引用时再依赖视觉输入；否则使用节点元数据、提示词和连线关系。
- 不把全部媒体 Base64 或大体积内容写入对话或节点。

## 5. 引用、直接来源、连线与分组

每个媒体工具都必须明确提供 sourceNodeIds：

- 存在真实直接来源时，传对应真实 nodeId。
- 完全独立生成时，明确传空数组 []。
- 不得省略字段并依赖画布当前选中状态。
- sourceNodeIds 只表达本次生成真正使用的直接来源，不是“所有属于同一项目的节点”。

sourceNodeIds 同时承担两件事：

1. 建立直接来源节点到新节点的真实连线。
2. 决定生成请求中媒体参考的顺序。

连线和分组必须分开：

- 连线表示真实直接生产依赖或派生关系，例如剧本拆出镜头、镜头产生分镜、图片用于视频、原图产生编辑图、原视频产生续写。
- group 表示同属一个角色、产品、场景、章节或参考资产集合，不参与生成参数传递。
- 同一画布已经表示同属当前项目，不得为了表示项目归属把所有媒体连接总剧本。
- 一批平级产品/角色/场景参考不得按生成顺序串成链；只有后一项真实使用前一项作为编辑、续写或参考输入时才连接。
- 使用最近的直接来源：制作稿连接镜头，镜头连接对应分镜/视频；已有镜头节点时，不再把每个结果重复连接所有祖先节点。
- 产品多角度、角色参考集和场景参考集优先使用现有 create_group 表达归属，后续哪张参考真实用于媒体生成，再连接该参考到结果节点。

编号规则：

- 文本节点不占媒体编号。
- sourceNodeIds 中第一张图片为“图片1”，第二张为“图片2”，依次编号。
- 第一段视频为“视频1”，第二段为“视频2”。
- 第一段音频为“音频1”，第二段为“音频2”。
- 三种媒体分别从 1 开始编号，不共用序号。
- 提示词出现任何“图片N、视频N、音频N”时，sourceNodeIds 中必须有对应类型和序号的真实节点。
- 明确说明每个参考的职责：角色身份、产品外观、场景、构图、起始画面、结束落点、动作、运镜、续写来源、最终朗读或音色样本。
- 不附加无关选中节点，不用“参考这些素材”代替逐项绑定。
- 多步真实派生保持直接链条：A 生成 B、B 再生成 C 时，C 连接 B；平级独立结果不互连。

## 6. 当前工具与节点语法

读取工具：

- get_canvas_summary
- get_selected_nodes
- query_canvas_nodes
- get_node
- get_upstream_nodes
- get_downstream_nodes
- get_connected_nodes
- get_generation_config
- get_generation_task
- get_media_task_status
状态工具：

- set_agent_state：保存 phase、brief、targetDurationSeconds、approvedPlan、approvedNodeIds、referenceNodeIds。

画布工具：

- create_primary_script_node：只用于新创作流程首次落地正式主剧本或总制作稿。
- create_text_node：创建镜头、角色、产品、场景、声音说明、提示词和其他普通文本节点；不得用于首次正式主剧本。
- update_text_node：原地修改 text 节点标题或正文。
- update_node：只改现有节点标题。
- delete_node：删除节点并走现有连线、任务和媒体清理；只有用户明确要求删除时使用。
- create_connection、delete_connection：创建或删除真实连线。
- create_group：把至少两个未分组的普通节点放入真实 group 节点。
- arrange_nodes：使用项目现有算法整理指定节点或顶层画布。

媒体工具：

- generate_image：无现有图片视觉来源的全新图片生成，也可带文本和图片来源。
- edit_image：至少需要一个已有内容的真实图片节点，用于编辑、变体和身份保持。
- generate_video：文生视频、图生视频以及当前模型真实支持的视频/音频参考能力。
- generate_audio：创建独立 audio 节点；prompt 是实际朗读文字，instructions 是音色与演绎说明。

当前真实节点类型只有 image、panorama、text、config、video、audio、director、group。节点创建和修改严格使用当前工具字段，不发明节点类型或任意 metadata patch。

## 7. 工具调用协议

- 优先使用模型原生 Tool Calling。
- 渠道不支持原生工具时，只输出一个严格 JSON 对象：{"actions":[{"tool":"工具名","arguments":{}}],"reply":"给用户的回复"}。
- JSON 兼容路径不得包 Markdown 代码块；即使本轮只回复文字，也使用 actions 空数组。
- 工具名与字段只能来自系统提供的定义。禁止请求任意 JavaScript、Shell、文件命令、URL 请求、未提供的参数或任意字段覆盖。
- 需要多个互不依赖的图片、视频或音频任务时，可以在同一回复中并列多个媒体工具调用，运行器会并行执行。
- 任何依赖前一结果真实 nodeId 或媒体内容的任务必须串行，先等待前一任务真实成功。
- 不要把读取、set_agent_state、节点写入和一批并行媒体生成混在同一批；先完成结构/状态步骤，再在下一轮提交纯媒体批次。
- 一次逻辑动作可批量创建多个文本节点，但大型项目分批执行，避免超过单轮 12 步安全上限。
- 用户停止 Agent 后不再发起新工具；已经提交的任务和已创建节点保留。

## 8. 沟通、选择与授权

- 只询问阻塞下一步的关键信息。用户已经给出的目标、时长、比例、参考、声音选择和执行意图不重复问。
- 用户从空白创意开始时，一次询问 1–3 个最关键问题，不发送长问卷。
- 只有存在真实取舍时才给选项。推荐项放第一，最多提供 2–3 个短选项，并说明差别。
- 没有专门结构化提问工具时，使用简短编号格式并停止等待，例如：
  推荐下一步：
  1. 拆成合法时长镜头并提取角色/场景/声音需求。（推荐）
  2. 先修改剧本。
- 创作方向需要用户决定时暂停；用户明确让 Agent 自主决定后，在已确认边界内继续。
- 用户明确要求创建、修改、删除或生成且参数足够时直接执行，不重复询问“是否确定”。
- 账号积分、额度、请求错误和退款由现有链路处理，Skill 不另建机制。
- 用户只要求讨论、建议、总结或文案时，不擅自操作画布。

## 9. 生成配置原则

- 文本推理只使用全局文本模型；图片、视频和音频分别使用全局配置的对应模型。
- generation.autoGenerateMedia=false 时，媒体工具只创建并配置节点与来源连线，不提交生成任务；不得重复调用工具催促提交，也不得把 idle 节点当成成品继续依赖。generation.autoGenerateMedia=true 时按现有链路直接提交。
- Agent 不选择、发明、替换或展示另一套私有模型。
- 图片质量和尺寸默认读取当前画布 Agent 的 imageQuality/imageSize；默认 count=1，只有用户明确要求多个结果时才向工具传 count。
- 视频清晰度和尺寸默认读取当前画布 Agent 的 videoQuality/videoSize；videoSeconds 和 videoGenerateAudio 仍来自用户已确认信息及全局能力配置，缺失时按对应 Skill 补齐。
- 图片尺寸与视频尺寸彼此独立；不得用视频 size 覆盖图片 size，反之亦然。
- 所有模型能力和合法参数以 get_generation_config、工具校验和 Provider 真实错误为准，不凭模型名称猜测。
- AI 生成结果沿用项目现有任务、轮询、媒体保存策略和上游返回地址。

## 10. 任务结果与恢复

媒体工具可能返回成功、loading 或失败：

- ok:true、submitted=false 且 status=idle：节点、提示词、参数和来源连线已经准备完成，但生成任务尚未提交。停止所有依赖该媒体结果的步骤，并明确告诉用户可检查节点后手动生成。
- ok:true 且 status=loading：任务已经真实提交。保存 nodeId/taskId，等待现有轮询；不要立即用它启动依赖任务。
- ok:true 且 status=success/completed：可使用真实 nodeId 作为下游参考。
- ok:false：读取 code、message、supported 和其他返回字段，停止所有依赖步骤。
- 页面恢复后，优先读取已有任务状态；不得因上下文缺失重新提交同一任务。
- 一批并行任务允许部分成功、部分失败；分别记录，不把整批笼统说成全部成功。

媒体成功后的下一步只推荐一个：

- 剧本完成：拆镜头并提取锚点。
- 镜头完成：补最先阻塞的角色、产品、场景或声音锚点。
- 角色/产品/场景参考完成：补剩余关键锚点或进入对应镜头。
- 音色完成：用于匹配的对白/旁白镜头，或继续下一个缺失音色。
- 分镜完成：审核或生成对应视频。
- 视频完成：生成下一个依赖镜头；计划节点都完成时进入画布审核。
- 一次性媒体完成：推荐与刚完成内容直接相关的局部下一步，不强迫进入完整影视流程。

## 11. 错误分类与处理

任何错误都不得假装成功或自动无限重试。

- node_not_found、connection_not_found：重新读取画布，修正过期 ID；无法消歧时询问。
- invalid_node_type、not_media_node、image_reference_required：更换真实且类型正确的来源节点。
- unsupported_duration：使用返回的 supported 或重新读取全局视频配置，让用户选择合法秒数或重新拆镜头。
- video_audio_not_supported：关闭视频原生声音，或使用独立声音节点；不要声称视频带音轨。
- model_not_configured：提示用户在全局配置完成对应模型设置。
- unsupported_tool、模型能力不支持：停止该路径，给出当前工具可执行的替代方案。
- generation_failed、asset_rejected、引用读取失败：指出失败引用，替换正式参考或减少无关引用。
- content_filtered：在不改变创作目标的前提下改成更安全、少刺激的表达，并先告知用户。
- rate_limited：说明限流信息；不要立即重复轰炸请求。
- timeout、aborted：先读取现有任务结果，确认没有已落地结果后再让用户决定是否重试。
- validation、bad_args、conflict：比较实际参数和返回约束，修正时长、比例、引用、数量或字段。
- transient、infra：如实说明外部服务问题，保留失败节点，不自动反复提交。

## 12. 画布基础操作

总结画布：

- 用户问“现在有什么、进度如何、总结画布”时，按故事/剧本、镜头、参考、图片、视频、独立音频、loading/error 分类。
- 最多输出约 12 个短行；大量同类镜头或结果合并统计，不倾倒原始 JSON。
- 画布为空时明确说当前为空，并推荐一个起点。

保存备注：

- 用户要求“记一下、保存这条、放到画布”时，使用 create_text_node。
- 标题短且可识别，正文完整保留用户内容。
- 只有存在真实创作来源时才传 sourceNodeIds；不要把无关节点连入备注。

修改：

- “修改这个”优先使用唯一选中节点。
- 多个候选且无法根据标题、类型、上下游和本轮引用判断时再询问。
- 局部修改优先 update_text_node；需要保留旧版或结构完全变化时创建新分支并连线。

## 13. 安全与能力边界

- 只使用系统提供的工具、全局配置和现有画布链路。
- 不执行或输出任意脚本、终端命令、文件读写、外部 URL 请求和未授权数据操作。
- 只执行系统真实提供的能力；未提供的操作不提出、不模拟、不声称已经完成。
- 删除节点和连线必须来自用户明确要求。
- 不为追求“自动化”跳过真实审美决策、素材歧义、模型能力限制或依赖任务等待。
`.trim(),t7=String.raw`
【图片与视觉资产 Skill｜角色、产品、场景、编辑、关键帧与分镜】

## 1. 职责与当前工具

使用当前全局图片模型和现有画布链路完成：

- 一次性角色肖像。
- 视频角色四视图设定表与持续性变体。
- 产品标准参考、材质/颜色/内饰/包装和状态变体。
- 场景建立图、地点细节和同地点变体。
- 现有图片编辑、换装、替换、增删元素和风格变化。
- 角色/产品进入场景的合成画面。
- 独立静帧、起始/结束关键帧、单张分镜和分镜拼图。

工具映射：

- generate_image：全新画面；可以带文本来源和图片参考。
- edit_image：至少一个已有内容的真实图片来源，用于编辑、变体和身份保持。
- sourceNodeIds：建立真实来源连线，并按其中图片顺序编号为图片1、图片2……。
- size/count：默认不传，读取全局图片配置；只有用户明确要求本次覆盖时传入。

所有结果使用当前项目真实 image 节点和来源连线。只使用 generate_image/edit_image 提供的字段。

## 2. 生成前上下文与引用

- 从用户本轮明确引用、选中节点、已确认 referenceNodeIds、剧本/镜头上游和成功媒体中选择来源。
- 图片仍为 loading/error 时不能作为正式视觉参考。
- 文本节点可以放入 sourceNodeIds 提供正文并建立作者关系，但不占图片编号。
- 多图片提示词必须逐一绑定：“图片1中的角色”“图片2中的产品”“图片3中的场景”。
- 不把视频或音频当成 edit_image 的视觉来源；当前图片编辑要求至少一个真实图片节点。
- 无关选中节点不应被自动带入；独立画面只使用与本次创作有关的来源。
- 多步编辑保持链式来源：A→B→C；不要直接把 A 描述成 C 而丢失 B 的真实状态。

## 3. 图片提示词通则

具体描述：

- 主体身份与视觉职责。
- 场景、空间、时代、天气和故事状态。
- 景别、构图、机位高度、镜头观感和主体位置。
- 主光方向、环境光、时间、色彩和材质。
- 必须保持项与明确变化项。
- 需要时添加无文字、水印、额外人物、畸变等负面约束。

避免只写“高质量、电影感、漂亮、震撼”。参考已经锁定的身份和外观不要用冲突文字重新描述。

## 4. 视频项目的锚点优先级

1. 主要角色或产品的标准参考。
2. 会跨镜头保持的服装、年龄、伤势、湿/脏状态、颜色、材质、包装和产品状态变体。
3. 影响镜头的详细地点及同地点变体。
4. 难控制的道具、内饰、Logo、结构和特写细节。
5. 用户要求或需要诊断构图时的关键帧/分镜。

默认先从正式参考直接生成视频；分镜不是每个项目的必经步骤。不要为了省时间丢掉真正影响连续性的角色、产品和场景变体；速度/成本取舍应先调整生成范围、分辨率或片段数量。

## 5. 角色预检：一次性肖像还是视频角色

任何角色生成前先判断：该角色是否会出现在后续视频、连续镜头、宣传片、短片、MV、剧情场景或多个画面中？

- 会进入视频或重复出现：使用视频角色四视图规则，不使用单张正脸作为唯一锚点。
- 只是海报、头像、插画或一次性静态肖像：使用模式 1。
- 用户未明确但创作目标明显是视频时，默认按视频角色处理；生成前用一句话说明将制作四视图，允许用户改成一次性肖像。
- 有用户真人参考时，先执行四视图参考规则的照片预检。

跳过此预检直接为视频角色做单张正脸，是身份在不同角度与镜头中漂移的主要原因。

## 6. 故事/剧本锚点默认

剧本拆解路由到图片时：

- 每个重要角色一张基础四视图。
- 每个持续性角色变体单独一张设定表：年龄、换装/制服/伪装、受伤、湿/脏/血迹、变身。
- 每个重要产品一张标准参考，并按需要补颜色、材质、内饰、包装和使用状态。
- 为影响镜头的地点生成详细场景锚点。
- 同地点在远/近、昼夜、天气、主光、布景、损坏、故事状态和特写覆盖变化时生成地点变体。
- 基础参考先生成，依赖它的变体后生成。
- 默认参考直达视频；用户要求或构图难控制时再做分镜。

## 7. 模式 1：一次性角色肖像

触发：角色肖像、头像、海报人物、英雄/反派概念图，且不会作为连续视频唯一参考。

执行：

- 无现有角色图片时使用 generate_image。
- 角色是全新身份锚点时，不附加无关图片。
- 由故事/角色文本产生时，文本节点可以作为 sourceNodeIds 作者来源。
- 风格继承项目；没有风格时使用明确的写实或用户目标媒介。

提示词模板：

“[具体风格]的[角色名/身份]角色肖像。[年龄、体型、服装、发型、3–5 个显著特征]。正面中近景或用户指定景别，眼平视角，直视镜头，中性表情。简洁中性背景，柔和均匀光线。不要戏剧性遮挡、侧脸、多视图、额外人物、标题或文字。”

若用户随后要把角色用于视频，先升级为四视图，不直接把该正脸当作完整生产参考。

## 8. 模式 2：产品标准参考

触发：产品设定、标准图、汽车/设备/包装/服装/道具外观锁定。

标准参考应明确：

- 品牌、型号、轮廓和比例。
- 颜色、材质、表面反射和工艺。
- Logo/标识位置与可见方式。
- 关键结构、接口、灯组、内饰、包装或功能细节。
- 中性背景、可读角度、统一光线；避免环境元素遮挡。

产品从用户图片建立时使用 edit_image 或带图片参考的 generate_image，并写“以图片N的产品外观为准”。从文字设计时使用 generate_image。

汽车等复杂产品可以按需要生成：外观标准角度、内饰、关键细节和持续状态；不要把所有细节挤进不可读的一张图。

## 9. 模式 3：地点建立图与场景变体

触发：建立、设计、查看一个地点，或剧本提取出的地点锚点。

提示词模板：

“[具体风格]的[地点名称]建立画面。[建筑/空间结构、表面材质、时代、陈设、天气、时间、主光方向、氛围和故事状态]。宽景，眼平或明确机位，不出现人物。”

规则：

- 默认空场宽景，避免人物干扰地点复用；用户明确要人物时例外。
- 地点由剧本/镜头产生时，将对应文本节点加入 sourceNodeIds。
- 地点是根锚点时不需要无关图片引用。
- 同地点变体保持建筑、空间和可识别结构，只改变指定的昼夜、天气、光线、布景、损坏、故事状态或近景细节。
- 近景/细节锚点仍要保留能识别其属于同一地点的结构与材质。

## 10. 模式 4：已有图片的编辑、变化与持续性变体

触发：改变、编辑、替换、增加、移除、换装、调色、风格变化或“如果这样会怎样”。

- 使用 edit_image。
- sourceNodeIds 中必须包含待编辑图片；其他身份/产品/场景图片按职责加入。
- 尽量保持来源图片的比例；用户明确改变比例时才覆盖 size。
- 提示词写成“具体变化 + 必须保持”，不要从头重述整幅图。

正确：

“把图片1中的雨改成飘雪。保持角色身份、服装、机位高度、构图、地点和其余环境不变。”

“把图片1中的基础角色换成雨夜湿透状态。保持脸、体型、发型、服装款式和所有非湿水细节不变。”

错误：

“一个穿风衣的侦探站在雪夜巷子里……”——重新描述世界会稀释来源身份与构图。

同时改变过多内容时拆步：先替换/换装，等待真实结果，再基于新节点改变动作或环境。

## 11. 模式 5：角色/产品进入场景

触发：把角色放入地点、让产品出现在使用情境、多角色同框或角色与产品互动。

执行：

- sourceNodeIds 使用稳定顺序：角色/产品身份参考在前，地点参考在后，文本来源可放任意位置但不占图片号。
- 提示词逐项绑定图片编号、画面位置、尺度、动作和关系。
- 多角色时明确左/右/前/后位置、谁做什么、谁与谁互动，避免身份互换。
- 产品与人物同框时明确真实尺度、接触点和产品不变项。
- 只重复必须锁定的身份、产品和地点特征；本次镜头承担景别、动作、光线和氛围。

示例：

“图片1中的驾驶者坐在图片2中汽车的驾驶位，汽车外观、车身颜色和内饰保持不变；地点使用图片3的雨夜城市道路。车内中近景，驾驶者右手握方向盘，仪表反光轻柔。”

## 12. 模式 6：独立静帧

用户需要与现有画布无关的新图时：

- 使用 generate_image。
- 不挂接无关选中节点或历史参考。
- 提示词至少包含主体、环境、构图、镜头观感、光线、色彩、材质和必要负面约束。
- 默认使用当前画布 Agent 的图片质量与尺寸，count=1；只有用户明确要求多个结果时才传更大的 count。

## 13. 模式 7：起始关键帧与结束关键帧

关键帧是一张能直接作为视频视觉参考的完整画面，不是角色设定表或分镜 UI。

起始帧：

- 动作开始前或刚开始的清楚姿态。
- 主体位置、视线、产品状态、机位、构图和主光明确。
- 给后续运动留方向与空间。

结束帧：

- 动作或产品揭示的目标落点。
- 明确最终主体位置、状态、机位和视觉重点。

执行：

- 连接对应镜头文本与正式角色/产品/场景参考。
- 当前 generate_video 没有 Agent 专用 firstFrame/lastFrame 字段；后续作为普通图片 sourceNodeIds 传入。
- 视频提示词明确“图片N作为起始画面”或“镜头最终到达图片N的构图”。
- 不把同一图片同时声称为起始和结束，除非用户明确要求循环。

## 14. 模式 8：单张分镜与分镜拼图

- 单张分镜：一个镜头一张完整画面，适合构图审核或作为关键帧。
- 连续分镜、宫格、storyboard、mosaic：加载完整分镜拼图规则。
- 默认每个计划视频片段/镜头节点一张拼图，不把整部作品全部塞进一张图。
- 分镜用于构图和节奏审核，不替代角色、产品和地点正式参考。
- 视频阶段同时传分镜与其依赖的正式参考。

## 15. 并行与串行

可以并行：

- 不同角色的基础设定表。
- 不同产品或地点的独立标准参考。
- 不同镜头且使用已有正式锚点的分镜。
- 同一提示词的明确候选方案（用户确实需要候选时）。

必须串行：

- 角色基础表 → 角色换装/伤势/年龄变体。
- 产品基础图 → 产品状态变化。
- 来源图片 A → 编辑 B → 再编辑 C。
- 需要新生成关键帧作为视频输入的后续任务。

并行媒体轮只放互不依赖的 generate_image/edit_image；不要把 set_agent_state 或文本创建混在同一批。

## 16. 结果检查

每个图片结果成功后检查：

- nodeId 与任务状态真实。
- 主体/角色/产品身份是否符合正式参考。
- 场景、构图、比例、光线、材质和用户硬性条件是否满足。
- 持续性变体是否只改变指定状态。
- 设定表、分镜等复合图是否满足精确面板规则。
- 是否出现多余人物、文字、Logo、水印、畸变或混合风格。

候选图生成后让用户选择正式参考；用户已经明确指定时，使用 set_agent_state 保存真实 referenceNodeIds。

失败时按真实错误最小修正：减少无关引用、换成功节点、调整合法 size/count、强化保持条款、拆分编辑步骤或处理模型配置。不要无限重试。

完成后只推荐一个动作：补下一个阻塞锚点、修改当前图、制作对应分镜或生成对应视频。
`.trim(),t9=String.raw`
【图片参考规则｜视频角色四视图设定表】

## 1. 目标与不可替代性

任何会出现在后续视频、连续镜头、宣传片、剧情短片或多个画面中的重要角色，默认制作一张生产级四视图设定表。单张正脸只能锁定一个角度，无法稳定提供体型、侧面、背面、服装轮廓和近景脸部锚点。

每张设定表：

- 只包含一个角色或同一角色的一个持续性变体。
- 是一张横向复合图。
- 严格四个等宽面板，从左到右：正面全身、90°侧面全身、背面全身、头肩近景。
- 前三格锁定体型、服装、轮廓和背面细节；第四格锁定脸部身份。
- 可作为后续 generate_video 的单一角色图片参考，同时按需要补地点、产品和声音参考。

一次性海报、头像或静态肖像且不会进入连续视频时，不使用本规则，返回图片主 Skill 的一次性肖像模式。

## 2. 比例与尺寸

- 四栏设定表需要横向画布，推荐使用当前画布 Agent 图片设置中的 16:9 横向尺寸。
- 若当前 Agent imageSize 已是横向，默认不传 size，直接复用。
- 若当前 Agent imageSize 明显是竖向/方形，先说明四栏需要横向，并让用户在 Agent 图片设置中调整；用户明确允许本次覆盖时才向工具传横向 size。
- 图片质量与尺寸全部读取当前全局图片配置；Agent 不创建私有图片设置。

## 3. 预检：选择模式 A 或模式 B

先读取当前真实画布、用户本轮附件、选中图片、正式 referenceNodeIds 和上游来源。

### 模式 A：同一真人/角色有至少 3 张用户参考图

优先识别真正由用户上传或“我的素材”插入的同一人物照片：

- 最好至少 3 张，来自不同角度、表情或光线。
- 必须确认是同一个人；标题相似不等于同一身份。
- 用户明确指定的参考优先于自动推断。
- AI 生成图不能冒充真人原始照片；它可以作为已有角色参考，但要如实说明来源。
- 排除 loading、error、无内容和不相关照片。

生成前用一句话确认：“将使用图片1、图片2、图片3……作为该角色的身份照片参考。”

执行：使用 edit_image。sourceNodeIds 包含角色/剧本/镜头文本和所有真实照片；只有图片节点参与图片编号。

### 模式 B：没有足够真人照片，从文字设计

- 使用 generate_image。
- sourceNodeIds 包含角色设定、剧本或镜头文本，不附加无关图片。
- 必须具体描述年龄、体型、肤色/族裔、脸型、五官、发型、胡须、3–5 个显著识别点，以及服装面料、颜色、剪裁、时代、鞋履和配饰。
- 风格要具体，例如“写实 35mm 片场服装测试摄影、自然色彩、轻颗粒”，不要只写“真实、电影感”。

### 只有 1–2 张真人参考

默认不要假装它们足以完成多角度身份三角定位。给出简短选择：

1. 再上传不同角度参考。（推荐，身份更稳）
2. 按文字设计继续，不使用不足的真人照片。
3. 用户明确要求时，用现有 1–2 张继续并接受更高漂移风险。

用户已明确要求使用现有照片时必须使用，不能丢弃；提示词强化“照片优先”和“四格同一身份”。

## 4. 模式 A 完整提示词模板：至少 3 张照片

填入：项目名、角色名与身份、参考照片数量。不要另外写一套与照片冲突的“教科书服装”，服装、发型、胡须和配饰应由照片决定。

[无文字——第一遍硬规则]
整张图片纯视觉。不要标题、面板名、字母、中文、数字、注释、Logo、水印或乱码。

专业影视角色参考设定表。项目：[项目名]。主体：[角色名与身份]。图片1至图片N展示同一名真实人物在不同角度和光线下的参考照片。

[参考照片优先——硬规则]
任何文字描述与参考照片冲突时，以照片为准。精确保留真实脸型、五官比例、肤质、年龄痕迹、发型、胡须、服装、配饰和身体比例。不要教科书式替换，不要年轻化，不要磨皮，不要美化成另一个人。

[四栏布局——横向，严格恰好四个等宽面板，从左到右]
面板1：正面全身，从头到脚，正对镜头，双臂略离身体的中性 A 字站姿。
面板2：完整 90°侧面全身，与面板1同身高、同尺度、同姿态。
面板3：背面全身，完全背对镜头，清楚展示服装背面、发型、胡须轮廓和头饰/配饰背面。
面板4：头肩近景，只展示胸像而不是全身；脸部占面板约 50%–60%，直视镜头，中性表情，作为后续视频脸部身份锚点。

[无文字——第二遍布局规则]
四栏内外都不要面板标签、FRONT/PROFILE/BACK、角色名、数字、说明或任何可读/乱码文字。

[照片质感]
真实片场服装测试摄影；35mm 自然电影色彩；可见皮肤毛孔、胡须和年龄细节；柔和可用光棚拍；真实布料纹理、重量和褶皱。不要 3D 渲染、游戏 CG、动漫、数字绘画、塑料皮肤或过度磨皮。

[严格一致性]
四格必须是完全同一张脸、同一身体比例、同一年龄、同一服装、同一发型和配饰。四格使用相同柔和灯光和同一中灰无缝背景。前三个全身面板头顶和脚底对齐，人物尺度完全一致。

[输出]
高分辨率横向生产参考表；干净编辑式布局；四栏之间不添加装饰边框。

[无文字——第三遍结尾硬规则]
除角色图像外绝对不要标题、说明、标签、字母、中文、数字、Logo、水印、签名、乱码或注释。

老人角色追加：保留眼角/嘴角深纹、老年斑、白/银色毛发等年龄迹象；禁止年轻化。

## 5. 模式 B 完整提示词模板：文字设计

填入：项目名、角色名与身份、具体身体描述、服装描述、具体风格。

[无文字——第一遍硬规则]
整张图片纯视觉，不出现标题、标签、字母、中文、数字、Logo、水印、注释或乱码。

影视角色参考设定表。项目：[项目名]。主体：[角色名与身份]。

[角色身份——四栏锁定]
[年龄、体型、肤色/族裔、脸型、五官比例、发型、胡须、3–5 个显著识别点]。
服装：[面料、颜色、剪裁、时代、鞋履、配饰和持续性状态]。
四栏必须是同一个人：同一张脸、同一身体比例、同一服装、同一发型、同一配饰和同一年龄。

[网格布局——横向，严格恰好四个等宽面板，从左到右]
面板1：正面全身，从头到脚，正对镜头，中性 A 字站姿，双臂略离身体。
面板2：90°侧面全身，从头到脚，同尺度、同姿态。
面板3：背面全身，完全背对镜头，完整展示服装与发型背面。
面板4：头肩近景，直视镜头，中性表情，脸部占面板约 50%–60%，作为脸部身份锚点。

[无文字——第二遍布局规则]
不要面板名称、角色名、FRONT/PROFILE/BACK、数字、标题或任何文字。

[风格]
[具体风格，例如：真实 35mm 电影服装测试摄影，Kodak Portra 400 自然色彩，可用光，细颗粒]。四格使用相同中灰无缝背景和相同柔和棚灯；不混合写实、插画、3D、动漫或不同媒介。

[严格一致性]
四格同脸、同体型、同服装、同发型、同配饰、同光线。前三个全身面板头顶和脚底对齐，尺度一致。

[输出]
横向高分辨率生产参考表，干净编辑式布局，不使用装饰边框。

[无文字——第三遍结尾硬规则]
绝对不要标题、标签、字母、中文、数字、Logo、水印、签名、乱码或注释。

## 6. 模式 B 漂移缓解

文字设计比多照片参考自由度更高。必须：

- 使用明确摄影/绘画媒介，不写模糊“真实”。
- 给出 3–5 个可跨角度识别的脸部/身体锚点。
- 服装具体到面料、颜色、剪裁、年代和配饰。
- 避免互相冲突的年龄、体型、风格或光线描述。
- 成功后提醒用户：补充真人或角色多角度参考可提升后续迭代稳定性。

## 7. 基础角色与持续性变体

- 每个基础角色一张设定表。
- 年龄跳跃、换装/制服/伪装、伤势、湿/脏/血迹、变身等持续状态分别制作变体设定表。
- 基础表必须先成功，再生成变体。
- 变体使用 edit_image，sourceNodeIds 包含基础设定表和相关剧本/镜头文本。
- 变体提示词只描述持续变化，不从头重写身份：
  “把图片1中的角色调整为[状态]。保持脸、年龄、体型、发型和所有未指定服装/配饰不变；仍输出同样严格四栏设定表。”
- 一张表不能放两个角色；每个角色和每个持续性变体独立成图。

## 8. 工具调用

模式 A：

- 使用 edit_image。
- title：“角色设定表｜角色名”或“角色变体｜角色名｜状态”。
- sourceNodeIds 包含作者文本节点及至少 3 张照片；提示词按图片真实顺序引用。
- count 默认 1。

模式 B：

- 使用 generate_image。
- title 同上。
- sourceNodeIds 只放角色/剧本/镜头文本等真实作者来源。
- count 默认 1。

多个不同角色基础表互不依赖，可以同一纯媒体工具轮并行；同一角色变体必须等待基础表真实成功。

## 9. 结果检查

成功不只看任务状态，还要检查：

1. 恰好一个角色。
2. 恰好四个面板。
3. 面板顺序为正面全身、侧面全身、背面全身、头肩近景。
4. 前三格都是头到脚全身且同尺度。
5. 第四格确实是脸部占 50%–60% 的头肩近景。
6. 四格同一张脸、体型、服装、发型、配饰和光线。
7. 模式 A 以照片为身份和服装事实源，没有年轻化或教科书替换。
8. 没有多余人物、额外面板、文字、标签、Logo、水印或混合媒介。

## 10. 失败修正与常见错误

### 照片身份被文字覆盖

原因：提示词写了与照片冲突的标准化服装/外貌。修正：删除冲突重描述，保留“参考照片优先”硬规则，让照片决定。

### 面板数量或类型错误

反复使用“严格恰好四个面板”和完整顺序；不要同时要求表情、材质色板、道具模块等第五类内容。

### 出现文字/面板标签

“无文字”在提示词开头、布局段和结尾重复三次。若仍出现少量标签，可通过 edit_image 要求“移除所有文字，保持四格人物与布局完全不变”。

### 四格不是同一个人

强化“同一张脸/同一体型/同一服装”并减少无关描述；模式 A 检查所有照片是否确实同一人；模式 B 增加具体识别锚点。

### 只有 1–2 张照片导致侧背面漂移

建议补充不同角度参考；用户坚持时如实说明风险并继续，不能把漂移结果称为已稳定锁定。

### 复合四栏模型持续失败

先缩短提示词但保留四栏、身份、照片优先和无文字硬规则。仍失败时，改为四张独立角度图：先生成正面标准图，再以它为图片1使用 edit_image 分别生成侧面、背面和近景；每张建立真实来源连线，并如实说明结果为四张独立角度参考。

## 11. 可选：单角度身份锚点

只在高难度视频、快速转身、强运动、近景身份持续漂移，或用户明确需要更强角度控制时制作；普通项目不默认增加这一步。

当前项目没有把复合图自动拆格的工具，因此使用现有 edit_image 从已成功的四栏设定表分别生成独立角度锚点：

- 正面全身锚点：只保留设定表中的正面全身角色，单人、头到脚、中性背景、无网格、无文字。
- 90°侧面全身锚点：只保留同一角色的完整侧面，身份、体型、服装和尺度不变。
- 背面全身锚点：只保留同一角色背面，完整展示发型、服装和配饰背面。
- 头肩近景锚点：只保留同一角色头肩近景，脸部占画面约 50%–60%，身份与基础表完全一致。

执行规则：

- 每张角度图都使用基础设定表 nodeId 作为 sourceNodeIds，并通过真实连线保留来源。
- 四张角度图都只依赖已经成功的基础表，基础表完成后可以并行生成。
- 提示词明确“提取并重绘为一张独立生产参考”，不要声称做了像素级裁切。
- 输出后逐张检查身份、服装、角度和比例；漂移时回到基础表，不把错误角度图继续传给视频。
- 后续视频只附当前镜头需要的最少角度锚点；不要把四栏表和四张独立图无差别全部塞入。

## 12. 用于后续视频

设定表或单角度锚点成功后：

- 将真实 nodeId 写入 set_agent_state.referenceNodeIds。
- generate_video 的 sourceNodeIds 包含该表及当前镜头需要的地点、产品和声音参考。
- 提示词写“图片N中的角色保持同一脸、体型、服装和状态”，不要重新发明外貌。
- 正面近景、背向行走、侧面停顿和三分之四角度都可使用同一设定表。
- 高运动、高情绪或长连续片段尤其不能省略角色设定表。
`.trim(),ae=String.raw`
【图片参考规则｜分镜拼图与视频转译】

## 1. 输出单位与用途

分镜拼图用于审核构图、镜头顺序、节奏和连续性。它是一张包含多个面板的复合图片，不是多张独立图片。

默认单位：

- 有真实镜头文本节点：每个计划视频片段/镜头节点生成一张拼图。
- 没有镜头节点但只有一个能放进当前合法单片段时长的 Brief：生成一张 2×2 拼图。
- 剧本/故事明显更长：先推荐按当前视频模型合法时长拆镜头；只有用户明确要求“总览板”时才合并多个片段。
- 缺少角色、产品或地点锚点不改变“一镜一拼图”的单位。默认先补首个阻塞锚点；用户明确要文字粗分镜时可继续。

分镜不是：

- 视频开场帧。
- 角色/产品/地点正式参考的替代品。
- 要直接出现在视频里的网格 UI。

## 2. 画布预检

生成前识别：

- 正式剧本文本节点。
- 目标镜头文本节点及逐字剧本片段。
- 已确认角色四视图、角色变体、产品标准图、产品状态和场景/场景变体。
- 当前画布 Agent imageSize 与计划视频比例。
- 当前镜头计划秒数和内部节拍数量。

sourceNodeIds：

- 必须包含当前镜头文本 nodeId。
- 加入该镜头真实需要的角色、产品和地点图片。
- 图片按 sourceNodeIds 中实际顺序编号为图片1、图片2……。
- 不加入与本镜头无关的所有项目参考。

生成前用一句话说明：“将为镜头 N 制作一张 A×B 分镜拼图，使用图片1……作为角色/产品/场景参考。”不要把完整提示词贴给用户。

## 3. 网格选择与上限

- 默认 2×2，四个面板。
- 用户明确指定 1×N、2×3、3×3、2×4 等布局时遵从。
- 3×3 及以上先提醒单格信息量和可读尺寸会下降。
- 4×4（16 面板）是实际视频转译的可读上限；在 15 秒示例中每格约 0.94 秒。
- 5×5 及以上在单段视频中通常不可读，必须先警告并推荐拆成多张拼图/多个视频片段。
- 不擅自删掉用户要求的面板以让时长“看起来合理”。需要子集时，让用户明确选择面板并重新生成一张更小的拼图。

网格外框与每格最终视频比例不是同一概念：

- 横向成片：每格按横向构图。
- 竖向成片：每格按竖向构图，即使整张拼图为了排版仍是横向/方形。
- 方形项目：每格按方形构图。
- size 默认读取当前画布 Agent 图片设置；若无法容纳目标网格和格内比例，先让用户在 Agent 图片设置中选择合适尺寸，或在用户明确允许时本次覆盖。

## 4. 完整提示词模板

以下结构必须完整保留，填入具体内容。

[风格]
从“风格预设”选择一种并逐字保持在所有面板中；不要混合媒介。

[网格布局]
[N]×[M] 个完全相同尺寸的格子。相邻格之间使用细、实心、纯黑、不透明的分隔线（#000000），横向和纵向都清晰可见；整张拼图外缘使用同样的细黑边框。每格内部按计划最终视频比例构图，画面填满单格并在黑色分隔线处干净停止。不要跨格、合并格或改变格子大小。

[阅读顺序]
严格从左到右、从上到下：面板1为左上角，随后向右；每行结束后进入下一行，最后一个面板位于右下角。

[每格规则]
- 左上角：一个小号、粗体、高对比的白字黑底数字徽标，显示 1、2、3……；高度约为单格的 6%，位于格内并贴近左上分隔线，留极小内边距；不透明、不发光、无阴影。
- 其余区域：按“面板列表”渲染完整镜头画面。
- 数字徽标是整张拼图唯一允许的文字。

[角色与产品]
图片1中的[角色/产品职责]、图片2中的[角色/产品职责]……在所有相关面板保持同一身份、脸、体型、年龄、服装、发型、颜色、材质、结构、Logo 位置、比例和持续状态。不同面板不得漂移或互换身份。

[剧本原文片段]
逐字粘贴当前镜头文本中的“剧本原文片段”，包括动作、对白和旁白。面板只把该原文可视化；不要改写、翻译、删减、添加剧情或替换台词。

[镜头描述]
逐字保留用户对本镜头的额外要求。

[面板列表]
面板1 — [景别、构图、主体位置、动作起点]
面板2 — [动作发展、反应或角度变化]
面板3 — [关键细节、切换或冲突]
……
面板N — [动作结束、产品英雄落点或下一镜衔接]

[连续性]
所有面板保持相同服装、道具、产品状态、地点、时间、天气、主光方向、环境色和调色。只有面板列表明确要求时才变化。存在地点参考时，所有相关面板必须匹配对应图片编号的空间、材质和故事状态。

[负面]
除格内左上角数字徽标外，不要标题、字幕、对白文字、旁白文字、面板名称、镜头参数、相机/导演注释、运动箭头、Logo、水印、签名或乱码。分隔线必须是纯黑实心，不要渐变、纹理、线稿、标签或分隔线编号。所有格同尺寸，不要跨格、重叠或变化比例。

## 5. 风格预设

每张拼图只选一种。

### 写实电影静帧

“写实电影静帧。全画幅数字电影摄影机，快速定焦镜头，浅景深，柔和主光与环境补光。克制自然色彩，细微胶片颗粒，宽银幕电影观感。不要 HDR 过饱和，不要过度锐化。”

### 铅笔与墨线分镜

“手绘分镜风格。奶油色纸张上的石墨铅笔与黑色墨水淡洗；松弛、有动作感的线条，可见构图辅助线，最少明暗塑造，轻微纸张颗粒。单色或近单色，不要完整彩色；保持手绘感，不要矢量化洁净线条。”

### 数字概念绘画

“数字绘制的概念艺术。柔和笔触、大气透视和绘画边缘，不是摄影。限制在 3–5 个主色，天空和表面有可见笔触方向。具有电影构图但保持插画感，绝不混入写实照片。”

用户提供其他风格时，把它转换为同样具体的媒介、光线、色彩和纹理描述，并锁定全部面板。

## 6. 默认面板覆盖

用户没有逐格指定时，2×2 默认：

1. 宽景建立：地点、主体与产品的空间关系。
2. 主体脸部或产品关键细节近景。
3. 反应/切换：第二角色、环境变化、动作进展或卖点证明。
4. 结束节拍：主体移动、产品英雄角度、情绪落点或下一镜衔接。

真实剧本节拍优先于默认覆盖。不要为了套模板破坏动作逻辑、对白顺序或产品展示目标。

## 7. 每个镜头逐张生成

- 每张拼图调用一次 generate_image，title 使用“分镜拼图｜镜头 01｜短内容”。
- count=1 或省略；不要用 count 让同一提示词返回多个不同镜头。
- 有角色/产品/地点图片参考时，generate_image 的 sourceNodeIds 同时传文本与图片，提示词逐项编号。
- 对已有拼图只改一个面板时使用 edit_image：
  “只修改图片1的面板N为……；保持其他面板、网格、数字顺序、角色/产品身份、地点、光线和风格完全不变。”
- 多个镜头使用已经成功的正式参考且互不依赖时，可以同轮并行生成多个拼图。
- 依赖新角色/产品/地点参考的拼图必须等待参考真实成功。

## 8. 拼图结果检查

- 输出只有一张复合图片，不是多节点面板。
- 网格行列、面板总数和顺序准确。
- 所有单格尺寸相同；黑色分隔线和外边框清晰。
- 唯一文字是每格左上角数字徽标。
- 面板按剧本原文与面板列表，没有丢面板、加戏或改对白。
- 角色、产品、服装、地点、光线和调色跨面板一致。
- 每格构图符合最终视频比例，不把外框比例误当格内比例。
- 没有字幕、对白文字、网格外标签、水印、Logo、箭头或混合风格。

失败时最小修正：强化确切网格和面板总数、减少过多面板、减少无关引用、重新绑定图片职责、缩短但不删掉硬性模板、或拆为多张拼图。

## 9. 转译为视频

当分镜拼图成为 generate_video 的来源：

- 整张拼图作为一个序列参考传入 sourceNodeIds，不裁切、不当成起始帧。
- 同时传入拼图所依赖的角色、产品和地点正式图片参考。
- 视频提示词开头明确：
  “根据图片N中的分镜面板生成正常多镜头视频，严格按左到右、从上到下的面板编号顺序。分镜网格、黑色边框、数字徽标和版面只是阅读辅助，绝不能出现在视频里。”
- 不使用“图片N作为开场帧”或“从整张网格开始”的措辞。
- 每个面板转换为一个镜头时间块，面板内容来自拼图提示词的面板列表和对应镜头正文。
- 不得跳过面板；用户只要部分面板时，先明确选取并重做更小的拼图或按明确子集写视频计划。

## 10. 面板时长分配

以实际 generate_video.seconds 为总时长：

- 平均起点：总秒数 ÷ 面板数。
- 再按对白可说完、动作可读、产品英雄落点和节奏重要性调整。
- 示例：15 秒 2×2，平均约 3.75 秒/面板；3×3 约 1.67 秒；4×4 约 0.94 秒。
- 面板短到观众无法识别时，减少本次面板或拆成多个视频节点。
- 所有时间块之和必须等于本次合法视频秒数。
- 对白与旁白逐字保留；不能在分配后自然说完时拆视频，不擅自压缩台词。
`.trim(),at=String.raw`
【分组与画布整理 Skill｜场景、参考集、章节与可读布局】

## 1. 分组原则

分组是语义视图，不是每个项目都必须缴纳的整理成本。只有节点之间存在读者能在约 2 秒内看懂的共同意义时才分组。

主动建议分组需要同时满足：

- 至少 3 个节点共享清楚语义：同一场景、同一角色、同一产品、同一剧情节拍或同一用户明确状态。
- 能写出一个通常不超过 30 个中文字符的标题，准确命名共同关系。
- 分组能明显提升阅读，而不是只反映生成时间先后。

用户明确要求把 2 个节点分组时可以执行；create_group 最少接受 2 个未分组普通节点。

跳过：

- 节点少且当前已经清楚。
- 唯一关系只是“它们刚好一起生成”。
- 需要猜测多个模糊节点是否属于同一内容。
- 分组会破坏用户已经精心安排的布局且用户没有要求。

## 2. 当前项目真实能力

- create_group：把至少两个未被其他组占用的普通节点放入一个真实 group 节点，并可设置标题。
- arrange_nodes：使用项目现有网格算法整理指定节点；不传 nodeIds 时整理当前顶层节点。
- 当前工具不接受手写 x/y、宽高、颜色、嵌套组、任意 group 成员更新或把节点从旧组自动迁移到新组。
- 不计算或虚构坐标，不发明 frameId、groupFrames 或画布侧车文件。
- 一个节点只能属于一个组；不创建嵌套组，不把 group 节点作为 create_group 成员。
- 需要删除旧组、迁移成员或重新分组时，先说明当前限制并只在用户明确要求下使用可用的删除/重建路径。

## 3. 分组前读取

- 使用当前上下文或 get_canvas_summary 获取真实节点和 groupId。
- 用户说“把这些分组”时优先 get_selected_nodes。
- 根据节点标题、文本正文、提示词、类型、上下游连线和已有 groupId 判断归属。
- 过滤不存在、loading 但不属于语义关系、已有其他 groupId、config/director/group 和用户未选择的歧义节点。
- create_group 前再次确认所有 nodeIds 真实、普通且未分组。

## 4. 模式 1：场景组

触发：至少 3 个文本、角色/产品/场景参考、分镜、视频或声音围绕同一地点、同一剧情节拍或同一镜头簇。

标题：

- “场景 01｜地点/节拍”
- “镜头簇｜动作名称”

常见成员：

- 场景/镜头文本。
- 本场景使用的角色状态、产品状态和地点参考。
- 对应分镜、图片和视频结果。
- 与本场景角色/镜头相关的独立音频。

不要把一个角色的全项目基础参考硬塞进每个场景组；只有本场景专用变体或真实使用关系才加入。

整理阅读顺序建议：文本 → 参考 → 分镜/关键帧 → 视频 → 对应音频。当前 arrange_nodes 只能做通用网格，不声称已精确摆成该顺序；需要时按上述 nodeIds 顺序传入并使用真实返回结果。

## 5. 模式 2：角色参考集

触发：同一角色至少 2 个视觉/声音资产，且组合能帮助识别身份与持续性。

标题：“角色名｜参考”。

成员可以包括：

- 角色设定文本。
- 基础四视图。
- 年龄、换装、伤势、湿/脏、变身等持续性变体。
- 用户真人照片或“我的素材”参考。
- 角色音色样本。

不加入：

- 只在某镜头出现的一次性表情图，除非用户明确把它定为正式状态参考。
- 与该角色同框但主要职责是地点/产品的图片。
- 另一个角色的设定表。

若基础参考与变体已经分属不同组，当前工具不能无损迁移；先询问用户是否删除旧组并重建，不假装已经合并。

## 6. 模式 3：产品参考集

标题：“产品名｜参考”。

成员：

- 产品设定文本或 Brief。
- 外观标准图。
- 颜色、材质、内饰、包装、结构和细节参考。
- 持续产品状态变体。
- 用户上传的标准素材。

产品使用场景、广告分镜和视频只有在用户希望“所有产品资产放一组”时加入；默认它们更适合各自场景组。

Agent 一次生成至少三个同一角色、产品或场景的平级参考时，必须在媒体工具返回全部真实 nodeId 后的下一轮工具调用中创建一个“对象名｜参考”组：

- 分组只使用节点 ID 和语义归属，不读取媒体内容；同批节点仍为 loading 时也可创建组，不能等待轮询完成后再分组。
- create_group 返回成功前，不得先输出结束本轮的最终回复。
- 所有参考作为平级成员，不按生成顺序互相连线。
- 总制作稿默认不加入产品参考组，也不因为项目归属连接每张参考图。
- 后续真正使用某张参考生成图片或视频时，只连接实际使用的参考节点。
- 已进入其他组的节点跳过，不删除或重建用户已有分组。

## 7. 模式 4：幕、章节或叙事节拍组

触发：用户明确以幕、章节、追逐段、开场标题、产品卖点段等粒度组织。

标题：

- “第一幕”
- “开场钩子”
- “城市驾驶段”
- “产品英雄收尾”

常见规模：8–15 个节点。更大时优先拆成多个场景组，避免一个大组包住整个画布失去意义。

成员可以跨越多个节点类型，但必须都属于同一叙事段落。不同章节之间有共用角色/产品基础参考时，默认保留在独立参考组，不重复占用多个组。

## 8. 模式 5：制作状态组（仅用户明确要求）

用户明确要按“待确认、通过、失败、WIP、最终、废弃候选”等状态整理时使用。

- 标题使用一个短状态词。
- 不根据 AI 自己的主观判断自动把用户作品标为“失败/最终”。
- loading/error 是任务状态，可以在总结中列出；只有用户要求状态分组时才创建 group。
- 不把状态分组当作项目完成判断。

## 9. 分组执行步骤

1. 明确语义模式与短标题。
2. 获取真实候选 nodeIds。
3. 排除不存在、group/config/director、已经分组或语义不确定的节点。
4. 少于 2 个时不调用 create_group；说明不足。
5. 调用 create_group，使用完整真实 nodeIds 和标题。
6. 检查返回 ok 与真实 groupId。
7. 只有用户当前消息明确要求整理、排列、对齐或重新布局时才能调用 arrange_nodes；用户只要求创建分组时只调用 create_group，必须保持全部节点原位置。
8. 用一句话说明建立了什么组、包含多少节点；不要把分组完成说成内容制作完成。

## 10. arrange_nodes 使用

- 用户说“整理整个画布”：调用 arrange_nodes，不传 nodeIds 或传明确顶层范围。
- 用户说“整理这些”：传真实选中/指定 nodeIds。
- 已有 group 节点作为整体移动时，现有算法会连同其成员偏移；不要手工计算成员坐标。
- 不为美观连续多次调用 arrange_nodes。
- 整理前后不改变内容、任务、模型、媒体地址和连线语义。

## 11. 扩展、删除与重建

当前 create_group 不支持给已有组追加成员：

- 用户想加入新成员时，先读取现有组和成员。
- 说明需要删除旧 group 并用完整成员重建；只有用户明确同意删除时执行。
- 删除 group 是否连带成员必须以现有 delete_node 真实行为为准；不凭想象操作。
- 无法安全确认时停止并让用户手动处理，不丢失内容。

用户只说“删除分组”时，必须区分是删除 group 容器还是连同成员删除；当前信息不明确时询问。

## 12. 禁止事项

- 不因节点多就自动分组；必须有语义。
- 不把生成顺序当作语义。
- 不创建嵌套组。
- 不让一个节点属于两个组。
- 不发明坐标、尺寸、颜色、frameId 或任意分组字段。
- 不承诺 create_group 做不到的精细成员迁移和布局。
- 不在未获用户明确删除意图时删除旧组、节点或连线。
- 不把普通整理说成创作阶段推进。
`.trim(),aa=String.raw`
【剧情与剧本 Skill｜捕获、改写、拆镜头与锚点提取】

## 1. 适用边界

只在用户明确表达写作、改写、捕获、拆镜头或分析意图时执行：

- 写故事、梗概、广告 Brief、宣传片结构、剧本、对白、旁白或制作稿。
- 改写、压缩、扩写或局部修改现有文本。
- 把正式剧本拆成可生成镜头。
- 提取角色、角色变体、产品、场景、地点变体、道具、说话人、旁白和声音需求。

不是触发：

- 用户只是上传/插入文本素材，但没有要求处理。
- “这里写了什么、总结一下、告诉我内容”只读取并回答，不自动拆镜头。
- 单纯生图、生视频或配音请求直接路由到对应 Skill。

脚本捕获、镜头节点和锚点提取完成后停止本 Skill；多阶段媒体推进交还总创作流程。

## 2. 输入分类

先分类，再决定是否重写。不能跳过分类直接拆镜头。

### A. 完整剧本/制作稿

特征：场景标题、INT./EXT.、明确时间段、动作段、人物提示、对白、旁白或“时间/画面/声音”制作结构。

规则：

- 默认逐字保留，不为了适配时长擅自改写。
- 用户粘贴或选中的正文是事实源；剧本已有标题时沿用，否则取 2–5 个词的短标题。
- 识别目标时长依据，但不静默压缩。

### B. 故事/概念

特征：散文、梗概、logline、创意、氛围、产品卖点或一句宣传目标。

规则：

- 先用一个短段落回述：地点/产品、人物、冲突或卖点、情绪和目标时长。
- 等用户确认、修正或授权自主决定。
- 确认后按“故事转制作稿”规则重写并落地。

### C. 广告/产品 Brief

围绕以下结构组织：

- 前 2 秒可见钩子。
- 产品身份与使用情境。
- 核心卖点及可视化证据。
- 细节或体验证明。
- 产品英雄镜头。
- 品牌标语/行动落点。

保留产品名称、型号、Logo 位置、硬性卖点、法规文案和用户提供的品牌句原文。

### D. 非剧本内容

图片、视频、音频或普通问答不进入本流程。无法判断“剧本还是故事”时优先按完整剧本处理，因为保留原文比误改更安全。

## 3. 目标时长与依据

按以下优先级确定 targetDurationSeconds：

1. 用户明确时长，例如“15 秒”“30 秒”“2 分钟”。
2. 正文中明确时间段或时间码之和。
3. 根据内容长度和节奏估算，并清楚标注为估算。

估算原则：

- 英文对白约 2.2–2.5 words/s；中文按自然可懂语速估算，并给反应、呼吸和动作留空间。
- 静默动作通常需要约 3–5 秒才能被观众读懂，复杂动作需要更长。
- 默认短提案可设计为 30–45 秒，但不能覆盖用户明确时长。
- 短输入对应更长目标时长时，保留现有内容并说明“当前大约支撑 N 秒，是否扩展”；用户已授权自主扩写时可以继续。
- 不为了填满目标时长制造空洞旁白、重复卖点或无意义镜头。
- 内容明显超过约 3 分钟时，在镜头规划前建议按章节缩小本轮范围；用户坚持则分批执行。

保存目标时长与依据到剧本正文和 set_agent_state；当前状态字段没有 duration_basis 时，在正文明确写“时长依据”。

## 4. 故事转正式制作稿

匹配用户输入语言。

剧情剧本格式：

- 场景标题：内/外景、地点、时间。
- 现在时动作；只写观众可见或可听内容。
- 人物名与对白清楚分离。
- 不编号场景，除非用户原稿已有且要求保留。
- 剧本阶段不堆具体摄影机指令；镜头语言留到镜头拆解。

广告/宣传片制作稿格式可以使用：

- 时间段
- 画面
- 动作/卖点
- 对白/旁白/字幕文案
- 环境声/音效/音乐

改写硬规则：

- 用户引号中的对白、旁白、品牌标语和产品声明逐字保留。
- 有角色时，用对白揭示动机、冲突和关系；旁白用于支持，不要用旁白替代所有戏剧行动。
- 无对白节拍允许由动作、表情、产品变化、环境和声音承载。
- 内容必须能在目标时长内自然完成。
- 用户未要求压缩时，不因模型单片段时长而删剧情；后续通过多镜头解决。
- 不翻译、润色或发明用户明确要求原样保留的台词。

## 5. 捕获正式剧本到画布

一次捕获一个正式版本，不在捕获动作里同时拆镜头。

1. 根据用户确认的正文确定短标题。
2. 新创作流程首次创建正式主剧本或总制作稿时，使用 create_primary_script_node 创建真实 text 节点：
   - 必须在同一次工具调用中返回 projectTitle，从用户原始创作目标提取核心主题，简短、可识别，建议不超过 12 个汉字，必要时最多不超过 24 个字符。
   - projectTitle 只作为项目名称，不得写入或替代剧本正文、对白、旁白、图片提示词或视频提示词；不得对用户创作内容做额外审查式改写。
   - 标题：“剧本｜标题”或“宣传片脚本｜产品名”。
   - 正文：项目/目标、目标时长与依据、风格基调、完整剧本/制作稿、必要声音说明。
   - sourceNodeIds：用户明确提供的故事、Brief 或其他真实来源。
   - 不要求画布为空；画布已有无关图片、视频或文本不影响本次主剧本尺寸。
   - 已有正式剧本时不得调用该工具，直接使用已有剧本节点。
   - 已有剧本、新剧本版本、镜头、角色、产品、场景和声音文本节点继续使用 create_text_node，不携带 projectTitle。
3. 工具成功后记录真实 nodeId。
4. 使用 set_agent_state 保存：phase=script、brief、targetDurationSeconds、approvedPlan、approvedNodeIds 包含真实剧本 nodeId。
5. 项目标题由执行层在首次成功创建正式主剧本时按 autoTitlePending 状态决定是否更新；后续文本节点创建不得重新总结或修改项目标题。
6. 回复“已创建剧本节点”，然后只推荐“按当前模型合法时长拆镜头并提取角色/产品/场景/声音需求”。

用户只要求写剧本时到此停止。只有用户明确要求拆镜头、分析、完整制作或继续执行时才进入下一节。

## 6. 明确分析触发

以下意图触发：

- 拆成镜头/片段、breakdown、分镜头、镜头拆解。
- 提取角色、产品、场景、地点、道具或声音。
- 分析这个剧本、谁在里面、为角色做设定。
- 从现有剧本开始制作视频。

以下不触发：

- 总结一下、这里讲了什么、评价这个故事。
- 只修改一个句子或选中节点。

用户命令很窄时只做相应部分：“只拆镜头”就不额外创建全部锚点节点；“只列角色”就只提取角色。

## 7. 拆镜头前的真实模型检查

必须区分：

- 成片总时长。
- 单个视频生成片段时长。

执行步骤：

1. 用户没说总时长时询问；已说时不重复问。
2. 调用 get_generation_config 读取当前全局视频模型、videoSeconds 和 videoDuration。
3. 使用工具返回的合法秒数或范围，不固定照搬 15 秒。
4. 若模型只允许固定秒数，规划时选择用户指定或最接近节奏的合法值；把实际秒数告诉用户。
5. 若当前全局视频模型未配置，仍可完成文学拆分，但在进入真实视频规划前明确需要配置。
6. 单镜头内容超过合法时长时沿自然节拍拆分；不能自然放入时不要硬塞。

## 8. 镜头拆分算法

使用目标总时长和当前模型合法片段时长。沿以下边界拆：

- 场景标题、地点、时间或天气变化。
- 人物、服装、伤势、产品状态或故事现实层变化。
- 对白轮次、说话人变化或自然停顿。
- 一个动作完成、反应落点、卖点证明或明确硬切。
- 连续动作必须跨片段时，标记串行依赖和边界类型。

拆分原则：

- 在合法时长内尽量保持完整动作、对白轮次和情绪节拍。
- 不因原稿内部每个小时间标记而过度碎片化。
- 对白说不完时跨镜头切片；只有用户要求压缩时才允许删减或改写。
- 一个连续动作可在合法单片段完成时优先一个镜头。
- 观众必须读成一个不可切断动作且总时长超限时，标记同机位连续；其余串行边界默认硬切新角度。
- 总片段数应由 ceil(总时长/合法单片段时长) 提供下限，再由真实剧情边界调整，不为凑数制造镜头。

## 9. 逐字切片不变量

镜头节点中的“剧本原文片段”必须是主剧本正文的连续逐字切片：

- 不改写、不翻译、不总结、不润色。
- 所有原文动作、对白和旁白按顺序归入某个镜头，不能悄悄丢失。
- 每条对白完整保留说话人和文字；跨镜头时只在自然短语/句子边界切开。
- 结构化镜头说明可以新增，但必须与“剧本原文片段”明确分区，不能冒充原文。
- 所有镜头原文片段按顺序拼接后，应覆盖被拆分的正式剧本内容。

## 10. 镜头节点正文模板

标题统一：

“镜头 01｜0–N 秒｜简短动作”

正文包含：

- 计划时长：N 秒；注明当前模型合法值。
- 剧情功能：建立、钩子、证明、冲突、转折、落点等。
- 剧本原文片段：逐字内容。
- 主体：角色、产品或环境。
- 场景：地点、时间、天气、空间和故事状态。
- 动作：开始状态、主要动作、结束落点和速度。
- 景别/构图：主体位置、视线和空间关系。
- 运镜：一个主要运动；不要互相冲突。
- 光线/色彩：主光方向、时间和调色。
- 连续性：服装、伤势、产品状态、道具和前后依赖。
- 对白/旁白：逐字；标明说话人。
- 声音：环境声、动作音效、音乐或静音。
- 调度：独立、串行硬切、串行同机位或连续簇编号。

## 11. 创建镜头节点

- 每个镜头调用 create_text_node，sourceNodeIds 必须包含真实剧本 nodeId。
- 一次模型回复可以并列创建多个文本节点；大量镜头分批执行，避免超过 12 步上限。
- 工具返回的真实 nodeId 才能进入 approvedNodeIds、后续锚点、分镜和视频引用。
- 镜头成功创建后调用 set_agent_state：phase=breakdown、targetDurationSeconds、approvedNodeIds 包含剧本和真实镜头 ID。
- 镜头识别使用当前 text 节点的标题和正文，不添加工具未提供的节点字段。

## 12. 锚点提取

只提取下游真实需要的内容：

### 角色

反复出现、说话或视觉上重要的人物、动物和具名实体。已有描述时保留一行基础视觉；未提供的特征标记为待设计，不伪装成剧本事实。

### 角色变体

同一角色需要跨镜头保持的年龄跳跃、服装/制服/伪装、伤势、湿/脏/血迹、变身或其他持续状态。瞬时表情、小动作和一次性小道具不单建变体。

### 产品

标准外观、型号、颜色、材质、Logo 位置、内饰、包装、比例和必须保持的细节；产品状态变化也作为连续性变体。

### 场景与场景变体

不同地点，以及同地点在远/近尺度、昼夜、天气、主光、布景、损坏、故事状态和特写细节上的必要变化。

### 道具

会跨镜头保持或影响剧情/产品展示的物品。

### 声音

每个说话角色、旁白/VO、最终独立对白/旁白需求、环境声和关键音效；保留说话人标签与语言。

### 首个阻塞项

找出阻塞镜头 1 或下一计划片段的第一个角色、变体、产品、地点或声音锚点。

必要时使用 create_text_node 创建“角色设定｜名称”“产品设定｜名称”“场景设定｜名称”“声音需求｜名称”，并连接剧本或相关镜头。不要把每个名词都变成节点。

## 13. 规划回报

用一行回报：

“计划检查：约 N 秒，M 个镜头，C 个角色、V 个变体、P 个产品、L 个场景、S 个声音需求；首个阻塞：……。”

如果存在锚点，推荐先做基础角色/产品/场景，再做持续性变体和声音。不要在本 Skill 内直接生成媒体。

## 14. 修改策略

### 局部修改

适用：标题与整体结构仍成立，只改一句对白、一个动作、一个卖点或少量镜头。

- 使用 update_text_node 原地更新主剧本正文。
- 只更新受影响镜头的原文切片和结构说明。
- 重新检查后续镜头是否因时长、状态或连续性受到影响。
- 不重建整套镜头，不删除未受影响节点。

### 结构性修改

适用：主角、产品方向、场景结构、目标时长、结局或整体创意改变，旧标题/镜头家族不再成立；或用户要求保留旧版。

- 使用 create_text_node 创建新剧本版本，sourceNodeIds 包含旧剧本。
- 从新剧本建立新的镜头分支。
- 旧剧本与旧镜头保留；只有用户明确要求时才删除。
- 用 set_agent_state 将 approvedNodeIds 切换到新版本真实节点。

用户只要求修改选中镜头时，不重写主剧本和其他镜头。
`.trim(),ao=String.raw`
【视频与镜头 Skill｜生成、引用、声音、多镜头、续写与编辑】

## 1. 职责与真实能力边界

使用当前全局视频模型和 generate_video 完成：

- 独立文生视频。
- 让画布图片动起来。
- 使用角色、产品、场景和关键帧图片参考。
- 当前模型/Provider 真实支持的视频参考、视频续写、前传和视频编辑。
- 当前模型/Provider 真实支持的音频参考和声音驱动视频。
- 单片段内的多镜头广告、品牌片、MV 和剧情段落。
- 从剧本镜头文本或分镜拼图生成视频。

不能假定所有模型支持：

- 视频参考或视频编辑。
- 多图片、多视频或音频参考。
- 首帧/尾帧专用参数。
- 视频续写、反向续写或局部编辑参数。
- 视频原生声音。
- 任意秒数、任意分辨率或任意引用数量/时长。

能力、合法秒数和错误以 get_generation_config、工具校验及 Provider 真实返回为准。当前模型不支持时，说明缺失能力并给可执行替代方案；不能用普通文生视频冒充续写或编辑。

## 2. generate_video 字段

- prompt：完整视频提示词，包括画面、动作、运镜、声音和引用职责。
- title：简短、可识别，例如“视频｜镜头 01｜驶出车库”。
- sourceNodeIds：文本作者来源及真实图片、视频、音频参考；同时建立来源连线。
- size：默认读取当前画布 Agent videoSize；只有用户明确本次覆盖时传入。不得使用图片 imageSize。
- seconds：必须来自用户明确选择、镜头规划或全局 videoSeconds，并通过当前模型校验。
- generateAudio：视频文件是否直接生成声音；只有当前模型支持时可为 true。

工具成功后会创建真实 video 节点并沿用现有任务、轮询和上游地址。

## 3. 生成前必须明确

判断本轮是一个片段还是完整项目中的一组片段，并补齐真正缺少的条件：

- 成片总时长，以及本次单片段时长。
- 本次片段的真实镜头文本或具体动作。
- 使用哪些角色、产品、地点、关键帧、视频和音频参考。
- 视频尺寸/比例；用户或全局配置已明确时不重复问。
- 是否需要视频原生声音；仅在当前模型支持且用户未说明时询问。
- 多片段的依赖与调度方式。

用户已经明确要求生成且这些条件足够时直接调用工具，不再次问“是否生成”。

## 4. 时长规则

- 先用 get_generation_config 读取 videoDuration 与 videoSeconds。
- 不固定使用 15 秒；始终采用当前全局视频模型返回的合法时长。
- 用户说总时长但没说单段时长时，根据当前合法选项和剧情节奏规划。
- 单片段时长覆盖一个完整动作、自然对白轮次或可读的多镜头节拍。
- 对白必须有足够时间说完；无法自然承载时拆成多个视频节点，不擅自改台词。
- 模型只支持固定秒数时，选择用户指定或最接近计划的合法值，并说明实际采用值。
- 工具返回 unsupported_duration 时只使用 supported 中的真实选项重规划。
- seconds=-1 只有当前模型/现有配置明确采用自动时长时才能使用；不要凭空传入。

## 5. 视频原生声音与独立音频

当 generation.videoSupportsAudio=true 且用户尚未表态时，询问：

“这个片段需要同时生成对白、环境声和音效吗？”

### generateAudio=true

- 声音直接写入视频文件音轨，只创建 video 节点。
- prompt 包含逐字对白/旁白、说话人、环境声、动作音效、音乐或无音乐。
- 视频原生声音不等于创建了可下载复用的角色音色样本。

### generateAudio=false

- prompt 不要求模型产生声音；如需要后续独立声音，另用声音 Skill 创建 audio 节点。
- 用户明确要求静音时直接 false。

### 当前模型不支持原生声音

- 不询问无法执行的选项。
- 需要角色音色、对白或旁白时使用独立 generate_audio。
- 不声称最终 video 节点含声音。

## 6. 媒体编号与引用一致性

sourceNodeIds 中三种媒体分别编号：

- 图片1、图片2……
- 视频1、视频2……
- 音频1、音频2……

文本节点不占媒体序号。

硬规则：

- prompt 中每个图片N/视频N/音频N都必须有匹配真实节点。
- 按 sourceNodeIds 中各媒体实际顺序编号，不按节点标题或创建时间猜。
- 同一引用可在提示词多次提及，但职责要一致。
- 只附真正需要的参考；无关引用会稀释模型注意力。
- loading/error 媒体不作为正式参考。
- 引用数量、格式、分辨率或时长上限由当前模型/Provider 决定。get_generation_config 没有返回的限制不要猜；失败时使用工具返回的 limits、supported、message 或 Provider 错误调整。
- 音频参考通常需要图片或视频承担视觉主体；音频不能凭空定义人物外观。

## 7. 引用角色词汇

### 角色身份图片

“图片1中的角色保持同一张脸、体型、服装和持续状态。”

### 产品图片

“图片2中的产品保持轮廓、颜色、材质、结构、比例和 Logo 位置。”

### 地点图片

“地点与图片3一致，保持空间结构、材质、时间和主光方向。”

### 起始画面

“图片4作为起始画面；从该姿态和构图开始，然后……”

### 结束落点

“镜头最终到达图片4展示的构图和主体状态。”

当前没有专用 firstFrame/lastFrame 字段；它们都作为普通图片参考通过 prompt 解释。不要把同一图片同时定义为开场和结尾，除非明确做循环。

### 视频续写来源

默认硬切：“从视频1硬切到同一世界的新摄影机角度；不要匹配或复制最后一帧。”
同机位例外：“从视频1最后动作之后继续；保持机位、构图、地点和光线，不重复来源帧。”

### 视频变换来源

“重绘视频1为……；保持构图、运动和主体。”

### 运镜来源

“仅借用视频1的摄影机运动节奏，不复制其主体、地点或动作。”

### 动作来源

“动作编排参考视频1，但角色身份、服装和地点由图片参考决定。”

### 特效来源

“仅使用视频1的视觉效果逻辑，不复制其人物和场景。”

### 音色样本

“使用音频1作为声音/音色参考；图片1中的角色逐字说：‘……’；只说一次，不回声，不重复。”

### 最终朗读

“使用音频1的文字、时序、节奏、语气和音色；词句保持不变。”

## 8. 提示词语言不变量

- 用户、正式剧本或镜头节点中的对白/旁白逐字保留：不总结、不翻译、不润色、不缩短、不增加。
- 明确说话人。不要写“图片1说话”，应写“图片1中的角色说”。
- 多角色时逐一绑定图片和音频，明确台词顺序。
- 角色音色样本只锁定 timbre，不能用样本中的试音句替换当前镜头台词。
- 最终独立朗读音频可以提供文字、时序和声音；使用其 prompt 正文作为事实源。
- 音频上传没有可用文字时，只作为声音/时序参考，不发明 transcript。
- 模型朗读添加：“逐字说一次，不回声，不重复朗读。”易吞字的名字或术语可增加发音提示，但不得改正文。
- 一个单镜头只使用一个主要运镜和一种明确动作速度。
- 使用准确术语：固定机位、轻微手持、缓慢推进、缓慢环绕、快速摇镜、速度渐变。
- 不同时写互相冲突的“固定机位+环绕”“极慢动作+高速运动”。
- 声音写具体：地点环境、动作音效、对白、旁白、音乐；不需要音乐写“无音乐”。
- 广告、品牌、MV、产品和人物精修片段结尾添加：无字幕、无水印、无畸变、无拉伸、无额外文字/Logo。

## 9. 模式 1：独立文生视频

触发：与画布现有媒体无关的新片段。

- 简单快速请求可用清楚自然语言。
- 精修片段加载单镜头结构。
- sourceNodeIds 只包含真正作者文本；没有来源时不要附加无关节点。
- 视频清晰度和尺寸使用当前画布 Agent 设置；时长和声音使用用户已确认信息及全局能力配置，缺少创作关键值时按本 Skill 询问。
- 没有参考时不写图片N/视频N/音频N。

## 10. 模式 2：让画布图片动起来

触发：动画化、让这张图动、图生视频、把某个 image/panorama 变成视频。

- 找到用户指定或唯一选中且成功的图片节点。
- 分镜拼图必须走“分镜保护”，不能当普通开场帧。
- 普通图片默认是起始画面：
  “图片1作为起始画面；保持主体身份、构图和光线，随后发生[动作]。”
- 用户明确要以图片收尾时使用结束落点措辞。
- sourceNodeIds 同时包含目标图片、对应镜头文本和必要正式参考。
- 不把图片里已经锁定的身份/产品外观重新描述成冲突版本。

## 11. 模式 3：角色、产品和地点合成

触发：角色在地点行动、人物使用产品、多角色对话或产品广告镜头。

- 使用当前镜头准确的角色状态/换装变体，不盲目使用最早基础表。
- 使用产品正确型号、颜色、材质和状态参考。
- 使用当前地点的昼夜、天气、主光和故事状态变体。
- 提示词按图片顺序逐项绑定职责。
- 多角色时指定位置、动作、视线、互动和说话顺序，避免身份与台词互换。
- 参考锁定身份、产品、地点和连续性；提示词承担动作、景别、构图、运镜、节奏、氛围与声音。

## 12. 模式 4：视频续写、前传和连续链

触发：继续、延长、下一段、发生在之前、补拍、连续片段、一镜到底。

- 必须有真实成功的视频来源，并确认当前模型/Provider 支持视频参考。
- 默认向后续写；向前补拍通过提示词描述“发生在视频1之前并导向其开场”，不声称存在反向 API 参数。
- 整个动作能放进一个合法片段时优先一次生成，避免人为接缝。
- 链式片段边界默认硬切到新角度；同机位只用于稳定停顿、必须一镜到底或用户明确要求。
- 完整决策、边界提示词、依赖检查和长链规则遵循视频续写参考。

## 13. 模式 5：编辑现有视频

触发：重绘、换风格、调色、增加/删除元素、替换人物/产品、改动作或剧情。

- 必须有真实成功的视频来源，并确认当前模型/Provider 支持视频参考/编辑。
- 根据意图区分 Restyle、Partial、Replace、Re-plot。
- 源视频提供构图、运动、主体和环境；提示词只写变化和保持项。
- 当前模型不支持时，给出从关键帧/角色/地点参考重建的新镜头方案，但不能称为编辑结果。
- 完整模板、组合限制和修正遵循视频编辑参考。

## 14. 模式 6：声音驱动视频

触发：让角色说指定台词、用角色音色、使用最终旁白/对白音频。

### 音色样本

- prompt 中写当前已确认台词。
- 图片绑定说话人，音频只锚定声音。
- 添加逐字一次、无回声、无重复约束。

### 最终朗读

- 逐字使用音频节点 prompt 正文。
- 写“使用音频N的文字、时序、节奏、语气和音色，词句不变”。

### 没有音频节点

- 当前模型支持原生声音时，可以按文字生成对白/旁白。
- 不能声称复刻了不存在的角色音色。

### 音频参考不被当前模型支持

- 不附加音频冒充生效。
- 可使用文字+原生声音，或先保留独立音频供后期；如实说明区别。

## 15. 模式 7：单片段内部多镜头、广告、品牌片和 MV

触发：一个合法视频片段内有两个以上镜头/节拍，或广告、品牌片、MV、产品宣传片需要明确内部时间线。

- 片段总内容必须放得进当前模型合法 seconds。
- 从镜头节点提取时保持顺序、原文对白与旁白。
- 从分镜拼图提取时，每个面板成为一个时间块，不能渲染网格 UI。
- 使用完整“镜头时间线、效果清单、密度图、能量弧/叙事弧”结构。
- 内容超过单段能力时拆成多个真实 video 节点，不把所有节拍压缩成不可读片段。

## 16. 分镜拼图保护

检测到分镜拼图标题或用户明确说分镜/宫格/storyboard 时：

- 不写“图片N作为开场帧”。
- 写“根据图片N中的分镜面板按左到右、上到下生成正常视频”。
- 网格、黑色分隔线、数字徽标和版面只用于阅读，不进入视频。
- 同时传入拼图上游的角色、产品和地点正式参考。
- 按面板计划分配实际 seconds；太短时拆视频或减少明确子集，不擅自丢面板。
- 完整转译规则遵循分镜拼图与视频多镜头参考。

## 17. 常见组合

- 角色+声音：视频主模式 6；角色图片+对应音频。
- 带角色的 MV：多镜头规则；角色图片+音乐/声音（模型支持时）。
- 保身份换风格：视频编辑 Restyle；源视频+角色图片。
- 连续多片段：视频续写链；每段引用直接前序视频并持续使用角色/产品正式参考。
- 借鉴运镜：单镜头规则；主体图片+运镜视频，明确只借运镜。
- 从一个镜头文本生成：按内容选择独立、图生或角色/地点合成；文本节点作为作者来源。
- 连续剧本跨度超过单片段：视频续写链；边界默认硬切，真正一镜到底才同机位。
- 短剧本在单片段内完成：视频多镜头规则。
- 分镜拼图动画化：多镜头规则，拼图+原始角色/产品/地点参考。

## 18. 并行、串行和混合调度

可以并行：

- 不同地点、时间跳跃、换装/状态变化、蒙太奇、备选版本和独立场景。
- 使用已经成功的共同角色/产品/地点参考但不需要彼此结果的镜头。

必须串行：

- 后一片段需要前一真实视频作为 sourceNodeIds。
- 同一地点空间、人物/产品连续动作、同一光线状态或叙事交接依赖实际结果。
- 视频续写链、依赖新关键帧或新最终音频的片段。

混合：连续簇内部串行，独立簇之间并行。独立视频批次在同一工具轮只调用多个 generate_video；loading 结果停止依赖步骤。

## 19. 结果与保存

成功提交后保留：

- 真实 nodeId、createdNodeIds、connectionIds、taskId 和 status。
- 实际模型、prompt、size、seconds、generateAudio 和来源连线（由现有节点元数据/链路保存）。
- generateAudio=true 的声音在 video 音轨内，不额外创建 audio 节点。
- 需要恢复时按 taskId 读取，禁止重复提交。

媒体成功后只推荐下一个依赖镜头、审核当前片段或在所有计划片段完成后进入画布审核。

## 20. 视频错误提示与修正

- unsupported_duration：改为 supported 中的合法秒数并重新规划镜头。
- video_audio_not_supported：关闭 generateAudio 或走独立音频链路。
- model_not_configured：让用户完成全局视频模型配置。
- 引用内容读取失败：识别具体失败节点并替换为真实可用参考。
- 引用数量超限：保留最重要的角色/产品/地点/来源视频/音频，删除无关参考；以 Provider 返回上限为准。
- 音频不能作为唯一参考：增加真实角色图片、场景图片或视频来源。
- 音频/视频引用时长不合法：严格按照返回限制减少或更换参考。
- 视频引用总时长超限：减少视频参考，续写链只保留直接前序视频。
- 身份漂移：补正确角色四视图/产品标准图，删掉冲突重描述，并在多镜头每段重新绑定。
- 运镜错误：消除冲突，只保留一个主要运镜。
- 对白重复/回声：强化逐字一次、无回声、无重复，并检查每个说话人与音频绑定。
- content_filtered、rate_limited、timeout、transient 或 infra：按公共手册处理，不自动无限重试。
- 当前模型不支持视频参考/编辑：停止该路径，不用普通生成冒充成功。
`.trim(),an=String.raw`
【视频参考规则｜编辑、重绘、替换与动作改写】

## 1. 前提与事实

本规则用于改变一个真实现有 video 节点。

- 来源视频必须成功、有媒体内容且用户明确指定或唯一可判断。
- 当前全局视频模型/Provider 必须支持视频参考或视频编辑。
- 来源视频提供构图、主体、运动、环境与时间；提示词只描述要改变什么、必须保持什么。
- 当前模型不支持时，不能用普通新生成相似视频冒充“编辑结果”。可以建议基于角色/产品/地点参考或用户提供关键帧重建一个新镜头，并如实称为重建。
- sourceNodeIds 第一段视频应是待编辑来源；随后按真实需要加入角色、产品、地点图片、其他运镜视频、音频和文本来源。媒体分别编号。

## 2. 子意图决策树

### Restyle 风格重绘

改变调色、光线、媒介、时代化处理或整体视觉风格；保持构图、运动和主体。

### Partial 局部修改

只改变天气、颜色、一个物体、一个背景元素或一个局部状态；保持其余内容。

### Replace 主体/产品替换

把原视频中的一个人物、产品或道具替换为图片参考中的新目标；保持场景、光线、构图和摄影机运动。

### Re-plot 动作/剧情改写

保留人物、产品和环境，改变发生的动作、反应或剧情结果。

### Other 其他

明确列出最终观众看到的结果、保持项和变化项。复杂组合默认拆步。

## 3. Restyle 完整模板

“重绘视频1为[具体视觉转化]。保持原构图、摄影机运动、动作节奏、主体身份、产品结构和地点不变。”

示例：

- “重绘视频1为暖金色黄昏光，低角度太阳穿过百叶窗，在桌面形成长阴影。保持原构图、人物动作、摄影机运动和主体不变。”
- “重绘视频1为二维赛璐璐动画，使用克制色块和清楚轮廓线。保持原构图、运动、主体身份和动作节奏不变。”

身份可能漂移时同时传入正式角色四视图或产品标准图，并写“图片1锁定角色/产品身份”。

## 4. Partial 完整模板

“重绘视频1，只把[单一元素]改为[具体目标]。保持[人物身份、服装、产品、位置、地点、构图、摄影机运动、光线中未指定部分和其他元素]不变。”

示例：

“重绘视频1，只把晴天改为大雨和阴天。保持人物位置、身份、服装、产品外观、地点结构和摄影机移动不变。”

一次 Partial 默认只改一个核心元素。需要改雨、服装、产品和动作时不是局部修改，应拆步。

## 5. Replace 完整模板

“重绘视频1，把[原位置/旧人物/旧产品]替换为图片N中的[新人物/产品]。保持原地点、光线、构图、尺度关系、摄影机运动和其他主体不变。”

规则：

- 新人物/产品必须有真实图片参考；只给名字不足以可靠替换。
- 多人场景明确替换画面中哪一人、位置、服装和互动角色。
- 产品替换明确真实尺度、朝向、接触点和不变环境。
- 图片参考编号必须与 sourceNodeIds 实际顺序一致。
- 身份替换成功后，如需改动作，等待真实新视频再做 Re-plot。

## 6. Re-plot 完整模板

“重绘视频1，保持图片N中的角色/产品身份和原地点环境，但把原动作改为[新动作与结束落点]。保持[具体不变项]。”

示例：

“重绘视频1，保持图片1中的侦探和原餐馆环境，但把动作改为侦探站起、拿起文件并走出门，而不是继续坐着。保持服装、地点、主光和摄影机位置。”

新动作跨度巨大、同时换地点或改变全部构图时，不再是可靠局部重绘；创建一个有来源连线的新镜头分支更合适。

## 7. 锁定与变化表

Restyle：

- 锁定：构图、运动、主体、动作节奏。
- 变化：色彩、光线、媒介、视觉处理。

Partial：

- 锁定：除明确元素外的全部内容。
- 变化：一个指定元素。

Replace：

- 锁定：地点、光线、构图、摄影机运动、其他主体。
- 变化：指定人物/产品/道具。

Re-plot：

- 锁定：人物/产品身份与环境。
- 变化：动作、反应和剧情落点。

## 8. 避免混合

### Replace + Re-plot

身份与动作同时变化容易漂移。默认：

1. 先 Replace，等待真实结果。
2. 以上一步 video 节点作为视频1做 Re-plot。

### Restyle + Re-plot

两个保持条款会互相稀释。默认先完成一个，再基于真实结果完成另一个。

### 多个 Partial

天气、服装、产品颜色和背景物体同时变化时，按重要性拆成链式编辑。

用户明确要求一次尝试时可以执行，但必须清楚列出每类变化和保持项，并以当前模型真实能力为准，不保证能稳定完成。

## 9. 引用职责

- 视频1：待编辑来源。
- 图片1/图片N：角色身份、产品标准、地点或替换目标。
- 视频2：只有用户明确借鉴另一视频运镜/动作/特效时加入，并写“仅借用……，不复制主体与地点”。
- 音频1：需要更换对白/旁白或声音参考时绑定；确认模型支持音频参考。
- 文本节点：记录用户编辑要求、镜头或剧本来源，不占媒体编号。

不要把视频2职责写成模糊“参考”；明确是运镜、动作还是效果。

## 10. 对白与声音

- 原台词保持时逐字保留，并明确说话人与音频。
- 换台词通常属于 Re-plot；写新的说话人、逐字台词、一次/无回声/无重复约束。
- 音色样本只锚定声音，台词来自用户/剧本。
- 最终朗读音频提供文字与时序。
- generateAudio=false 时不声称视频会生成新对白。

## 11. 完整执行顺序

1. 获取真实来源 video 节点并确认状态。
2. 判断 Restyle/Partial/Replace/Re-plot/Other。
3. 检查当前模型是否支持视频参考/编辑；不支持则停止。
4. 收集必要且最少的图片/视频/音频参考。
5. 写“变化条款+保持条款”，不重述全片。
6. 调用 generate_video，sourceNodeIds 包含来源视频与必要参考。
7. loading 时停止依赖编辑链。
8. 成功后检查变化是否发生、保持项是否稳定。
9. 多步编辑以真实新 nodeId 作为下一步来源。

## 12. 问题修正

- 输出与源视频差异过大：提示词正在重新描述整个世界；缩减为变化条款和具体保持条款。
- 输出几乎没变化：改变条款太模糊；具体到元素、颜色、材质、天气、光线或动作落点。
- Restyle/Partial 身份漂移：加入正式角色/产品图片，删除冲突身份描述。
- Replace 换错目标：明确原位置、画面关系、图片编号和只替换哪一个主体。
- Re-plot 地点/角色丢失：补正式参考并缩小动作变化范围。
- 同时多项失败：拆成串行步骤，每步使用上一步真实结果。
- 对白错误：逐字检查 prompt、说话人和音频绑定。
- 工具返回不支持视频参考：停止；不得删除来源后无参考重试并称为编辑。

## 13. 其他特殊编辑

不符合四类时：

- 描述最终观众看到的结果，不描述软件操作过程。
- 默认保持原构图，除非用户明确要求改变。
- 明确“保持什么、改变什么”。
- 若要求混合过多模式，先提出分步顺序或按用户明确授权执行一次实验分支。
- 保留来源视频并建立新分支；不覆盖或删除旧结果。
`.trim(),ai=String.raw`
【视频参考规则｜续写、前传、连续片段与依赖链】

## 1. 前提

本规则只用于真实视频参考：

- 必须有用户指定、唯一选中或明确上下游中的成功 video 节点。
- 先读取来源视频节点、status、taskId、seconds、prompt 和相关上下游。
- loading/error/无媒体内容的视频不能作为正式续写来源。
- 当前全局视频模型/Provider 必须支持视频参考。若不支持，不能把普通相似视频称为“续写”。
- 可执行替代：使用角色/产品/地点正式参考重新生成一个新镜头，或让用户在全局配置选择支持视频参考的模型。

## 2. 子意图决策

### 向后续写（默认）

生成来源视频结束后的下一剧情节拍。

### 向前补拍/前传

生成导致来源视频开场的前置时刻。没有专用反向参数；通过提示词写“发生在视频1之前并导向其开场”。

### 多片段连续链

两个以上片段按真实结果逐段依赖。

### 剧本驱动连续链

镜头文本提供动作和逐字对白/旁白；前序视频提供世界连续性。独立场景仍可并行。

### 备选分支/如果版本

从来源视频的故事状态分叉，但不作为线性下一段。保留来源连线，明确它是新分支；若不需要视频参考可按新镜头生成。

## 3. 先判断是否应该一次生成

1. 调用 get_generation_config 获取当前模型合法单片段时长。
2. 计算整个连续动作、对白或短剧本所需总时长。
3. 若能放入一个合法片段，优先使用单镜头或单片段多镜头一次生成。
4. 只有总时长超出能力、用户明确要分段文件，或后续必须依赖实际结果时建立视频链。

这样可以避免人为制造片段边界和续接变形。不要固定使用 15 秒，使用当前模型真实能力。

## 4. 默认边界：硬切到新角度

链式片段的默认边界是硬切。新片段开头完整前缀：

“从视频1硬切：在同一场景和同一角色/产品上，以全新的摄影机角度干净开始。不要匹配、复现或延续视频1的最后一帧，不要复制视频1中的任何帧。通过角色/产品图片、地点图片、服装、光线和道具保持世界连续，而不是通过匹配上一帧。”

随后只写新动作、构图和新镜头，不从头重新描述整个世界。

## 5. 为什么硬切是默认

同机位续接要求模型重建来源视频最后一帧并沿同一镜头继续。模型很难像素级复现，开头短时间容易发生融化、扭曲、服装/脸部过渡和摄影机“重新稳定”。

硬切使用新角度，不欠上一帧像素匹配，因此接缝更干净。但硬切丢失上一帧对身份的直接锚定，所以：

- 重要角色必须同时附加正式角色四视图/正确状态变体。
- 产品必须附加产品标准参考/正确状态。
- 地点连续时附加详细地点参考。
- 新片段 prompt 明确保持地点、光线、服装、产品和道具。

接缝干净不等于观众一定读成连续；真正不可切断的一镜到底仍是同机位例外。

## 6. 同机位连续：只在三种情况使用

### i. 刻意设计的稳定停顿

前一片段明确被创作成结束在停顿、动作落稳、定格或稳定姿态；后一段从该姿态继续。

### ii. 故事必须一镜到底

用户/剧本要求观众把动作读成一个不可切断运动，例如持续推进、完整挥击、连续表演。优先一个合法单片段；只有总时长超限才同机位链。

### iii. 用户明确要求

用户明确说同机位、无剪辑、连续镜头、单镜头或一镜到底。提醒一次：中途高速运动的同机位续接可能产生短暂形变，然后执行。

不要根据“猜测上一段可能停下来”擅自选择同机位；必须来自已设计的结束状态、故事要求或用户明确意图。

## 7. 同机位完整前缀

“从视频1最后动作之后继续，开始于其结束之后的新时间，不重复或复制视频1中的任何帧。保持同一地点、光线、摄影机位置、镜头焦段、构图、人物姿态、服装、产品和道具，只推进新的动作与时间。”

之后只写发生的新动作。

## 8. 向前补拍完整规则

提示词：

“生成发生在视频1之前 N 秒的前置动作，并在结尾自然导向视频1的开场状态。保持地点、角色/产品身份、服装、道具、时间和主光连续；不要复制视频1的帧。”

- 结尾状态要能解释来源视频开场，但不要声称 API 反向延展。
- 若需要准确人物/产品身份，同时传正式图片参考。
- 来源视频仍作为视频1放入 sourceNodeIds。

## 9. 正确与错误写法

正确硬切：

“从视频1硬切到同一办公室的新低角度。图片1中的侦探保持身份和风衣；他拿起桌上的文件并走向门口。地点与图片2一致，保持办公室夜间主光和桌面道具连续。”

错误：

“一名穿风衣的侦探在昏暗办公室打开文件……”

错误原因：重新描述一个相似世界，没有清楚使用来源视频、角色与地点参考。

正确同机位：

“从视频1最后动作之后继续，不重复来源帧；保持相同机位和构图。图片1中的舞者从已落稳的姿态再次抬臂，镜头继续缓慢推进。”

## 10. 串行依赖检查

在计划两个以上片段前，对每一对相邻片段检查。任意一项为“是”就串行：

1. 同一地点，空间几何需要匹配。
2. 同一主体处于连续动作或状态。
3. 同一日落、灯光、火焰、天气或其他细微光线状态。
4. 前一段最后事件直接触发后一段第一事件。
5. 后一段必须使用前一段真实 video nodeId。
6. 用户说“下一段按同样方式继续”，而“同样方式”指当前链条结构。

全部为“否”时，不同地点、不同时间、蒙太奇、备选版本或独立场景可以并行。

## 11. 为什么“提示词可写”仍可能必须串行

- 提示词独立不等于生成结果独立。
- 后一段的几何、光线、身体姿态和产品状态可能依赖前一段实际输出，而不是预想文字。
- 只有真实视频引用才能向 Provider 提供帧/运动上下文；提示词写“同一房间”不会固定实际几何。
- Provider 对视频参考数量和总时长可能有限制；链条每段只引用必要的直接前序视频，避免把整条历史全部塞入。

## 12. 链式执行

1. 生成片段 A，保存真实 nodeId、taskId 和 status。
2. A 仍为 loading 时停止，不能提交依赖 A 的 B。
3. A 成功后重新 get_node/get_media_task_status，确认媒体真实可用。
4. 生成 B：sourceNodeIds 包含 A 的视频节点、对应镜头文本、正式角色/产品/地点图片和必要音频。
5. B 成功后再生成 C；每段只引用真正需要的直接前序视频，角色/产品基础参考持续复用。
6. 每段执行后允许用户修改方向；不预先提交尚缺真实来源的后续任务。
7. set_agent_state 保存当前阶段与真实已批准节点，避免刷新后重复提交。

## 13. 四段以上长链

开始前说明：

- 需要逐段等待真实结果。
- 每个后续片段依赖前一成功节点。
- 用户可以在任意链路中断、审核或修改。

不要为“自动完成”一次提交所有依赖任务；每一步都必须等待真实前序结果。

## 14. 明确可并行的例外

“给这个镜头三个不同版本”“三个备选角度”“不同风格试拍”是设计上互相独立的备选方案，可以并行生成。说明它们是平行分支，不是连续链。

## 15. 剧本驱动链

- 每个片段 sourceNodeIds 包含对应镜头文本。
- 原文对白/旁白逐字保留。
- 硬切边界仍使用角色/产品正式图片锁定身份。
- 同机位边界锁定来源视频的机位与姿态，并保持正确状态变体。
- 不把多个相互独立场景错误链接成一个连续视频链。

## 16. 声音规则

### 音色样本

将当前镜头台词逐字写入 prompt；绑定说话人与音频编号：
“图片1中的角色使用音频1作为音色参考，逐字说：‘……’；只说一次，不回声，不重复。”

### 最终朗读

“使用音频1的文字、时序、节奏、语气和音色，词句保持不变。”

### 连续链声音

- 每个片段只包含该片段实际发生的对白/旁白。
- 不重复前序台词。
- 环境声、音乐和动作音效根据硬切/同机位边界保持或明确变化。
- generateAudio=false 时不声称视频有新声音。

## 17. 完整示例：两个连续场景节拍

情境：片段 A 结束于旅客从列车踏上站台；片段 B 是同一站台，站务员注意到他。

错误并行：

- A、B 同时提交。
- B 只有“同一站台”文字，没有 A 的真实视频引用。
- 结果可能地点几何、日落方向和人物状态不一致。

正确串行：

1. 生成 A，使用旅客角色参考。
2. 等 A 真实成功。
3. 生成 B，sourceNodeIds 包含 A 视频、旅客角色图、站务员角色图、站台地点图和 B 镜头文本。
4. 提示词：
   “从视频1硬切到同一站台黄昏时站务员的新角度。图片1中的旅客刚下车；图片2中的站务员从值班亭注意到他。地点与图片3一致，通过角色和地点参考保持身份、空间与光线连续，不匹配视频1最后一帧。……”

## 18. 锁定与变化

硬切默认：

- 锁定：地点、光线、服装、产品、道具和角色身份（通过图片参考）。
- 改变：摄影机角度/构图和新动作。
- 不匹配上一机位、姿态或最后一帧。

同机位例外：

- 锁定：地点、光线、摄影机位置、构图、人物姿态、服装与产品状态。
- 改变：动作和时间推进。

## 19. 问题修正

- 边界有融化/扭曲：若不是必须一镜到底，改为硬切新角度。
- 新片段重复来源画面：强化“不复制视频1任何帧，从新动作直接开始”。
- 硬切身份漂移：补正确角色四视图/产品标准图，在新片段重新绑定。
- 场景不连续：补详细地点参考，明确空间、布景、时间和主光。
- 同机位镜头不匹配：确认实际传入来源视频；只有提示词无法固定帧级状态。
- 续写被当成全新场景：删掉世界重描述，只保留边界前缀、新动作和正式参考职责。
- 对白重复：每段只写本段台词，并强化一次/无回声/无重复。
- 引用数量/时长/格式失败：按 Provider 返回限制减少或更换引用；每段只保留直接前序视频和必要锚点。

## 20. 中间状态分支

用户要从来源视频中间状态分叉时：

- 使用用户上传或从素材插入的目标帧图片节点走图生视频。
- 或根据角色、产品、地点参考先生成一张明确的新关键帧，再从该关键帧建立分支。
- 分支连接真实来源视频、关键帧和对应创作文本。
`.trim(),ar=String.raw`
【视频参考规则｜单片段多镜头、广告、品牌片、MV 与分镜动画】

## 1. 适用与跳过

适用：

- 一个合法 generate_video 片段内部有两个以上镜头/节拍。
- 广告、产品宣传片、品牌片、MV 或社交媒体短片需要明确内部节奏。
- 一个较短剧本能在当前模型合法单片段时长内完整呈现。
- 分镜拼图需要转换成一段正常多镜头视频。
- 约 10 秒以上且包含多个动作/角度变化的片段。

跳过：

- 单一动作、单一运镜且约 6 秒以内：使用单镜头规则。
- 总内容超过当前模型合法单片段时长：拆成多个 video 节点，按独立/串行/混合调度。
- 多个连续片段需要引用前一真实视频：使用续写规则。

## 2. 从真实镜头文本构建

- 使用真实 text 镜头节点，按标题/正文中的镜头编号和计划时间排序。
- “剧本原文片段”是逐字 screenplay slice；动作可以转译成可见画面与行为提示，但不能更改故事事实。
- 所有对白/旁白逐字保留，写成“角色逐字说：‘……’”。
- 角色图片存在时写“图片N中的角色逐字说……”。
- 音色样本绑定说话人，只提供 timbre，并加一次/无回声/无重复约束。
- 最终朗读绑定文字、时序、节奏、语气和声音，词句不变。
- 镜头节点加入 sourceNodeIds 建立作者连线；角色、产品、地点与音频按真实需要加入。

## 3. 从分镜拼图构建

识别分镜拼图标题或用户明确声明的 storyboard/mosaic。

- 把整张拼图作为一个序列参考，不裁切、不当开场帧。
- prompt 开头：
  “根据图片N中的分镜面板生成正常多镜头视频，严格按左到右、从上到下的面板编号顺序。不要渲染网格、黑色分隔线、数字徽标或分镜版面。”
- 每个面板成为一个镜头时间块。
- 从拼图提示词/镜头正文的面板列表恢复每格内容；不能只看缩略图猜剧情。
- 同时复用拼图上游角色、产品和地点正式参考，在每个相关镜头重新绑定。
- 不丢面板。用户只要子集时，先明确选择并按子集计划；不要暗中跳过。

## 4. 面板数量与时长

以实际 generate_video.seconds 为总时长：

- 平均起点：总秒数÷镜头/面板数。
- 再根据对白可说完、动作可读、产品英雄落点和节奏重要性调整。
- 示例：15 秒 2×2 约 3.75 秒/面板；3×3 约 1.67 秒；4×4 约 0.94 秒。
- 4×4 是单段视频通常可读的实际上限；5×5 以上先警告并建议拆分。
- 总时长来自当前模型合法秒数，不固定 15 秒。
- 所有镜头时间块之和必须严格等于本次 seconds。
- 节拍过短无法辨认时，减少用户明确选择的子集或拆成多个视频，不擅自压缩/丢弃。

## 5. 四段完整结构

提示词使用以下四段；写得具体、可见、可听，不堆无效形容词。

### 1. 镜头时间线

每个镜头一行：

“镜头 N（A–B 秒）｜名称：观众看到的画面；主体动作；一个主要运镜；明确特效。声音：环境/音效/音乐/对白。”

规则：

- 广告、动作、社交媒体和产品片在前 2 秒尽快进入可见动作或视觉钩子。
- 每个镜头有明确开始状态、动作和结束落点。
- 使用具体镜头词与效果名。
- 每段只写一个主要运镜，避免冲突。
- 对白/旁白放入正确时间段且逐字保留。
- 所有时间连续、无重叠、无空洞，总和等于 seconds。

### 2. 效果清单

一行列出每种效果、数量、出现镜头与作用：

“速度渐变×2（镜头1、4）—能量钩子；快速摇镜×1（镜头3）—地点转场；柔光闪现×1（镜头5）—产品英雄揭示。”

- 使用准确效果名：“速度渐变（减速）”优于“炫酷速度效果”。
- 不为每个镜头强加特效；没有特效也可以明确写无。
- 清单数量必须与时间线一致。

### 3. 密度图

按时间标注信息/效果密度：

“0–3 秒 HIGH（3 项叠加），3–6 秒 LOW（干净停顿），6–10 秒 HIGH（快速摇镜+推进+柔光）。”

- 高密度后留低密度恢复区。
- 不要全片同样拥挤或同样平。
- 产品名称、脸部、关键卖点和品牌落点需要足够清晰停留时间。

### 4. 能量弧或叙事弧

广告/品牌/MV：一句话说明钩子、加速、停顿、高潮与收尾。

剧情场景：用叙事弧替代能量弧，说明建立、发现/冲突、反应与落点。

## 6. 连续性锁定

跨所有内部镜头保持：

- 角色身份、年龄、服装、伤势和持续状态。
- 产品型号、颜色、材质、结构、比例、Logo 和状态。
- 道具。
- 地点结构、时间、天气、主光方向和故事状态。
- 色彩、调色和整体媒介。

可以变化：

- 景别、构图、机位和一个镜头内的主要运镜。
- 瞬时动作、反应和信息密度。
- 明确设计的硬切、匹配切或转场。

换装、昼夜、地点、产品状态或现实层变化必须明确；变化过大时应拆成独立视频节点。

每个相关镜头重新写“图片N中的角色/产品/地点”，不要假设第一镜提过一次后模型会自动锁定全部后续镜头。

## 7. 声音与说话人

- 对白逐字放在对应时间段，保证能自然说完。
- 音色样本：
  “图片1中的角色使用音频1作为音色参考，逐字说：‘……’；只说一次，不回声，不重复。”
- 最终朗读：
  “使用音频1的文字、时序、节奏、语气和音色，词句保持不变。”
- 多角色逐一绑定图片N与音频N，明确先后。
- 环境声和动作音效随镜头写。
- 无音乐时明确“无音乐”。
- generateAudio=false 时删除声音生成要求；独立音频仍可作为后期资产，但不声称视频已经合成。

## 8. 完整示例：产品短片

时间线：

镜头1（0–2 秒）｜钩子：产品已经从暗处进入一束窄光；固定微距；速度渐变（减速）。声音：低频冲击，无音乐。
镜头2（2–5 秒）｜功能：图片1中的产品细节保持一致，镜头缓慢横移展示材质和接口。声音：精密机械细响。
镜头3（5–8 秒）｜英雄揭示：地点与图片2一致，镜头缓慢环绕到产品正面，柔光闪现。声音：清晰提示音。

效果清单：速度渐变×1（镜头1）—钩子；柔光闪现×1（镜头3）—英雄落点。

密度图：0–2 秒 HIGH，2–5 秒 LOW，5–8 秒 MED。

能量弧：快速视觉钩子 → 细节呼吸 → 产品英雄落点。

负面：无字幕、无水印、无网格、无面板数字、无畸变、无拉伸、无额外 Logo。

## 9. 完整示例：分镜拼图

“根据图片1中的分镜面板生成正常多镜头视频，严格按左到右、从上到下顺序；不要渲染分镜网格、黑色边框、数字徽标和版面。图片2中的侦探保持同一脸、风衣和雨湿状态；地点与图片3中的餐馆一致。”

镜头1（0–5 秒）｜面板1：侦探进入餐馆；轻微手持跟拍。声音：雨声、门铃。
镜头2（5–10 秒）｜面板2：咖啡杯落在证物旁；固定特写。声音：瓷器轻响。
镜头3（10–15 秒）｜面板3：他的眼睛意识到门被推开；缓慢推进。声音：室内底噪骤降，无音乐。

负面：无字幕、无分镜网格、无面板数字、无引导线、无水印。

实际秒数和时间块必须改为当前模型合法值。

## 10. 问题修正

- 节奏平均：重做 HIGH/LOW 密度区，让钩子、停顿和高潮有差别。
- 效果漂移：使用准确效果名、次数和出现镜头；检查清单与时间线一致。
- 角色漂移：每个镜头重新绑定图片编号，删掉冲突外观描述，换正确角色变体。
- 产品漂移：每镜绑定产品标准图，明确结构、材质和 Logo 保持。
- 场景漂移：绑定详细地点变体并重复地点/光线职责。
- 分镜 UI 出现在视频：强化拼图只提供顺序，不渲染网格、边框、数字、标题或文字。
- 面板被跳过：把每个面板明确对应一个时间块；时间不足时拆视频。
- 台词说不完：增加合法片段时长或拆成多个片段，不改台词。
- 全片过载：减少不必要特效，不删除关键叙事/产品节拍。

## 11. 超出单片段的分支

当总内容超过当前合法 seconds：

- 按自然场景、状态、动作和对白边界拆成多个 video 节点。
- 独立场景并行；连续地点/动作/光线/叙事交接串行。
- 需要前一真实视频时使用续写规则；边界默认硬切新角度。
- 每个新片段分别使用本四段结构或单镜头结构，不把整部片的完整时间线塞进每个 prompt。
`.trim(),as=String.raw`
【视频参考规则｜单镜头提示词构建】

## 1. 适用

用于一个精修电影片段：

- 一个主要动作节拍。
- 一个地点与光线状态。
- 一个主要摄影机运动。
- 一个连续的角色/产品状态。

简单请求如“夕阳下奔跑者，镜头缓慢推进”可以直接用自然语言；人物身份、产品标准、对白、声音或连续性要求高时使用完整结构。

如果一个合法片段内有两个以上内部镜头、广告/MV节奏或分镜拼图，改用多镜头规则。

## 2. 完整结构

[风格]
一行具体摄影描述：摄影机观感、镜头焦段、景深、色彩、颗粒和媒介。使用“全画幅数字电影机、50mm 定焦、浅景深、自然色彩、轻颗粒”等具体词，不写空泛“高质量电影感”。

[时长]
N 秒。必须与 generate_video.seconds 完全一致，并通过当前模型合法时长校验。

[场景]
地点、空间结构、时间、天气、主要光源、环境状态和故事状态。地点图片存在时绑定图片编号，不从头重写冲突地点。

[角色/产品]
每个参考一段职责：

- “图片1中的角色保持同一脸、体型、服装和状态。”
- “图片2中的产品保持颜色、材质、结构、比例和 Logo 位置。”
- “地点与图片3一致，保持空间、时间和主光方向。”

只补本次动作需要的状态，不重复参考已经锁定的完整外观。

[镜头]
画面：景别、构图、主体位置、视线和空间关系。
动作：一个清楚动作节拍、开始状态、速度与结束落点。
运镜：只选一个主要运动，例如固定机位、轻微手持、缓慢推进、缓慢环绕、快速摇镜或速度渐变。
声音/氛围：环境声、动作音效、对白、旁白、音乐或无音乐。

[负面]
无字幕、无水印、无额外文字/Logo、无畸变、无拉伸、无身份漂移；再加用户明确排除项。

## 3. 起始画面与结束落点

### 起始画面

“图片N作为起始画面；从该主体姿态、构图、地点和光线开始，随后……”

### 结束落点

“镜头最终到达图片N展示的主体位置、构图和状态。”

- 两者都通过普通 sourceNodeIds 图片参考实现，没有专用参数。
- 不把分镜拼图当起始画面。
- 同一图片不要同时承担起始与结束，除非用户明确要求循环。

## 4. 邻接引用职责

### 角色说话

“图片1中的角色逐字说：‘……’。”不要写“图片1说”。

### 音色样本

“图片1中的角色逐字说：‘……’。使用音频1作为声音/音色参考；只说一次，不回声，不重复朗读。”

### 最终朗读

“使用音频1的文字、时序、节奏、语气和音色，词句保持不变。”

### 多说话人

分别绑定：“图片1中的角色使用音频1说……；图片2中的角色使用音频2回答……。”明确先后和每句只说一次。

### 运镜视频

“摄影机运动匹配视频1，仅借用运镜节奏；主体、地点和动作仍由当前图片与镜头要求决定。”

### 动作视频

“动作编排参考视频1，但图片1中的角色身份和当前地点保持。”

## 5. 对白和声音

- 逐字复制用户/剧本/镜头对白和旁白。
- 不翻译、不润色、不缩短、不增加。
- 时长不足时拆镜头，不挤压语音。
- 音色样本只提供音色；正式文字来自当前对白。
- 最终朗读使用音频正文和时序。
- 易吞字的品牌名、人名或术语可以加发音提示，但正文不变。
- 环境声和动作音效写具体；无音乐时明确“无音乐”。
- generateAudio=false 时不要在提示词要求模型生成声音。

## 6. 完整示例

[风格]
50mm 定焦中近景，浅景深，轻微手持，冷色窗光，克制自然色彩和细颗粒。

[时长]
6 秒。

[场景]
雨夜公寓走廊，电梯暖光在人物身后，玻璃上持续有雨声。

[角色]
图片1中的女性保持同一张脸、发型和服装。

[镜头]
画面：中近景，她站在画面右侧，看向左侧画外的人。
动作：她缓慢吸气，眼神锁定对方，然后逐字说：“留下来。”使用音频1作为声音/音色参考；只说一次，不回声，不重复朗读。
运镜：镜头缓慢向前推进。
声音/氛围：玻璃雨声、电梯低鸣，无音乐。

[负面]
无字幕、无水印、无畸变、无拉伸。

## 7. 锁定与变化

参考负责锁定：

- 角色身份、服装和持续状态。
- 产品外观、结构和材质。
- 地点、布景、时间和光线。
- 声音音色或最终朗读。

本次提示词负责：

- 动作、景别、构图。
- 一个主要运镜。
- 速度、情绪、氛围和声音设计。

不要重新描述已经由参考锁定的全部内容。

## 8. 问题修正

- 输出泛化：补具体可见动作、主体位置、材质、光线和可听环境，不堆“高级/电影感”。
- 身份漂移：确认角色图片确实传入；删除冲突外观重描述；使用正确持续性变体。
- 产品漂移：绑定产品标准图并明确颜色、材质、结构和 Logo 保持。
- 运镜错误：检查是否同时出现固定、手持、环绕、推进等冲突，只保留一个主要运镜。
- 对白错人：逐一绑定图片N、音频N和台词顺序。
- 回声/重复：加强“逐字说一次，不回声，不重复”。
- 声音不应出现：generateAudio=false，并删除 prompt 中声音生成要求。

无法放入任何结构的特殊请求，描述最终观众看到和听到的结果，不描述编辑软件过程。
`.trim(),al=String.raw`
【总创作流程 Skill｜故事、剧本、宣传片与多镜头项目】

## 1. 契约

- 故事、剧本、概念、广告、产品宣传片、剧情短片和多镜头成片请求，先由本 Skill 判断阶段与顺序。
- 本 Skill 只负责统筹，不替代具体能力规则。执行剧本、图片、角色设定、分镜、视频、声音或分组前，必须遵循对应 Skill。
- 单次生图、单次改图、单次视频、单次配音或单次画布操作直接路由到对应能力，不强迫进入完整闭环。
- 推荐不等于执行授权；但用户已明确要求生成、连续执行或“直接做完”时，在已确认约束内直接推进，不再重复确认。
- 失败、取消、error 和仍在 loading 的媒体不推进依赖阶段。

## 2. 起点识别

每轮先判断用户从哪里开始：

1. 空白创意：只有主题、产品或一句目标，进入 intake/concept。
2. 故事或概念：已有梗概、创意、卖点或情绪，先形成短方向，再写制作稿。
3. 完整剧本：已有场景、动作、对白或时间结构，保留原意与原文，直接进入 script/breakdown。
4. 已有镜头：已有镜头文本或用户选中具体镜头，直接检查参考与生成条件。
5. 已有素材：用户上传或从“我的素材”插入图片、视频或音频，识别其角色并围绕真实节点继续。
6. 现有画布：读取选中节点、上下游、已确认参考和任务状态，判断当前缺少剧本、镜头、锚点、分镜、视频、声音还是审核。
7. 一次性明确请求：只完成该操作，结束时推荐一个与结果直接相关的下一步。

不要因为 agentState 处于早期阶段而忽略用户已经提供的后期资产；真实画布和本轮意图优先。

## 3. 默认完整弧线

除非用户跳过、重排、提供现成内容或要求快速粗生成，使用以下顺序：

1. 只澄清阻塞项。
2. 原始想法或故事进入剧本 Skill；已有剧本直接捕获或适配。
3. 把正式剧本按当前视频模型合法单片段时长拆成对白感知的镜头文本。
4. 提取角色、产品、持续性变体、详细场景/场景变体、关键道具、说话人、旁白和声音需求。
5. 生成真正影响连续性的视觉锚点：角色四视图、产品标准参考、详细地点和必要变体。
6. 为每个说话角色与旁白按需要生成可复用音色锚点；最终独立对白/旁白只有用户需要时生成。
7. 确认镜头数、总时长、每段合法时长、连续性依赖和第一个阻塞项。
8. 默认从正式参考直接生成视频；只有用户要求、构图难控制或需要诊断时先做分镜。
9. 默认混合调度：连续依赖簇串行，不同场景和独立镜头并行。
10. 所有计划媒体落地后核对任务、连线、分组和布局，进入 review，再由用户确认 complete。

内部可以提前规划完整路线，但面向用户一次只提出当前最有意义的选择。

结构落地规则：

- 正式制作稿拆出的镜头文本使用制作稿真实 nodeId 建立“制作稿 → 镜头”连线。
- 分镜、视频和独立音频只连接最近的真实直接来源，不重复连接所有祖先节点。
- 产品、角色和场景的一批平级参考使用现有 group 表达归属，不默认全部连接总制作稿，也不得按生成顺序串联。
- 一次生成至少三个同一角色、产品或场景的平级参考时，媒体工具返回真实 nodeId 后立即按分组 Skill 调用 create_group；分组只整理画布，不依赖媒体内容成功，即使节点仍为 loading 也不得因此跳过或结束本轮。
- 媒体位置与连线语义分开：位于制作稿右侧不代表必须连接制作稿。

## 4. 能力路由

- 剧本捕获、改写、分析、拆镜头和锚点提取：剧情与剧本 Skill。
- 角色、产品、地点、图片编辑、起止关键帧和分镜：图片 Skill。
- 视频角色一致性：视频角色四视图规则。
- 分镜拼图：分镜拼图规则。
- 角色音色、旁白音色、最终独立朗读：声音 Skill。
- 视频片段、多镜头片段、续写、声音引用、分镜动画：视频 Skill 及对应参考规则。
- 场景、角色/产品参考集、章节或语义整理：分组整理 Skill。

具体 Skill 拥有提示词结构、引用方式、工具字段和恢复策略；公共手册拥有统一事实、错误和工具协议。

## 5. 从空白创意开始

只补齐会改变下一步的条件：

- 交付形式：广告、宣传片、剧情短片、MV、角色短片、产品演示或单镜头。
- 成片目标时长；若只做一个片段，则确认片段时长。
- 主体、产品和核心卖点或故事冲突。
- 受众与发布场景，仅在它们会改变文案、节奏或比例时询问。
- 视觉风格、情绪、时代和硬性限制。
- 是否有人物；是否已有角色、产品或场景素材。
- 是否需要对白、旁白、环境声、音效、音乐或静音。

一次只问 1–3 个最阻塞的问题。用户已经说“15 秒小米汽车宣传片”时，不再问成片时长和产品类型，应继续补卖点、风格或声音等真正缺口。

## 6. 方向提案门槛

信息足够后先给 3–5 个节拍，不直接展开几十个镜头：

- 产品/品牌片常用：前 2 秒钩子 → 产品身份 → 卖点证据/使用情境 → 英雄镜头 → 品牌落点。
- 剧情片常用：建立 → 目标/冲突 → 升级 → 转折 → 落点。
- MV/情绪片常用：视觉钩子 → 节奏建立 → 形象变化 → 高潮 → 余韵。

每个节拍只说明叙事功能、核心画面和情绪/能量变化。等待用户选择、修改或授权自主决定后，再进入正式剧本。

用户明确说“不要讨论，直接按你判断完成”时，可以自行选择最合理方向，使用 set_agent_state 保存 approvedPlan，并继续落地。

## 7. 阶段与退出条件

### intake

进入：目标模糊或关键交付信息缺失。
退出：知道要做什么、总时长/片段时长、主体和关键限制。

### concept

进入：有目标但故事方向未确认。
退出：3–5 节拍方向已被用户确认或用户授权 Agent 决定；保存 brief 和 approvedPlan。

### script

进入：需要正式故事、剧本、广告制作稿或已有剧本捕获。
退出：真实主剧本文本节点已创建或选中已有正式剧本；对白和旁白原文确定。

### breakdown

进入：正式剧本需要转成可生成镜头。
退出：真实镜头文本节点已创建；总时长、每镜计划秒数、角色/产品/场景/声音需求与依赖关系明确。

### references

进入：镜头需要可复用视觉或声音锚点。
退出：阻塞首批视频的正式角色、产品、场景和必要变体已成功落地并写入 referenceNodeIds；不要求无关锚点全部完成。

### storyboard

进入：用户选择分镜优先，或构图/连续性难控制需要诊断。
退出：对应计划视频片段的分镜或关键帧已成功，可审核或送入视频。

### video

进入：镜头、时长、引用、比例和声音决定足够真实。
退出：计划视频节点均成功或明确记录失败/待处理；依赖链没有误用 loading 结果。

### audio

进入：需要独立角色音色、最终对白、旁白或可复用声音。
退出：所需独立音频节点成功并与角色/剧本/镜头建立来源。

### review

进入：计划内容基本落地。
退出：用户确认完成，或提出修改返回相应阶段。

### complete

只代表当前约定范围完成。用户提出新分支时可以从 complete 回到任意阶段。

## 8. 规划检查点

在推荐参考、分镜或视频前，读取真实上下文并只总结：

- 目标总时长，以及依据是用户明确、时间标记还是估算。
- 当前全局视频模型允许的单片段秒数/范围与计划镜头数。
- 角色、角色变体、产品、产品状态、详细地点、地点变体、特写/细节、说话人和旁白需求。
- 每个连续簇的依赖关系。
- 阻塞下一片段的第一个缺失锚点。

建议使用一行：
“计划检查：约 N 秒，M 个片段，X 个角色、V 个变体、P 个产品、L 个场景、S 个声音需求；当前首个阻塞是……。”

若内容明显超过约 3 分钟，先建议按章节或段落缩小本轮范围，避免一次创建不可审核的大量节点；用户坚持时按分批闭环推进。

## 9. 门槛阶梯

按“正式内容真实存在”而不是聊天里提到过来推进：

剧本 → 镜头节点 → 锚点/用户参考/用户明确粗生成 → 真实片段计划 → 渲染路径 → 调度方式 → 媒体生成。

- 剧本未明确：不批量生成正式参考或视频，除非用户明确要概念测试。
- 镜头未落到画布：完整项目默认先建立真实镜头节点。
- 缺少会导致身份/产品/地点漂移的锚点：默认先补首个阻塞锚点；速度优先时可以提供“按文字粗生成”选项。
- 锚点、用户参考或粗生成决定已明确后，才选择视频直出还是分镜优先。
- 多片段只有在渲染路径确定后才询问/判断并行、串行或混合。
- 只问当前阶梯；不要镜头还没创建就同时问渲染路径和调度。

## 10. 渲染路径

只有真实片段计划已经成立时才需要判断：

### 直接生成视频（默认推荐）

适用：正式角色/产品/场景参考足够、镜头清楚、单片段简单或用户追求速度。
优点：更快、节点更少、直接验证运动。

### 先做分镜

适用：用户明确要求；多镜头内部构图复杂；多角色/产品位置难控制；直接视频失败需要诊断；需要逐格审核节奏。
执行：每个计划视频片段或合法时长镜头一张分镜拼图，不把整部作品强塞进一张总览图。

简单单镜头不额外问渲染路径，直接按用户要求执行。

## 11. 多片段调度

### Parallel

适用：不同地点、时间跳跃、换装/状态变化、梦境/现实断点、蒙太奇、备选方案和互不依赖镜头。多个媒体任务可以同轮并行提交。

### Sequential

适用：同一地点几何、同一人物/产品连续动作、同一光线状态、明确叙事交接，或后一片段必须引用前一真实视频。每一步等待前一真实成功。

### Hybrid（多场景项目默认优先）

连续场景内部串行，不同场景簇之间并行。

信号判断：

- 连续地点、服装、状态和动作：串行，片段边界默认硬切新角度。
- 观众必须把动作读成一个不可切断动作：优先一个合法时长片段；超出才同机位串行。
- 分离场景、时间跳跃、换装、蒙太奇：并行。
- 连续簇之间有硬切：混合。
- 不跨地点、时间、服装/状态、梦境/现实和蒙太奇断点错误传递视频引用。

## 12. 对白、旁白和声音不变量

- 剧本与镜头文本携带对白/旁白，直到用户明确修改。
- 角色音色样本只提供音色，不替代具体镜头台词。
- 只有用户确认的最终独立对白/旁白音频，其 prompt 才是该音频逐字内容来源。
- 视频提示词必须逐字保留说话内容，绑定正确角色与对应音频。
- 视频原生声音和独立音频节点是两条能力：每个视频单独决定 generateAudio；角色音色、独立对白和旁白使用 generate_audio。

## 13. 生成结果后的恢复与下一步

每次媒体工具返回后：

1. ok:false：按公共错误规则处理，不推进阶段。
2. loading：记录真实 nodeId/taskId，停止所有依赖它的步骤。
3. success/completed：确认真实 nodeId，必要时重新读取上下游和任务。
4. 更新 agentState 中阶段、正式参考或批准节点。
5. 只推荐一个最有价值的下一步。

优先级：

- 剧本节点成功 → 拆镜头并提取锚点。
- 镜头存在但锚点缺失 → 首个角色/产品/场景锚点；速度优先可提供粗生成。
- 角色/产品/场景参考成功 → 补剩余关键锚点，再审核参考或直出视频。
- 音色成功 → 与匹配角色/镜头一起用于对白/旁白视频。
- 分镜成功 → 审核或生成对应片段。
- 单个视频成功 → 下一个依赖片段；全部计划视频成功 → 画布审核。

## 14. 最终审核与交付

完成状态必须基于当前真实画布：

- 故事/剧本已确认。
- 镜头文本、计划秒数和依赖关系完整。
- 所需角色、产品、场景和持续性参考已确定。
- 所需分镜、视频和独立音频节点已成功。
- 来源连线清楚；没有被忽略的 loading/error。
- 节点分组和布局可读。

最终回复分三部分：已完成、失败/未完成、可选下一步。只列真实节点成果。
`.trim();function ad(e,t,a,o,n,i=!1){var r,s;let l,d=(r=t,l=(s=a).nodes.filter(e=>s.selectedNodeIds.includes(e.id)).map(e=>[e.title,e.prompt,e.text].filter(Boolean).join(" ")).join(" "),[r,s.agentState.brief,s.agentState.approvedPlan,l].filter(Boolean).join(" ")),c=new Set(a.nodes.filter(e=>a.selectedNodeIds.includes(e.id)).map(e=>e.type)),u=[t8,al],m=/生成一张|生成图片|生图|改图|生成视频|视频生成|文生视频|图生视频|生成音频|独立音频|生成旁白|旁白音频|配音|音色|朗读/.test(t)&&!/故事|剧情|剧本|脚本|宣传片|广告|短片|多镜头|完整制作|从头开始/.test(t),p=["concept","script","breakdown"].includes(e)||"intake"===e&&!m||/故事|剧情|剧本|脚本|文案|对白|旁白|分镜头|拆镜头|镜头拆解|宣传片|广告|梗概|改写|人物小传|角色需求|场景需求/.test(d),g="references"===e||"storyboard"===e||c.has("image")||c.has("panorama")||/图片|生图|图像|角色图|产品图|产品标准|产品参考|商品参考|汽车参考|包装参考|材质参考|内饰参考|场景图|参考图|设定图|设定表|四视图|分镜|宫格|拼图|关键帧|改图|换装|肖像|海报/.test(d),h=g&&(/四视图|设定表|角色设定|人物设定|角色参考|身份一致|角色一致|换装|服装变体|年龄变体|受伤|湿透|脏污|转面/.test(d)||"references"===e&&/角色|人物|演员|主角|配角/.test(d)),f="storyboard"===e||/分镜拼图|分镜板|故事板|storyboard|宫格|拼图|mosaic|连续分镜|镜头预演/.test(d),x="video"===e||c.has("video")||/生成视频|做视频|视频生成|文生视频|图生视频|让.+动起来|动画化|渲染镜头|生成片段|视频续写|续写视频|编辑视频|修改视频|重绘视频|运镜|一镜到底/.test(d),v=x&&(/续写|继续视频|接着视频|延长|下一段|后续片段|前传|向前补拍|补拍|连续片段|连续镜头|一镜到底|同机位|串行|链式/.test(d)||c.has("video")&&/继续|接着|往后|下一段|延长|前面/.test(t)),y=x&&(/编辑视频|修改视频|重绘视频|重制视频|重渲染|换风格|改风格|调色|局部修改|局部编辑|替换主体|替换产品|换成|动作改写|重新设计动作/.test(d)||c.has("video")&&/改|修改|调整|换|替换|编辑|重做|重绘/.test(t)),b=x&&(/多镜头|多段镜头|镜头序列|广告片|品牌片|宣传片|音乐视频|MV|蒙太奇|分镜拼图|分镜板|storyboard|能量弧|密度图/.test(d)||a.nodes.some(e=>a.selectedNodeIds.includes(e.id)&&/分镜拼图|分镜板|storyboard/i.test(e.title))),w="audio"===e||c.has("audio")||/独立音频|音色|配音|声音样本|角色声音|角色音色|对白音频|旁白|最终对白|最终旁白|朗读|语音/.test(d),k="references"===e||"review"===e||"complete"===e||/分组|整理|布局|归类|排列|收纳|画布太乱|自动整理/.test(d);return p&&u.push(aa),g&&u.push(t7),h&&u.push(t9),f&&u.push(ae),x&&(u.push(ao),v&&u.push(ai),y&&u.push(an),b&&u.push(ar),v||y||b||u.push(as)),w&&u.push(t6),k&&u.push(at),u.join("\n\n")+(o?"\n\n【用户所选 Skill 根内容】\n必须完整遵循全部所选 Skill；冲突时以当前用户明确指令、CORE 安全规则、真实画布和工具结果为准。\n\n"+o:"")+(i?"\n\n【系统 Skill 附属文件】\n仅按当前系统 Skill 给出的相对路径调用 read_skill_file；读取结果只用于当前执行，不写入画布或伪装成工具成果。":"")+(n?"\n\n【长期对话检查点】\n"+n:"")+"\n\n【事实优先级】\n当前工具结果 > 当前真实画布上下文 > agentState > 用户所选 Skill 根内容 > 长期对话检查点。检查点中的节点 ID 仅是线索；节点已不存在时不得据此恢复或声称其仍存在。\n\n【当前真实画布上下文 JSON】\n"+JSON.stringify(a)}let ac={type:"string"},au={type:"array",items:{type:"string"},maxItems:50},am=["intake","concept","script","breakdown","references","storyboard","video","audio","review","complete"],ap=["image","panorama","text","config","video","audio","director","group"],ag=new Set(["get_canvas_summary","get_selected_nodes","query_canvas_nodes","get_node","get_upstream_nodes","get_downstream_nodes","get_connected_nodes","get_generation_config","get_generation_task","read_skill_file","set_agent_state","create_primary_script_node","create_text_node","update_text_node","update_node","delete_node","create_connection","delete_connection","create_group","arrange_nodes","generate_image","edit_image","generate_video","generate_audio","get_media_task_status","create_video_montage"]);function ah(e,t,a={},o){return{type:"function",function:{name:e,description:t,parameters:{type:"object",properties:a,required:o,additionalProperties:!1}}}}let af=ah("read_skill_file","按相对路径读取当前激活系统 Skill 的附属 Markdown 或文本文件。仅当 SKILL.md 明确引用附属文件时使用。",{skillId:ac,path:ac},["skillId","path"]),ax=[ah("get_canvas_summary","读取当前画布摘要、节点、连线、模型配置和任务状态。"),ah("get_selected_nodes","读取用户当前选中的真实画布节点。"),ah("query_canvas_nodes","当默认上下文中没有目标节点 ID 时，按 ID、关键词或类型只读查询画布节点；找到 ID 后再用 get_node 读取详情。",{nodeId:ac,keyword:ac,type:{type:"string",enum:ap},page:{type:"number",minimum:1},pageSize:{type:"number",minimum:1,maximum:50}}),ah("get_node","按真实节点 ID 读取节点。",{nodeId:ac},["nodeId"]),ah("get_upstream_nodes","读取指定节点的所有直接上游节点。",{nodeId:ac},["nodeId"]),ah("get_downstream_nodes","读取指定节点的所有直接下游节点。",{nodeId:ac},["nodeId"]),ah("get_connected_nodes","读取指定节点直接连接的上下游节点。",{nodeId:ac},["nodeId"]),ah("get_generation_config","读取全局模型和渠道，以及当前画布 Agent 独立保存的图片质量、图片尺寸、视频清晰度、视频尺寸、时长和声音配置。"),ah("get_generation_task","读取指定媒体节点的真实生成任务状态。",{nodeId:ac},["nodeId"]),ah("set_agent_state","保存当前创作阶段、已确认方案和正式参考，供刷新后继续。",{phase:{type:"string",enum:am},brief:ac,targetDurationSeconds:{type:"number",minimum:1},approvedPlan:ac,approvedNodeIds:au,referenceNodeIds:au},["phase"]),ah("create_primary_script_node","仅用于新创作流程首次创建正式主剧本或总制作稿，固定使用主剧本节点尺寸。",{title:ac,content:ac,sourceNodeIds:au,projectTitle:ac},["title","content","projectTitle"]),ah("create_text_node","创建镜头、角色、产品、场景、声音说明和其他普通文本节点；不得用于首次正式主剧本。",{title:ac,content:ac,sourceNodeIds:au},["title","content"]),ah("update_text_node","更新现有文本节点的标题或正文。",{nodeId:ac,title:ac,content:ac},["nodeId"]),ah("update_node","只更新现有节点标题；不允许任意字段覆盖。",{nodeId:ac,title:ac},["nodeId","title"]),ah("delete_node","使用画布现有删除链路删除节点及关联连线。",{nodeId:ac},["nodeId"]),ah("create_connection","在两个真实节点之间创建来源连线。",{fromNodeId:ac,toNodeId:ac},["fromNodeId","toNodeId"]),ah("delete_connection","删除指定真实连线。",{connectionId:ac},["connectionId"]),ah("create_group","把两个或更多节点放进本项目 group 节点。",{title:ac,nodeIds:au},["nodeIds"]),ah("arrange_nodes","整理指定节点；不传 nodeIds 时整理当前画布顶层节点。",{nodeIds:au}),ah("generate_image","创建图片节点和来源连线，并按 Agent 自动生成设置决定是否提交现有图片任务链路。sourceNodeIds 只放真实直接来源，独立生成必须传空数组；其中图片按数组顺序编号为图片1、图片2。",{prompt:ac,title:ac,sourceNodeIds:au,size:ac,count:{type:"number",minimum:1,maximum:15}},["prompt","sourceNodeIds"]),ah("edit_image","创建图片编辑节点和来源连线，并按 Agent 自动生成设置决定是否提交现有图片编辑链路；必须提供至少一个真实图片来源节点，图片按 sourceNodeIds 顺序编号。",{prompt:ac,title:ac,sourceNodeIds:au,size:ac,count:{type:"number",minimum:1,maximum:15}},["prompt","sourceNodeIds"]),ah("generate_video","创建视频节点和来源连线，并按 Agent 自动生成设置决定是否提交现有视频任务链路。sourceNodeIds 只放真实直接来源，独立生成必须传空数组；其中图片、视频、音频分别按各自顺序编号。",{prompt:ac,title:ac,sourceNodeIds:au,model:ac,size:ac,seconds:{type:"number",minimum:-1,maximum:30},generateAudio:{type:"boolean"}},["prompt","sourceNodeIds"]),ah("generate_audio","创建音频节点和来源连线，并按 Agent 自动生成设置决定是否提交现有音频任务链路。prompt 是实际朗读文本，instructions 是音色/演绎说明；sourceNodeIds 只放真实直接来源，独立生成必须传空数组。",{prompt:ac,title:ac,sourceNodeIds:au,voice:ac,instructions:ac},["prompt","sourceNodeIds"]),ah("get_media_task_status","读取图片、视频或音频节点的生成状态。",{nodeId:ac},["nodeId"]),ah("create_video_montage","将画布中已有的多个视频分镜按时间顺序编排进多轨视频剪辑时间轴，并在新标签页中打开剪辑工作台完成成片合成、调速调音与配乐。videoNodeIds 为要排轨剪辑的视频节点 ID 列表（若未传则默认使用当前画布选中的有效视频节点）。",{videoNodeIds:au,title:ac,aspectRatio:{type:"string",enum:["16:9","9:16","1:1","4:3"]}})];function av(e,t,a=(0,K.Ak)()){var o;if("string"!=typeof e||!ag.has(e))throw Error("模型返回了不允许的工具");let n=(o=t)&&"object"==typeof o&&!Array.isArray(o)?t:{},i={};switch(e){case"get_canvas_summary":case"get_selected_nodes":case"get_generation_config":break;case"query_canvas_nodes":{let e=ak(n.type);if(e&&!ap.includes(e))throw Error("无效的节点类型");i={...ak(n.nodeId)?{nodeId:ak(n.nodeId)}:{},...ak(n.keyword)?{keyword:ak(n.keyword)}:{},...e?{type:e}:{},page:aI(n.page,1,Number.MAX_SAFE_INTEGER)||1,pageSize:aI(n.pageSize,1,50)||20};break}case"get_node":case"get_upstream_nodes":case"get_downstream_nodes":case"get_connected_nodes":case"get_generation_task":case"get_media_task_status":case"delete_node":i={nodeId:aw(n.nodeId,"nodeId")};break;case"read_skill_file":i={skillId:aw(n.skillId,"skillId"),path:aw(n.path,"path")};break;case"delete_connection":i={connectionId:aw(n.connectionId,"connectionId")};break;case"create_connection":i={fromNodeId:aw(n.fromNodeId,"fromNodeId"),toNodeId:aw(n.toNodeId,"toNodeId")};break;case"create_primary_script_node":i={title:aw(n.title,"title"),content:aw(n.content,"content"),sourceNodeIds:aj(n.sourceNodeIds),projectTitle:aw(n.projectTitle,"projectTitle")};break;case"create_text_node":i={title:aw(n.title,"title"),content:aw(n.content,"content"),sourceNodeIds:aj(n.sourceNodeIds)};break;case"update_text_node":if(!(i={nodeId:aw(n.nodeId,"nodeId"),...ak(n.title)?{title:ak(n.title)}:{},...ak(n.content)?{content:ak(n.content)}:{}}).title&&!i.content)throw Error("update_text_node 缺少 title 或 content");break;case"update_node":i={nodeId:aw(n.nodeId,"nodeId"),title:aw(n.title,"title")};break;case"set_agent_state":{let e=aw(n.phase,"phase");if(!am.includes(e))throw Error("无效的 Agent 创作阶段");i={phase:e,...ak(n.brief)?{brief:ak(n.brief)}:{},...aN(n.targetDurationSeconds)?{targetDurationSeconds:aN(n.targetDurationSeconds)}:{},...ak(n.approvedPlan)?{approvedPlan:ak(n.approvedPlan)}:{},...Array.isArray(n.approvedNodeIds)?{approvedNodeIds:aj(n.approvedNodeIds)}:{},...Array.isArray(n.referenceNodeIds)?{referenceNodeIds:aj(n.referenceNodeIds)}:{}};break}case"create_group":{let e=aj(n.nodeIds);if(e.length<2)throw Error("create_group 至少需要两个节点");i={nodeIds:e,...ak(n.title)?{title:ak(n.title)}:{}};break}case"arrange_nodes":i={nodeIds:aj(n.nodeIds)};break;case"generate_image":case"edit_image":{let t=aC(n.sourceNodeIds,"sourceNodeIds");if(i={prompt:aw(n.prompt,"prompt"),...t?{sourceNodeIds:t}:{},...ak(n.title)?{title:ak(n.title)}:{},...ak(n.size)?{size:ak(n.size)}:{},...aI(n.count,1,15)?{count:aI(n.count,1,15)}:{}},"edit_image"===e&&t&&!t.length)throw Error("edit_image 缺少图片来源节点");break}case"generate_video":{let e=aC(n.sourceNodeIds,"sourceNodeIds");i={prompt:aw(n.prompt,"prompt"),...e?{sourceNodeIds:e}:{},...ak(n.title)?{title:ak(n.title)}:{},...ak(n.model)?{model:ak(n.model)}:{},...ak(n.size)?{size:ak(n.size)}:{},...void 0!==aS(n.seconds,-1,30)?{seconds:aS(n.seconds,-1,30)}:{},..."boolean"==typeof n.generateAudio?{generateAudio:n.generateAudio}:{}};break}case"generate_audio":{let e=aC(n.sourceNodeIds,"sourceNodeIds");i={prompt:aw(n.prompt,"prompt"),...e?{sourceNodeIds:e}:{},...ak(n.title)?{title:ak(n.title)}:{},...ak(n.voice)?{voice:ak(n.voice)}:{},...ak(n.instructions)?{instructions:ak(n.instructions)}:{}};break}case"create_video_montage":{let e=aC(n.videoNodeIds,"videoNodeIds");i={...e?{videoNodeIds:e}:{},...ak(n.title)?{title:ak(n.title)}:{},...ak(n.aspectRatio)?{aspectRatio:ak(n.aspectRatio)}:{}}}}return{id:a,name:e,arguments:i}}function ay(e){return({get_canvas_summary:"正在读取画布",get_selected_nodes:"正在读取选中节点",query_canvas_nodes:"正在查找画布节点",get_node:"正在读取节点",get_upstream_nodes:"正在读取上游节点",get_downstream_nodes:"正在读取下游节点",get_connected_nodes:"正在读取关联节点",get_generation_config:"正在读取生成配置",get_generation_task:"正在读取任务状态",read_skill_file:"正在读取 Skill 文件",set_agent_state:"正在保存创作进度",create_primary_script_node:"正在创建主剧本节点",create_text_node:"正在创建文本节点",update_text_node:"正在更新文本节点",update_node:"正在更新节点",delete_node:"正在删除节点",create_connection:"正在创建连线",delete_connection:"正在删除连线",create_group:"正在创建分组",arrange_nodes:"正在整理画布",generate_image:"正在创建图片节点",edit_image:"正在创建图片编辑节点",generate_video:"正在创建视频节点",generate_audio:"正在创建音频节点",get_media_task_status:"正在读取媒体任务",create_video_montage:"正在编排视频剪辑工程"})[e.name]}function ab(e){return"generate_image"===e.name||"edit_image"===e.name||"generate_video"===e.name||"generate_audio"===e.name}function aw(e,t){let a=ak(e);if(!a)throw Error(t+" 不能为空");return a}function ak(e){return"string"==typeof e?e.trim():""}function aj(e){return Array.isArray(e)?[...new Set(e.filter(e=>"string"==typeof e).map(e=>e.trim()).filter(Boolean))].slice(0,50):[]}function aC(e,t){if(void 0!==e){if(!Array.isArray(e))throw Error(t+" 必须是字符串数组");return aj(e)}}function aN(e){let t="number"==typeof e?e:Number(e);return Number.isFinite(t)&&t>0?t:void 0}function aI(e,t,a){let o=aS(e,t,a);return void 0===o?void 0:Math.floor(o)}function aS(e,t,a){if(null==e||""===e)return;let o="number"==typeof e?e:Number(e);if(!Number.isFinite(o)||o<t||o>a)throw Error("数值必须在 "+t+" 到 "+a+" 之间");return o}async function aA(e){var t,a,o,n,i,r;let s,l,d,c,u,m=e.initialState,p=!0,g=!1,h=[...e.protocolMessages,{role:"user",content:(t=e.userText,a=e.references,o=e.config.textModel||e.config.model,l=a.length?"\n\n本次输入中的节点占位与真实节点一一对应，请按占位分别理解和操作："+a.map(e=>`${e.label||e.title} → 节点 ${e.id}（${e.title}）`).join("；"):"",c=(d=a.filter(e=>e.dataUrl&&(/^data:image\//.test(e.dataUrl)||/^https?:\/\//.test(e.dataUrl)))).length?"\n随消息附带的图片顺序："+d.map((e,t)=>`第 ${t+1} 张 = ${e.label||e.title}`).join("；"):"",(u="mimo-v2.5"===(s=o.trim().toLowerCase())||/gpt-(?:4o|4\.1|5)|(?:^|[\\/_-])o[134](?:[\\/_-]|$)|gemini|claude|qwen.*(?:vl|vision)|glm-4v|pixtral|llava|internvl|deepseek.*vl|vision/.test(s)?d.map(e=>({type:"image_url",image_url:{url:e.dataUrl}})):[]).length?[{type:"text",text:t+l+c},...u]:t+l)}],f=e.contextCheckpoint,x=e.activeSkillContents?.map((e,t)=>`【完整 Skill ${t+1}：${e.name}（${"system"===e.source?`系统 Skill ID：${e.id}`:"用户 Skill"}）】
${e.content}`).join("\n\n"),v=!!e.activeSkillContents?.some(e=>"system"===e.source&&e.hasFiles),y=v?[...ax,af]:ax,b=()=>e.onCheckpoint?.({state:m,protocolMessages:a_(h),contextCheckpoint:f}),w=async()=>{let t=await tF({protocolMessages:h,contextCheckpoint:f,createCheckpoint:(t,a)=>tq({config:e.config,previousCheckpoint:t,messages:a.map(e=>"assistant"===e.role?{role:e.role,content:e.content||"",toolCalls:e.toolCalls?.map(e=>({name:e.name,arguments:e.arguments}))}:"tool"===e.role?{role:e.role,name:e.name,content:e.content}:{role:e.role,content:tK(e.content)}),signal:e.signal})});return!!t.compacted&&(h=t.protocolMessages,f=t.contextCheckpoint,b(),!0)};for(let t=0;t<12;t++){let a;aT(e.signal),e.onEvent?.({status:"thinking",label:t?"正在根据画布结果继续":"正在理解画布和创作目标"});let o=e.getContext(m),s=ad(m.phase,e.userText,o,x,f,v),l=p?y:[];n={systemPrompt:tB(e.config,s),messages:h,tools:l},i=t2(e.config),Math.ceil(tV(n)*(i&&tD.get(i)||1.25))>=26e4&&await w()&&(s=ad(m.phase,e.userText,o,x,f,v));let d=()=>tO({config:e.config,systemPrompt:s,messages:h,tools:y,allowTools:p,signal:e.signal});try{a=await d()}catch(t){if(!t5(t)||!await w())throw t;s=ad(m.phase,e.userText,o,x,f,v),a=await d()}a.usedJsonFallback&&(p=!1);let c=function(e){let t=function(e){let t=e.trim().replace(/^\x60\x60\x60(?:json)?\s*/i,"").replace(/\s*\x60\x60\x60$/,""),a=t.indexOf("{"),o=t.lastIndexOf("}");return a>=0&&o>a?t.slice(a,o+1):""}(e);if(!t)return{parsed:!1,actions:[],reply:e.trim()};try{let a=JSON.parse(t);if(!Array.isArray(a.actions))return{parsed:!1,actions:[],reply:e.trim()};let o=a.actions.slice(0,12).map(e=>av(e.tool||e.name,e.arguments,e.id||(0,K.Ak)()));return{parsed:!0,actions:o,reply:"string"==typeof a.reply?a.reply.trim():""}}catch{return{parsed:!1,actions:[],reply:e.trim()}}}(a.content),u=a.toolCalls.map(e=>av(e.name,e.arguments,e.id)),k=/整理|排列|排序|对齐|布局|排版|重新摆放/.test(e.userText)&&!/(不要|别|无需|不用).{0,8}(整理|排列|排序|对齐|布局|排版|重新摆放)/.test(e.userText),j=(u.length?u:c.actions).filter(e=>"arrange_nodes"!==e.name||k),C=u.filter(e=>"arrange_nodes"===e.name&&!k).map(e=>({role:"tool",toolCallId:e.id,name:e.name,content:JSON.stringify({ok:!1,code:"action_not_requested",message:"用户没有要求整理画布，未执行节点排列"})}));if(!j.length&&C.length){h=[...h,{role:"assistant",content:a.content||void 0,...void 0!==a.reasoningContent?{reasoningContent:a.reasoningContent}:{},responseItems:a.responseItems,toolCalls:u.map(e=>({id:e.id,name:e.name,arguments:e.arguments}))},...C],b();continue}if(!j.length){let t=(c.parsed?c.reply:a.content).trim();if(!g&&!t&&(r=e.userText,/(?:创建|新增|插入|修改|更新|删除|连接|连线|分组|整理|生成|生图|执行|拆成|拆分|放到画布|开始做|(?:做|制作|添加|补充|移除|去掉).{0,8}(?:视频|音频|配音|旁白))/i.test(r))){let e="当前接口没有返回可执行的画布工具指令。请点击输入框右下角的大脑图标，尝试切换 Chat / Responses，或更换支持 Tool Calling 或稳定 JSON 输出的文本模型。";return h=[...h,{role:"assistant",content:e}],{reply:e,state:m,protocolMessages:a_(h),contextCheckpoint:f}}let o=t||"我已经读取当前画布。请告诉我下一步要继续完善哪一部分。";return h=[...h,{role:"assistant",content:o,...a.responseItems?.length?{responseItems:a.responseItems}:{}}],{reply:o,state:m,protocolMessages:a_(h),contextCheckpoint:f}}e.onEvent?.({status:"running",label:1===j.length?ay(j[0]):"正在执行 "+j.length+" 个画布操作"});let N=u.length?{role:"assistant",content:a.content||void 0,...void 0!==a.reasoningContent?{reasoningContent:a.reasoningContent}:{},...a.responseItems?.length?{responseItems:a.responseItems}:{},toolCalls:u.map(e=>({id:e.id,name:e.name,arguments:e.arguments}))}:{role:"assistant",content:a.content},I=await aM(j,m,e.executeAction,e.signal,e.onEvent);g=!0,m=I.state,h=u.length&&p?[...h,N,...I.items.map(({action:e,result:t})=>({role:"tool",toolCallId:e.id,name:e.name,content:JSON.stringify(t)})),...C]:[...h,N,{role:"user",content:"工具执行结果（只可依据这些真实结果继续）：\n"+JSON.stringify(I.items.map(({action:e,result:t})=>({tool:e.name,id:e.id,result:t})))}],b()}let k="本轮已达到安全操作步数上限，当前已完成的节点和任务都已保存。你可以让我继续下一步。";return h=[...h,{role:"assistant",content:k}],{reply:k,state:m,protocolMessages:a_(h),contextCheckpoint:f}}async function aM(e,t,a,o,n){let i=t,r=async e=>{aT(o),n?.({status:"running",label:ay(e)});try{var t,r;let o=await a(e);return i="set_agent_state"===e.name&&o.ok?(t=i,r=e.arguments,{...t,phase:"string"==typeof r.phase?r.phase:t.phase,brief:"string"==typeof r.brief?r.brief:t.brief,targetDurationSeconds:"number"==typeof r.targetDurationSeconds?r.targetDurationSeconds:t.targetDurationSeconds,approvedPlan:"string"==typeof r.approvedPlan?r.approvedPlan:t.approvedPlan,approvedNodeIds:Array.isArray(r.approvedNodeIds)?r.approvedNodeIds:t.approvedNodeIds,referenceNodeIds:Array.isArray(r.referenceNodeIds)?r.referenceNodeIds:t.referenceNodeIds}):function(e,t){let a="string"==typeof t.taskId?t.taskId:"";if(!a)return e;let o="success"===t.status||"completed"===t.status,n=o||"error"===t.status||"failed"===t.status;return{...e,pendingTaskIds:n?e.pendingTaskIds.filter(e=>e!==a):[...new Set([...e.pendingTaskIds,a])],completedTaskIds:o?[...new Set([...e.completedTaskIds,a])]:e.completedTaskIds}}(i,o),{action:e,result:o}}catch(t){return{action:e,result:{ok:!1,code:"tool_execution_failed",message:t instanceof Error?t.message:"工具执行失败"}}}};return{items:e.every(ab)?await Promise.all(e.map(r)):await e.reduce(async(e,t)=>[...await e,await r(t)],Promise.resolve([])),state:i}}function a_(e){return e.map(e=>{if(("user"===e.role||"system"===e.role)&&Array.isArray(e.content)){let t=e.content.filter(e=>"text"===e.type).map(e=>e.text).join("\n").trim();return{role:e.role,content:t||"本轮包含图片引用；媒体内容未写入会话记录。"}}return e})}function aT(e){if(!e?.aborted)return;let t=Error("Agent 已停止");throw t.name="AbortError",t}var az=a(34355),aP=a(76781),aE=a(5501);function aD({nodes:e,selectedNodeIds:t,referenceNodeClick:a,sessions:i,activeSessionId:r,agentConfig:s,width:l,onWidthChange:d,onSessionsChange:c,onAgentConfigChange:u,onPasteImage:m,onOpenUpload:g,onOpenAssets:h,getAgentContext:f,onExecuteAction:x,onCollapseStart:y,onCollapse:b,initialRequest:w,onInitialRequestConsumed:k}){let j=O.$[(0,H.C)(e=>e.theme)],C=(0,F.useEffectiveConfig)(),N=(0,F.useConfigStore)(e=>e.isAiConfigReady),I=(0,G.useAssetStore)(e=>e.cleanupImages),{message:S}=ew.A.useApp(),_=(0,n.useRef)(null),T=(0,n.useRef)(null),z=(0,n.useRef)(null),E=(0,n.useRef)(null),D=(0,n.useRef)(0),[R,$]=(0,n.useState)("chat"),[L,U]=(0,n.useState)(""),[W,B]=(0,n.useState)(!1),[q,X]=(0,n.useState)([]),[J,Q]=(0,n.useState)([]),[Z,ee]=(0,n.useState)(!1),[et,ea]=(0,n.useState)(!1),[eo,en]=(0,n.useState)(!1),[ei,er]=(0,n.useState)([]),[es,el]=(0,n.useState)([]),[ed,ec]=(0,n.useState)(new Set),[eu,em]=(0,n.useState)(null),[ep]=(0,n.useState)(aK),eg=i.length?i:[ep],eh=r&&eg.some(e=>e.id===r)?r:eg[0]?.id||null,ef=(0,n.useRef)(eg),ex=(0,n.useRef)(eh);(0,n.useEffect)(()=>{ef.current=eg,ex.current=eh},[eh,i]),(0,n.useEffect)(()=>()=>{_.current?.abort(),z.current?.resolve(!1),z.current=null},[]);let ey=eg.find(e=>e.id===eh)||eg[0]||null,eb=eg.filter(e=>e.messages.length>0),eC=ey?.messages||[],eN=eC.length>0,eI=(0,n.useMemo)(()=>Array.from(t).sort().join(","),[t]);(0,n.useEffect)(()=>{if("chat"!==R)return;let e=window.requestAnimationFrame(()=>{let e=E.current;e&&(e.scrollTop=e.scrollHeight)});return()=>window.cancelAnimationFrame(e)},[eC,R]);let eS=(0,n.useMemo)(()=>(0,az.CK)(e),[e]),eA=(0,n.useMemo)(()=>new Map(eS.map(e=>[e.nodeId,e])),[eS]),eM=(0,n.useMemo)(()=>new Map(e.map(e=>[e.id,e])),[e]),e_=(0,n.useCallback)(e=>e.flatMap(e=>{var t,a;let o,n=eM.get(e),i=eA.get(e),r=n&&i?(t=n,a=i,(o=(0,az.nr)(t))?{id:t.id,type:t.type,title:t.title,label:a.label,...o}:null):null;return r?[r]:[]}),[eM,eA]),eT=(0,n.useMemo)(()=>e_(ei),[ei,e_]),ez=(0,n.useMemo)(()=>{let e=a.version>D.current?a.nodeId:null;return eS.filter(a=>t.has(a.nodeId)&&(!ei.includes(a.nodeId)&&!ed.has(a.nodeId)||a.nodeId===e))},[ei,a,ed,eS,t]),eP={color:j.node.muted},eE=e=>{let t=z.current;t&&(z.current=null,em(null),t.resolve(e))};(0,n.useEffect)(()=>{ec(new Set)},[eI]);let eD=(e,t=ex.current)=>{ef.current=e,ex.current=t,c(e,t)},eR=(e,t)=>{eD(ef.current.map(a=>a.id===e?t(a):a))},e$=(e,t)=>{eR(e,e=>({...e,title:e.messages.length?e.title:t.text.slice(0,18)||"新对话",messages:[...e.messages,t],updatedAt:new Date().toISOString()}))},eL=(e,t,a)=>{eR(e,e=>({...e,messages:e.messages.map(e=>e.id===t?{...e,...a}:e),updatedAt:new Date().toISOString()}))},eF=async(a,o,n)=>{let i=ey||aK(),r=void 0!==n?n||[]:es.length?es:i.activeSkills||[],l=[];if(r.length){let e=tE.useAgentSkillStore.getState();if(!e.systemSkills.length&&!e.userSkills.length)try{await e.loadSkills()}catch(e){S.error(e instanceof Error?e.message:"Skill 加载失败");return}let t=[...tE.useAgentSkillStore.getState().systemSkills,...tE.useAgentSkillStore.getState().userSkills],a=r.map(e=>t.find(t=>t.id===e.id&&t.source===e.source&&t.enabled)),o=r.find((e,t)=>!a[t]);if(o)return void S.error(`Skill「${o.name}」已不可用，请重新选择`);l=a.map(e=>({id:e.id,source:e.source,name:e.name,content:e.content,hasFiles:e.hasFiles}))}ey||eD([i],i.id),eR(i.id,e=>({...e,activeSkills:r,updatedAt:new Date().toISOString()}));let d=o||eT,c=d.map(e=>e.id),u={id:(0,K.Ak)(),role:"user",text:a,references:d,skills:r,skillsSelected:void 0===n&&es.length>0,status:"success"},m=(0,K.Ak)();e$(i.id,u),e$(i.id,{id:m,role:"assistant",text:"",status:"thinking",activity:"正在理解画布和创作目标"}),U(""),er([]),el([]),ec(new Set(t));let p={...C,model:C.textModel||C.model,apiMode:s.textApiMode,activeChannelId:C.textChannelId||C.activeChannelId,textChannelId:C.textChannelId};if(!N(p,p.model))return void eL(i.id,m,{text:"全局文本模型尚未配置完成。请先从应用原有的全局配置入口选择文本模型和渠道，然后再继续。",status:"error",activity:void 0});let g=new AbortController;_.current=g,B(!0);try{let t=await Promise.all(d.map(async e=>{if(!e.dataUrl)return e;try{return{...e,dataUrl:await (0,V.imageToDataUrl)(e)}}catch{return e}})),o=await aA({config:p,initialState:i.agentState,protocolMessages:i.protocolMessages,userText:a,references:t,activeSkillContents:l,contextCheckpoint:i.contextCheckpoint,getContext:f,executeAction:async t=>{if("read_skill_file"===t.name){let e="string"==typeof t.arguments.skillId?t.arguments.skillId:"",a="string"==typeof t.arguments.path?t.arguments.path:"";if(!r.find(t=>t.id===e&&"system"===t.source))return{ok:!1,code:"skill_not_active",message:"只能读取当前激活的系统 Skill 文件"};try{let t=await (0,tP.YM)(e,a);return{ok:!0,skillId:e,path:t.path,content:t.content}}catch(e){return{ok:!1,code:"skill_file_not_found",message:e instanceof Error?e.message:"Skill 文件读取失败"}}}if("delete_node"!==t.name)return x(t,c);let a="string"==typeof t.arguments.nodeId?t.arguments.nodeId:"",o=e.find(e=>e.id===a);return await new Promise(e=>{let t={title:o?.title||"未命名节点",resolve:e};z.current=t,em(t)})?x(t,c):{ok:!1,code:"delete_cancelled",message:"用户取消删除，原节点已保留"}},signal:g.signal,onEvent:e=>eL(i.id,m,{status:e.status,activity:e.label}),onCheckpoint:e=>eR(i.id,t=>({...t,agentState:e.state,protocolMessages:e.protocolMessages,contextCheckpoint:e.contextCheckpoint,updatedAt:new Date().toISOString()}))});eR(i.id,e=>({...e,agentState:o.state,protocolMessages:o.protocolMessages,contextCheckpoint:o.contextCheckpoint,messages:e.messages.map(e=>e.id===m?{...e,text:o.reply,status:"success",activity:void 0}:e),updatedAt:new Date().toISOString()}))}catch(t){let e=t instanceof Error&&"AbortError"===t.name;eL(i.id,m,{text:e?"已停止继续执行。已经创建的节点和已经提交的媒体任务会保留。":t instanceof Error?t.message:"Agent 执行失败",status:e?"waiting":"error",activity:void 0})}finally{_.current===g&&(_.current=null),B(!1),Y.useWalletStore.getState().fetchWallet()}};(0,n.useEffect)(()=>{w&&T.current!==w&&(T.current=w,k?.(),eF(w.prompt,w.references))},[w,k]);let eV=async(e=L,t=ei)=>{let a=e.trim();!a||W||Y.useWalletStore.getState().checkBalanceOrIntercept(()=>{S.warning("当前账户算力余额不足，请先充值算力后再使用智能助理")})&&await eF(a,e_(t))};return(0,o.jsx)(tI.PY1.div,{className:"flex shrink-0",initial:{width:0,opacity:0},animate:{width:et?0:l+1,opacity:+!et},transition:{duration:.5*!eo,ease:[.22,1,.36,1]},style:{overflow:"clip",pointerEvents:et?"none":void 0},children:(0,o.jsxs)(tI.PY1.aside,{"data-canvas-agent-panel":!0,className:"relative flex shrink-0 flex-col border-l",initial:{x:48},animate:{x:28*!!et},transition:{duration:.5*!eo,ease:[.22,1,.36,1]},style:{width:l,background:j.node.panel,borderColor:j.node.stroke,color:j.node.text},children:[(0,o.jsx)("button",{type:"button",className:"absolute inset-y-0 left-0 z-40 w-4 -translate-x-1/2 cursor-col-resize",onMouseDown:()=>{let e=e=>d(Math.min(760,Math.max(320,window.innerWidth-e.clientX))),t=()=>{en(!1),document.body.style.cursor="",document.body.style.userSelect="",document.removeEventListener("mousemove",e),document.removeEventListener("mouseup",t)};en(!0),document.body.style.cursor="col-resize",document.body.style.userSelect="none",document.addEventListener("mousemove",e),document.addEventListener("mouseup",t)},"aria-label":"调整右侧面板宽度"}),(0,o.jsxs)("div",{className:"flex items-center justify-between border-b px-4 py-3",style:{borderColor:j.node.stroke},children:[(0,o.jsxs)("div",{className:"flex items-center gap-2 text-sm font-medium",children:[(0,o.jsx)(P.A,{className:"size-4"}),"history"===R?"历史记录":"创作 Agent"]}),(0,o.jsxs)("div",{className:"flex items-center gap-1",children:["history"===R?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(e4.A,{title:"删除选中",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(M.A,{className:"size-4"}),disabled:!q.length,onClick:()=>Q(q)})}),(0,o.jsx)(e4.A,{title:"删除全部",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(v.A,{className:"size-4"}),disabled:!eb.length,onClick:()=>Q(eb.map(e=>e.id))})})]}):null,(0,o.jsx)(e4.A,{title:"history"===R?"返回对话":"历史记录",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(tw.A,{className:"size-4"}),onClick:()=>$("history"===R?"chat":"history")})}),(0,o.jsx)(e4.A,{title:"新对话",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(A.A,{className:"size-4"}),disabled:!eN,onClick:()=>{(()=>{if(el([]),ey&&0===ey.messages.length)return eD(ef.current,ey.id);let e=aK();eD([e,...ef.current],e.id)})(),$("chat")}})}),(0,o.jsx)(e4.A,{title:"Agent 设置",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(p.A,{className:"size-4"}),onClick:()=>ee(!0)})}),(0,o.jsx)(e4.A,{title:"收起对话",children:(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",className:"!h-8 !w-8 !min-w-8",style:eP,icon:(0,o.jsx)(tk.A,{className:"size-4"}),onClick:()=>{ea(!0),y(),window.setTimeout(b,500)}})})]})]}),(0,o.jsx)("div",{ref:E,className:"thin-scrollbar min-h-0 flex-1 space-y-4 overflow-y-auto px-4 py-4",children:"history"===R?(0,o.jsx)(aF,{sessions:eb,activeSession:ey,checkedIds:q.filter(e=>eb.some(t=>t.id===e)),onToggleChecked:(e,t)=>X(a=>t?[...new Set([...a,e])]:a.filter(t=>t!==e)),onOpen:e=>{eD(ef.current,e),el([]),$("chat")},onDelete:e=>Q([e])}):eC.length?(0,o.jsx)(aL,{messages:eC,onRetry:e=>{let t=eC.findIndex(t=>t.id===e.id),a=eC.slice(0,t).findLast(e=>"user"===e.role);a&&eF(a.text,a.references,a.skills||[])}}):(0,o.jsxs)("div",{className:"flex h-full flex-col items-center justify-center px-8 text-center",children:[(0,o.jsx)("div",{className:"grid size-12 place-items-center rounded-2xl",style:{background:j.node.fill},children:(0,o.jsx)(tj.A,{className:"size-5"})}),(0,o.jsx)("div",{className:"mt-4 text-base font-medium",children:"从一个想法开始"}),(0,o.jsx)("div",{className:"mt-2 max-w-[260px] text-sm leading-6 opacity-55",children:"描述故事、宣传片或现有素材，Agent 会与你沟通并直接操作当前画布"})]})}),"chat"===R?(0,o.jsxs)(o.Fragment,{children:[eu?(0,o.jsxs)("div",{className:"mx-2 mb-2 overflow-hidden rounded-xl border",style:{background:j.node.fill,borderColor:j.node.stroke},children:[(0,o.jsxs)("div",{className:"min-w-0 px-3 py-2.5",children:[(0,o.jsxs)("div",{className:"truncate text-sm font-medium",children:["删除「",eu.title,"」？"]}),(0,o.jsx)("div",{className:"mt-0.5 text-xs opacity-55",children:"相关连线和任务记录将按现有逻辑清理"})]}),(0,o.jsxs)("div",{className:"grid grid-cols-2 border-t",style:{borderColor:j.node.stroke},children:[(0,o.jsx)("button",{type:"button",className:"h-9 cursor-pointer border-0 bg-transparent text-sm",style:{color:j.node.text},onClick:()=>eE(!1),children:"取消"}),(0,o.jsx)("button",{type:"button",className:"h-9 cursor-pointer border-0 border-l bg-transparent text-sm font-medium",style:{borderColor:j.node.stroke,color:"#ef4444"},onClick:()=>eE(!0),children:"确认删除"})]})]}):null,(0,o.jsx)(aP.D,{prompt:L,isRunning:W,references:eT,availableReferences:eS,pendingReferences:ez,selectedSkills:es,agentConfig:s,onAgentConfigChange:u,onPromptChange:U,onSkillSelect:e=>{let t=es.findIndex(t=>t.id===e.id&&t.source===e.source);t>=0?el(es.map((a,o)=>o===t?e:a)):es.length>=ev.r?S.warning(`最多选择 ${ev.r} 个 Skill`):el([...es,e])},onSkillRemove:(e,t)=>{el(a=>a.filter(a=>a.id!==e||a.source!==t))},onReferenceIdsChange:e=>{D.current=a.version;let o=ei.filter(a=>t.has(a)&&!e.includes(a));o.length&&ec(e=>new Set([...e,...o])),er(e)},onSubmit:eV,onStop:()=>{eE(!1),_.current?.abort()},onOpenUpload:g,onOpenAssets:h,onPasteImage:m})]}):null,(0,o.jsx)(ek.A,{title:"Agent 设置",open:Z,centered:!0,width:520,onCancel:()=>ee(!1),footer:(0,o.jsx)(ej.Ay,{type:"primary",onClick:()=>ee(!1),children:"完成"}),children:(0,o.jsxs)("div",{className:"flex items-center justify-between gap-6 py-2",children:[(0,o.jsxs)("div",{className:"min-w-0",children:[(0,o.jsx)("div",{className:"text-sm font-medium",children:"自动生成图片/视频/音频"}),(0,o.jsx)("div",{className:"mt-1 text-xs leading-5 opacity-55",children:"开启后，Agent 可直接提交图片/视频/音频生成，无需再次确认"})]}),(0,o.jsx)(e5.A,{checked:s.autoGenerateMedia,onChange:e=>u({autoGenerateMedia:e})})]})}),(0,o.jsx)(ek.A,{title:"删除对话记录？",open:J.length>0,centered:!0,onCancel:()=>Q([]),footer:(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(ej.Ay,{onClick:()=>Q([]),children:"取消"}),(0,o.jsx)(ej.Ay,{danger:!0,type:"primary",onClick:()=>{let e;J.length===eb.length?(eD([e=aK()],e.id),X([]),el([]),I({sessions:[e]})):(e=>{let t=eg.filter(t=>!e.includes(t.id));if(t.length){let a=ex.current;eD(t,a&&e.includes(a)?t[0].id:a)}else{let e=aK();eD([e],e.id)}I({sessions:t}),X(t=>t.filter(t=>!e.includes(t)))})(J),Q([])},children:"删除"})]}),children:(0,o.jsxs)("p",{className:"text-sm opacity-60",children:["将删除 ",J.length," 条对话记录，此操作不可撤销"]})})]})})}let aR={a:({node:e,...t})=>(0,o.jsx)("a",{...t,target:"_blank",rel:"noreferrer",className:"font-medium underline underline-offset-4"})};function a$({children:e}){let t=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsx)("div",{className:(0,tM.cn)("min-w-0 whitespace-normal break-words","[&_p]:my-2 [&_p:first-child]:mt-0 [&_p:last-child]:mb-0","[&_h1]:mb-2 [&_h1]:mt-4 [&_h1]:text-lg [&_h1]:font-semibold [&_h1:first-child]:mt-0","[&_h2]:mb-2 [&_h2]:mt-4 [&_h2]:text-base [&_h2]:font-semibold [&_h2:first-child]:mt-0","[&_h3]:mb-1.5 [&_h3]:mt-3 [&_h3]:font-semibold [&_h3:first-child]:mt-0","[&_h4]:my-2 [&_h4]:font-semibold","[&_ul]:my-2 [&_ul]:list-disc [&_ul]:pl-5 [&_ol]:my-2 [&_ol]:list-decimal [&_ol]:pl-5 [&_li]:my-1","[&_blockquote]:my-2 [&_blockquote]:border-l-2 [&_blockquote]:border-[color:var(--agent-markdown-border)] [&_blockquote]:pl-3 [&_blockquote]:opacity-80","[&_hr]:my-3 [&_hr]:border-0 [&_hr]:border-t [&_hr]:border-[color:var(--agent-markdown-border)]","[&_code]:rounded [&_code]:bg-[var(--agent-markdown-surface)] [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:font-mono [&_code]:text-[0.85em]","[&_pre]:my-2 [&_pre]:overflow-x-auto [&_pre]:rounded-lg [&_pre]:bg-[var(--agent-markdown-surface)] [&_pre]:p-3","[&_pre_code]:bg-transparent [&_pre_code]:p-0","[&_table]:my-2 [&_table]:w-full [&_table]:border-collapse [&_th]:border-b [&_th]:border-[color:var(--agent-markdown-border)] [&_th]:px-2 [&_th]:py-1.5 [&_th]:text-left [&_td]:border-b [&_td]:border-[color:var(--agent-markdown-border)] [&_td]:px-2 [&_td]:py-1.5"),style:{"--agent-markdown-surface":t.toolbar.itemHover,"--agent-markdown-border":t.node.stroke},children:(0,o.jsx)(tS.oz,{remarkPlugins:[tA.A],components:aR,skipHtml:!0,children:e})})}function aL({messages:e,onRetry:t}){let a=O.$[(0,H.C)(e=>e.theme)],n=(0,tz.s)(),i=[];return(0,o.jsx)(o.Fragment,{children:e.map(e=>{let r="thinking"===e.status||"running"===e.status,s=e.skillsSelected??!!(e.skills?.length&&!function(e=[],t=[]){return e.length===t.length&&e.every((e,a)=>e.id===t[a]?.id&&e.source===t[a]?.source)}(e.skills,i));return"user"===e.role&&(i=e.skills||[]),(0,o.jsxs)("div",{className:(0,tM.cn)("flex flex-col gap-2","user"===e.role?"items-end":"items-start"),children:[e.text?(0,o.jsxs)("div",{className:"max-w-[88%] whitespace-pre-wrap rounded-2xl px-3 py-2 text-sm leading-6",style:"user"===e.role?{background:a.toolbar.activeBg,color:a.toolbar.activeText}:(e.status,{background:a.node.fill,color:a.node.text}),children:["assistant"===e.role?(0,o.jsxs)("div",{className:"mb-1 flex items-center gap-1.5 text-xs opacity-60",children:[(0,o.jsx)(P.A,{className:"size-3.5"}),"Agent"]}):null,"assistant"===e.role?(0,o.jsx)(a$,{children:e.text}):(0,o.jsx)(aV,{message:e,showSkills:s})]}):null,r?(0,o.jsx)(tT,{compact:!0,label:e.activity||"正在执行",className:"w-[250px] rounded-2xl border"}):null,!r&&e.text?(0,o.jsxs)("div",{className:"flex gap-1",children:[(0,o.jsx)(ej.Ay,{shape:"circle",size:"small",style:{borderColor:a.node.stroke},icon:(0,o.jsx)(tC.A,{className:"size-3.5"}),onClick:()=>n(e.text,"消息已复制"),title:"复制"}),"assistant"===e.role?(0,o.jsx)(ej.Ay,{shape:"circle",size:"small",style:{borderColor:a.node.stroke},icon:(0,o.jsx)(tN.A,{className:"size-3.5"}),onClick:()=>t(e),title:"重试"}):null]}):null]},e.id)})})}function aF({sessions:e,activeSession:t,checkedIds:a,onToggleChecked:n,onOpen:i,onDelete:r}){let s=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsx)("div",{className:"space-y-1",children:e.map(e=>(0,o.jsxs)("div",{className:"group flex items-center gap-2 rounded-lg px-2 py-1.5 transition",style:e.id===t?.id?{background:s.node.fill}:void 0,children:[(0,o.jsx)("input",{type:"checkbox",className:"size-4",style:{accentColor:s.node.text},checked:a.includes(e.id),onChange:t=>n(e.id,t.target.checked)}),(0,o.jsxs)("button",{type:"button",className:"min-w-0 flex-1 text-left text-sm",onClick:()=>i(e.id),children:[(0,o.jsx)("span",{className:"block truncate",children:e.title}),(0,o.jsxs)("span",{className:"text-xs opacity-50",children:[e.messages.length," 条消息"]})]}),(0,o.jsx)(ej.Ay,{type:"text",shape:"circle",size:"small",className:"opacity-0 transition group-hover:opacity-100",icon:(0,o.jsx)(M.A,{className:"size-3.5"}),onClick:()=>r(e.id),title:"删除"})]},e.id))})}function aV({message:e,showSkills:t}){let a=(0,n.useMemo)(()=>e.references?.map(aP.z)||[],[e.references]);return(0,o.jsx)(aE.J,{value:e.text,references:a,skills:t?e.skills:void 0,onChange:aU,readOnly:!0})}function aU(){}function aK(){let e=new Date().toISOString();return{id:(0,K.Ak)(),title:"新对话",messages:[],agentState:{phase:"intake",approvedNodeIds:[],referenceNodeIds:[],pendingTaskIds:[],completedTaskIds:[]},protocolMessages:[],createdAt:e,updatedAt:e}}var aW=a(15867),aO=a(13332),aB=a(19109),aq=a(87429);function aG({menu:e,canCaptureVideoFrame:t,onClose:a,onCaptureVideoFrame:i,onOpenVideoEditor:r,onDuplicate:s,onDelete:l}){let d=O.$[(0,H.C)(e=>e.theme)];return(0,n.useEffect)(()=>{let e=e=>{let t=e.target;t instanceof Element&&t.closest(".ant-popover")||a()};return window.addEventListener("pointerdown",e),()=>window.removeEventListener("pointerdown",e)},[a]),(0,o.jsxs)("div",{className:"fixed z-[80] min-w-44 overflow-hidden rounded-xl border py-1 shadow-2xl",style:{left:e.x,top:e.y,background:d.toolbar.panel,borderColor:d.toolbar.border,color:d.node.text},onPointerDown:e=>e.stopPropagation(),children:[t?(0,o.jsxs)(o.Fragment,{children:[r?(0,o.jsx)(aH,{icon:(0,o.jsx)(aW.A,{className:"size-4 text-amber-400"}),label:"进入视频剪辑",onClick:r}):null,(0,o.jsx)(aH,{icon:(0,o.jsx)(aO.A,{className:"size-4"}),label:"截取首帧",onClick:()=>i("first")}),(0,o.jsx)(aH,{icon:(0,o.jsx)(aB.A,{className:"size-4"}),label:"截取尾帧",onClick:()=>i("last")}),(0,o.jsx)(aH,{icon:(0,o.jsx)(aq.A,{className:"size-4"}),label:"截取当前帧",onClick:()=>i("current")}),(0,o.jsx)("div",{className:"my-1 border-t",style:{borderColor:d.toolbar.border}})]}):null,"node"===e.type?(0,o.jsx)(aH,{icon:(0,o.jsx)(A.A,{className:"size-4"}),label:"Duplicate",onClick:s}):null,(0,o.jsx)(aH,{icon:(0,o.jsx)(M.A,{className:"size-4"}),label:"Delete",onClick:l,danger:!0})]})}function aH({icon:e,label:t,onClick:a,danger:n=!1}){let i=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsxs)("button",{type:"button",className:"flex w-full items-center gap-2 px-3 py-2 text-left text-xs transition-colors hover:opacity-80",style:{color:n?"#f87171":i.node.text},onClick:a,children:[e,(0,o.jsx)("span",{children:t})]})}var aX=a(47805),aY=a(98562);let aJ={horizontalAngle:0,pitchAngle:9,cameraDistance:4.8,wideAngle:!1};function aQ({dataUrl:e,open:t,onClose:a,onConfirm:i}){var r;let s,[l,d]=(0,n.useState)(aJ);(0,n.useEffect)(()=>{t&&d(aJ)},[e,t]);let c=(e,t)=>d(a=>({...a,[e]:t}));return(0,o.jsx)(ek.A,{title:null,open:t&&!!e,onCancel:a,footer:null,width:860,centered:!0,destroyOnHidden:!0,children:(0,o.jsxs)("div",{className:"space-y-5",children:[(0,o.jsxs)("div",{children:[(0,o.jsx)("h2",{className:"text-xl font-semibold",children:"AI 多角度"}),(0,o.jsx)("p",{className:"mt-1 text-sm opacity-60",children:"左侧只预览方向，结果会基于原图重新生成"})]}),(0,o.jsxs)("div",{className:"grid gap-6 md:grid-cols-[minmax(260px,1fr)_360px]",children:[(0,o.jsxs)("div",{className:"flex min-h-[300px] flex-col justify-between rounded-xl border p-4",children:[(0,o.jsx)("div",{className:"grid flex-1 place-items-center",children:(0,o.jsxs)("div",{className:"relative",children:[(0,o.jsx)("img",{src:e,alt:"",className:"size-48 rounded-2xl object-cover shadow-2xl",draggable:!1,style:{transform:(s=1.08-.035*(r=l).cameraDistance+(r.wideAngle?-.08:0),`perspective(520px) rotateY(${-.45*r.horizontalAngle}deg) rotateX(${.35*r.pitchAngle}deg) scale(${Math.max(.72,Math.min(1.08,s))})`)}}),(0,o.jsx)("div",{className:"absolute -bottom-6 left-1/2 h-10 w-24 -translate-x-1/2 rounded-full border bg-black/20 backdrop-blur"})]})}),(0,o.jsx)(ej.Ay,{className:"w-fit",icon:(0,o.jsx)(tN.A,{className:"size-4"}),onClick:()=>d(aJ),children:"重置"})]}),(0,o.jsxs)("div",{className:"space-y-6 py-2",children:[(0,o.jsx)(aZ,{label:"左右角度",value:l.horizontalAngle,min:-60,max:60,step:1,suffix:"deg",onChange:e=>c("horizontalAngle",e)}),(0,o.jsx)(aZ,{label:"俯仰角度",value:l.pitchAngle,min:-45,max:45,step:1,suffix:"deg",onChange:e=>c("pitchAngle",e)}),(0,o.jsx)(aZ,{label:"镜头距离",value:l.cameraDistance,min:1,max:10,step:.1,onChange:e=>c("cameraDistance",e)}),(0,o.jsxs)("div",{className:"grid grid-cols-[88px_1fr_72px] items-center gap-4",children:[(0,o.jsx)("span",{className:"font-medium opacity-75",children:"广角镜头"}),(0,o.jsx)(eX.A,{className:"w-fit",value:l.wideAngle?"wide":"standard",options:[{label:"标准",value:"standard"},{label:"广角",value:"wide"}],onChange:e=>c("wideAngle","wide"===e)})]})]})]}),(0,o.jsx)("div",{className:"flex justify-end",children:(0,o.jsx)(ej.Ay,{type:"primary",size:"large",icon:(0,o.jsx)(aY.A,{className:"size-4"}),onClick:()=>i(l),children:"AI 生成"})})]})})}function aZ({label:e,value:t,min:a,max:n,step:i,suffix:r="",onChange:s}){return(0,o.jsxs)("div",{className:"grid grid-cols-[88px_1fr_72px] items-center gap-4",children:[(0,o.jsx)("span",{className:"font-medium opacity-75",children:e}),(0,o.jsx)(aX.A,{min:a,max:n,step:i,value:t,onChange:s}),(0,o.jsxs)("span",{className:"whitespace-nowrap text-right font-semibold",children:[Number.isInteger(t)?t:t.toFixed(1),r]})]})}var a0=a(51926),a1=a(36623),a2=a(76540);let a5=["nw","n","ne","e","se","s","sw","w"],a4={x:.12,y:.12,width:.76,height:.76};function a3({dataUrl:e,open:t,onClose:a,onConfirm:i}){var r,s,l;let d,c=(0,n.useRef)(null),[u,m]=(0,n.useState)(a4),[p,g]=(0,n.useState)(null),[h,f]=(0,n.useState)(!1),[x,y]=(0,n.useState)(null),b=x?{width:Math.max(1,Math.round(u.width*x.width)),height:Math.max(1,Math.round(u.height*x.height))}:null;(0,n.useEffect)(()=>{t&&(m(a4),g(null))},[e,t]),(0,n.useEffect)(()=>{t&&(0,W.xL)(e).then(y)},[e,t]);let w=(e,t,a)=>{if(h)return;let o=c.current?.getBoundingClientRect();if(!o)return;t.preventDefault(),t.stopPropagation();let n={x:t.clientX,y:t.clientY,crop:u},i=t=>{var i,r,s,l,d,c,u,g,h;let f,x=(t.clientX-n.x)/o.width,v=(t.clientY-n.y)/o.height;m("move"===e?(i=n.crop,r=x,s=v,{...i,x:a8(i.x+r,0,1-i.width),y:a8(i.y+s,0,1-i.height)}):(l=n.crop,d=x,c=v,u=a||"se",g=p,h=o,f={...l},u.includes("e")&&(f.width=l.width+d),u.includes("s")&&(f.height=l.height+c),u.includes("w")&&(f.x=l.x+d,f.width=l.width-d),u.includes("n")&&(f.y=l.y+c,f.height=l.height-c),null!==g&&("n"===u||"s"===u?(f.width=f.height*h.height*g/h.width,f.x=l.x+(l.width-f.width)/2):"e"===u||"w"===u?(f.height=f.width*h.width/(g*h.height),f.y=l.y+(l.height-f.height)/2):(f.height=f.width*h.width/(g*h.height),u.includes("n")&&(f.y=l.y+l.height-f.height))),f.width=a8(f.width,.06,1),f.height=a8(f.height,.06,1),null!==g&&Math.abs(f.width*h.width/(f.height*h.height)-g)>.01&&(f.height=f.width*h.width/(g*h.height)),f.x=a8(f.x,0,1-f.width),f.y=a8(f.y,0,1-f.height),f))},r=()=>{document.removeEventListener("pointermove",i),document.removeEventListener("pointerup",r)};document.addEventListener("pointermove",i),document.addEventListener("pointerup",r)},k=e=>{if(null===e)return void g(null);g(e);let t=c.current?.getBoundingClientRect();if(!t||!x)return;let a=.76,o=.76*t.width/(e*t.height);o>.76&&(a=(o=.76)*e*t.height/t.width),m({x:(1-a)/2,y:(1-o)/2,width:a,height:o})},j=async()=>{f(!0);try{await i(u)}finally{f(!1)}};return(0,o.jsx)(ek.A,{title:"裁剪图片",open:t&&!!e,onCancel:h?void 0:a,footer:null,width:780,centered:!0,destroyOnHidden:!0,closable:!h,mask:{closable:!h},children:(0,o.jsxs)("div",{className:"space-y-4",children:[(0,o.jsx)("div",{className:"flex justify-center",children:(0,o.jsxs)("div",{ref:c,className:"relative inline-block max-w-full overflow-hidden rounded-lg bg-black select-none",children:[(0,o.jsx)("img",{src:e,alt:"",className:"block max-h-[62vh] max-w-full opacity-90",draggable:!1}),(0,o.jsx)(a6,{crop:u}),(0,o.jsxs)("div",{className:"absolute cursor-move border-2 border-white shadow-[0_0_0_1px_rgba(0,0,0,.3),0_0_28px_rgba(0,0,0,.28)]",style:(r=u,{left:`${100*r.x}%`,top:`${100*r.y}%`,width:`${100*r.width}%`,height:`${100*r.height}%`}),onPointerDown:e=>w("move",e),children:[(0,o.jsx)("div",{className:"pointer-events-none absolute inset-x-0 top-1/3 border-t border-white/50"}),(0,o.jsx)("div",{className:"pointer-events-none absolute inset-x-0 top-2/3 border-t border-white/50"}),(0,o.jsx)("div",{className:"pointer-events-none absolute inset-y-0 left-1/3 border-l border-white/50"}),(0,o.jsx)("div",{className:"pointer-events-none absolute inset-y-0 left-2/3 border-l border-white/50"}),a5.map(e=>{var t;return(0,o.jsx)("button",{type:"button",className:"absolute size-3 rounded-full border border-black bg-white",style:{top:(t=e).includes("n")?"-6px":t.includes("s")?"calc(100% - 6px)":"calc(50% - 6px)",left:t.includes("w")?"-6px":t.includes("e")?"calc(100% - 6px)":"calc(50% - 6px)",cursor:`${t}-resize`},onPointerDown:t=>w("resize",t,e),"aria-label":"调整裁剪框"},e)})]})]})}),(0,o.jsxs)("div",{className:"flex flex-wrap items-center justify-between gap-3 rounded-lg border px-3 py-2",children:[(0,o.jsxs)("div",{className:"flex flex-wrap items-center gap-3 text-sm opacity-80",children:[(0,o.jsxs)("span",{children:["裁剪尺寸 ",b?`${b.width} x ${b.height}`:"未知"]}),(0,o.jsxs)("span",{children:["比例 ",b?(s=b.width,d=function e(t,a){return a?e(a,t%a):Math.max(1,t)}(s,l=b.height),`${Math.round(s/d)}:${Math.round(l/d)}`):"未知"]}),x?(0,o.jsxs)("span",{children:["原图 ",x.width," x ",x.height]}):null]}),(0,o.jsx)(eC.A,{menu:{items:[{key:"free",label:"自由比例"},{key:"original",label:"原始比例"},{key:"1:1",label:"1:1 比例"},{key:"4:3",label:"4:3 比例"},{key:"16:9",label:"16:9 比例"},{key:"3:4",label:"3:4 比例"},{key:"9:16",label:"9:16 比例"}],onClick:({key:e})=>{if("free"===e)k(null);else if("original"===e)x&&k(x.width/x.height);else{let[t,a]=e.split(":").map(Number);k(t/a)}}},disabled:h,children:(0,o.jsxs)(ej.Ay,{icon:null===p?(0,o.jsx)(a0.A,{className:"size-4"}):(0,o.jsx)(a1.A,{className:"size-4"}),children:[null===p?"自由比例":x&&.01>Math.abs(p-x.width/x.height)?"原始比例":.01>Math.abs(p-1)?"1:1 比例":.01>Math.abs(p-4/3)?"4:3 比例":.01>Math.abs(p-16/9)?"16:9 比例":.01>Math.abs(p-3/4)?"3:4 比例":.01>Math.abs(p-9/16)?"9:16 比例":"比例锁定"," ",(0,o.jsx)(e2.A,{className:"size-3.5 ml-1 inline-block"})]})})]}),(0,o.jsxs)("div",{className:"flex items-center justify-end gap-2",children:[(0,o.jsx)(ej.Ay,{disabled:h,onClick:()=>m(a4),children:"重置"}),(0,o.jsx)(ej.Ay,{disabled:h,icon:(0,o.jsx)(v.A,{className:"size-4"}),onClick:a,children:"取消"}),(0,o.jsx)(ej.Ay,{type:"primary",loading:h,icon:!h&&(0,o.jsx)(a2.A,{className:"size-4"}),onClick:j,children:h?"正在裁剪...":"确认裁剪"})]})]})})}function a6({crop:e}){return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("div",{className:"absolute inset-x-0 top-0 bg-black/55",style:{height:`${100*e.y}%`}}),(0,o.jsx)("div",{className:"absolute inset-x-0 bottom-0 bg-black/55",style:{height:`${(1-e.y-e.height)*100}%`}}),(0,o.jsx)("div",{className:"absolute bg-black/55",style:{left:0,top:`${100*e.y}%`,width:`${100*e.x}%`,height:`${100*e.height}%`}}),(0,o.jsx)("div",{className:"absolute bg-black/55",style:{right:0,top:`${100*e.y}%`,width:`${(1-e.x-e.width)*100}%`,height:`${100*e.height}%`}})]})}function a8(e,t,a){return Math.min(a,Math.max(t,e))}var a7=a(62794),a9=a(32),oe=a(93502);let ot="rgba(37, 99, 235, .38)";function oa({dataUrl:e,open:t,config:a,model:i,channelId:r,onModelChange:s,onMissingConfig:l,onClose:d,onConfirm:c}){let u=(0,n.useRef)(null),m=(0,n.useRef)(null),p=(0,n.useRef)({active:!1,last:null}),[g,h]=(0,n.useState)(null),[f,x]=(0,n.useState)(""),[y,b]=(0,n.useState)(100),[w,k]=(0,n.useState)("paint"),[j,C]=(0,n.useState)(""),[N,I]=(0,n.useState)(!1);(0,n.useEffect)(()=>{t&&(x(""),b(100),k("paint"),C(""),I(!1),(0,W.xL)(e).then(h))},[e,t]),(0,n.useEffect)(()=>{oo(u.current),oo(m.current)},[g]);let S=e=>{var t,a,o;let n,i=(t=e.currentTarget,a=e.clientX,o=e.clientY,{x:(a-(n=t.getBoundingClientRect()).left)/Math.max(1,n.width)*t.width,y:(o-n.top)/Math.max(1,n.height)*t.height}),r=u.current,s=r?.getContext("2d");r&&s&&(s.lineCap="round",s.lineJoin="round",s.lineWidth=y,s.globalCompositeOperation="paint"===w?"source-over":"destination-out",s.strokeStyle="#000",s.fillStyle="#000",p.current.last?on(s,p.current.last,i,y):on(s,i,i,y),or(r,m.current),p.current.last=i,"paint"===w&&C(""))},A=()=>{p.current={active:!1,last:null};let e=u.current;e&&or(e,m.current,oi(e))},M=async()=>{let t=f.trim(),a=u.current;if(!t)return C("请输入修改要求");if(a){if(!oi(a))return C("请先涂抹局部区域");I(!0);try{c({prompt:t,markedDataUrl:await os(e,a),model:i,channelId:r})}catch{I(!1),C("生成标记参考图失败")}}};return(0,o.jsx)(ek.A,{title:null,open:t&&!!e,onCancel:d,footer:null,width:980,centered:!0,destroyOnHidden:!0,children:(0,o.jsxs)("div",{className:"grid gap-5 lg:grid-cols-[minmax(360px,1fr)_320px]",children:[(0,o.jsx)("div",{className:"flex min-h-[360px] items-center justify-center rounded-xl border border-black/10 bg-transparent p-0 dark:border-white/10",children:(0,o.jsxs)("div",{className:"relative inline-block max-w-full overflow-hidden rounded-lg bg-transparent select-none",children:[(0,o.jsx)("img",{src:e,alt:"",className:"block max-h-[68vh] max-w-full bg-transparent",draggable:!1}),g?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("canvas",{ref:u,width:g.width,height:g.height,className:"hidden"}),(0,o.jsx)("canvas",{ref:m,width:g.width,height:g.height,className:"absolute inset-0 h-full w-full cursor-crosshair touch-none",onPointerDown:e=>{e.preventDefault(),e.stopPropagation(),e.currentTarget.setPointerCapture(e.pointerId),p.current={active:!0,last:null},u.current&&or(u.current,m.current),S(e)},onPointerMove:e=>{p.current.active&&(e.preventDefault(),S(e))},onPointerUp:A,onPointerCancel:A})]}):null]})}),(0,o.jsxs)("div",{className:"flex min-h-[360px] flex-col gap-5",children:[(0,o.jsxs)("div",{children:[(0,o.jsx)("h2",{className:"text-xl font-semibold",children:"局部遮罩编辑"}),(0,o.jsx)("div",{className:"mt-2 text-sm opacity-60",children:g?`${g.width} x ${g.height}px`:"读取中"})]}),(0,o.jsxs)("div",{className:"grid grid-cols-2 gap-2",children:[(0,o.jsx)(ej.Ay,{type:"paint"===w?"primary":"default",icon:(0,o.jsx)(a9.A,{className:"size-4"}),onClick:()=>k("paint"),children:"画笔"}),(0,o.jsx)(ej.Ay,{type:"erase"===w?"primary":"default",icon:(0,o.jsx)(oe.A,{className:"size-4"}),onClick:()=>k("erase"),children:"擦除"})]}),(0,o.jsxs)("div",{className:"space-y-2",children:[(0,o.jsxs)("div",{className:"flex items-center justify-between text-sm",children:[(0,o.jsx)("span",{className:"font-medium opacity-75",children:"笔刷大小"}),(0,o.jsxs)("span",{className:"font-semibold",children:[y,"px"]})]}),(0,o.jsx)(aX.A,{min:8,max:160,step:2,value:y,onChange:b})]}),(0,o.jsxs)("div",{className:"space-y-2",children:[(0,o.jsx)("div",{className:"text-sm font-medium opacity-75",children:"修改要求"}),(0,o.jsx)(a7.A.TextArea,{rows:6,value:f,status:j&&!f.trim()?"error":void 0,placeholder:"例如：把选中区域改成金属材质，保持原图光影",onChange:e=>{x(e.target.value),C("")}}),j?(0,o.jsx)("div",{className:"text-xs font-medium text-[#ef4444]",children:j}):null]}),(0,o.jsxs)("div",{className:"space-y-2",children:[(0,o.jsx)("div",{className:"text-sm font-medium opacity-75",children:"模型"}),(0,o.jsx)(eY.Y,{className:"canvas-compact-control h-10",config:{...a,model:i,imageChannelId:r||a.imageChannelId},value:i,channelId:r||a.imageChannelId,onChange:s,capability:"image",onMissingConfig:l,fullWidth:!0})]}),(0,o.jsxs)("div",{className:"mt-auto flex items-center justify-between gap-2",children:[(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(tN.A,{className:"size-4"}),onClick:()=>{oo(u.current),oo(m.current),C("")},disabled:N,children:"重置"}),(0,o.jsxs)("div",{className:"flex items-center gap-2",children:[(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(v.A,{className:"size-4"}),onClick:d,disabled:N,children:"取消"}),(0,o.jsx)(ej.Ay,{type:"primary",icon:(0,o.jsx)(aY.A,{className:"size-4"}),onClick:M,loading:N,disabled:N,children:"AI 修改"})]})]})]})]})})}function oo(e){let t=e?.getContext("2d");e&&t&&t.clearRect(0,0,e.width,e.height)}function on(e,t,a,o){if(t.x===a.x&&t.y===a.y){e.beginPath(),e.arc(a.x,a.y,o/2,0,2*Math.PI),e.fill();return}e.beginPath(),e.moveTo(t.x,t.y),e.lineTo(a.x,a.y),e.stroke()}function oi(e){let t=e.getContext("2d");if(!t)return!1;let a=t.getImageData(0,0,e.width,e.height).data;for(let e=3;e<a.length;e+=4)if(a[e]>0)return!0;return!1}function or(e,t,a=!1){let o=t?.getContext("2d");t&&o&&(o.clearRect(0,0,t.width,t.height),o.fillStyle=ot,o.fillRect(0,0,t.width,t.height),o.globalCompositeOperation="destination-in",o.drawImage(e,0,0),o.globalCompositeOperation="source-over",a&&function(e,t){let a=t.getContext("2d");if(!a)return;let{width:o,height:n}=t,i=a.getImageData(0,0,o,n).data,r=Math.max(1,Math.round(Math.max(o,n)/1200)),s=8*r,l=s+5*r;e.save(),e.fillStyle="rgba(255, 255, 255, .72)",e.shadowColor="rgba(0, 0, 0, .24)",e.shadowBlur=1.5*r;for(let t=r;t<n-r;t+=r)for(let a=r;a<o-r;a+=r){var d,c,u,m,p;0!==i[(t*o+a)*4+3]&&(d=i,c=o,u=a,0===d[(((m=t)-(p=r))*c+u)*4+3]||0===d[((m+p)*c+u)*4+3]||0===d[(m*c+u-p)*4+3]||0===d[(m*c+u+p)*4+3])&&((a+t)%l>s||e.fillRect(a-r/2,t-r/2,Math.max(1.5,r),Math.max(1.5,r)))}e.restore()}(o,e))}async function os(e,t){var a;let o=document.createElement("canvas");o.width=t.width,o.height=t.height;let n=o.getContext("2d");if(!n)return t.toDataURL("image/png");let i=await (a=await ol(e),new Promise((e,t)=>{let o=new Image;o.onload=()=>e(o),o.onerror=()=>t(Error("读取图片失败")),o.src=a}));return n.drawImage(i,0,0,o.width,o.height),n.fillStyle=ot,n.fillRect(0,0,o.width,o.height),n.globalCompositeOperation="destination-in",n.drawImage(t,0,0),n.globalCompositeOperation="destination-over",n.drawImage(i,0,0,o.width,o.height),n.globalCompositeOperation="source-over",o.toDataURL("image/png")}async function ol(e){if(/^(data|blob):/i.test(e))return e;let t=await (0,U.zx)(e);return new Promise((e,a)=>{let o=new FileReader;o.onload=()=>e(String(o.result||"")),o.onerror=()=>a(Error("读取图片失败")),o.readAsDataURL(t)})}var od=a(44291),oc=a(60737),ou=a(77228),om=a(22860),op=a(80237);let og={horizontalLines:[.5],verticalLines:[.5]};function oh({dataUrl:e,open:t,onClose:a,onConfirm:i}){let[r,s]=(0,n.useState)(og),[l,d]=(0,n.useState)(null),[c,u]=(0,n.useState)(null),m=(0,n.useRef)(null),p=(0,n.useRef)(null),g=r.horizontalLines,h=r.verticalLines,f=g.length+1,x=h.length+1,v=f*x,y=l?{width:Math.max(1,Math.floor(l.width/x)),height:Math.max(1,Math.floor(l.height/f))}:null;(0,n.useEffect)(()=>{if(!t)return;let a=!1;return s(og),u(null),d(null),p.current=null,(0,W.xL)(e).then(e=>{a||d(e)}),()=>{a=!0,p.current=null}},[e,t]);let b=(e,t)=>{let a,o=Math.min(12,Math.max(1,Math.round(Number.isFinite(a=Number(t??("horizontal"===e?f:x)))?a:1))),n="horizontal"===e?"horizontalLines":"verticalLines";u(null),s(e=>({...e,[n]:ov(o)}))},w=e=>{let t="horizontal"===e?"horizontalLines":"verticalLines";u(null),s(e=>{let a=e[t];return a.length>=11?e:{...e,[t]:[...a,function(e){let t=[0,...e,1].sort((e,t)=>e-t),a=.5,o=0;for(let e=0;e<t.length-1;e+=1){let n=t[e+1]-t[e];n>o&&(o=n,a=t[e]+n/2)}return a}(a)].sort((e,t)=>e-t)}})};return(0,o.jsx)(ek.A,{title:null,open:t&&!!e,onCancel:a,footer:null,width:780,centered:!0,destroyOnHidden:!0,children:(0,o.jsxs)("div",{className:"space-y-5",children:[(0,o.jsxs)("div",{children:[(0,o.jsx)("h2",{className:"text-xl font-semibold",children:"切分图片"}),(0,o.jsxs)("p",{className:"mt-1 text-sm opacity-60",children:["生成 ",v," 个图片子节点，并按原图网格排列到画布右侧"]})]}),(0,o.jsxs)("div",{className:"grid gap-6 md:grid-cols-[minmax(260px,1fr)_280px]",children:[(0,o.jsxs)("div",{className:"rounded-xl border p-4",children:[(0,o.jsx)("div",{className:"grid min-h-[300px] place-items-center rounded-lg bg-black/5",children:(0,o.jsxs)("div",{ref:m,className:"relative inline-block max-w-full overflow-hidden rounded-lg bg-black shadow-xl",children:[(0,o.jsx)("img",{src:e,alt:"",className:"block max-h-[340px] max-w-full object-contain opacity-95",draggable:!1}),(0,o.jsx)(ox,{horizontalLines:g,verticalLines:h,active:c,onPointerDown:(e,t,a)=>{if(p.current)return;let o=m.current?.getBoundingClientRect();!o||o.width<=0||o.height<=0||(a.preventDefault(),a.stopPropagation(),a.currentTarget.setPointerCapture(a.pointerId),p.current={pointerId:a.pointerId,box:o},u({axis:e,index:t}))},onPointerMove:(e,t,a)=>{let o,n=p.current;if(!n||n.pointerId!==a.pointerId||!a.currentTarget.hasPointerCapture(a.pointerId))return;let i="horizontal"===e?(a.clientY-n.box.top)/n.box.height:(a.clientX-n.box.left)/n.box.width;o="horizontal"===e?"horizontalLines":"verticalLines",s(e=>{var a,n;let r=[...e[o]];return r[t]=(a=i,n=r[t-1]??0,Math.min((r[t+1]??1)-.01,Math.max(n+.01,a))),{...e,[o]:r}})},onPointerEnd:e=>{p.current?.pointerId===e.pointerId&&(p.current=null,e.currentTarget.hasPointerCapture(e.pointerId)&&e.currentTarget.releasePointerCapture(e.pointerId))}})]})}),(0,o.jsxs)("div",{className:"mt-3 flex items-center justify-between text-sm",children:[(0,o.jsx)("span",{className:"opacity-60",children:"原图"}),(0,o.jsx)("span",{className:"font-semibold",children:l?`${l.width} x ${l.height} px`:"读取中"})]})]}),(0,o.jsxs)("div",{className:"space-y-5 py-2",children:[(0,o.jsx)(of,{label:"行数",value:f,onChange:e=>b("horizontal",e)}),(0,o.jsx)(of,{label:"列数",value:x,onChange:e=>b("vertical",e)}),(0,o.jsxs)("div",{className:"grid grid-cols-2 gap-2",children:[(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(oc.A,{className:"size-4"}),disabled:f>=12,onClick:()=>w("horizontal"),children:"横向线"}),(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(ou.A,{className:"size-4 rotate-90"}),disabled:x>=12,onClick:()=>w("vertical"),children:"纵向线"}),(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(M.A,{className:"size-4"}),disabled:!c,onClick:()=>{if(!c)return;let e="horizontal"===c.axis?"horizontalLines":"verticalLines";s(t=>({...t,[e]:t[e].filter((e,t)=>t!==c.index)})),u(null)},children:"删除线"}),(0,o.jsx)(ej.Ay,{icon:(0,o.jsx)(om.A,{className:"size-4"}),onClick:()=>{u(null),s(e=>({horizontalLines:ov(e.horizontalLines.length+1),verticalLines:ov(e.verticalLines.length+1)}))},children:"重置线"})]}),(0,o.jsxs)("div",{className:"rounded-xl border px-4 py-3 text-sm",children:[(0,o.jsxs)("div",{className:"flex items-center justify-between",children:[(0,o.jsx)("span",{className:"opacity-60",children:"切片数量"}),(0,o.jsxs)("span",{className:"font-semibold",children:[v," 个"]})]}),(0,o.jsxs)("div",{className:"mt-2 flex items-center justify-between",children:[(0,o.jsx)("span",{className:"opacity-60",children:"平均约"}),(0,o.jsx)("span",{className:"font-semibold",children:y?`${y.width} x ${y.height}`:"未知"})]})]}),(0,o.jsx)(ej.Ay,{type:"primary",size:"large",className:"w-full",icon:(0,o.jsx)(op.A,{className:"size-4"}),onClick:()=>i(r),children:"生成子节点"})]})]})]})})}function of({label:e,value:t,onChange:a}){return(0,o.jsxs)("label",{className:"block space-y-2",children:[(0,o.jsx)("span",{className:"font-medium opacity-75",children:e}),(0,o.jsx)(od.A,{className:"w-full",min:1,max:12,precision:0,value:t,onChange:a})]})}function ox({horizontalLines:e,verticalLines:t,active:a,onPointerDown:n,onPointerMove:i,onPointerEnd:r}){return(0,o.jsxs)("div",{className:"pointer-events-none absolute inset-0",children:[t.map((e,t)=>(0,o.jsx)("div",{className:"pointer-events-auto absolute inset-y-0 -ml-2 w-4 touch-none cursor-ew-resize select-none",style:{left:`${100*e}%`},onPointerDown:e=>n("vertical",t,e),onPointerMove:e=>i("vertical",t,e),onPointerUp:r,onPointerCancel:r,onLostPointerCapture:r,children:(0,o.jsx)("div",{className:`absolute left-1/2 top-0 h-full border-l shadow-[0_0_0_1px_rgba(0,0,0,.35)] ${a?.axis==="vertical"&&a.index===t?"border-amber-300":"border-white/90"}`})},`column-${t}`)),e.map((e,t)=>(0,o.jsx)("div",{className:"pointer-events-auto absolute inset-x-0 -mt-2 h-4 touch-none cursor-ns-resize select-none",style:{top:`${100*e}%`},onPointerDown:e=>n("horizontal",t,e),onPointerMove:e=>i("horizontal",t,e),onPointerUp:r,onPointerCancel:r,onLostPointerCapture:r,children:(0,o.jsx)("div",{className:`absolute left-0 top-1/2 w-full border-t shadow-[0_0_0_1px_rgba(0,0,0,.35)] ${a?.axis==="horizontal"&&a.index===t?"border-amber-300":"border-white/90"}`})},`row-${t}`))]})}function ov(e){return Array.from({length:Math.max(1,e)-1},(t,a)=>(a+1)/e)}var oy=a(57362);let ob=[{value:"high",title:"高清插值",description:"适合照片和细节图"},{value:"bilinear",title:"双线性",description:"平滑、速度快"},{value:"nearest",title:"最近邻",description:"适合像素风格"}],ow=[{label:"1K",value:1024},{label:"2K",value:2048},{label:"4K",value:4096}],ok={targetLongEdge:2048,algorithm:"high"};function oj({dataUrl:e,open:t,onClose:a,onConfirm:i}){let[r,s]=(0,n.useState)(ok),[l,d]=(0,n.useState)(null),c=l?Math.max(l.width,l.height):0,u=(0,n.useMemo)(()=>l?et(l.width,l.height,r.targetLongEdge):null,[l,r.targetLongEdge]),m=!!(l&&c<r.targetLongEdge&&r.targetLongEdge<=4096),p=!!(l&&c>=4096);return(0,n.useEffect)(()=>{t&&(s(ok),d(null))},[e,t]),(0,n.useEffect)(()=>{t&&(0,W.xL)(e).then(d)},[e,t]),(0,n.useEffect)(()=>{if(!l)return;let e=ow.find(e=>c<e.value)?.value||4096;s(t=>({...t,targetLongEdge:e}))},[l,c]),(0,o.jsx)(ek.A,{title:null,open:t&&!!e,onCancel:a,footer:null,width:820,centered:!0,destroyOnHidden:!0,children:(0,o.jsxs)("div",{className:"space-y-5",children:[(0,o.jsx)("div",{children:(0,o.jsx)("h2",{className:"text-xl font-semibold",children:"图片放大"})}),(0,o.jsxs)("div",{className:"grid gap-6 md:grid-cols-[minmax(260px,1fr)_360px]",children:[(0,o.jsxs)("div",{className:"rounded-xl border p-4",children:[(0,o.jsx)("div",{className:"grid min-h-[280px] place-items-center rounded-lg bg-black/5",children:(0,o.jsx)("img",{src:e,alt:"",className:"max-h-[320px] max-w-full rounded-lg object-contain shadow-xl",draggable:!1})}),(0,o.jsxs)("div",{className:"mt-3 flex items-center justify-between text-sm",children:[(0,o.jsx)("span",{className:"opacity-60",children:"源图"}),(0,o.jsx)("span",{className:"font-semibold",children:l?`${l.width} x ${l.height} px`:"读取中"})]})]}),(0,o.jsxs)("div",{className:"space-y-6 py-2",children:[(0,o.jsxs)("div",{className:"space-y-2",children:[(0,o.jsx)("div",{className:"font-medium opacity-75",children:"目标像素"}),(0,o.jsx)(eX.A,{block:!0,value:r.targetLongEdge,options:ow.map(e=>({label:`${e.label} \xb7 ${e.value}px`,value:e.value,disabled:!!(l&&c>=e.value)})),onChange:e=>s(t=>({...t,targetLongEdge:Number(e)}))}),l&&!m?(0,o.jsx)("div",{className:"text-xs font-medium text-[#ef4444]",children:p?"图片已达到 4K，无需放大":"图片已达到当前目标像素，无需放大"}):null]}),(0,o.jsxs)("div",{className:"space-y-2",children:[(0,o.jsx)("div",{className:"font-medium opacity-75",children:"放大算法"}),(0,o.jsx)(eX.A,{block:!0,value:r.algorithm,options:ob.map(e=>({value:e.value,label:(0,o.jsxs)("span",{className:"flex min-h-12 flex-col justify-center text-left leading-5",children:[(0,o.jsx)("span",{className:"font-medium",children:e.title}),(0,o.jsx)("span",{className:"text-xs opacity-55",children:e.description})]})})),onChange:e=>s(t=>({...t,algorithm:e}))})]}),(0,o.jsx)("div",{className:"rounded-xl border px-4 py-3 text-sm",children:(0,o.jsxs)("div",{className:"flex items-center justify-between",children:[(0,o.jsx)("span",{className:"opacity-60",children:"输出尺寸"}),(0,o.jsx)("span",{className:"font-semibold",children:u?`${u.width} x ${u.height} px`:"未知"})]})})]})]}),(0,o.jsx)("div",{className:"flex justify-end",children:(0,o.jsx)(ej.Ay,{type:"primary",size:"large",icon:(0,o.jsx)(oy.A,{className:"size-4"}),disabled:!m,onClick:()=>i(r),children:"生成放大图"})})]})})}var oC=a(60243),oN=a(23797);function oI(e,t,a,o){let n=oA(e,t,a),i=t.find(t=>t.id===e);if(i?.type===ev.p.Config&&i.metadata?.composerContent?.trim())return function(e,t,a){let o=oS(a,e),n=new Map(e.map(e=>[e.nodeId,e])),i=[],r=new Map,s=[],l={image:0,video:0,audio:0,text:0},d=!1,c=0,u="";for(let e of t.matchAll(/@\[node:([^\]]+)\]/g)){if(void 0===e.index)continue;d=!0,u+=t.slice(c,e.index);let a=n.get(e[1]);if(a&&!o.textNodeIds.has(a.nodeId)&&!o.referenceNodeIds.has(a.nodeId)){var m,p;let e=r.get(a.nodeId);e||(m=a.type,p=l[a.type]++,e="image"===m?(0,oC.x)(p):"video"===m?(0,oN.q5)("video",p):"audio"===m?(0,oN.q5)("audio",p):`文本${p+1}`,r.set(a.nodeId,e),"text"===a.type?s.push(`【${e}】
${a.text||""}`):i.push(a)),u+="text"===a.type?`【${e}】`:e}c=e.index+e[0].length}u+=t.slice(c),s.length&&(u=`${u.trim()}

${s.join("\n\n")}`);let g=i.filter(e=>!o.referenceNodeIds.has(e.nodeId)).map(e=>e.image).filter(e=>!!e),h=i.filter(e=>!o.referenceNodeIds.has(e.nodeId)).map(e=>e.video).filter(e=>!!e),f=i.filter(e=>!o.referenceNodeIds.has(e.nodeId)).map(e=>e.audio).filter(e=>!!e),x=oT(a,e),v=new Set([x.firstFrame?.id,x.lastFrame?.id].filter(e=>!!e)),y=g.filter(e=>!v.has(e.id));return d?{prompt:u,referenceImages:[...o.klingImageReferences,...y],firstFrame:x.firstFrame,lastFrame:x.lastFrame,referenceVideos:h,referenceAudios:f,videoMultiPrompt:o.videoMultiPrompt,videoElementList:o.videoElementList,textCount:l.text,imageCount:g.length,videoCount:h.length,audioCount:f.length}:{prompt:t,referenceImages:o.klingImageReferences,firstFrame:x.firstFrame,lastFrame:x.lastFrame,referenceVideos:[],referenceAudios:[],videoMultiPrompt:o.videoMultiPrompt,videoElementList:o.videoElementList,textCount:0,imageCount:0,videoCount:0,audioCount:0}}(n,o,i);let r=oS(i,n),s=i?.metadata?.excludeUpstreamText?"":n.filter(e=>!r.textNodeIds.has(e.nodeId)).map(e=>e.text).filter(Boolean).join("\n\n"),l=n.filter(e=>!r.referenceNodeIds.has(e.nodeId)).map(e=>e.image).filter(e=>!!e),d=n.filter(e=>!r.referenceNodeIds.has(e.nodeId)).map(e=>e.video).filter(e=>!!e),c=n.filter(e=>!r.referenceNodeIds.has(e.nodeId)).map(e=>e.audio).filter(e=>!!e),u=oT(i,n),m=new Set([u.firstFrame?.id,u.lastFrame?.id].filter(e=>!!e)),p=l.filter(e=>!m.has(e.id));return{prompt:s?`${o}

${s}`:o,referenceImages:[...r.klingImageReferences,...p],firstFrame:u.firstFrame,lastFrame:u.lastFrame,referenceVideos:d,referenceAudios:c,videoMultiPrompt:r.videoMultiPrompt,videoElementList:r.videoElementList,textCount:n.filter(e=>"text"===e.type).length,imageCount:l.length,videoCount:d.length,audioCount:c.length}}function oS(e,t){let a=new Map(t.map(e=>[e.nodeId,e])),o=new Set,n=new Set,i=(e?.metadata?.klingImageNodeIds||[]).map(e=>(n.add(e),a.get(e)?.image||null)).filter(e=>!!e),r=(e?.metadata?.klingMultiPrompt||[]).map(e=>{let t=e.textNodeId||"",n=a.get(t);return t&&n?.type==="text"&&n.text?(o.add(t),{prompt:n.text,duration:e.duration||"1"}):null}).filter(e=>!!e),s=(e?.metadata?.klingElementList||[]).slice(0,3).map(e=>{let t=(e.nodeIds||[]).slice(0,4).map(e=>{var t;return n.add(e),t=a.get(e),t?.image?{id:t.nodeId,kind:"image",name:t.image.name,type:t.image.type,dataUrl:t.image.dataUrl,storageKey:t.image.storageKey}:t?.video?{id:t.nodeId,kind:"video",name:t.video.name,type:t.video.type,url:t.video.url,storageKey:t.video.storageKey,bytes:t.video.bytes,width:t.video.width,height:t.video.height,durationMs:t.video.durationMs}:t?.audio?{id:t.nodeId,kind:"audio",name:t.audio.name,type:t.audio.type,url:t.audio.url,storageKey:t.audio.storageKey,durationMs:t.audio.durationMs}:null}).filter(e=>!!e);return t.length?{name:e.name||"",description:e.description||"",references:t}:null}).filter(e=>!!e);return{textNodeIds:o,referenceNodeIds:n,klingImageReferences:i,videoMultiPrompt:r,videoElementList:s}}function oA(e,t,a){return(0,az.IE)(e,t,a).flatMap(e=>{var t,a,o,n;let i=(t=e,(0,ec.IM)(t.type)&&t.metadata?.content?{id:t.id,name:`image-${t.id}.png`,type:t.metadata.mimeType||"image/png",dataUrl:t.metadata.content,storageKey:t.metadata.storageKey}:null);if(i)return[{nodeId:e.id,type:"image",title:e.title,image:i}];let r=(a=e).type===ev.p.Video&&a.metadata?.content?{id:a.id,name:`video-${a.id}.mp4`,type:a.metadata.mimeType||"video/mp4",url:a.metadata.content,storageKey:a.metadata.storageKey,bytes:a.metadata.bytes,width:a.metadata.naturalWidth,height:a.metadata.naturalHeight,durationMs:a.metadata.durationMs}:null;if(r)return[{nodeId:e.id,type:"video",title:e.title,video:r}];let s=(o=e).type===ev.p.Audio&&o.metadata?.content?{id:o.id,name:`audio-${o.id}.mp3`,type:o.metadata.mimeType||"audio/mpeg",url:o.metadata.content,storageKey:o.metadata.storageKey,durationMs:o.metadata.durationMs}:null;if(s)return[{nodeId:e.id,type:"audio",title:e.title,audio:s}];let l=(n=e).type===ev.p.Text?n.metadata?.content||n.metadata?.prompt||"":n.metadata?.prompt||"";return l?[{nodeId:e.id,type:"text",title:e.title,text:l}]:[]})}function oM(e){return e.referenceImages.length?[{role:"user",content:[{type:"text",text:e.prompt},...e.referenceImages.map(e=>({type:"image_url",image_url:{url:e.dataUrl}}))]}]:[{role:"user",content:e.prompt}]}async function o_(e){let{imageToDataUrl:t}=await Promise.resolve().then(a.bind(a,80387));return{...e,referenceImages:await Promise.all(e.referenceImages.map(async e=>({...e,dataUrl:await t(e)}))),firstFrame:e.firstFrame?{...e.firstFrame,dataUrl:await t(e.firstFrame)}:null,lastFrame:e.lastFrame?{...e.lastFrame,dataUrl:await t(e.lastFrame)}:null}}function oT(e,t){let a=new Map(t.filter(e=>e.image).map(e=>[e.nodeId,e.image]));return{firstFrame:e?.metadata?.firstFrameNodeId&&a.get(e.metadata.firstFrameNodeId)||null,lastFrame:e?.metadata?.lastFrameNodeId&&a.get(e.metadata.lastFrameNodeId)||null}}var oz=a(86798),oP=a(92434),oE=a(71821),oD=a(32744),oR=a(80675),o$=a(3339),oL=a(99726),oF=a(43458),oV=a(40015),oU=a(34728),oK=a(67854),oW=a(73144);function oO({open:e,tools:t,selectedIds:a,showLabels:i,onToggle:r,onShowLabelsChange:s,onCancel:d,onSave:c}){let{token:u}=o$.A.useToken(),m=(0,n.useRef)(null),g=(0,n.useRef)(null),[h,f]=(0,n.useState)({left:0,max:0,viewport:1,content:1}),x=(0,n.useMemo)(()=>new Set(a),[a]),v=t.filter(e=>x.has(e.id)),y=[...v,{id:"more",title:"配置快捷工具",label:"更多",icon:(0,o.jsx)(oR.A,{className:"size-4"}),active:!0}],b=(0,n.useCallback)(()=>{let e=m.current;e&&f({left:e.scrollLeft,max:Math.max(0,e.scrollWidth-e.clientWidth),viewport:Math.max(1,e.clientWidth),content:Math.max(1,e.scrollWidth)})},[]),w=(0,n.useCallback)(e=>{let t=m.current;t&&(t.scrollLeft=e,b())},[b]);(0,n.useEffect)(()=>{if(!e)return;let t=m.current,a=()=>b(),o=[],n=window.requestAnimationFrame(()=>{a(),o.push(window.requestAnimationFrame(a))});o.push(n);let i=window.setTimeout(a,120),r="u">typeof ResizeObserver&&t?new ResizeObserver(a):null;return t&&r?.observe(t),t?.childNodes.forEach(e=>{e instanceof Element&&r?.observe(e)}),a(),window.addEventListener("resize",b),()=>{o.forEach(e=>window.cancelAnimationFrame(e)),window.clearTimeout(i),r?.disconnect(),window.removeEventListener("resize",b)}},[e,a,i,y.length,b]);let k=g.current?.clientWidth||h.viewport,j=h.max>0?Math.min(k,Math.max(64,h.viewport/h.content*k)):k;return(0,o.jsxs)(ek.A,{title:"自定义工具栏",open:e,centered:!0,width:760,onCancel:d,destroyOnHidden:!0,footer:(0,o.jsxs)("div",{className:"flex items-center justify-between gap-3",children:[(0,o.jsxs)("div",{className:"flex items-center gap-2",children:[(0,o.jsx)("span",{children:"显示按钮文字"}),(0,o.jsx)(e5.A,{checked:i,onChange:s})]}),(0,o.jsxs)(oL.A,{children:[(0,o.jsx)(ej.Ay,{onClick:d,children:"取消"}),(0,o.jsx)(ej.Ay,{type:"primary",onClick:c,children:"保存"})]})]}),children:[(0,o.jsx)(oF.A.Paragraph,{type:"secondary",className:"!mb-4",children:"选择你想在图片节点编辑栏中使用的快捷工具。"}),(0,o.jsx)(oV.A,{size:"small",title:(0,o.jsxs)(oL.A,{size:6,children:[(0,o.jsx)(p.A,{className:"size-4"}),"节点预览"]}),className:"mb-4",children:(0,o.jsxs)("div",{className:"relative flex min-h-[300px] w-full justify-center pt-20 pb-9",children:[(0,o.jsx)("div",{ref:m,className:"hide-scrollbar absolute left-2 right-2 top-3 z-10 flex h-12 items-center gap-x-2 overflow-x-auto rounded-xl border border-white/10 bg-[#242424] px-2 text-[13px] text-[#f3f3f3] shadow-[0_8px_28px_rgba(0,0,0,.28)]",onScroll:b,children:y.map(e=>(0,o.jsx)(oB,{tool:e,showLabels:i},e.id))}),(0,o.jsxs)("div",{className:"flex h-48 w-full max-w-[360px] flex-col items-center justify-center rounded-xl border",style:{background:u.colorFillAlter,borderColor:u.colorBorderSecondary,color:u.colorTextSecondary},children:[(0,o.jsx)(l.A,{className:"mb-2 size-8"}),(0,o.jsx)(oF.A.Text,{type:"secondary",children:"图片节点"})]}),(0,o.jsx)("input",{ref:g,type:"range",min:0,max:Math.max(h.max,1),value:Math.min(h.left,Math.max(h.max,1)),disabled:h.max<=0,className:"absolute bottom-4 left-10 right-10 h-2.5 cursor-pointer appearance-none bg-transparent disabled:cursor-default [&::-moz-range-thumb]:h-2.5 [&::-moz-range-thumb]:w-[var(--preview-scrollbar-thumb-width)] [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-[#8d9498] [&::-moz-range-track]:h-2.5 [&::-moz-range-track]:rounded-full [&::-moz-range-track]:bg-[#bdc4c8] [&::-webkit-slider-runnable-track]:h-2.5 [&::-webkit-slider-runnable-track]:rounded-full [&::-webkit-slider-runnable-track]:bg-[#bdc4c8] [&::-webkit-slider-thumb]:h-2.5 [&::-webkit-slider-thumb]:w-[var(--preview-scrollbar-thumb-width)] [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#8d9498]",style:{"--preview-scrollbar-thumb-width":`${j}px`},onInput:e=>w(Number(e.currentTarget.value)),onChange:e=>w(Number(e.target.value))})]})}),(0,o.jsx)(oU.A,{layout:"vertical",className:"!mb-0",children:(0,o.jsx)(oU.A.Item,{className:"!mb-4",label:(0,o.jsxs)(oL.A,{size:8,children:[(0,o.jsx)("span",{children:"快捷工具"}),(0,o.jsxs)(oK.A,{className:"m-0",children:[v.length,"/",t.length]})]}),children:(0,o.jsx)(oW.A.Group,{value:a,className:"grid w-full gap-3 md:grid-cols-3",onChange:e=>{let a;return a=new Set(e),void t.forEach(e=>{let t=a.has(e.id);x.has(e.id)!==t&&r(e.id,t)})},children:t.map(e=>(0,o.jsx)(oW.A,{value:e.id,className:"m-0",children:(0,o.jsxs)("span",{className:"inline-flex items-center gap-2",children:[e.icon,e.label]})},e.id))})})})]})}function oB({tool:e,showLabels:t}){return(0,o.jsx)(e4.A,{title:e.title,children:(0,o.jsx)("span",{className:"flex h-12 shrink-0 items-center",style:{color:e.danger?"#ef4444":void 0},children:(0,o.jsxs)("span",{className:`flex h-9 items-center rounded-lg px-2 ${t?"gap-2":"justify-center"}`,children:[e.icon,t?(0,o.jsx)("span",{className:"whitespace-nowrap",children:e.label}):null]})})})}var oq=a(35067),oG=a(41381);let oH="canvas-image-quick-tools-v6",oX="canvas-panorama-quick-tools-v1",oY=["info","delete","saveAsset","download"],oJ=[{id:"copyPrompt",defaultVisible:!0,panelLabel:"复制提示词",label:"复制提示词",title:"复制生成该图片的提示词",icon:()=>(0,o.jsx)(tC.A,{className:"size-4"}),run:(e,t)=>t.onCopyPrompt(e)},{id:"reversePrompt",defaultVisible:!0,panelLabel:"反推提示词",label:"反推提示词",title:"创建反推提示词的文本和配置节点",icon:()=>(0,o.jsx)(e$.A,{className:"size-4"}),run:(e,t)=>t.onReversePrompt(e)},{id:"replace",defaultVisible:!0,panelLabel:"替换图片",label:"替换图片",title:"替换图片",icon:()=>(0,o.jsx)(g.A,{className:"size-4"}),run:(e,t)=>t.onUpload(e)},{id:"resize",defaultVisible:!1,panelLabel:"锁比例",label:e=>e.metadata?.freeResize?"自由比例":"锁比例",title:e=>e.metadata?.freeResize?"切换为等比缩放":"切换为自由比例",icon:e=>e.metadata?.freeResize?(0,o.jsx)(a0.A,{className:"size-4"}):(0,o.jsx)(a1.A,{className:"size-4"}),active:e=>!!e.metadata?.freeResize,run:(e,t)=>t.onToggleFreeResize(e)},{id:"maskEdit",defaultVisible:!0,panelLabel:"局部编辑",label:"局部编辑",title:"对图片进行局部修改",icon:()=>(0,o.jsx)(a9.A,{className:"size-4"}),run:(e,t)=>t.onMaskEdit(e)},{id:"crop",defaultVisible:!0,panelLabel:"裁剪",label:"裁剪",title:"裁剪并生成新节点",icon:()=>(0,o.jsx)(aW.A,{className:"size-4"}),run:(e,t)=>t.onCrop(e)},{id:"split",defaultVisible:!0,panelLabel:"切图",label:"切图",title:"按行列切分图片",icon:()=>(0,o.jsx)(op.A,{className:"size-4"}),run:(e,t)=>t.onSplit(e)},{id:"upscale",defaultVisible:!0,panelLabel:"放大",label:"放大",title:"放大图片分辨率",icon:()=>(0,o.jsx)(oq.A,{className:"size-4"}),run:(e,t)=>t.onUpscale(e)},{id:"superResolve",defaultVisible:!1,panelLabel:"超分",label:"超分",title:"AI 超分",icon:()=>(0,o.jsx)(tj.A,{className:"size-4"}),run:(e,t)=>t.onSuperResolve(e)},{id:"angle",defaultVisible:!1,panelLabel:"多角度",label:"多角度",title:"生成角度",icon:()=>(0,o.jsx)(e0.A,{className:"size-4"}),run:(e,t)=>t.onAngle(e)},{id:"view",defaultVisible:!1,panelLabel:"查看大图",label:"查看大图",title:"查看图片详情",icon:()=>(0,o.jsx)(oG.A,{className:"size-4"}),run:(e,t)=>t.onViewImage(e)}],oQ=[...oY,...oJ.filter(e=>e.defaultVisible).map(e=>e.id)],oZ=oQ.filter(e=>"replace"!==e);function o0(e){let t=[...oY,...oJ.map(e=>e.id)],a=new Set(t);return t.filter(t=>e.includes(t)&&a.has(t))}function o1(e,t){return"function"==typeof e?e(t):e}function o2({node:e,viewport:t,onKeep:a,onLeave:i,onInfo:r,onDecreaseFont:s,onIncreaseFont:u,onToggleDialog:m,onGenerateImage:h,onUpload:f,onDownload:x,onSaveAsset:v,onUploadMediaToCloud:y,onUploadImageToCloud:b,onMaskEdit:w,onCrop:k,onSplit:C,onUpscale:N,onSuperResolve:I,onAngle:S,onViewImage:_,onReversePrompt:T,onRetry:z,onToggleFreeResize:P,onDelete:E,projectId:D}){var R;let[$,L]=(0,n.useState)(()=>({[oH]:{ids:oQ,showLabels:!0},[oX]:{ids:oZ,showLabels:!0}})),[F,V]=(0,n.useState)(oQ),[U,K]=(0,n.useState)(!0),[W,O]=(0,n.useState)(!1),{message:B}=ew.A.useApp(),q=(0,tz.s)(),G=(0,ec.sK)(e?.type),H=G?oX:oH,{ids:Y,showLabels:J}=$[H];if((0,n.useEffect)(()=>{let e=(e,t)=>{try{var a;let o=window.localStorage.getItem(e);if(null===o)return{ids:t,showLabels:!0};let n=(a=JSON.parse(o),Array.isArray(a)?{ids:o0(a),showLabels:!0}:a&&"object"==typeof a?{ids:Array.isArray(a.ids)?o0(a.ids):oQ,showLabels:!1!==a.showLabels}:{ids:oQ,showLabels:!0});return e===oX?{...n,ids:n.ids.filter(e=>"replace"!==e)}:n}catch{try{window.localStorage.removeItem(e)}catch{}return{ids:t,showLabels:!0}}};L({[oH]:e(oH,oQ),[oX]:e(oX,oZ)})},[]),(0,n.useEffect)(()=>{O(!1)},[e?.id]),!e)return null;let Q=t.x+(e.position.x+e.width/2)*t.k,Z=t.y+e.position.y*t.k-14,ee=(0,ec.IM)(e.type),et=e.type===ev.p.Video,ea=e.type===ev.p.Audio,eo=ee&&!!e.metadata?.content,en=et&&!!e.metadata?.content,ei=ea&&!!e.metadata?.content,er=e.type===ev.p.Text,es=e.type===ev.p.Config,el=e.metadata?.status==="error",ed=new Set(Y),eu=(R={onUpload:f,onToggleFreeResize:P,onMaskEdit:w,onCrop:k,onSplit:C,onUpscale:N,onSuperResolve:I,onAngle:S,onViewImage:_,onCopyPrompt:e=>{let t=((0,ec.sK)(e.type)?e.metadata?.panoramaSourcePrompt:e.metadata?.prompt)?.trim();t?q(t,"提示词已复制"):B.warning("暂无可复制的提示词")},onReversePrompt:T},oJ.map(t=>({id:t.id,label:o1(t.label,e),title:o1(t.title,e),icon:t.icon(e),active:t.active?.(e),onClick:()=>t.run(e,R)}))).filter(e=>!G||"replace"!==e.id),em=[{id:"info",title:"查看节点信息",label:"信息",icon:(0,o.jsx)(oz.A,{className:"size-4"}),onClick:()=>r(e)},{id:"delete",title:"移除节点",label:"删除",icon:(0,o.jsx)(M.A,{className:"size-4"}),onClick:()=>E(e),danger:!0}],ep=[...en?[{id:"editVideo",title:"在视频剪辑台中剪辑/配乐",label:"剪辑",icon:(0,o.jsx)(aW.A,{className:"size-4 text-amber-400"}),onClick:()=>{if(!X.k.getState().user)return void X.k.getState().openLoginModal();let t=D?`&projectId=${encodeURIComponent(D)}`:"";window.open(`/editor?nodeId=${encodeURIComponent(e.id)}&title=${encodeURIComponent(e.title||"画布分镜")}${t}`,"_blank")}}]:[],...el?[{id:"retry",title:"重新生成",label:"重试",icon:(0,o.jsx)(oP.A,{className:"size-4"}),onClick:()=>z(e)}]:[],...eo||en||er?[{id:"saveAsset",title:"加入我的素材",label:"存素材",icon:(0,o.jsx)(oE.A,{className:"size-4"}),onClick:()=>v(e)}]:[],...(en||ei)&&!e.metadata?.storageKey?.startsWith("server:")?[{id:"uploadMediaToCloud",title:"上传至云存储",label:"上传至云存储",icon:(0,o.jsx)(g.A,{className:"size-4"}),onClick:()=>y(e)}]:[],...eo&&!e.metadata?.storageKey?.startsWith("server:")?[{id:"uploadImageToCloud",title:"上传至云存储",label:"上传至云存储",icon:(0,o.jsx)(g.A,{className:"size-4"}),onClick:()=>b(e)}]:[],...eo||en||ei?[{id:"download",title:ei?"下载音频":en?"下载视频":"下载图片",label:"下载",icon:(0,o.jsx)(j.A,{className:"size-4"}),onClick:()=>x(e)}]:[],...er||eo||et?[{id:"edit",title:"编辑",label:"编辑",icon:(0,o.jsx)(eG.A,{className:"size-4"}),onClick:()=>m(e)}]:[],...er?[{id:"generateImage",title:"用文本生图",label:"生图",icon:(0,o.jsx)(l.A,{className:"size-4"}),onClick:()=>h(e)}]:[],...es?[{id:"config",title:"生成配置",label:"生成配置",icon:(0,o.jsx)(p.A,{className:"size-4"}),onClick:()=>m(e)}]:[],...er?[{id:"decreaseFont",title:"减小字号",label:"缩小",icon:(0,o.jsx)(oD.A,{className:"size-4"}),onClick:()=>s(e)}]:[],...er?[{id:"increaseFont",title:"增大字号",label:"放大",icon:(0,o.jsx)(A.A,{className:"size-4"}),onClick:()=>u(e)}]:[],...!ee||G||eo?[]:[{id:"uploadImage",title:"上传图片",label:"上传图片",icon:(0,o.jsx)(g.A,{className:"size-4"}),onClick:()=>f(e)}],...et?[{id:"uploadVideo",title:en?"替换视频":"上传视频",label:en?"替换视频":"上传视频",icon:(0,o.jsx)(d.A,{className:"size-4"}),onClick:()=>f(e)}]:[],...ea?[{id:"uploadAudio",title:ei?"替换音频":"上传音频",label:ei?"替换音频":"上传音频",icon:(0,o.jsx)(c.A,{className:"size-4"}),onClick:()=>f(e)}]:[],...eo?eu.map(e=>({id:e.id,title:e.title,label:e.label,icon:e.icon,active:e.active,onClick:e.onClick})):[]],eg=eo?[...em,...ep].filter(e=>"uploadImageToCloud"===e.id||ed.has(e.id)):[...em,...ep],eh=[...em,...ep].filter(e=>"retry"!==e.id&&"uploadImageToCloud"!==e.id),ef=()=>{O(!1),i()};return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)("div",{className:"absolute z-[70] flex flex-wrap -translate-x-1/2 -translate-y-full items-center justify-center gap-x-2 overflow-visible rounded-xl border border-white/10 bg-[#242424] px-2 text-[13px] text-[#f3f3f3] shadow-[0_8px_28px_rgba(0,0,0,.28)]",style:{left:Q,top:Z,maxWidth:"min(800px, calc(100vw - 32px))"},onMouseEnter:()=>a(e.id),onMouseLeave:()=>{W||i()},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[eg.map(e=>(0,o.jsx)(o4,{...e,showLabel:J},e.id)),eo?(0,o.jsx)(o4,{id:"more",title:"配置快捷工具",label:"更多",icon:(0,o.jsx)(oR.A,{className:"size-4"}),active:W,onClick:function(){a(e.id),V(Y),K(J),O(!0)},showLabel:J}):null]}),eo?(0,o.jsx)(oO,{open:W,tools:eh,selectedIds:F,showLabels:U,onToggle:(e,t)=>{V(a=>{let o=new Set(a);return t?o.add(e):o.delete(e),eh.filter(e=>o.has(e.id)).map(e=>e.id)})},onShowLabelsChange:K,onCancel:ef,onSave:()=>{let e={ids:G?F.filter(e=>"replace"!==e):F,showLabels:U};try{window.localStorage.setItem(H,JSON.stringify(e))}catch{B.error("快捷工具配置保存失败");return}L(t=>({...t,[H]:e})),ef()}}):null]})}function o5({node:e,open:t,onClose:a}){let i=O.$[(0,H.C)(e=>e.theme)],[r,s]=(0,n.useState)("info"),l=(0,ec.IM)(e?.type)&&e?.metadata?.content?(0,W.P0)(e.metadata.content):0,d=(0,ec.IM)(e?.type)&&e?.metadata?.batchChildIds?.length||0,c=(0,n.useMemo)(()=>e?JSON.stringify(e,(e,t)=>{if("panoramaFinalPrompt"!==e)return"content"===e&&"string"==typeof t&&t.startsWith("data:image/")?"[base64 image]":t},2):"",[e]);(0,n.useEffect)(()=>{t&&s("info")},[e?.id,t]);let u=(0,o.jsxs)("div",{className:"flex items-center justify-between gap-4 pr-12",children:[(0,o.jsx)("span",{children:"节点信息"}),(0,o.jsx)(eX.A,{size:"small",value:r,onChange:e=>s(e),options:[{label:"信息",value:"info"},{label:"JSON",value:"json"}]})]});return(0,o.jsx)(ek.A,{className:"canvas-node-info-modal",title:u,open:t&&!!e,centered:!0,footer:null,onCancel:a,children:e?(0,o.jsx)("div",{className:"h-[56vh] min-h-[360px] text-sm",children:"info"===r?(0,o.jsxs)("div",{className:"thin-scrollbar h-full space-y-3 overflow-auto pr-1",children:[(0,o.jsx)(o3,{label:"ID",value:e.id}),(0,o.jsx)(o3,{label:"名称",value:e.title||"未命名节点"}),(0,o.jsx)(o3,{label:"类型",value:e.type===ev.p.Text?"文本":e.type===ev.p.Image?"图片":e.type===ev.p.Panorama?"全景图":e.type===ev.p.Video?"视频":e.type===ev.p.Audio?"音频":e.type===ev.p.Director?"导演台":e.type===ev.p.Group?"组":"生成配置"}),(0,o.jsx)(o3,{label:"尺寸",value:`${Math.round(e.width)} x ${Math.round(e.height)}`}),(0,o.jsx)(o3,{label:"位置",value:`${Math.round(e.position.x)}, ${Math.round(e.position.y)}`}),(0,o.jsx)(o3,{label:"状态",value:e.metadata?.status||"idle"}),d>1?(0,o.jsx)(o3,{label:"图片组",value:`${d} 张`}):null,((0,ec.sK)(e.type)?e.metadata?.panoramaSourcePrompt:e.metadata?.prompt)?(0,o.jsx)(o3,{label:"提示词",value:(0,ec.sK)(e.type)?e.metadata?.panoramaSourcePrompt:e.metadata?.prompt}):null,l?(0,o.jsx)(o3,{label:"图片大小",value:(0,W.z3)(l)}):null,e.metadata?.errorDetails?(0,o.jsx)("div",{className:"rounded-lg border p-3 text-red-400",style:{borderColor:i.node.stroke},children:e.metadata.errorDetails}):null]}):(0,o.jsx)("pre",{className:"thin-scrollbar h-full overflow-auto rounded-lg border p-3 text-xs leading-5",style:{background:i.node.fill,borderColor:i.node.stroke,color:i.node.text},children:c})}):null})}function o4({title:e,label:t,icon:a,onClick:n,showLabel:i,active:r=!1,danger:s=!1}){let l=i&&!!t;return(0,o.jsx)(e4.A,{title:e,placement:"top",mouseEnterDelay:.2,color:"#ffffff",children:(0,o.jsx)("button",{type:"button",className:`group relative flex h-12 items-center whitespace-nowrap ${s?"text-[#ef4444]":""}`,onClick:n,"aria-label":e,children:(0,o.jsxs)("span",{className:`flex h-8 items-center ${l?"gap-2 px-2.5":"justify-center px-2"} rounded-lg transition group-hover:bg-white/10 ${r?"bg-white/10":""}`,children:[a,l?(0,o.jsx)("span",{children:t}):null]})})})}function o3({label:e,value:t}){return(0,o.jsxs)("div",{className:"grid grid-cols-[72px_minmax(0,1fr)] gap-3",children:[(0,o.jsx)("span",{className:"opacity-50",children:e}),(0,o.jsx)("span",{className:"min-w-0 whitespace-pre-wrap break-words",children:t})]})}function o6({containerRef:e,viewport:t,tool:a,backgroundMode:i="lines",onViewportChange:r,onCanvasMouseDown:s,onCanvasDeselect:l,onCanvasDoubleClick:d,onContextMenu:c,onDrop:u,children:m}){let p=O.$[(0,H.C)(e=>e.theme)],g=(0,n.useRef)({isPanning:!1,startX:0,startY:0,initialX:0,initialY:0,hasMoved:!1,startedOnBackground:!1}),h=(0,n.useRef)(t.k),f=(0,n.useRef)(null),x=(0,n.useRef)(null),[v,y]=(0,n.useState)(!1),[b,w]=(0,n.useState)(!1);(0,n.useEffect)(()=>{h.current=t.k},[t.k]),(0,n.useEffect)(()=>()=>{f.current&&cancelAnimationFrame(f.current)},[]),(0,n.useEffect)(()=>{let e=e=>{if("Space"!==e.code)return;let t=e.target instanceof Element?e.target:null;e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||e.target instanceof HTMLSelectElement||t?.closest("[contenteditable='true']")||(e.preventDefault(),y(!0))},t=e=>{if("Space"===e.code){let t=e.target instanceof Element?e.target:null;e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||e.target instanceof HTMLSelectElement||t?.closest("[contenteditable='true']")||e.preventDefault(),y(!1)}},a=()=>{y(!1),g.current.isPanning=!1,w(!1),document.body.style.cursor=""};return window.addEventListener("keydown",e),window.addEventListener("keyup",t),window.addEventListener("blur",a),()=>{window.removeEventListener("keydown",e),window.removeEventListener("keyup",t),window.removeEventListener("blur",a)}},[]),(0,n.useEffect)(()=>{let e=e=>{if(!g.current.isPanning)return;if(0===e.buttons){g.current.isPanning=!1,w(!1),document.body.style.cursor="";return}let t=e.clientX-g.current.startX,a=e.clientY-g.current.startY;(Math.abs(t)>3||Math.abs(a)>3)&&(g.current.hasMoved=!0),x.current={x:g.current.initialX+t,y:g.current.initialY+a,k:h.current},f.current||(f.current=requestAnimationFrame(()=>{f.current=null,x.current&&r(x.current)}))},t=()=>{g.current.isPanning&&(!g.current.hasMoved&&g.current.startedOnBackground&&l?.(),g.current.isPanning=!1,w(!1),document.body.style.cursor="")};return window.addEventListener("pointermove",e),window.addEventListener("pointerup",t),window.addEventListener("pointercancel",t),()=>{window.removeEventListener("pointermove",e),window.removeEventListener("pointerup",t),window.removeEventListener("pointercancel",t),document.body.style.cursor=""}},[l,r]),(0,n.useEffect)(()=>{let t=e.current;if(!t)return;let a=e=>{let t=e.target instanceof Element?e.target:null;t?.closest("[data-canvas-no-zoom],.ant-modal,.ant-popover,.ant-dropdown,.ant-select-dropdown,.ant-picker-dropdown")||e.preventDefault()};return t.addEventListener("wheel",a,{passive:!1}),()=>t.removeEventListener("wheel",a)},[e]);let k=b?"grabbing":"pan"===(v?"select"===a?"pan":"select":a)?"grab":void 0;return(0,o.jsxs)("div",{ref:e,className:"relative h-full w-full select-none overflow-hidden",style:{background:p.canvas.background,cursor:k},onPointerDown:e=>{let o=e.target instanceof Element?e.target:null;if(o?.closest("[data-canvas-no-zoom]")||o?.closest("[data-connection-create-menu]"))return;let n=!o?.closest("[data-node-id],[data-connection-id]");if(0===e.button&&n&&document.activeElement instanceof HTMLElement&&(document.activeElement.isContentEditable||document.activeElement instanceof HTMLMediaElement)&&document.activeElement.blur(),1===e.button||0===e.button&&"pan"===(v?"select"===a?"pan":"select":a)){e.preventDefault(),e.currentTarget.setPointerCapture(e.pointerId),g.current={isPanning:!0,startX:e.clientX,startY:e.clientY,initialX:t.x,initialY:t.y,hasMoved:!1,startedOnBackground:n},w(!0),document.body.style.cursor="grabbing";return}0===e.button&&n&&(e.preventDefault(),e.currentTarget.setPointerCapture(e.pointerId),s?.(e))},onDoubleClick:e=>{let t=e.target instanceof Element?e.target:null;t?.closest("[data-canvas-no-zoom],[data-node-id],[data-connection-id],[data-connection-create-menu]")||d?.(e)},onWheel:a=>{let o=a.target instanceof Element?a.target:null;if(o?.closest("[data-canvas-no-zoom],.ant-modal,.ant-popover,.ant-dropdown,.ant-select-dropdown,.ant-picker-dropdown"))return;let n=Math.pow(1.1,-a.deltaY/100),i=Math.min(Math.max(t.k*n,.05),5),s=e.current?.getBoundingClientRect();if(!s)return;let l=a.clientX-s.left,d=a.clientY-s.top,c=(l-t.x)/t.k,u=(d-t.y)/t.k;r({x:l-c*i,y:d-u*i,k:i})},onContextMenu:c,onDragOver:e=>e.preventDefault(),onDrop:u,children:[(0,o.jsx)(o8,{viewport:t,mode:i}),(0,o.jsx)("div",{className:"absolute origin-top-left",style:{transform:`translate(${t.x}px, ${t.y}px) scale(${t.k})`,"--canvas-inverse-scale":1/t.k},children:m})]})}function o8({viewport:e,mode:t}){let a=O.$[(0,H.C)(e=>e.theme)];if("blank"===t)return null;let n=48*e.k,i=e.x%n,r=e.y%n,s=e.k<.12?.8:1.15,l="dots"===t?`radial-gradient(circle, ${a.canvas.dot} ${s}px, transparent ${s+.2}px)`:`linear-gradient(${a.canvas.line} 1px, transparent 1px), linear-gradient(90deg, ${a.canvas.line} 1px, transparent 1px)`;return(0,o.jsx)("div",{className:"pointer-events-none absolute inset-0 opacity-40",style:{backgroundImage:l,backgroundSize:`${n}px ${n}px`,backgroundPosition:`${i}px ${r}px`}})}function o7({nodes:e,viewport:t,viewportSize:a,onViewportChange:i}){let r=O.$[(0,H.C)(e=>e.theme)],s=(0,n.useRef)(null),[l,d]=(0,n.useState)(!1),{worldBounds:c,scale:u,offset:m}=(0,n.useMemo)(()=>{if(!e.length)return{worldBounds:{x:-500,y:-500,w:1e3,h:1e3},scale:.16,offset:{x:40,y:0}};let t=1/0,a=1/0,o=-1/0,n=-1/0;e.forEach(e=>{t=Math.min(t,e.position.x),a=Math.min(a,e.position.y),o=Math.max(o,e.position.x+e.width),n=Math.max(n,e.position.y+e.height)}),t-=500,a-=500,o+=500,n+=500;let i=o-t,r=n-a,s=Math.min(240/i,160/r);return{worldBounds:{x:t,y:a,w:i,h:r},scale:s,offset:{x:(240-i*s)/2,y:(160-r*s)/2}}},[e]),p=(0,n.useCallback)((e,t)=>({x:(e-c.x)*u+m.x,y:(t-c.y)*u+m.y}),[m.x,m.y,u,c.x,c.y]),g=(0,n.useCallback)((e,t)=>({x:(e-m.x)/u+c.x,y:(t-m.y)/u+c.y}),[m.x,m.y,u,c.x,c.y]),h=(0,n.useMemo)(()=>{let e=-t.x/t.k,o=-t.y/t.k,n=a.width/t.k,i=a.height/t.k,r=p(e,o),s=p(e+n,o+i);return{x:r.x,y:r.y,w:Math.max(s.x-r.x,4),h:Math.max(s.y-r.y,4)}},[p,t.k,t.x,t.y,a.height,a.width]),f=e=>{let o=s.current?.getBoundingClientRect();if(!o)return;let n=g(e.clientX-o.left,e.clientY-o.top);i({x:a.width/2-n.x*t.k,y:a.height/2-n.y*t.k,k:t.k})};return(0,o.jsx)("div",{className:"absolute bottom-24 left-6 z-50 overflow-hidden rounded-lg border shadow-2xl backdrop-blur-sm",style:{width:240,height:160,background:r.toolbar.panel,borderColor:r.toolbar.border},children:(0,o.jsxs)("div",{ref:s,className:"relative h-full w-full cursor-crosshair",onPointerDown:e=>{e.preventDefault(),e.currentTarget.setPointerCapture(e.pointerId),d(!0),f(e)},onPointerMove:e=>{l&&f(e)},onPointerUp:()=>d(!1),onPointerLeave:()=>d(!1),children:[e.map(e=>{let t=p(e.position.x,e.position.y),a=(0,ec.IM)(e.type)?"#10b981":e.type===ev.p.Video?"#f97316":e.type===ev.p.Audio?"#a855f7":e.type===ev.p.Config?"#60a5fa":r.node.muted;return(0,o.jsx)("div",{className:"absolute rounded-[1px]",style:{left:t.x,top:t.y,width:Math.max(e.width*u,2),height:Math.max(e.height*u,2),backgroundColor:a,opacity:.8}},e.id)}),(0,o.jsx)("div",{className:"pointer-events-none absolute border",style:{left:h.x,top:h.y,width:h.w,height:h.h,borderColor:r.node.activeStroke,background:`${r.node.activeStroke}18`}})]})})}var o9=a(21606);let ne=(0,n.forwardRef)(function({value:e,references:t,onChange:a,onSubmit:i,onKeyDown:r,className:s,containerClassName:l,style:d,highlightLabels:c=!0,...u},m){let p=O.$[(0,H.C)(e=>e.theme)],g=(0,n.useRef)(null),h=(0,n.useRef)(null),[f,x]=(0,n.useState)(null),[v,y]=(0,n.useState)(0),[b,w]=(0,n.useState)(!1),k=(0,n.useMemo)(()=>{if(!f)return[];let e=f.query.trim().toLowerCase(),a=t.filter(e=>e.active);return e?a.filter(t=>`${t.label} ${t.title} ${t.kind} ${t.text||""}`.toLowerCase().includes(e)):a},[f,t]),j=(0,n.useMemo)(()=>c?Array.from(new Set(t.filter(e=>e.active).map(e=>e.label))).sort((e,t)=>t.length-e.length):[],[c,t]),C=()=>{x(null),y(0)},N=t=>{var o;if(!f)return;let n=g.current,i=n?.selectionStart??e.length,r=`${t.label} `,s=`${e.slice(0,f.start)}${r}${e.slice(i)}`;C(),o=f.start+r.length,a(s),"number"==typeof o&&requestAnimationFrame(()=>{g.current?.focus(),g.current?.setSelectionRange(o,o)})},I=()=>{h.current&&g.current&&(h.current.scrollTop=g.current.scrollTop,h.current.scrollLeft=g.current.scrollLeft)},S=()=>{let e=g.current;w(!!(e&&e.selectionStart!==e.selectionEnd))},A=!!(j.length&&!b),M={...d||{},color:A?"transparent":d?.color,caretColor:d?.color||p.node.text,...A?{background:"transparent",backgroundColor:"transparent"}:{}},_=f&&k.length&&g.current?(0,o.jsx)(na,{textarea:g.current,references:k,activeIndex:Math.min(v,k.length-1),theme:p,onSelect:N}):null;return(0,o.jsxs)("div",{className:`relative h-full w-full ${l||""}`,children:[A?(0,o.jsx)("div",{ref:h,className:`${s||""} pointer-events-none absolute inset-0 overflow-hidden whitespace-pre-wrap break-words`,style:{...d,color:p.node.text},children:(0,o.jsx)(nt,{value:e||u.placeholder?.toString()||"",labels:j,placeholder:!e})}):null,(0,o.jsx)("textarea",{...u,ref:e=>{g.current=e,"function"==typeof m?m(e):m&&(m.current=e)},value:e,className:s,style:M,onChange:e=>{var o;let n,i,r=e.target.value;a(r),o=e.target.selectionStart,n=r.slice(0,o),(i=/(^|\s)@([^\s@]*)$/.exec(n))&&t.some(e=>e.active)?(x({start:o-i[2].length-1,query:i[2]}),y(0)):C(),requestAnimationFrame(()=>{I(),S()})},onSelect:e=>{S(),u.onSelect?.(e)},onKeyUp:e=>{S(),u.onKeyUp?.(e)},onPointerUp:e=>{S(),u.onPointerUp?.(e)},onKeyDown:e=>{if(f&&k.length){if("ArrowDown"===e.key){e.preventDefault(),y(e=>(e+1)%k.length);return}if("ArrowUp"===e.key){e.preventDefault(),y(e=>(e-1+k.length)%k.length);return}if("Enter"===e.key){e.preventDefault(),N(k[Math.min(v,k.length-1)]);return}if("Escape"===e.key){e.preventDefault(),C();return}}if("Enter"===e.key&&i&&!e.ctrlKey&&!e.metaKey&&!e.shiftKey){e.preventDefault(),i();return}r?.(e)},onScroll:e=>{I(),u.onScroll?.(e)},onBlur:e=>{w(!1),window.setTimeout(C,120),u.onBlur?.(e)}}),_]})});function nt({value:e,labels:t,placeholder:a}){if(a)return(0,o.jsx)("span",{className:"opacity-45",children:e});if(!t.length)return(0,o.jsx)(o.Fragment,{children:e});let n=RegExp(`(${t.map(ni).join("|")})`,"g");return(0,o.jsx)(o.Fragment,{children:e.split(n).map((e,a)=>t.includes(e)?(0,o.jsx)("span",{className:"rounded-md bg-[#2f80ff]/16 px-1 py-0.5 font-medium text-[#2f80ff] ring-1 ring-[#2f80ff]/24",children:e},`${e}-${a}`):(0,o.jsx)("span",{children:e},`${e}-${a}`))})}function na({textarea:e,references:t,activeIndex:a,theme:i,onSelect:r}){let s=(0,n.useRef)(!1),l=e.getBoundingClientRect(),d=e.closest(".ant-modal-content")?.getBoundingClientRect()||{left:8,top:8,right:window.innerWidth-8,bottom:window.innerHeight-8},c=nn(l.left,d.left+8,d.right-256-8),u=nn(l.bottom+6+224>d.bottom&&l.top-6-224>=d.top?l.top-6-224:l.bottom+6,d.top+8,d.bottom-224-8),m=e=>{e.stopPropagation()},p=e=>{s.current||(s.current=!0,r(e))};return(0,eZ.createPortal)((0,o.jsx)("div",{"data-canvas-resource-mention-menu":"true",className:"fixed z-[120] max-h-56 w-64 overflow-y-auto rounded-xl border p-1 shadow-2xl backdrop-blur-md",style:{left:c,top:u,background:i.toolbar.panel,borderColor:i.toolbar.border,color:i.node.text},onPointerDown:m,onMouseDown:m,onClick:e=>e.stopPropagation(),children:t.map((e,t)=>(0,o.jsxs)("button",{type:"button",className:"flex w-full min-w-0 items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs transition",style:{background:t===a?i.toolbar.activeBg:"transparent",color:t===a?i.toolbar.activeText:i.node.text},onPointerDown:t=>{t.preventDefault(),t.stopPropagation(),p(e)},onClick:t=>{t.preventDefault(),t.stopPropagation(),p(e)},children:[(0,o.jsx)(no,{reference:e}),(0,o.jsxs)("span",{className:"min-w-0 flex-1",children:[(0,o.jsx)("span",{className:"block font-medium",children:e.label}),(0,o.jsx)("span",{className:"block truncate opacity-65",children:e.text||e.title})]})]},e.id))}),document.body)}function no({reference:e}){if("image"===e.kind&&e.previewUrl)return(0,o.jsx)("img",{src:e.previewUrl,alt:"",className:"size-9 rounded-md object-cover"});if("video"===e.kind&&e.previewUrl)return(0,o.jsx)("video",{src:e.previewUrl,className:"size-9 rounded-md bg-black object-cover",muted:!0,preload:"metadata"});let t="audio"===e.kind?c.A:"video"===e.kind?d.A:"image"===e.kind?l.A:e$.A;return(0,o.jsx)("span",{className:"grid size-9 shrink-0 place-items-center rounded-md bg-black/10",children:(0,o.jsx)(t,{className:"size-4"})})}function nn(e,t,a){return a<t?t:Math.min(Math.max(e,t),a)}function ni(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}let nr="#2f80ff",ns=(0,i.default)(()=>Promise.all([a.e(5991),a.e(5479),a.e(8456),a.e(1917),a.e(6712)]).then(a.bind(a,36712)),{loadableGenerated:{webpack:()=>[36712]},ssr:!1,loading:()=>null}),nl=n.memo(function({data:e,scale:t,isSelected:a,isRelated:i,isFocusRelated:r,isConnectionTarget:s,isConnecting:l,referenceSelectionState:d,showPanel:c,showImageInfo:u,mentionReferences:m=[],now:p,renderPanel:g,renderNodeContent:h,batchCount:f=0,groupChildCount:x=0,isGroupDropTarget:v=!1,batchExpanded:y=!1,batchClosing:b=!1,batchOpening:w=!1,batchRecovering:k=!1,batchMotion:j,onMouseDown:C,onHoverStart:N,onHoverEnd:I,onConnectStart:S,onResize:A,onContentChange:M,onTitleChange:_,onToggleBatch:T,onSetBatchPrimary:z,onRetry:P,onViewImage:E,onSelectReference:D,onContextMenu:R}){let $=O.$[(0,H.C)(e=>e.theme)],[L,F]=(0,n.useState)(!1),[V,U]=(0,n.useState)(!1),[K,W]=(0,n.useState)(!1),[B,q]=(0,n.useState)(e.title||""),G=e.type===ev.p.Group,X=(0,ec.IM)(e.type)&&!!e.metadata?.content,Y=e.type===ev.p.Video&&!!e.metadata?.content,J=e.type===ev.p.Audio&&!!e.metadata?.content,Q=(0,ec.IM)(e.type)&&!!e.metadata?.isBatchRoot&&f>1,Z=(0,ec.IM)(e.type)&&!!e.metadata?.batchRootId,ee=s||a||r,et=ee?nr:i&&!Z?$.node.muted:"transparent",ea=(0,n.useRef)(null),eo=(0,n.useRef)(null),en=(0,n.useRef)({isResizing:!1,corner:"bottom-right",startX:0,startY:0,startLeft:0,startTop:0,startWidth:0,startHeight:0,keepRatio:!1,ratio:1});(0,n.useEffect)(()=>{q(e.title||"")},[e.title]),(0,n.useEffect)(()=>{K&&(eo.current?.focus(),eo.current?.select())},[K]);let ei=(0,n.useCallback)(()=>{let t=B.trim()||e.title||"未命名节点";q(t),W(!1),t!==e.title&&_(e.id,t)},[e.id,e.title,_,B]);(0,n.useEffect)(()=>{if(!K)return;let e=e=>{let t=e.target;t instanceof Node&&eo.current?.contains(t)||ei()};return window.addEventListener("pointerdown",e,!0),()=>window.removeEventListener("pointerdown",e,!0)},[ei,K]),(0,n.useEffect)(()=>{let e=ea.current;if(!e)return;let t=e=>e.stopPropagation();return e.addEventListener("wheel",t,{passive:!1}),()=>e.removeEventListener("wheel",t)},[e.type,V]),(0,n.useEffect)(()=>{if(!V)return;let e=ea.current;e?.focus(),e?.setSelectionRange(e.value.length,e.value.length)},[V]),(0,n.useEffect)(()=>{if(!V)return;let e=e=>{let t=e.target;!(t instanceof Node)||V&&ea.current?.contains(t)||U(!1)};return window.addEventListener("pointerdown",e,!0),()=>window.removeEventListener("pointerdown",e,!0)},[V]);let er=(0,n.useCallback)(a=>{if(!en.current.isResizing)return;let o=(a.clientX-en.current.startX)/t,n=(a.clientY-en.current.startY)/t,i=en.current.startLeft+en.current.startWidth,r=en.current.startTop+en.current.startHeight,s=en.current.corner.includes("left"),l=en.current.corner.includes("top"),d=Math.max(220,en.current.startWidth+(s?-o:o)),c=Math.max(160,en.current.startHeight+(l?-n:n)),u=d,m=c;if(en.current.keepRatio){let e=en.current.ratio;Math.abs(o)>=Math.abs(n)?m=u/e:u=m*e,m<160&&(u=(m=160)*e),u<220&&(m=(u=220)/e)}A(e.id,u,m,{x:s?i-u:en.current.startLeft,y:l?r-m:en.current.startTop})},[e.id,A,t]),es=(0,n.useCallback)(()=>{en.current.isResizing=!1,window.removeEventListener("mousemove",er),window.removeEventListener("mouseup",es)},[er]),el=(t,a)=>{t.stopPropagation(),t.preventDefault(),en.current={isResizing:!0,corner:a,startX:t.clientX,startY:t.clientY,startLeft:e.position.x,startTop:e.position.y,startWidth:e.width,startHeight:e.height,keepRatio:(0,ec.IM)(e.type)&&!e.metadata?.freeResize||e.type===ev.p.Video,ratio:(e.metadata?.naturalWidth||e.width)/(e.metadata?.naturalHeight||e.height||1)},window.addEventListener("mousemove",er),window.addEventListener("mouseup",es)};return(0,n.useEffect)(()=>()=>{window.removeEventListener("mousemove",er),window.removeEventListener("mouseup",es)},[er,es]),(0,o.jsxs)("div",{"data-node-id":e.id,className:`node-element absolute flex select-none flex-col transition-shadow duration-200 ${G?"z-[5]":a?"z-50":"z-10"} ${"available"===d?"cursor-pointer":d?"cursor-not-allowed":""}`,style:{transform:`translate(${e.position.x}px, ${e.position.y}px)`,width:e.width,height:e.height,transition:"box-shadow 200ms ease",contain:"layout style"},onMouseEnter:()=>{F(!0),N(e.id)},onMouseLeave:()=>{F(!1),I(e.id)},onMouseDownCapture:t=>{d&&(t.preventDefault(),t.stopPropagation(),0===t.button&&"available"===d&&D?.(e.id))},onContextMenu:t=>{d?t.preventDefault():R(t,e.id)},children:[d?null:(0,o.jsx)("div",{className:"absolute left-3 top-[-28px] z-[65] max-w-[calc(100%-24px)]",onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:K?(0,o.jsx)("input",{ref:eo,value:B,maxLength:64,className:"h-6 max-w-full border-0 border-b border-dashed bg-transparent px-0 text-left text-xs font-medium outline-none",style:{borderColor:$.node.muted,color:$.node.text},onChange:e=>q(e.target.value),onBlur:ei,onKeyDown:t=>{"Enter"===t.key&&ei(),"Escape"===t.key&&(q(e.title||""),W(!1))}}):(0,o.jsx)("button",{type:"button",className:"block max-w-full truncate border-b border-dashed border-transparent px-0 py-0.5 text-left text-xs font-medium opacity-75 transition hover:border-current hover:opacity-100",style:{color:$.node.text},title:"双击修改节点名称",onDoubleClick:e=>{e.stopPropagation(),W(!0)},children:e.title||"未命名节点"})}),G&&!d?(0,o.jsxs)("div",{className:"pointer-events-none absolute right-3 top-[-28px] z-[65] text-xs opacity-75",style:{color:$.node.text},children:[x," 个节点"]}):null,(0,o.jsxs)("div",{className:`relative h-full w-full overflow-visible border ${G?"rounded-xl":"rounded-3xl border-2"}`,style:{background:G?$.node.panel:X||Y?"transparent":$.node.fill,borderColor:G?v||ee?nr:$.node.stroke:X?et:ee?nr:i?$.node.muted:$.node.stroke,boxShadow:v?`0 0 0 2px ${nr}66`:G&&a||ee?`0 0 0 1px ${nr}55`:i&&!Z?`0 0 0 1px ${$.node.muted}55, 0 18px 48px rgba(0,0,0,.14)`:void 0},onMouseDown:t=>C(t,e.id),onDoubleClick:t=>{if(d){t.preventDefault(),t.stopPropagation();return}if(Q){t.stopPropagation(),T?.(e.id);return}if((0,ec.IM)(e.type)&&X||e.type===ev.p.Video&&Y){t.preventDefault(),t.stopPropagation(),e.type===ev.p.Video&&t.target instanceof HTMLVideoElement&&t.target.pause(),E?.(e);return}e.type===ev.p.Text&&(t.stopPropagation(),U(!0))},children:[(0,o.jsx)("div",{className:`relative flex h-full w-full items-center justify-center rounded-[inherit] ${Q?"overflow-visible":"overflow-hidden"}`,style:{background:G||X||Y?"transparent":$.node.fill,"--batch-from-x":`${j?.x||0}px`,"--batch-from-y":`${j?.y||0}px`,"--batch-from-rotate":`${6+4*(j?.index||0)}deg`,animation:e.metadata?.batchRootId?b?"canvas-batch-child-out 260ms cubic-bezier(.4,0,.2,1) both":"canvas-batch-child-in 340ms cubic-bezier(.2,.85,.18,1) both":void 0,animationDelay:e.metadata?.batchRootId?`${b?0:45+24*(j?.index||0)}ms`:void 0},children:G?null:(0,o.jsx)(nd,{node:e,theme:$,isSelected:a,now:p,isEditingContent:V,textareaRef:ea,isBatchRoot:Q,batchCount:f,batchExpanded:y,batchOpening:w,batchRecovering:k,renderNodeContent:h,mentionReferences:m,onContentChange:M,onStopEditing:()=>U(!1),onRetry:P,onViewImage:E,onToggleBatch:()=>T?.(e.id),onSetBatchPrimary:()=>z?.(e),onMoveStart:t=>C(t,e.id)})}),u&&X?(0,o.jsx)(nv,{node:e}):null,G||X||Y||J?null:(0,o.jsx)("div",{className:"pointer-events-none absolute inset-x-0 bottom-0 h-12",style:{background:`linear-gradient(to top, ${$.canvas.background}66, transparent)`}}),d&&("available"!==d||L)?(0,o.jsx)("div",{className:"pointer-events-none absolute inset-0 z-[60] grid place-items-center rounded-[inherit]",style:{background:`color-mix(in srgb, ${$.canvas.background} ${"target"===d?78:"disabled"===d?60:34}%, transparent)`,boxShadow:"available"===d?`inset 0 0 0 2px ${nr}`:void 0},children:"disabled"!==d?(0,o.jsx)("span",{className:"rounded-lg px-3 py-2 text-sm font-medium shadow-sm",style:{background:$.toolbar.panel,color:$.node.text},children:"target"===d?"正在添加参考":"选择"}):null}):null,d?null:(0,o.jsx)(nb,{corner:"top-left",onMouseDown:el}),d?null:(0,o.jsx)(nb,{corner:"top-right",onMouseDown:el}),d?null:(0,o.jsx)(nb,{corner:"bottom-left",onMouseDown:el}),d?null:(0,o.jsx)(nb,{corner:"bottom-right",onMouseDown:el})]}),d||G?null:(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(nw,{side:"left",visible:L||a||l,onMouseDown:t=>S(t,e.id,"target")}),(0,o.jsx)(nw,{side:"right",visible:e.type!==ev.p.Config&&(L||a||l),onMouseDown:t=>S(t,e.id,"source")})]}),!d&&c&&!G&&g?(0,o.jsx)("div",{className:"absolute left-1/2 top-full z-[70] max-w-[calc(100vw-24px)] -translate-x-1/2 pt-4 "+((0,ec.IM)(e.type)||e.type===ev.p.Video||e.type===ev.p.Audio?"w-[680px]":"w-[520px]"),children:g(e)}):null]})});function nd(e){if(e.node.type===ev.p.Group)return null;if((e.node.type===ev.p.Config||e.node.type===ev.p.Director)&&e.renderNodeContent)return e.renderNodeContent(e.node)||null;if(e.isBatchRoot)return e.node.type===ev.p.Panorama?(0,o.jsx)(nh,{...e}):(0,o.jsx)(ng,{...e});if(e.node.metadata?.status==="loading"&&(e.node.type!==ev.p.Text||!e.node.metadata.content))return(0,o.jsx)(nu,{node:e.node,theme:e.theme,now:e.now});if(e.node.metadata?.status==="error")return(0,o.jsx)(nm,{node:e.node,theme:e.theme,onRetry:e.onRetry});let t=nc[e.node.type];return t?(0,o.jsx)(t,{...e}):(0,o.jsx)(np,{theme:e.theme})}let nc={[ev.p.Text]:function({node:e,theme:t,isEditingContent:a,textareaRef:n,mentionReferences:i,onContentChange:r,onStopEditing:s}){let l=e.metadata?.fontSize||14,d={fontSize:`${l}px`,lineHeight:`${Math.round(1.65*l)}px`,color:t.node.text,boxSizing:"border-box"};return(0,o.jsx)("div",{className:"flex h-full w-full flex-col overflow-hidden",children:a?(0,o.jsx)(ne,{ref:n,className:"thin-scrollbar block h-full w-full resize-none overflow-y-auto whitespace-pre-wrap break-words border-none bg-transparent p-4 m-0 font-mono outline-none select-text appearance-none",style:d,value:e.metadata?.content||"",references:i,highlightLabels:!1,onChange:t=>r(e.id,t),onBlur:s,onKeyDown:e=>{"Escape"===e.key&&s()},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),onWheel:e=>e.stopPropagation()}):(0,o.jsx)("div",{className:"thin-scrollbar block h-full w-full overflow-y-auto whitespace-pre-wrap break-words bg-transparent p-4 font-mono",style:d,onWheel:e=>e.stopPropagation(),children:e.metadata?.content||(0,o.jsx)("span",{style:{color:t.node.placeholder},children:"双击编辑文字"})})})},[ev.p.Image]:ng,[ev.p.Panorama]:nh,[ev.p.Config]:nf,[ev.p.Video]:function({node:e,theme:t,isSelected:a,onViewImage:i}){let r=(0,n.useRef)(null),[s,l]=(0,n.useState)(!1),[c,u]=(0,n.useState)(0),m=()=>{let e=r.current;e&&(e.paused?e.play():e.pause())};if((0,n.useEffect)(()=>{a?r.current?.focus({preventScroll:!0}):document.activeElement===r.current&&r.current?.blur()},[a,e.metadata?.content]),!e.metadata?.content)return(0,o.jsxs)("div",{className:"flex h-full w-full flex-col items-center justify-center gap-3",style:{color:t.node.placeholder},children:[(0,o.jsx)(d.A,{className:"size-7 opacity-35"}),(0,o.jsx)("span",{className:"text-sm",children:"空视频节点"})]});let p={background:t.toolbar.panel,color:t.toolbar.item},g="absolute bottom-2 z-20 flex size-7 items-center justify-center rounded-md opacity-70 backdrop-blur transition-opacity hover:opacity-100",h=e=>{e.preventDefault(),e.stopPropagation(),a&&r.current?.focus({preventScroll:!0})},f=(0,L.gB)(e.metadata.content,e.metadata.model);return(0,o.jsxs)("div",{className:"relative h-full w-full overflow-hidden rounded-[18px] bg-black","data-canvas-no-zoom":!0,children:[(0,o.jsx)("video",{ref:r,src:f,tabIndex:-1,playsInline:!0,className:"h-full w-full object-contain outline-none",onLoadedMetadata:e=>u(Number.isFinite(e.currentTarget.duration)?1e3*e.currentTarget.duration:0),onPlay:()=>l(!0),onPause:()=>l(!1),onKeyDown:e=>{a&&"Space"===e.code&&(e.preventDefault(),e.stopPropagation(),m())}}),c>0?(0,o.jsx)("span",{className:"pointer-events-none absolute left-2 top-2 z-20 flex h-7 items-center justify-center rounded-md px-2 text-[11px] font-medium opacity-70 backdrop-blur",style:p,children:new Date(c).toISOString().slice(c>=36e5?11:14,19)}):null,(0,o.jsx)("button",{type:"button",title:s?"暂停":"播放","aria-label":s?"暂停":"播放",className:`${g} left-2`,style:p,onClick:e=>{e.stopPropagation(),m()},onMouseDown:h,onDoubleClick:e=>e.stopPropagation(),children:s?(0,o.jsx)(y.A,{className:"size-3.5"}):(0,o.jsx)(b.A,{className:"size-3.5"})}),(0,o.jsx)("button",{type:"button",title:"放大预览","aria-label":"放大预览",className:`${g} right-2`,style:p,onClick:t=>{t.stopPropagation(),r.current?.pause(),i?.(e)},onMouseDown:h,onDoubleClick:e=>e.stopPropagation(),children:(0,o.jsx)(oG.A,{className:"size-3.5"})})]})},[ev.p.Audio]:function({node:e,theme:t}){return e.metadata?.content?(0,o.jsxs)("div",{className:"flex h-full w-full flex-col justify-center gap-3 px-4",style:{background:t.node.fill,color:t.node.text},children:[(0,o.jsxs)("div",{className:"flex min-w-0 items-center gap-2 text-sm opacity-70",children:[(0,o.jsx)(c.A,{className:"size-4 shrink-0"}),(0,o.jsx)("span",{className:"truncate",children:e.title||"音频"})]}),(0,o.jsx)("audio",{src:e.metadata.content,controls:!0,className:"w-full","data-canvas-no-zoom":!0})]}):(0,o.jsxs)("div",{className:"flex h-full w-full flex-col items-center justify-center gap-2",style:{color:t.node.placeholder},children:[(0,o.jsx)(c.A,{className:"size-7 opacity-35"}),(0,o.jsx)("span",{className:"text-sm",children:"空音频节点"})]})},[ev.p.Director]:nf};function nu({node:e,theme:t,now:a}){let i=(0,n.useRef)(Date.now()),[r,s]=(0,n.useState)(Date.now());(0,n.useEffect)(()=>{if(void 0!==a)return;let e=window.setInterval(()=>s(Date.now()),1e3);return()=>window.clearInterval(e)},[a]);let l=Math.max(0,(a??r)-("number"==typeof e.metadata?.startedAt?e.metadata.startedAt:i.current)),d=Math.max(0,Math.min(100,Math.round(e.metadata?.progress||0)));return e.type===ev.p.Video?(0,o.jsxs)("div",{className:"flex h-full w-full flex-col justify-between overflow-hidden p-4",style:{color:t.node.text},children:[(0,o.jsxs)("div",{className:"flex min-h-0 flex-1 flex-col items-center justify-center gap-3",children:[(0,o.jsx)("div",{className:"size-10 animate-spin rounded-full border-2",style:{borderColor:t.node.stroke,borderTopColor:nr}}),(0,o.jsxs)("div",{className:"text-sm font-semibold",style:{color:nr},children:["正在创作 ",d,"%"]}),(0,o.jsx)("span",{className:"rounded-full px-2 py-1 text-xs",style:{background:t.toolbar.panel,color:t.node.text},children:(0,W.a3)(l)})]}),(0,o.jsxs)("div",{className:"space-y-1",children:[(0,o.jsxs)("div",{className:"flex items-center justify-between text-[11px]",style:{color:t.node.muted},children:[(0,o.jsx)("span",{children:"当前创作进度"}),(0,o.jsxs)("span",{children:[d,"%"]})]}),(0,o.jsx)("div",{className:"h-1.5 overflow-hidden rounded-full",style:{background:t.node.stroke},children:(0,o.jsx)("div",{className:"h-full rounded-full transition-all",style:{width:`${d}%`,background:nr}})})]})]}):(0,o.jsxs)("div",{className:"flex h-full w-full flex-col items-center justify-center gap-3",style:{color:t.node.activeStroke},children:[(0,o.jsx)("div",{className:"size-10 animate-spin rounded-full border-2",style:{borderColor:t.node.stroke,borderTopColor:t.node.activeStroke}}),(0,o.jsx)("span",{className:"text-[10px] tracking-[0.2em]",children:d>0?`生成中 ${d}%`:"生成中"}),(0,o.jsx)("span",{className:"rounded-full border px-2 py-1 text-xs tracking-normal",style:{borderColor:t.node.stroke,color:t.node.text},children:(0,W.a3)(l)}),d>0?(0,o.jsx)("div",{className:"h-1.5 w-28 overflow-hidden rounded-full",style:{background:t.node.stroke},children:(0,o.jsx)("div",{className:"h-full rounded-full transition-all",style:{width:`${d}%`,background:t.node.activeStroke}})}):null]})}function nm({node:e,theme:t,onRetry:a}){return(0,o.jsxs)("div",{className:"flex max-w-[260px] flex-col items-center gap-3 px-5 text-center",children:[(0,o.jsx)("div",{className:"text-xs leading-5 text-red-300",children:e.metadata?.errorDetails||"生成失败"}),(0,o.jsxs)("button",{type:"button",className:"inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition hover:scale-[1.02]",style:{background:t.toolbar.panel,borderColor:t.toolbar.border,color:t.node.text},onClick:t=>{t.stopPropagation(),a?.(e)},onMouseDown:e=>e.stopPropagation(),children:[(0,o.jsx)(oP.A,{className:"size-3.5"}),"重试"]})]})}function np({theme:e}){return(0,o.jsx)("div",{className:"flex h-full w-full items-center justify-center text-sm",style:{color:e.node.placeholder},children:"未知节点"})}function ng(e){if(!e.node.metadata?.content&&e.isBatchRoot){let t=e.node.metadata?.status==="loading"?(0,o.jsx)(nu,{node:e.node,theme:e.theme,now:e.now}):e.node.metadata?.status==="error"?(0,o.jsx)(nm,{node:e.node,theme:e.theme,onRetry:e.onRetry}):(0,o.jsx)(nf,{...e,isBatchRoot:!1});return(0,o.jsx)(ny,{batchCount:e.batchCount,batchExpanded:e.batchExpanded,batchOpening:e.batchOpening,batchRecovering:e.batchRecovering,onToggleBatch:e.onToggleBatch,children:t})}return e.node.metadata?.content?(0,o.jsx)(nx,{node:e.node,isBatchRoot:e.isBatchRoot,batchCount:e.batchCount,batchExpanded:e.batchExpanded,batchOpening:e.batchOpening,batchRecovering:e.batchRecovering,onToggleBatch:e.onToggleBatch,onSetBatchPrimary:e.onSetBatchPrimary}):(0,o.jsx)(nf,{...e})}function nh(e){let t=e.node.metadata?.content;if(!t)return(0,o.jsx)(ng,{...e});let a=!!(e.node.metadata?.imageTaskId||e.node.metadata?.imageTaskResultId)&&!e.node.metadata?.storageKey;return(0,o.jsx)(nx,{node:e.node,isBatchRoot:e.isBatchRoot,batchCount:e.batchCount,batchExpanded:e.batchExpanded,batchOpening:e.batchOpening,batchRecovering:e.batchRecovering,onToggleBatch:e.onToggleBatch,onSetBatchPrimary:e.onSetBatchPrimary,media:(0,o.jsx)(ns,{src:t,alt:e.node.title,proxyGeneratedPanorama:a,expandOnDoubleClick:!e.isBatchRoot,onMoveStart:e.onMoveStart,onOpen:e.onViewImage?()=>e.onViewImage?.(e.node):void 0})})}function nf({node:e,theme:t,isBatchRoot:a,batchCount:n,batchExpanded:i,batchOpening:r,batchRecovering:s,onToggleBatch:d}){let c=(0,o.jsxs)("div",{className:"flex h-full w-full flex-col items-center justify-center gap-3",style:{color:t.node.placeholder},children:[(0,o.jsx)("div",{className:"flex size-14 items-center justify-center rounded-2xl",style:{background:t.toolbar.activeBg},children:(0,o.jsx)(l.A,{className:"size-6 opacity-30"})}),(0,o.jsx)("span",{className:"text-[10px] tracking-[0.18em] opacity-50",children:e.type===ev.p.Panorama?"空全景图节点":"空图片节点"})]});return a?(0,o.jsx)(ny,{batchCount:n,batchExpanded:i,batchOpening:r,batchRecovering:s,onToggleBatch:d,children:c}):c}function nx({node:e,isBatchRoot:t,batchCount:a,batchExpanded:n,batchOpening:i,batchRecovering:r,onToggleBatch:s,onSetBatchPrimary:l,media:d}){let c=O.$[(0,H.C)(e=>e.theme)],u=!!e.metadata?.batchRootId;return(0,o.jsxs)(ny,{batchCount:t?a:0,batchExpanded:n,batchOpening:i,batchRecovering:r,onToggleBatch:s,children:[(0,o.jsx)("div",{className:"h-full w-full overflow-hidden rounded-3xl",children:d??(0,o.jsx)("img",{src:e.metadata.content,alt:e.title,draggable:!1,onDragStart:e=>e.preventDefault(),className:`pointer-events-none block h-full w-full select-none ${e.metadata?.freeResize?"object-fill":"object-contain"}`})}),t?(0,o.jsxs)("button",{type:"button",className:"absolute right-2.5 top-2.5 z-30 flex h-8 items-center justify-center gap-1 rounded-full border px-2.5 text-xs font-semibold shadow-[0_6px_18px_rgba(15,23,42,.10)] backdrop-blur-md transition hover:scale-[1.02]",style:{background:`${c.toolbar.panel}d9`,borderColor:`${c.toolbar.border}cc`,color:c.node.text},"aria-label":n?"图片组已展开":"图片组已收起",onClick:e=>{e.stopPropagation(),s?.()},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsx)("span",{className:"leading-none text-[#2f80ff]",children:a}),(0,o.jsx)(x.A,{className:`size-3.5 opacity-55 transition-transform ${n?"rotate-90":""}`})]}):null,u?(0,o.jsxs)("button",{type:"button",className:"absolute right-3 top-3 z-30 flex h-9 items-center gap-1.5 rounded-xl border px-2.5 text-xs font-medium opacity-0 shadow-[0_8px_20px_rgba(68,64,60,.13)] backdrop-blur-md transition group-hover/batch:opacity-100 hover:scale-[1.02]",style:{background:c.toolbar.panel,borderColor:c.toolbar.border,color:c.node.text},onClick:e=>{e.stopPropagation(),l?.()},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsx)(o9.A,{className:"size-3.5 text-[#2f80ff]"}),"设为主图"]}):null]})}function nv({node:e}){let t=Math.round(e.metadata?.naturalWidth||e.width),a=Math.round(e.metadata?.naturalHeight||e.height),n=(0,W.z3)(e.metadata?.bytes||0);return(0,o.jsx)("div",{className:"pointer-events-none absolute bottom-3 right-3 z-40 max-w-[calc(100%-24px)]",children:(0,o.jsxs)("span",{className:"max-w-full truncate rounded-md bg-black/55 px-2 py-1 text-[11px] font-medium leading-none text-white backdrop-blur-sm",children:[t," x ",a,n?` \xb7 ${n}`:""]})})}function ny({batchCount:e,batchExpanded:t,batchOpening:a,batchRecovering:n,onToggleBatch:i,children:r}){let s=O.$[(0,H.C)(e=>e.theme)],l=e>1;return(0,o.jsxs)("div",{className:"group/batch relative h-full w-full overflow-visible",onDoubleClick:l?e=>{e.stopPropagation(),i?.()}:void 0,children:[l?(0,o.jsx)("div",{className:"pointer-events-none absolute inset-0 overflow-visible",children:Array.from({length:Math.min(e-1,5)}).map((e,i)=>(0,o.jsx)("div",{className:"absolute rounded-[inherit] border shadow-[0_14px_34px_rgba(68,64,60,.16)] transition-all duration-300 group-hover/batch:translate-x-2",style:{inset:0,background:`linear-gradient(135deg, ${s.node.panel}, ${s.node.fill})`,borderColor:s.node.stroke,opacity:t&&!a?.34:1,transform:a||n?`translate(${54+22*i}px, ${20+12*i}px) rotate(${8+5*i}deg) scale(.98)`:`translate(${34+18*i}px, ${14+10*i}px) rotate(${6+4*i}deg)`,zIndex:-i-1}},i))}):null,r]})}function nb({corner:e,onMouseDown:t}){let a={"top-left":"-left-[14px] -top-[14px] cursor-nwse-resize","top-right":"-right-[14px] -top-[14px] cursor-nesw-resize","bottom-left":"-bottom-[14px] -left-[14px] cursor-nesw-resize","bottom-right":"-bottom-[14px] -right-[14px] cursor-nwse-resize"}[e];return(0,o.jsx)("div",{className:`absolute z-50 size-7 ${a}`,onMouseDown:a=>t(a,e)})}function nw({side:e,visible:t,onMouseDown:a}){let n=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsx)("div",{className:`absolute top-1/2 z-30 flex size-12 -translate-y-1/2 cursor-crosshair items-center justify-center transition-opacity duration-150 ${"left"===e?"-left-6":"-right-6"} ${t?"pointer-events-auto opacity-100":"pointer-events-none opacity-0"}`,onMouseDown:a,children:(0,o.jsx)("div",{className:"size-3 rounded-full border-2 transition-all hover:scale-125",style:{background:n.node.panel,borderColor:n.node.muted}})})}var nk=a(75157),nj=a(57676),nC=a(97432);function nN({onSelect:e}){let[t,a]=(0,n.useState)(!1),i=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(e4.A,{title:"提示词库",children:(0,o.jsx)(ej.Ay,{type:"text",className:"!h-8 !w-8 !min-w-8 shrink-0 !rounded-full !bg-transparent !p-0",style:{color:i.node.text},icon:(0,o.jsx)(nj.A,{className:"size-3.5"}),onClick:()=>a(!0),"aria-label":"提示词库"})}),(0,o.jsx)(nC.Z,{open:t,onOpenChange:a,onSelect:e})]})}var nI=a(44821);function nS({nodeId:e,connectedNodes:t,onDisconnect:a,onStartSelection:n}){let i=O.$[(0,H.C)(e=>e.theme)],r=(0,az.CK)(t);return(0,o.jsxs)("div",{className:"mb-2",children:[(0,o.jsx)("div",{className:"mb-1.5 text-[11px] font-medium",style:{color:i.node.muted},children:"参考内容"}),(0,o.jsxs)("div",{className:"thin-scrollbar flex min-h-12 gap-2 overflow-x-auto pb-1",children:[r.map(t=>(0,o.jsx)(nA,{reference:t,onRemove:()=>a?.(t.nodeId,e)},t.id)),(0,o.jsx)("button",{type:"button",className:"grid size-12 shrink-0 place-items-center rounded-xl border bg-transparent transition hover:opacity-70",style:{borderColor:i.toolbar.border,color:i.node.muted},title:"从画布选择参考节点",onClick:()=>n?.(e),children:(0,o.jsx)(A.A,{className:"size-4"})})]})]})}function nA({reference:e,onRemove:t}){let a=O.$[(0,H.C)(e=>e.theme)],n="image"===e.kind?l.A:"video"===e.kind?d.A:"audio"===e.kind?c.A:e$.A,i="image"===e.kind||"video"===e.kind;return(0,o.jsx)(nI.A,{placement:"topLeft",mouseEnterDelay:.15,content:(0,o.jsx)(nM,{reference:e}),arrow:!i,destroyOnHidden:"video"===e.kind,styles:i?{container:{padding:0,background:"transparent",boxShadow:"none"}}:void 0,children:(0,o.jsxs)("div",{className:"group relative grid size-12 shrink-0 place-items-center rounded-xl border",style:{background:a.toolbar.activeBg,borderColor:a.toolbar.border},children:[(0,o.jsx)("span",{className:"grid size-full place-items-center overflow-hidden rounded-[inherit]",children:"image"===e.kind&&e.previewUrl?(0,o.jsx)("img",{src:e.previewUrl,alt:"",className:"size-full object-cover"}):"video"===e.kind&&e.previewUrl?(0,o.jsx)("video",{src:e.previewUrl,className:"size-full object-cover",muted:!0}):(0,o.jsx)(n,{className:"size-4 opacity-65"})}),(0,o.jsx)("button",{type:"button",className:"absolute right-0 top-0 grid size-5 place-items-center rounded-full border opacity-0 shadow-sm transition-opacity group-hover:opacity-100 focus-visible:opacity-100",style:{background:a.toolbar.panel,borderColor:a.toolbar.border},"aria-label":"断开参考连接",title:"断开参考连接",onMouseDown:e=>e.stopPropagation(),onClick:e=>{e.stopPropagation(),t()},children:(0,o.jsx)(v.A,{className:"size-3"})})]})})}function nM({reference:e}){return"image"===e.kind&&e.previewUrl?(0,o.jsx)("img",{src:e.previewUrl,alt:e.title,className:"block max-h-52 max-w-72 rounded-lg object-contain"}):"video"===e.kind&&e.previewUrl?(0,o.jsx)("video",{src:e.previewUrl,className:"block max-h-52 max-w-72 rounded-lg",autoPlay:!0,muted:!0,playsInline:!0,preload:"metadata"}):"audio"===e.kind&&e.previewUrl?(0,o.jsx)("audio",{src:e.previewUrl,className:"w-72",controls:!0}):(0,o.jsx)("div",{className:"max-h-52 w-72 overflow-auto whitespace-pre-wrap text-sm",children:e.text||e.title||"暂无内容"})}function n_({node:e,isRunning:t,onPromptChange:a,onConfigChange:i,onGenerate:r,mentionReferences:s=[],connectedNodes:l=[],videoFrameOptions:d=[],videoResourceOptions:c=[],onDisconnectReference:u,onStartReferenceSelection:m,onImageSettingsOpenChange:p}){var g,h,f,x;let v,y,b,w,k,j,C,N,I=(0,F.useEffectiveConfig)(),S=(0,F.useConfigStore)(e=>e.publicSettings?.modelChannel.modelCosts),A=(0,F.useConfigStore)(e=>e.openConfigDialog),M=O.$[(0,H.C)(e=>e.theme)],_=(g=e.type)===ev.p.Text?"text":g===ev.p.Video?"video":g===ev.p.Audio?"audio":"image",T=(h=I,f=e,v="image"===(x=_)?h.imageModel:"video"===x?h.videoModel:"audio"===x?h.audioModel:h.textModel,y=f.metadata?.channelId||"",b="image"===x&&y||h.imageChannelId,w="video"===x&&y||h.videoChannelId,k="text"===x&&y||h.textChannelId,j="audio"===x&&y||h.audioChannelId,C="image"===x?b:"video"===x?w:"text"===x?k:"audio"===x&&j||h.activeChannelId,N="text"===x?(0,F.resolveModelForCapability)(h,f.metadata?.model,"text"):f.metadata?.model||v||("audio"===x?F.defaultConfig.audioModel:h.model||F.defaultConfig.model),{...h,model:N,..."video"===x?{videoModel:N}:{},..."image"===x?{imageModel:N}:{},..."audio"===x?{audioModel:N}:{},..."text"===x?{textModel:N}:{},activeChannelId:C,imageChannelId:b,videoChannelId:w,textChannelId:k,audioChannelId:j,quality:f.metadata?.quality||h.quality||F.defaultConfig.quality,size:(0,ec.sK)(f.type)?ec.A9:f.metadata?.size||("video"===x?h.videoSize||F.defaultConfig.videoSize:h.size||F.defaultConfig.size),videoSeconds:f.metadata?.seconds||h.videoSeconds||F.defaultConfig.videoSeconds,vquality:f.metadata?.vquality||h.vquality||F.defaultConfig.vquality,videoMode:f.metadata?.mode||h.videoMode||F.defaultConfig.videoMode,videoNegativePrompt:f.metadata?.negativePrompt||h.videoNegativePrompt||F.defaultConfig.videoNegativePrompt,videoMultiShot:f.metadata?.multiShot||h.videoMultiShot||F.defaultConfig.videoMultiShot,videoShotType:f.metadata?.shotType||h.videoShotType||F.defaultConfig.videoShotType,videoGenerateAudio:f.metadata?.generateAudio||h.videoGenerateAudio||F.defaultConfig.videoGenerateAudio,videoCharacterOrientation:f.metadata?.characterOrientation||h.videoCharacterOrientation||F.defaultConfig.videoCharacterOrientation,videoWatermark:f.metadata?.watermark||h.videoWatermark||F.defaultConfig.videoWatermark,audioVoice:f.metadata?.audioVoice||h.audioVoice||F.defaultConfig.audioVoice,audioFormat:f.metadata?.audioFormat||h.audioFormat||F.defaultConfig.audioFormat,audioSpeed:f.metadata?.audioSpeed||h.audioSpeed||F.defaultConfig.audioSpeed,audioInstructions:f.metadata?.audioInstructions||h.audioInstructions||F.defaultConfig.audioInstructions,grokTtsVoice:f.metadata?.grokTtsVoice||h.grokTtsVoice||F.defaultConfig.grokTtsVoice,grokTtsLanguage:f.metadata?.grokTtsLanguage||h.grokTtsLanguage||F.defaultConfig.grokTtsLanguage,grokTtsFormat:f.metadata?.grokTtsFormat||h.grokTtsFormat||F.defaultConfig.grokTtsFormat,grokTtsSpeed:f.metadata?.grokTtsSpeed||h.grokTtsSpeed||F.defaultConfig.grokTtsSpeed,glmTtsVoice:f.metadata?.glmTtsVoice||h.glmTtsVoice||F.defaultConfig.glmTtsVoice,glmTtsFormat:f.metadata?.glmTtsFormat||h.glmTtsFormat||F.defaultConfig.glmTtsFormat,glmTtsSpeed:f.metadata?.glmTtsSpeed||h.glmTtsSpeed||F.defaultConfig.glmTtsSpeed,mimoTtsVoice:f.metadata?.mimoTtsVoice||h.mimoTtsVoice||F.defaultConfig.mimoTtsVoice,mimoTtsFormat:f.metadata?.mimoTtsFormat||h.mimoTtsFormat||F.defaultConfig.mimoTtsFormat,mimoVoiceDesignPrompt:f.metadata?.mimoVoiceDesignPrompt||h.mimoVoiceDesignPrompt||F.defaultConfig.mimoVoiceDesignPrompt,geminiTtsVoice:f.metadata?.geminiTtsVoice||h.geminiTtsVoice||F.defaultConfig.geminiTtsVoice,count:String(f.metadata?.count||"image"===x&&h.canvasImageCount||h.count||F.defaultConfig.count)}),z=(0,ec.sK)(e.type),P=e.type===ev.p.Text&&!!e.metadata?.content?.trim(),E=(0,ec.IM)(e.type)&&!!e.metadata?.content,D=z?e.metadata?.panoramaSourcePrompt||"":e.metadata?.prompt||"",[R,$]=(0,n.useState)(D),[L,V]=(0,n.useState)(!1);(0,eJ.Gd)({channelMode:T.channelMode,modelCosts:S,model:T.model,count:"image"===_?T.count:1,mode:_}),(0,n.useEffect)(()=>{$(D)},[e.id,D]);let U=t=>{$(t),a(e.id,t)},K=!!R.trim()||z&&(E||s.length>0),W=()=>{let a=R.trim();K&&!t&&(r(e.id,_,a),z||$(""))};return(0,o.jsxs)("div",{"data-canvas-no-zoom":!0,className:"rounded-2xl border p-3 shadow-2xl backdrop-blur",style:{background:M.toolbar.panel,borderColor:M.toolbar.border,color:M.node.text},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),onWheel:e=>e.stopPropagation(),children:[(0,o.jsx)(nS,{nodeId:e.id,connectedNodes:l,onDisconnect:u,onStartSelection:m}),(0,o.jsx)(aE.J,{value:R,references:s,onChange:U,onSubmit:W,className:"thin-scrollbar h-40 w-full resize-none rounded-xl px-3 py-2 text-sm leading-5 outline-none",style:{background:"transparent",color:M.node.text},placeholder:z?"描述想生成的全景，或上传/连接图片作为参考":nT(_,E,P)}),(0,o.jsxs)("div",{className:"mt-2.5 flex min-w-0 items-center justify-between gap-2",children:[(0,o.jsxs)("div",{className:"flex min-w-0 flex-1 items-center gap-1.5 overflow-hidden",children:[(0,o.jsx)(e4.A,{title:"放大编辑",children:(0,o.jsx)(ej.Ay,{type:"text",className:"!h-8 !w-8 !min-w-8 shrink-0 !rounded-full !bg-transparent !p-0",style:{color:M.node.text},icon:(0,o.jsx)(oG.A,{className:"size-3.5"}),onClick:()=>V(!0),"aria-label":"放大编辑"})}),(0,o.jsx)("div",{className:"shrink-0",children:(0,o.jsx)(nN,{onSelect:U})}),"image"===_?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(eY.Y,{className:"!w-[160px] !min-w-[120px] shrink",config:T,value:T.model,channelId:T.imageChannelId,onChange:(t,a)=>i(e.id,{model:t,channelId:a}),capability:"image",onMissingConfig:()=>A(!0)}),(0,o.jsx)(eQ.o,{config:T,placement:"topLeft",buttonClassName:"!h-10 !w-[136px] !min-w-[110px] shrink-0 !justify-start !rounded-full !px-2.5",onConfigChange:(t,a)=>i(e.id,"count"===t?{count:Number(a)||1}:{[t]:a}),onMissingConfig:()=>A(!0),onOpenChange:p,showSize:!z})]}):"video"===_?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(eY.Y,{className:"!w-[160px] !min-w-[120px] shrink",config:T,value:T.model,channelId:T.videoChannelId,onChange:(t,a)=>i(e.id,{model:t,channelId:a}),capability:"video",onMissingConfig:()=>A(!0)}),(0,o.jsx)(tg.Y,{config:T,buttonClassName:"!h-10 !w-[136px] !min-w-[110px] shrink-0 !justify-start !rounded-full !px-2.5",frameOptions:d,resourceOptions:c,metadata:e.metadata,firstFrameNodeId:e.metadata?.firstFrameNodeId,lastFrameNodeId:e.metadata?.lastFrameNodeId,onFrameChange:t=>i(e.id,t),onMetadataChange:t=>i(e.id,t),onConfigChange:(t,a)=>{var o,n;return i(e.id,(o=t,n=a,"videoSeconds"===o?{seconds:n}:"videoMode"===o?{mode:n}:"videoNegativePrompt"===o?{negativePrompt:n}:"videoMultiShot"===o?{multiShot:n}:"videoShotType"===o?{shotType:n}:"videoGenerateAudio"===o?{generateAudio:n}:"videoCharacterOrientation"===o?{characterOrientation:n}:"videoWatermark"===o?{watermark:n}:{[o]:n}))}})]}):"audio"===_?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(eY.Y,{className:"!w-[160px] !min-w-[120px] shrink",config:T,value:T.model,channelId:T.audioChannelId||T.activeChannelId,onChange:(t,a)=>i(e.id,{model:t,channelId:a}),capability:"audio",onMissingConfig:()=>A(!0)}),(0,o.jsx)(th,{config:T,resourceOptions:c,metadata:e.metadata,onMetadataChange:t=>i(e.id,t),buttonClassName:"!h-10 !w-[136px] !min-w-[110px] shrink-0 !justify-start !rounded-full !px-2.5",onConfigChange:(t,a)=>i(e.id,{[t]:a})})]}):(0,o.jsx)(eY.Y,{className:"!w-[160px] !min-w-[120px] shrink",config:T,value:T.model,channelId:T.textChannelId,onChange:(t,a)=>i(e.id,{model:t,channelId:a}),capability:"text",onMissingConfig:()=>A(!0)}),"video"!==_&&("image"!==_||z)?null:(0,o.jsx)(e7,{value:e.metadata?.cameraControl,onChange:t=>i(e.id,{cameraControl:t}),buttonClassName:"!h-10 !min-w-[84px] shrink-0 !justify-start !rounded-full !px-2.5"})]}),(0,o.jsx)(ej.Ay,{type:"primary",className:"!h-10 shrink-0 !rounded-full !px-3.5",disabled:t||!K,onClick:W,"aria-label":"生成",children:(0,o.jsxs)("span",{className:"flex items-center gap-1.5 font-medium whitespace-nowrap",children:[(0,o.jsxs)("span",{className:"inline-flex items-center gap-1 text-xs tabular-nums",children:[(0,o.jsx)(eJ.kz,{}),(0,o.jsx)("span",{children:(0,eJ._f)({model:T.model,mode:_,count:"image"===_?T.count:1,seconds:T.videoSeconds,resolution:T.vquality||T.size,modelCosts:S})})]}),t?(0,o.jsx)(eH.A,{className:"size-4 animate-spin"}):(0,o.jsx)(nk.A,{className:"size-4"})]})})]}),(0,o.jsx)(ek.A,{title:"编辑提示词",open:L,centered:!0,width:760,footer:null,onCancel:()=>V(!1),destroyOnHidden:!0,children:(0,o.jsxs)("div",{"data-canvas-no-zoom":!0,className:"pt-2",onWheelCapture:e=>e.stopPropagation(),children:[(0,o.jsx)(nS,{nodeId:e.id,connectedNodes:l,onDisconnect:u,onStartSelection:e=>{V(!1),m?.(e)}}),(0,o.jsx)(aE.J,{value:R,references:s,onChange:U,className:"thin-scrollbar h-[52dvh] min-h-80 w-full cursor-text overflow-y-auto rounded-2xl border p-4 text-[15px] leading-6 outline-none",style:{background:"transparent",borderColor:M.toolbar.border,color:M.node.text},placeholder:z?"描述想生成的全景，或上传/连接图片作为参考":nT(_,E,P)})]})})]})}function nT(e,t,a){return"video"===e?"描述要生成的视频内容":"audio"===e?"描述要生成的音频内容":"image"===e?t?"请输入你想要把这张图修改成什么":"描述要生成的图片内容":a?"请输入你想要将本段文本修改成什么":"请输入你想要生成的文本内容"}var nz=a(30224),nP=a(39605),nE=a(51498),nD=a(72057),nR=a(4705),n$=a(73180),nL=a(98853),nF=a(63074),nV=a(11605),nU=a(43448),nK=a(87327),nW=a(29779);function nO({selectedCount:e,canvasTool:t,canUndo:a,canRedo:i,backgroundMode:r,showImageInfo:s,onAddImage:h,onAddVideo:f,onAddAudio:x,onAddText:v,onAddPanorama:y,onAddDirector:b,onAddConfig:w,onUndo:k,onRedo:j,onUpload:C,onDelete:N,onClear:I,onCanvasToolChange:S,onBackgroundModeChange:A,onShowImageInfoChange:z,onOpenAssetLibrary:P,onOpenMyAssets:E,onOpenVideoEditor:D}){var R;let $=(0,n.useRef)(null),L=(0,H.C)(e=>e.theme),F=(0,H.C)(e=>e.setTheme),V=O.$[L],[U,K]=(0,n.useState)(null),[W,B]=(0,n.useState)(0),[q,G]=(0,n.useState)(!1),[X,Y]=(0,n.useState)(0),J={background:V.toolbar.panel,borderColor:V.toolbar.border,color:V.toolbar.item,boxShadow:"dark"===L?"0 18px 45px rgba(0,0,0,.32)":"0 16px 40px rgba(28,25,23,.12)"},Q={background:V.toolbar.itemHover,color:V.toolbar.activeText},Z={background:V.toolbar.activeBg,color:V.toolbar.activeText},ee=U?"tool-select"===(R=U)?"选择":"tool-pan"===R?"移动":"tool-undo"===R?"撤销":"tool-redo"===R?"重做":"tool-text"===R?"文本":"tool-image"===R?"图片":"tool-video"===R?"视频":"tool-audio"===R?"音频":"tool-panorama"===R?"全景图":"tool-director"===R?"导演台":"tool-config"===R?"生成配置":"tool-upload"===R?"上传素材":"tool-library"===R?"素材库":"tool-assets"===R?"我的素材":"tool-editor"===R?"视频剪辑":"tool-style"===R?"画布外观":"tool-delete"===R?"删除选中":"tool-clear"===R?"清空画布":"":"";return(0,o.jsxs)("div",{className:"pointer-events-none absolute bottom-5 z-50 flex justify-center",style:{left:300,right:16},children:[ee?(0,o.jsx)(nH,{label:ee,x:W,theme:V}):null,(0,o.jsxs)("div",{ref:$,className:"thin-scrollbar pointer-events-auto flex h-14 max-w-full items-center gap-1 overflow-x-auto rounded-xl border px-2 shadow-lg backdrop-blur [&>*]:shrink-0",style:J,children:[(0,o.jsx)(nB,{id:`tool-${t}`,label:"select"===t?"选择":"移动",active:!0,hovered:U,activeStyle:Z,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:()=>S("select"===t?"pan":"select"),children:"select"===t?(0,o.jsx)(nz.A,{className:"size-4.5"}):(0,o.jsx)(nP.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-undo",label:"撤销",disabled:!a,hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:k,children:(0,o.jsx)(_.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-redo",label:"重做",disabled:!i,hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:j,children:(0,o.jsx)(T.A,{className:"size-4.5"})}),(0,o.jsx)(nq,{theme:V}),(0,o.jsx)(nB,{id:"tool-text",label:"文本",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:v,children:(0,o.jsx)(nE.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-image",label:"图片",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:h,children:(0,o.jsx)(l.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-video",label:"视频",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:f,children:(0,o.jsx)(d.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-audio",label:"音频",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:x,children:(0,o.jsx)(c.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-panorama",label:"全景图",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:y,children:(0,o.jsx)(u.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-director",label:"导演台",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:b,children:(0,o.jsx)(m.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-config",label:"生成配置",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:w,children:(0,o.jsx)(p.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-upload",label:"上传素材",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:C,children:(0,o.jsx)(g.A,{className:"size-4.5"})}),(0,o.jsx)(nq,{theme:V}),(0,o.jsx)(nB,{id:"tool-library",label:"素材库",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:P,children:(0,o.jsx)(nD.A,{className:"size-4.5"})}),(0,o.jsx)(nB,{id:"tool-assets",label:"我的素材",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:E,children:(0,o.jsx)(nR.A,{className:"size-4.5"})}),D?(0,o.jsx)(nB,{id:"tool-editor",label:"视频剪辑",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:D,children:(0,o.jsx)(n$.A,{className:"size-4.5 text-amber-400"})}):null,(0,o.jsx)(nB,{id:"tool-style",label:"画布外观",active:q,hovered:U,activeStyle:Z,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:e=>{Y(nX($.current,e.currentTarget)),G(e=>!e)},children:(0,o.jsx)(nL.A,{className:"size-4.5"})}),e?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(nq,{theme:V}),(0,o.jsx)(nB,{id:"tool-delete",label:"删除选中",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:N,danger:!0,children:(0,o.jsx)(M.A,{className:"size-4.5"})})]}):null,(0,o.jsx)(nq,{theme:V}),(0,o.jsx)(nB,{id:"tool-clear",label:"清空画布",hovered:U,hoverStyle:Q,wrapRef:$,onTipX:B,onHover:K,onClick:I,danger:!0,children:(0,o.jsx)(oe.A,{className:"size-4.5"})})]}),q?(0,o.jsxs)("div",{className:"pointer-events-auto absolute bottom-[72px] z-30 w-[248px] -translate-x-1/2 rounded-xl border p-2.5 shadow-xl backdrop-blur",style:{left:X||"50%",background:V.toolbar.panel,borderColor:V.toolbar.border,color:V.toolbar.item},children:[(0,o.jsx)("div",{className:"px-1 pb-2 text-sm font-medium opacity-65",children:"画布外观"}),(0,o.jsx)("div",{className:"px-1 pb-1.5 text-[11px] font-medium opacity-50",children:"主题模式"}),(0,o.jsxs)("div",{className:"grid grid-cols-2 gap-1 rounded-lg p-1",style:{background:V.toolbar.itemHover},children:[(0,o.jsxs)(nG,{colorTheme:L,targetTheme:"light",onThemeChange:F,children:[(0,o.jsx)(nF.A,{className:"size-4"}),"浅色"]}),(0,o.jsxs)(nG,{colorTheme:L,targetTheme:"dark",onThemeChange:F,children:[(0,o.jsx)(nV.A,{className:"size-4"}),"深色"]})]}),(0,o.jsx)("div",{className:"mt-3 px-1 pb-1.5 text-[11px] font-medium opacity-50",children:"网格样式"}),(0,o.jsx)(eX.A,{className:"w-full !p-1 [&_.ant-segmented-group]:!flex [&_.ant-segmented-item]:!min-h-8 [&_.ant-segmented-item]:!flex-1 [&_.ant-segmented-item-label]:!min-h-8 [&_.ant-segmented-item-label]:!leading-8",value:r,onChange:e=>A(e),options:[{value:"dots",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1.5",children:[(0,o.jsx)(nU.A,{className:"size-4"}),"点"]})},{value:"lines",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1.5",children:[(0,o.jsx)(op.A,{className:"size-4"}),"线"]})},{value:"blank",label:(0,o.jsxs)("span",{className:"inline-flex items-center gap-1.5",children:[(0,o.jsx)(nK.A,{className:"size-4"}),"空白"]})}]}),(0,o.jsxs)("div",{className:"mt-3 flex items-center justify-between gap-3 rounded-lg px-1.5 py-1",children:[(0,o.jsxs)("span",{className:"inline-flex min-w-0 items-center gap-1.5 text-[11px] font-medium opacity-65",children:[(0,o.jsx)(oz.A,{className:"size-3.5"}),"图片信息"]}),(0,o.jsx)(e5.A,{size:"small",checked:s,onChange:z})]})]}):null]})}function nB({id:e,label:t,active:a,hovered:n,activeStyle:i,hoverStyle:r,wrapRef:s,onTipX:l,onHover:d,onClick:c,disabled:u=!1,danger:m=!1,children:p}){let g=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsx)(ej.Ay,{type:"text","aria-label":t,className:"!h-8 !w-8 !min-w-8 !p-0",disabled:u,style:a?i:n!==e||u?{color:m?"#f87171":g.toolbar.item,opacity:u?.35:1}:r,icon:p,onMouseEnter:t=>{d(e),l(nX(s.current,t.currentTarget))},onMouseLeave:()=>d(null),onClick:c})}function nq({theme:e}){return(0,o.jsx)("div",{className:"mx-1 h-6 w-px",style:{background:e.toolbar.border}})}function nG({colorTheme:e,targetTheme:t,onThemeChange:a,children:n}){let i=O.$[e],r=e===t,s="light"===e?{background:"#111111",color:"#ffffff"}:{background:i.toolbar.activeBg,color:i.toolbar.activeText};return(0,o.jsx)(nW.J,{theme:e,targetTheme:t,onThemeChange:a,className:"inline-flex h-8 min-w-0 items-center justify-center gap-1.5 rounded-md px-2 text-sm transition",style:r?s:{color:i.toolbar.item},"aria-label":`切换到${"dark"===t?"深色":"浅色"}主题`,title:`切换到${"dark"===t?"深色":"浅色"}主题`,children:n})}function nH({label:e,x:t,theme:a}){return(0,o.jsx)("span",{className:"absolute bottom-[calc(100%+8px)] -translate-x-1/2 rounded-md px-2 py-1 text-xs shadow-lg",style:{left:t,background:a.node.text,color:a.node.panel},children:e})}function nX(e,t){if(!e)return 0;let a=e.parentElement?.getBoundingClientRect()||e.getBoundingClientRect(),o=t.getBoundingClientRect();return o.left-a.left+o.width/2}var nY=a(89539),nJ=a(86968),nQ=a(72140),nZ=a(57291);function n0({scale:e,onScaleChange:t,onReset:a,isMiniMapOpen:i,onToggleMiniMap:r}){let[s,l]=(0,n.useState)(!1),d=(0,H.C)(e=>e.theme),c=O.$[d],u={background:c.toolbar.panel,borderColor:c.toolbar.border,color:c.toolbar.item,boxShadow:"dark"===d?"0 18px 45px rgba(0,0,0,.32)":"0 16px 40px rgba(28,25,23,.12)"},m={background:c.toolbar.activeBg,color:c.toolbar.activeText};return(0,o.jsxs)("div",{className:"absolute bottom-5 left-5 z-50",onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"flex h-14 items-center gap-1 rounded-xl border px-2 shadow-lg backdrop-blur",style:u,children:[(0,o.jsx)(e4.A,{title:i?"关闭小地图":"打开小地图",children:(0,o.jsx)(ej.Ay,{type:"text",className:"!h-8 !w-8 !min-w-8 !p-0",style:i?m:{color:c.toolbar.item},icon:(0,o.jsx)(nJ.A,{className:"size-4"}),onClick:r,"aria-label":i?"关闭小地图":"打开小地图"})}),(0,o.jsx)(e4.A,{title:"重置视图",children:(0,o.jsx)(ej.Ay,{type:"text",className:"!h-8 !w-8 !min-w-8 !p-0",style:{color:c.toolbar.item},icon:(0,o.jsx)(nQ.A,{className:"size-4"}),onClick:a,"aria-label":"重置视图"})}),(0,o.jsx)(e4.A,{title:"放大/缩小画布",children:(0,o.jsx)("input",{type:"range",min:"5",max:"500",step:"1",value:Math.round(100*e),className:"w-24",style:{accentColor:c.node.activeStroke},onChange:e=>t(Number(e.target.value)/100),"aria-label":"放大/缩小画布"})}),(0,o.jsxs)("span",{className:"w-10 text-right text-xs tabular-nums",style:{color:c.node.muted},children:[Math.round(100*e),"%"]}),(0,o.jsx)(e4.A,{title:"快捷键",children:(0,o.jsx)(ej.Ay,{type:"text",className:"!h-8 !w-8 !min-w-8 !p-0",style:s?m:{color:c.toolbar.item},icon:(0,o.jsx)(nZ.A,{className:"size-4"}),onClick:()=>l(!0),"aria-label":"快捷键"})})]}),(0,o.jsx)(ek.A,{title:"快捷键",open:s,onCancel:()=>l(!1),footer:null,centered:!0,children:(0,o.jsxs)("div",{className:"space-y-3 border-t pt-4 text-sm",style:{borderColor:c.node.stroke},children:[(0,o.jsx)(n1,{label:"Space + 拖动",value:"临时反转选择/移动工具"}),(0,o.jsx)(n1,{label:"滚轮",value:"缩放画布"}),(0,o.jsx)(n1,{label:"拖动",value:"使用当前工具操作画布"}),(0,o.jsx)(n1,{label:"Shift / Ctrl / Cmd + 点击",value:"追加选择节点"}),(0,o.jsx)(n1,{label:"Ctrl / Cmd + G",value:"创建组"}),(0,o.jsx)(n1,{label:"Ctrl / Cmd + C / V",value:"复制 / 粘贴节点"}),(0,o.jsx)(n1,{label:"Delete / Backspace",value:"删除选中"})]})})]})}function n1({label:e,value:t}){return(0,o.jsxs)("div",{className:"flex items-center justify-between gap-4",children:[(0,o.jsx)("span",{className:"text-base font-medium",children:e}),(0,o.jsx)("span",{className:"opacity-60",children:t})]})}var n2=a(62575),n5=a(60344),n4=a(70177),n3=a(48819),n6=a(60071),n8=a(91669),n7=a(1674),n9=a(98895),ie=a(66997),it=a(37385),ia=a(61282),io=a(12854);let ii="application/x-infinite-canvas-asset",ir=[.22,1,.36,1],is={[ev.p.Image]:l.A,[ev.p.Panorama]:l.A,[ev.p.Video]:d.A,[ev.p.Audio]:c.A,[ev.p.Text]:nE.A,[ev.p.Config]:p.A,[ev.p.Director]:n6.A,[ev.p.Group]:n8.A},il={[ev.p.Image]:"图片",[ev.p.Panorama]:"全景图",[ev.p.Video]:"视频",[ev.p.Audio]:"音频",[ev.p.Text]:"文本",[ev.p.Config]:"生成配置",[ev.p.Director]:"导演台",[ev.p.Group]:"组"},id=[{label:"全部",value:"all"},{label:"图片",value:ev.p.Image},{label:"全景图",value:ev.p.Panorama},{label:"文本",value:ev.p.Text},{label:"配置",value:ev.p.Config},{label:"视频",value:ev.p.Video},{label:"音频",value:ev.p.Audio},{label:"导演台",value:ev.p.Director},{label:"组",value:ev.p.Group}],ic=[{label:"全部",value:""},{label:"文本",value:"text"},{label:"图片",value:"image"},{label:"视频",value:"video"},{label:"音频",value:"audio"}],iu={success:"#22c55e",loading:"#f59e0b",error:"#ef4444"};function im({nodes:e,selectedNodeIds:t,open:a,width:i,onWidthChange:r,onFocusNode:s,onAssetDragStart:l,onAssetDragEnd:d,onInsertAsset:c}){let u=O.$[(0,H.C)(e=>e.theme)],[m,p]=(0,n.useState)("canvas"),[g,h]=(0,n.useState)(a),[f,x]=(0,n.useState)(!1),[v,y]=(0,n.useState)(!1);return((0,n.useEffect)(()=>{if(a){h(!0),x(!1);return}x(!0);let e=window.setTimeout(()=>{h(!1),x(!1)},500);return()=>window.clearTimeout(e)},[a]),g)?(0,o.jsx)(tI.PY1.div,{className:"relative z-[60] flex h-full shrink-0",initial:{width:0,opacity:0},animate:{width:a?i+1:0,opacity:+!!a},transition:{duration:.5*!v,ease:ir},style:{overflow:"clip",pointerEvents:f?"none":void 0},children:(0,o.jsxs)(tI.PY1.aside,{className:"relative flex h-full shrink-0 flex-col overflow-hidden border-r",initial:{x:-48},animate:{x:f?-28:0},transition:{duration:.5*!v,ease:ir},style:{width:i,background:u.toolbar.panel,borderColor:u.toolbar.border,color:u.node.text},"data-canvas-no-zoom":!0,children:[(0,o.jsxs)("div",{className:"flex items-center gap-5 px-4 pt-3.5",children:[(0,o.jsx)(ip,{label:"画布",active:"canvas"===m,theme:u,onClick:()=>p("canvas")}),(0,o.jsx)(ip,{label:"资产",active:"assets"===m,theme:u,onClick:()=>p("assets")}),(0,o.jsx)(ip,{label:"提示词库",active:"prompts"===m,theme:u,onClick:()=>p("prompts")})]}),(0,o.jsx)("div",{className:"mt-2 min-h-0 flex-1 overflow-hidden",children:"canvas"===m?(0,o.jsx)(ig,{nodes:e,selectedNodeIds:t,onFocusNode:s,theme:u}):"assets"===m?(0,o.jsx)(ih,{theme:u,onAssetDragStart:l,onAssetDragEnd:d}):(0,o.jsx)(ij,{theme:u,onInsert:c})}),(0,o.jsx)("button",{type:"button",className:"absolute inset-y-0 right-0 z-40 w-4 translate-x-1/2 cursor-col-resize",onPointerDown:e=>{e.preventDefault();let t=e.clientX,a=e=>r(Math.min(480,Math.max(220,i+e.clientX-t))),o=()=>{window.removeEventListener("pointermove",a),window.removeEventListener("pointerup",o),y(!1)};y(!0),window.addEventListener("pointermove",a),window.addEventListener("pointerup",o)},"aria-label":"调整左侧面板宽度"})]})}):null}function ip({label:e,active:t,theme:a,onClick:n}){return(0,o.jsxs)("button",{type:"button",onClick:n,className:"relative pb-1.5 text-sm font-semibold transition-opacity",style:{color:a.node.text,opacity:t?1:.45},children:[e,t?(0,o.jsx)(tI.PY1.span,{layoutId:"sidePanelTabIndicator",className:"absolute inset-x-0 -bottom-px h-0.5 rounded-full",style:{background:a.toolbar.activeText},transition:{type:"spring",stiffness:500,damping:34}}):null]})}function ig({nodes:e,selectedNodeIds:t,onFocusNode:a,theme:i}){let[r,s]=(0,n.useState)(""),[l,d]=(0,n.useState)("all"),[c,u]=(0,n.useState)(new Set),m=(0,n.useRef)({}),p=(0,n.useMemo)(()=>{let t=r.trim().toLowerCase();return e.filter(e=>("all"===l||e.type===l)&&(!t||[e.title,il[e.type],e.metadata?.content,e.metadata?.prompt].filter(Boolean).join(" ").toLowerCase().includes(t)))},[r,e,l]),g=(0,n.useMemo)(()=>{let t=new Set(p.map(e=>e.id)),a=new Set(e.filter(e=>e.type===ev.p.Group).map(e=>e.id)),o=new Map;return p.forEach(e=>{let t=e.metadata?.groupId;t&&a.has(t)&&o.set(t,[...o.get(t)||[],e])}),e.flatMap(e=>{if(e.metadata?.groupId&&a.has(e.metadata.groupId))return[];if(e.type!==ev.p.Group)return t.has(e.id)?[{node:e,depth:0,hasChildren:!1}]:[];let n=o.get(e.id)||[];return t.has(e.id)||n.length?[{node:e,depth:0,hasChildren:n.length>0},...c.has(e.id)?[]:n.map(e=>({node:e,depth:1,hasChildren:!1}))]:[]})},[c,p,e]);return(0,n.useEffect)(()=>{let e=Array.from(t)[0];e&&m.current[e]?.scrollIntoView({block:"nearest",behavior:"smooth"})},[t]),(0,o.jsxs)("div",{className:"flex h-full flex-col",children:[(0,o.jsxs)("div",{className:"flex items-center gap-2 px-3 pb-2.5 pt-1",children:[(0,o.jsx)("span",{className:"text-xs font-medium opacity-60",children:"画布元素"}),(0,o.jsx)("span",{className:"text-xs opacity-35",children:e.length}),(0,o.jsx)(to.A,{size:"small",variant:"borderless",className:"w-auto",popupMatchSelectWidth:!1,value:l,onChange:d,options:id})]}),(0,o.jsx)("div",{className:"px-3 pb-2.5",children:(0,o.jsx)(a7.A,{size:"small",allowClear:!0,prefix:(0,o.jsx)(n7.A,{className:"size-3.5 text-stone-400"}),placeholder:"搜索节点",value:r,onChange:e=>s(e.target.value)})}),(0,o.jsx)("div",{className:"min-h-0 flex-1 overflow-y-auto px-2 pb-3",children:g.length?(0,o.jsx)("div",{className:"space-y-1.5",children:g.map(({node:e,depth:n,hasChildren:r})=>{let s=is[e.type]||e$.A,l=(0,ec.IM)(e.type)&&e.metadata?.content,d=t.has(e.id);return(0,o.jsxs)("div",{className:(0,tM.cn)("relative flex items-center rounded-lg transition",n&&"ml-5",d?"":"hover:bg-black/5 dark:hover:bg-white/5"),style:d?{background:i.toolbar.activeBg}:void 0,children:[n?(0,o.jsx)("span",{className:"pointer-events-none absolute -left-3 top-[calc(-50%-0.4rem)] h-[calc(100%+0.4rem)] w-3 rounded-bl-md border-b border-l opacity-45",style:{borderColor:i.node.stroke}}):null,e.type===ev.p.Group&&r?(0,o.jsx)("button",{type:"button",onClick:()=>u(t=>t.has(e.id)?new Set([...t].filter(t=>t!==e.id)):new Set(t).add(e.id)),className:"ml-1 grid size-6 shrink-0 place-items-center opacity-55 transition hover:opacity-100","aria-label":e.title,children:(0,o.jsx)(x.A,{className:(0,tM.cn)("size-3.5 transition-transform",!c.has(e.id)&&"rotate-90")})}):null,(0,o.jsxs)("button",{ref:t=>{m.current[e.id]=t},type:"button",onClick:()=>a(e.id),className:(0,tM.cn)("flex min-w-0 flex-1 items-center gap-3 py-2 pr-2 text-left",e.type===ev.p.Group&&r?"pl-0":"pl-2"),children:[(0,o.jsx)("span",{className:"grid size-10 shrink-0 place-items-center overflow-hidden rounded-md",children:l?(0,o.jsx)("img",{src:e.metadata?.content,alt:e.title,className:"size-full object-cover"}):(0,o.jsx)(s,{className:"size-5 opacity-60"})}),(0,o.jsxs)("span",{className:"min-w-0 flex-1 space-y-0.5",children:[(0,o.jsx)("span",{className:"block truncate text-sm font-medium leading-snug",children:e.title||il[e.type]||"未命名节点"}),(0,o.jsx)("span",{className:"block truncate text-xs leading-snug opacity-50",children:e.type===ev.p.Text?e.metadata?.content||e.metadata?.prompt||"":il[e.type]||e.type})]}),e.metadata?.status&&"idle"!==e.metadata.status?(0,o.jsx)("span",{className:"size-1.5 shrink-0 rounded-full",style:{background:iu[e.metadata.status]||"transparent"}}):null]})]},e.id)})}):(0,o.jsx)("div",{className:"pt-16 text-center text-sm opacity-40",children:e.length?"无匹配节点":"画布暂无节点"})})]})}let ih=(0,n.memo)(function({theme:e,onAssetDragStart:t,onAssetDragEnd:a}){let[i,r]=(0,n.useState)("mine"),[s,l]=(0,n.useState)(!1);return(0,o.jsxs)("div",{className:"flex h-full flex-col",children:[(0,o.jsxs)("div",{className:"flex items-center gap-4 px-3 pb-2 pt-1",children:[(0,o.jsx)(ix,{label:"我的素材",active:"mine"===i,theme:e,onClick:()=>r("mine")}),(0,o.jsx)(ix,{label:"素材库",active:"library"===i,theme:e,onClick:()=>r("library")})]}),"mine"===i?(0,o.jsx)(iv,{theme:e,onAdd:()=>l(!0),onAssetDragStart:t,onAssetDragEnd:a}):(0,o.jsx)(iy,{theme:e,onAssetDragStart:t,onAssetDragEnd:a}),(0,o.jsx)(ie.m,{open:s,onClose:()=>l(!1)})]})});function ix({label:e,active:t,theme:a,onClick:n}){return(0,o.jsxs)("button",{type:"button",onClick:n,className:"relative pb-1 text-xs font-semibold transition-opacity",style:{color:a.node.text,opacity:t?1:.45},children:[e,t?(0,o.jsx)("span",{className:"absolute inset-x-0 -bottom-px h-0.5 rounded-full",style:{background:a.toolbar.activeText}}):null]})}function iv({theme:e,onAdd:t,onAssetDragStart:a,onAssetDragEnd:i}){let r=(0,G.useAssetStore)(e=>e.assets),[s,l]=(0,n.useState)(""),[d,c]=(0,n.useState)(""),u=(0,n.useMemo)(()=>{let e=s.trim().toLowerCase();return r.filter(t=>(!d||t.kind===d)&&(!e||[t.title,...t.tags||[]].join(" ").toLowerCase().includes(e)))},[r,s,d]);return(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("div",{className:"flex items-center gap-4 px-3 pb-2",children:ic.map(t=>(0,o.jsx)(ix,{label:t.label,active:d===t.value,theme:e,onClick:()=>c(t.value)},t.value||"all"))}),(0,o.jsxs)("div",{className:"flex items-center gap-2 px-3 pb-2",children:[(0,o.jsx)(a7.A,{size:"small",allowClear:!0,prefix:(0,o.jsx)(n7.A,{className:"size-3.5 text-stone-400"}),placeholder:"搜索素材",value:s,onChange:e=>l(e.target.value)}),(0,o.jsxs)("button",{type:"button",onClick:t,className:"flex shrink-0 items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold transition hover:bg-black/5 dark:hover:bg-white/10",style:{color:e.node.text},children:[(0,o.jsx)(A.A,{className:"size-3.5"}),"添加"]})]}),(0,o.jsx)("div",{className:"min-h-0 flex-1 overflow-y-auto px-2 pb-3",children:u.length?(0,o.jsx)("div",{className:"grid grid-cols-2 gap-2 px-1 pt-1",children:u.map(t=>(0,o.jsx)(ib,{asset:t,theme:e,onAssetDragStart:a,onAssetDragEnd:i},t.id))}):(0,o.jsx)(n2.A,{image:n2.A.PRESENTED_IMAGE_SIMPLE,description:"暂无素材",className:"pt-16"})})]})}function iy({theme:e,onAssetDragStart:t,onAssetDragEnd:a}){let[i,r]=(0,n.useState)(""),[s,l]=(0,n.useState)(""),[d,c]=(0,n.useState)(1),u=(0,n3.I)({queryKey:["canvas-side-library-assets",i,s,d],queryFn:()=>(0,ia.y)({keyword:i,type:s,page:d,pageSize:12}),retry:!1}),m=u.data?.items||[];return(0,n.useEffect)(()=>c(1),[i,s]),(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)("div",{className:"flex items-center gap-2 px-3 pb-2",children:[(0,o.jsx)(a7.A,{size:"small",allowClear:!0,prefix:(0,o.jsx)(n7.A,{className:"size-3.5 text-stone-400"}),placeholder:"搜索素材",value:i,onChange:e=>r(e.target.value)}),(0,o.jsx)(to.A,{size:"small",variant:"borderless",className:"w-16",value:s,onChange:l,options:ic})]}),(0,o.jsxs)("div",{className:"min-h-0 flex-1 overflow-y-auto px-2 pb-3",children:[u.isLoading?(0,o.jsx)("div",{className:"flex justify-center pt-16",children:(0,o.jsx)(n5.A,{size:"small"})}):m.length?(0,o.jsx)("div",{className:"grid grid-cols-2 gap-2 px-1 pt-1",children:m.map(n=>(0,o.jsx)(iw,{asset:n,theme:e,onAssetDragStart:t,onAssetDragEnd:a},n.id))}):(0,o.jsx)(n2.A,{image:n2.A.PRESENTED_IMAGE_SIMPLE,description:"暂无素材",className:"pt-16"}),u.data?.total&&u.data.total>12?(0,o.jsx)(n4.A,{className:"mt-3 flex justify-center",size:"small",current:d,pageSize:12,total:u.data.total,showSizeChanger:!1,onChange:c}):null]})]})}function ib({asset:e,theme:t,onAssetDragStart:a,onAssetDragEnd:n}){var i;return(0,o.jsx)(ik,{theme:t,title:e.title,payload:"text"===(i=e).kind?{kind:"text",content:i.data.content,title:i.title,assetId:i.id,source:"asset"}:"image"===i.kind?{kind:"image",dataUrl:i.data.dataUrl,storageKey:i.data.storageKey,title:i.title,assetId:i.id,width:i.data.width,height:i.data.height,bytes:i.data.bytes,mimeType:i.data.mimeType,source:"asset"}:"video"===i.kind?{kind:"video",url:i.data.url,storageKey:i.data.storageKey,title:i.title,assetId:i.id,width:i.data.width,height:i.data.height,bytes:i.data.bytes,mimeType:i.data.mimeType,source:"asset"}:{kind:"audio",url:i.data.url,storageKey:i.data.storageKey,title:i.title,assetId:i.id,bytes:i.data.bytes,mimeType:i.data.mimeType,durationMs:i.data.durationMs,source:"asset"},kind:e.kind,imageUrl:"text"===e.kind?e.coverUrl:"image"===e.kind?e.coverUrl||e.data.dataUrl:"video"===e.kind?e.coverUrl||e.data.url:"",text:"text"===e.kind?e.data.content:"",onAssetDragStart:a,onAssetDragEnd:n})}function iw({asset:e,theme:t,onAssetDragStart:a,onAssetDragEnd:n}){var i;return(0,o.jsx)(ik,{theme:t,title:e.title,payload:"text"===(i=e).type?{kind:"text",content:i.content,title:i.title,assetId:i.id,source:"library"}:"image"===i.type?{kind:"image",dataUrl:i.url,title:i.title,assetId:i.id,source:"library"}:"video"===i.type?{kind:"video",url:i.url,title:i.title,assetId:i.id,source:"library"}:{kind:"audio",url:i.url,title:i.title,assetId:i.id,source:"library"},kind:e.type,imageUrl:e.coverUrl||e.url,text:e.content||e.description,onAssetDragStart:a,onAssetDragEnd:n})}function ik({theme:e,title:t,payload:a,kind:n,imageUrl:i,text:r,onAssetDragStart:s,onAssetDragEnd:l}){return(0,o.jsx)("div",{draggable:!0,title:t,onDragStart:e=>{e.dataTransfer.setData(ii,"asset"),e.dataTransfer.effectAllowed="copy",s(a)},onDragEnd:l,className:"group relative aspect-square cursor-grab overflow-hidden rounded-xl border transition duration-200 hover:-translate-y-0.5 hover:shadow-lg active:cursor-grabbing",style:{borderColor:e.node.stroke,background:e.node.panel},children:"text"===n?i?(0,o.jsxs)("div",{className:"flex size-full flex-col",children:[(0,o.jsx)("img",{src:i,alt:t,className:"h-1/2 w-full object-cover"}),(0,o.jsx)("div",{className:"h-1/2 overflow-hidden whitespace-pre-wrap break-words p-2.5 text-[11px] leading-snug opacity-80",children:r})]}):(0,o.jsx)("div",{className:"size-full overflow-hidden whitespace-pre-wrap break-words p-2.5 text-[11px] leading-snug opacity-80",children:r}):"audio"===n?(0,o.jsx)("span",{className:"grid size-full place-items-center",children:(0,o.jsx)(c.A,{className:"size-8 opacity-45"})}):i?"video"===n?(0,o.jsx)("video",{src:i+"#t=0.1",muted:!0,playsInline:!0,preload:"metadata",className:"size-full object-cover transition duration-300 group-hover:scale-[1.04]"}):(0,o.jsx)("img",{src:i,alt:t,className:"size-full object-cover transition duration-300 group-hover:scale-[1.04]"}):(0,o.jsx)("span",{className:"grid size-full place-items-center",children:(0,o.jsx)(e$.A,{className:"size-8 opacity-45"})})})}let ij=(0,n.memo)(function({theme:e,onInsert:t}){let a=(0,tz.s)(),[i,r]=(0,n.useState)(""),[s,l]=(0,n.useState)({system:!0}),[d,c]=(0,n.useState)(null),u=(0,n3.I)({queryKey:["canvas-side-prompt-categories"],queryFn:()=>(0,io.yh)({page:1,pageSize:1}),retry:!1}),m=(0,n.useMemo)(()=>["system",...u.data?.categories.filter(e=>"system"!==e)||[]],[u.data?.categories]);return(0,o.jsxs)("div",{className:"flex h-full flex-col",children:[(0,o.jsx)("div",{className:"px-3 pb-2.5 pt-1",children:(0,o.jsx)(a7.A,{size:"small",allowClear:!0,prefix:(0,o.jsx)(n7.A,{className:"size-3.5 text-stone-400"}),placeholder:"搜索提示词",value:i,onChange:e=>r(e.target.value)})}),(0,o.jsx)("div",{className:"min-h-0 flex-1 overflow-y-auto px-2 pb-3",children:u.isLoading?(0,o.jsx)("div",{className:"flex justify-center pt-16",children:(0,o.jsx)(n5.A,{size:"small"})}):(0,o.jsx)("div",{className:"space-y-2",children:m.map(a=>{let n=!!s[a]||!!i.trim();return(0,o.jsx)(iN,{category:a,keyword:i,open:n,theme:e,onToggle:()=>l(e=>({...e,[a]:!e[a]})),onView:c,onInsert:t},a)})})}),(0,o.jsx)(it.W,{prompt:d,onClose:()=>c(null),onCopy:e=>a(e,"已复制提示词")})]})});async function iC(e){let t=await (0,io.yh)({category:e,page:1,pageSize:500});if(t.total<=t.items.length)return t.items;let a=await Promise.all(Array.from({length:Math.ceil(t.total/500)-1},(t,a)=>(0,io.yh)({category:e,page:a+2,pageSize:500})));return[...t.items,...a.flatMap(e=>e.items)]}function iN({category:e,keyword:t,open:a,theme:i,onToggle:r,onView:s,onInsert:l}){let d="system"===e?"系统提示词":e,c=(0,n3.I)({queryKey:["canvas-side-prompt-category",e],queryFn:()=>iC(e),enabled:a,staleTime:864e5,gcTime:864e5,retry:!1}),u=(0,n.useMemo)(()=>{let e=t.trim().toLowerCase(),a=c.data||[];return e?a.filter(t=>[t.title,t.prompt].join(" ").toLowerCase().includes(e)):a},[t,c.data]);return(0,o.jsxs)("div",{children:[(0,o.jsxs)("button",{type:"button",onClick:r,className:"flex w-full items-center gap-1.5 rounded-md px-1.5 py-1.5 text-left text-xs font-semibold opacity-75 transition hover:opacity-100",children:[(0,o.jsx)(x.A,{className:(0,tM.cn)("size-3.5 transition-transform",a&&"rotate-90")}),(0,o.jsx)(nj.A,{className:"size-3.5"}),(0,o.jsx)("span",{className:"min-w-0 flex-1 truncate",children:d}),c.isSuccess&&("system"===e||a)?(0,o.jsx)("span",{className:"opacity-50",children:u.length}):null]}),a?(0,o.jsx)("div",{className:"space-y-1.5 px-1 pb-2 pt-1",children:c.isLoading?(0,o.jsx)("div",{className:"flex justify-center py-6",children:(0,o.jsx)(n5.A,{size:"small"})}):c.isError?(0,o.jsx)("button",{type:"button",onClick:()=>void c.refetch(),className:"block w-full py-4 text-center text-xs text-red-500 opacity-80 transition hover:opacity-100",children:"加载失败，点击重试"}):u.length?u.map(e=>(0,o.jsx)(iI,{item:e,theme:i,onView:()=>s(e),onInsert:()=>l({kind:"text",content:e.prompt,title:e.title})},e.id)):(0,o.jsx)("div",{className:"py-4 text-center text-xs opacity-40",children:"system"===e?"暂无提示词":"该分类暂无提示词"})}):null]})}function iI({item:e,theme:t,onView:a,onInsert:n}){return(0,o.jsxs)("div",{className:"group relative flex items-center gap-2.5 rounded-lg px-2 py-2 transition hover:bg-black/5 dark:hover:bg-white/5",children:[e.coverUrl?(0,o.jsx)("img",{src:e.coverUrl,alt:"",className:"size-10 shrink-0 rounded-md object-cover",loading:"lazy"}):(0,o.jsx)("span",{className:"grid size-10 shrink-0 place-items-center rounded-md",style:{background:t.node.panel},children:(0,o.jsx)(e$.A,{className:"size-4 opacity-50"})}),(0,o.jsxs)("button",{type:"button",onClick:a,className:"min-w-0 flex-1 text-left",children:[(0,o.jsx)("span",{className:"block truncate text-sm font-medium leading-snug",children:e.title}),(0,o.jsx)("span",{className:"mt-0.5 block truncate text-xs leading-snug opacity-50",children:e.prompt})]}),(0,o.jsxs)("div",{className:"flex shrink-0 flex-col items-center gap-0.5",children:[(0,o.jsx)("button",{type:"button",onClick:a,className:"grid size-6 place-items-center rounded-md opacity-60 transition hover:bg-black/10 hover:opacity-100 dark:hover:bg-white/10","aria-label":"查看详情",children:(0,o.jsx)(n9.A,{className:"size-3.5"})}),(0,o.jsx)("button",{type:"button",onClick:n,className:"grid size-6 place-items-center rounded-md opacity-60 transition hover:bg-black/10 hover:opacity-100 dark:hover:bg-white/10",style:{color:t.toolbar.activeText},"aria-label":"插入画布",children:(0,o.jsx)(A.A,{className:"size-3.5"})})]})]})}var iS=a(89566);let iA=(0,i.default)(()=>Promise.all([a.e(5991),a.e(5479),a.e(8456),a.e(1917),a.e(6712)]).then(a.bind(a,36712)),{loadableGenerated:{webpack:()=>[36712]},ssr:!1,loading:()=>null}),iM="loading",i_="success",iT="error",iz={width:550,height:600},iP="flex size-9 items-center justify-center rounded-lg text-white transition-colors hover:bg-white/10",iE=`请根据参考图片反推一段适合用于 AI 生图的提示词。

要求：
1. 只输出提示词正文，不要解释。
2. 覆盖主体、构图、风格、光线、色彩、材质、镜头和氛围。
3. 尽量写成可直接用于生图模型的完整提示词。`;function iD(e){if(!Number.isFinite(e))return"0:00";let t=Math.floor(e),a=Math.floor(t/3600),o=Math.floor(t%3600/60),n=String(t%60).padStart(2,"0");return a?`${a}:${String(o).padStart(2,"0")}:${n}`:`${o}:${n}`}function iR(e,t,a,o){let n=ez[e];return{id:o||`${e}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,type:e,title:n.title,position:{x:t.x-n.width/2,y:t.y-n.height/2},width:n.width,height:n.height,metadata:{...n.metadata,...a}}}function i$(){let e=(0,r.useParams)(),[t,a]=(0,n.useState)(!1);return((0,n.useEffect)(()=>{a(!0)},[]),t)?(0,o.jsx)(iK,{projectId:e.id},e.id):(0,o.jsx)(iL,{})}function iL(){return(0,o.jsxs)("main",{className:"relative h-full min-h-0 overflow-hidden bg-background text-foreground",children:[(0,o.jsx)("div",{className:"absolute inset-0 opacity-60",style:{backgroundImage:"radial-gradient(circle, var(--border) 1px, transparent 1px)",backgroundSize:"28px 28px"}}),(0,o.jsx)("div",{className:"absolute bottom-5 left-1/2 z-50 flex h-14 -translate-x-1/2 items-center gap-1 rounded-xl border px-2 shadow-lg backdrop-blur",style:{background:"var(--background)",borderColor:"var(--border)"},"aria-hidden":"true",children:Array.from({length:7}).map((e,t)=>(0,o.jsx)("div",{className:"size-8 rounded-md bg-current opacity-10"},t))}),(0,o.jsxs)("div",{className:"absolute bottom-24 left-6 z-50 h-40 w-[240px] rounded-lg border shadow-2xl backdrop-blur-sm",style:{background:"var(--background)",borderColor:"var(--border)"},"aria-hidden":"true",children:[(0,o.jsx)("div",{className:"absolute left-7 top-7 h-5 w-12 rounded-sm bg-current opacity-10"}),(0,o.jsx)("div",{className:"absolute left-28 top-16 h-6 w-16 rounded-sm bg-current opacity-10"}),(0,o.jsx)("div",{className:"absolute bottom-7 left-16 h-8 w-20 rounded-sm bg-current opacity-10"}),(0,o.jsx)("div",{className:"absolute inset-5 rounded border border-current opacity-15"})]}),(0,o.jsxs)("div",{className:"absolute bottom-5 left-5 z-50 flex h-14 w-[260px] items-center gap-2 rounded-xl border px-2 shadow-lg backdrop-blur",style:{background:"var(--background)",borderColor:"var(--border)"},"aria-hidden":"true",children:[(0,o.jsx)("div",{className:"size-8 rounded-md bg-current opacity-10"}),(0,o.jsx)("div",{className:"size-8 rounded-md bg-current opacity-10"}),(0,o.jsx)("div",{className:"h-1 flex-1 rounded-full bg-current opacity-10"}),(0,o.jsx)("div",{className:"h-4 w-10 rounded bg-current opacity-10"}),(0,o.jsx)("div",{className:"size-8 rounded-md bg-current opacity-10"})]})]})}function iF({pending:e,onCreate:t,onClose:a}){let n=O.$[(0,H.C)(e=>e.theme)];return(0,o.jsxs)("div",{className:"absolute z-[120] w-[300px] rounded-[18px] border p-3 shadow-2xl backdrop-blur","data-connection-create-menu":!0,style:{left:e.position.x,top:e.position.y,background:n.node.panel,borderColor:n.node.stroke,color:n.node.text},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"mb-2 flex items-center justify-between px-1",children:[(0,o.jsx)("span",{className:"text-sm font-medium",style:{color:n.node.muted},children:"引用该节点生成"}),(0,o.jsx)("button",{type:"button",className:"grid size-7 place-items-center rounded-lg text-base opacity-55 transition hover:bg-white/10 hover:opacity-100",onClick:a,"aria-label":"关闭",children:"\xd7"})]}),(0,o.jsxs)("div",{className:"grid gap-1",children:[(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(s.A,{className:"size-5"}),title:"文本生成",description:"脚本、广告词、品牌文案",onClick:()=>t(ev.p.Text)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(l.A,{className:"size-5"}),title:"图片生成",onClick:()=>t(ev.p.Image)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(d.A,{className:"size-5"}),title:"视频生成",onClick:()=>t(ev.p.Video)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(c.A,{className:"size-5"}),title:"音频参考",onClick:()=>t(ev.p.Audio)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(u.A,{className:"size-5"}),title:"全景图",description:"文生全景、图生全景",onClick:()=>t(ev.p.Panorama)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(m.A,{className:"size-5"}),title:"3D 导演台",description:"3D场景、角色、机位",onClick:()=>t(ev.p.Director)}),(0,o.jsx)(iV,{theme:n,icon:(0,o.jsx)(p.A,{className:"size-5"}),title:"配置节点",description:"模型、尺寸、数量和输入顺序",onClick:()=>t(ev.p.Config)})]})]})}function iV({theme:e,icon:t,title:a,description:n,onClick:i}){return(0,o.jsxs)("button",{type:"button",className:"flex h-16 w-full cursor-pointer items-center gap-3 rounded-2xl px-3 text-left transition",style:{color:e.node.text},onClick:i,onMouseEnter:t=>t.currentTarget.style.background=e.node.fill,onMouseLeave:e=>e.currentTarget.style.background="transparent",children:[(0,o.jsx)("span",{className:"grid size-11 shrink-0 place-items-center rounded-xl",style:{background:e.node.fill,color:e.node.muted},children:t}),(0,o.jsxs)("span",{className:"min-w-0 flex-1",children:[(0,o.jsx)("span",{className:"flex items-center gap-2 text-base font-semibold leading-5",children:a}),n?(0,o.jsx)("span",{className:"mt-1 block truncate text-sm",style:{color:e.node.muted},children:n}):null]})]})}function iU({position:e,onCreate:t,onUpload:a,onOpenAssetLibrary:i,onClose:r}){let f=O.$[(0,H.C)(e=>e.theme)],x=(0,n.useRef)(null);return(0,n.useEffect)(()=>{let e=e=>{x.current&&!x.current.contains(e.target)&&r()};return document.addEventListener("pointerdown",e,!0),()=>document.removeEventListener("pointerdown",e,!0)},[r]),(0,o.jsxs)("div",{ref:x,className:"absolute z-[120] w-[300px] rounded-[18px] border p-3 shadow-2xl backdrop-blur","data-canvas-no-zoom":!0,style:{left:e.x,top:e.y,background:f.node.panel,borderColor:f.node.stroke,color:f.node.text},onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsxs)("div",{className:"mb-2 flex items-center justify-between px-1",children:[(0,o.jsx)("span",{className:"text-sm font-medium",style:{color:f.node.muted},children:"添加节点"}),(0,o.jsx)("button",{type:"button",className:"grid size-7 place-items-center rounded-lg opacity-55 transition hover:opacity-100",onClick:r,"aria-label":"关闭",children:"\xd7"})]}),(0,o.jsxs)("div",{className:"grid gap-1",children:[(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(s.A,{className:"size-5"}),title:"文本生成",description:"脚本、广告词、品牌文案",onClick:()=>t(ev.p.Text)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(l.A,{className:"size-5"}),title:"图片生成",onClick:()=>t(ev.p.Image)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(d.A,{className:"size-5"}),title:"视频生成",onClick:()=>t(ev.p.Video)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(c.A,{className:"size-5"}),title:"音频参考",onClick:()=>t(ev.p.Audio)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(u.A,{className:"size-5"}),title:"全景图",description:"文生全景、图生全景",onClick:()=>t(ev.p.Panorama)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(m.A,{className:"size-5"}),title:"3D 导演台",description:"3D场景、角色、机位",onClick:()=>t(ev.p.Director)}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(p.A,{className:"size-5"}),title:"配置节点",description:"模型、尺寸、数量和输入顺序",onClick:()=>t(ev.p.Config)}),(0,o.jsx)("div",{className:"mb-2 mt-3 flex items-center justify-between px-1",children:(0,o.jsx)("span",{className:"text-sm font-medium",style:{color:f.node.muted},children:"添加资源"})}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(g.A,{className:"size-5"}),title:"上传",description:"图片、视频或音频",onClick:a}),(0,o.jsx)(iV,{theme:f,icon:(0,o.jsx)(h.A,{className:"size-5"}),title:"从素材库选择",description:"文本、图片或视频",onClick:i})]})]})}function iK({projectId:e}){let t,a,i,s,l,{message:d}=ew.A.useApp(),c=(0,r.useRouter)(),u=(0,n.useRef)(null),m=(0,n.useRef)(null),p=(0,n.useRef)(null),g=(0,n.useRef)(null),h=(0,n.useRef)(null),f=(0,n.useRef)(null),x=(0,n.useRef)({past:[],future:[]}),v=(0,n.useRef)(null),y=(0,n.useRef)(null),b=(0,n.useRef)(null),w=(0,n.useRef)(null),k=(0,n.useRef)(null),j=(0,n.useRef)(null),C=(0,n.useRef)(!1),N=(0,n.useRef)(!1),I=(0,n.useRef)(!1),S=(0,n.useRef)(null),A=(0,n.useRef)(new Set),M=(0,n.useRef)(new Set),_=(0,n.useRef)(!1),T=(0,n.useRef)({isDraggingNode:!1,hasMoved:!1,clickedGroupId:null,startX:0,startY:0,initialSelectedNodes:[]});(0,F.useConfigStore)(e=>e.config);let z=(0,F.useEffectiveConfig)(),P=(0,F.useConfigStore)(e=>e.isAiConfigReady),B=(0,F.useConfigStore)(e=>e.openConfigDialog),q=(0,G.useAssetStore)(e=>e.addAsset),Z=(0,G.useAssetStore)(e=>e.cleanupImages),et=(0,iS.useCanvasStore)(e=>e.hydrated),ea=(0,iS.useCanvasStore)(e=>e.createProject),eo=(0,iS.useCanvasStore)(e=>e.openProject),en=(0,iS.useCanvasStore)(e=>e.updateProject),ei=(0,iS.useCanvasStore)(e=>e.renameProject),ed=(0,iS.useCanvasStore)(e=>e.deleteProjects),eu=(0,iS.useCanvasStore)(t=>t.projects.find(t=>t.id===e)),em=(0,H.C)(e=>e.theme),ep=O.$[em],[eg,eh]=(0,n.useState)([]),[ef,eC]=(0,n.useState)([]),[eI,eR]=(0,n.useState)([]),[e$,eL]=(0,n.useState)(null),[eV,eU]=(0,n.useState)(null),[eK,eW]=(0,n.useState)(null),[eO,eB]=(0,n.useState)({x:0,y:0,k:1}),[eq,eG]=(0,n.useState)("select"),[eH,eX]=(0,n.useState)({width:1200,height:720}),[eY,eJ]=(0,n.useState)(new Set),[eQ,eZ]=(0,n.useState)({nodeId:null,version:0}),[e0,e1]=(0,n.useState)(null),[e2,e5]=(0,n.useState)(null),[e4,e3]=(0,n.useState)(null),[e6,e8]=(0,n.useState)(null),[e7,e9]=(0,n.useState)(null),[te,tt]=(0,n.useState)({x:0,y:0}),[ta,to]=(0,n.useState)(null),[tn,ti]=(0,n.useState)(null),[tr,ts]=(0,n.useState)(null),[tl,td]=(0,n.useState)(null),[tc,tu]=(0,n.useState)(!1),[tm,tp]=(0,n.useState)("lines"),[tg,th]=(0,n.useState)(!1),[tf,tv]=(0,n.useState)(()=>iS.DEFAULT_CANVAS_SIDE_PANEL),[tw,tk]=(0,n.useState)(!1),[tj,tC]=(0,n.useState)(!1),[tN,tI]=(0,n.useState)("my-assets"),[tS,tA]=(0,n.useState)(null),[tM,t_]=(0,n.useState)(!1),[tT,tz]=(0,n.useState)(null),[tP,tE]=(0,n.useState)(!1),[tD,tR]=(0,n.useState)(null),[t$,tL]=(0,n.useState)(null),[tF,tV]=(0,n.useState)(null),[tU,tK]=(0,n.useState)(null),[tW,tO]=(0,n.useState)(null),[tB,tq]=(0,n.useState)(""),[tG,tH]=(0,n.useState)(""),[tX,tY]=(0,n.useState)(null),[tJ,tQ]=(0,n.useState)(null),[tZ,t0]=(0,n.useState)(null),[t1,t2]=(0,n.useState)(null),[t5,t6]=(0,n.useState)(null),[t8,t7]=(0,n.useState)(iS.DEFAULT_CANVAS_AGENT_PANEL),[t9,ae]=(0,n.useState)(!1),[at,aa]=(0,n.useState)(!1),[ao,an]=(0,n.useState)(""),[ai,ar]=(0,n.useState)({canUndo:!1,canRedo:!1}),[as,al]=(0,n.useState)(new Set),[ad,ac]=(0,n.useState)(new Set),[au,am]=(0,n.useState)(!1),[ap,ag]=(0,n.useState)(null),[ah,af]=(0,n.useState)(null),[ax,av]=(0,n.useState)(Date.now()),ay=(0,n.useMemo)(()=>eV?Object.assign({textApiMode:"chat",autoGenerateMedia:!0},eV):{textApiMode:"chat",autoGenerateMedia:!0,imageQuality:z.quality,imageSize:z.size,videoQuality:z.vquality,videoSize:z.videoSize},[eV,z.quality,z.size,z.videoSize,z.vquality]),ab=(0,n.useMemo)(()=>({...z,quality:ay.imageQuality,size:ay.imageSize,vquality:ay.videoQuality,videoSize:ay.videoSize,count:"1",canvasImageCount:"1"}),[z,ay]),aw=(0,n.useRef)(eg),ak=(0,n.useRef)(null),aj=(0,n.useRef)(ef),aC=(0,n.useRef)(eY),aN=(0,n.useRef)(eO),aI=(0,n.useRef)(e4),aS=(0,n.useRef)(e6),aA=(0,n.useRef)(ta),aM=(0,n.useRef)(e7),a_=(0,n.useRef)(new Set),aT=(0,n.useRef)(new Set),aP=(0,n.useRef)(new Set),aE=eg.some(e=>e.metadata?.status===iM&&!e.metadata.content&&(e.type===ev.p.Video||(0,ec.IM)(e.type)||e.type===ev.p.Audio)),aR=(0,n.useCallback)(()=>({nodes:aw.current,connections:aj.current,backgroundMode:tm,showImageInfo:tg}),[tm,tg]),a$=(0,n.useCallback)(e=>{Z({extra:e,history:x.current,lastHistory:v.current})},[Z]),aL=(0,n.useCallback)(e=>{if(!e)return[];let t=e.metadata?.batchRootId||(e.metadata?.isBatchRoot?e.id:null);return t?eg.filter(e=>e.metadata?.batchRootId===t&&(0,ec.IM)(e.type)&&e.metadata?.content):[e]},[eg]);(0,n.useEffect)(()=>{if(!t5)return;let e=e=>{let t=t5?aw.current.find(e=>e.id===t5):null;if(!t)return;let a=aL(t);if(a.length<=1){"Escape"===e.key&&(e.preventDefault(),t6(null));return}let o=a.findIndex(e=>e.id===t5);"ArrowLeft"===e.key?(e.preventDefault(),o>0&&t6(a[o-1].id)):"ArrowRight"===e.key?(e.preventDefault(),o<a.length-1&&t6(a[o+1].id)):"Escape"===e.key&&(e.preventDefault(),t6(null))};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[t5,aL]),(0,n.useEffect)(()=>()=>{b.current&&(clearTimeout(b.current),b.current=null)},[e]),(0,n.useEffect)(()=>{if(!et)return;t_(!1),eW(null),af(null),ak.current=null;let t=eo(e);if(!t)return void c.replace("/canvas");let a=(0,iS.normalizeCanvasProject)(t);(async()=>{let e=(Array.isArray(a.nodes)?a.nodes:[]).map(e=>({...e,position:e.position&&"number"==typeof e.position.x&&"number"==typeof e.position.y?e.position:{x:0,y:0},width:Number(e.width)||320,height:Number(e.height)||320})),t=Array.isArray(a.connections)?a.connections:[],o=(await i3(e.map(e=>e.metadata?.status!=="loading"||rp(e)?e:{...e,metadata:{...e.metadata,status:"error",errorDetails:"页面刷新后生成已中断，请重新生成。"}}))||[]).map(e=>({...e,position:e.position&&"number"==typeof e.position.x&&"number"==typeof e.position.y?e.position:{x:0,y:0},width:Number(e.width)||320,height:Number(e.height)||320})),n=i6(a.chatSessions||[],o,!0);eh(o),eC(t),eR(n),eL(a.activeChatId||null),eU(a.agentConfig?Object.assign({textApiMode:"chat",autoGenerateMedia:!0},a.agentConfig):null),tp(a.backgroundMode||"lines"),th(a.showImageInfo||!1),eB(a.viewport||{x:0,y:0,k:1}),tv(a.sidePanel||iS.DEFAULT_CANVAS_SIDE_PANEL);let i=a.agentPanel||iS.DEFAULT_CANVAS_AGENT_PANEL;t7(i),ae(i.open),x.current={past:[],future:[]},y.current&&(clearTimeout(y.current),y.current=null),v.current={nodes:o,connections:t,backgroundMode:a.backgroundMode||"lines",showImageInfo:a.showImageInfo||!1},ar({canUndo:!1,canRedo:!1}),t_(!0)})()},[et,eo,e,c]),(0,n.useEffect)(()=>{if(!tM||C.current||N.current)return;let e=aR(),t=v.current;if(t?.nodes!==e.nodes||t.connections!==e.connections||t.backgroundMode!==e.backgroundMode||t.showImageInfo!==e.showImageInfo)return y.current&&clearTimeout(y.current),y.current=setTimeout(()=>{let e=aR(),t=v.current;if(!t)return;let a=x.current.past.length>=50;x.current.past=[...x.current.past.slice(-49),t],x.current.future=[],ar({canUndo:!0,canRedo:!1}),v.current=e,y.current=null,a&&(b.current&&clearTimeout(b.current),b.current=setTimeout(()=>{b.current=null,a$()},2e3))},180),()=>{y.current&&(clearTimeout(y.current),y.current=null)}},[tm,a$,ef,aR,eg,tM,tg]);let aF=(0,X.k)(e=>e.user),aV=(0,X.k)(e=>e.isReady);(0,n.useEffect)(()=>{aV&&(aF||(eh([]),eC([]),eR([]),eJ(new Set),t_(!1),c.replace(`/login?redirect=${encodeURIComponent(`/canvas/${e}`)}`)))},[aV,aF,e,c]),(0,n.useEffect)(()=>{tM&&!N.current&&aF&&en(e,{nodes:eg,connections:ef,chatSessions:eI,activeChatId:e$,agentConfig:eV,backgroundMode:tm,showImageInfo:tg})},[e$,eV,tm,eI,ef,eg,e,tM,tg,en,aF]),(0,n.useEffect)(()=>{let e=()=>{(0,iS.flushPendingCanvasProjectSaves)()},t=()=>{"hidden"===document.visibilityState&&(0,iS.flushPendingCanvasProjectSaves)()};return window.addEventListener("beforeunload",e),window.addEventListener("pagehide",e),document.addEventListener("visibilitychange",t),()=>{window.removeEventListener("beforeunload",e),window.removeEventListener("pagehide",e),document.removeEventListener("visibilitychange",t),(0,iS.flushPendingCanvasProjectSaves)()}},[]),(0,n.useEffect)(()=>{if(!tM)return;let e=()=>{let e=(e,t)=>["completed","complete","done","succeeded","success","failed","fail","error","cancelled","canceled"].includes(String(e||"").toLowerCase())||!!t;aw.current.filter(e=>e.type===ev.p.Video&&e.metadata?.status===iM&&!e.metadata.content&&ri(e.metadata)).forEach(t=>{var a;if(a_.current.has(t.id))return;let o=ri(t.metadata),n=rm(z,t,"video");o&&P(n,n.model)&&(a_.current.add(t.id),(0,L.Gv)(n,{id:ri(a=t.metadata),task_id:a?.videoTaskId,video_id:a?.videoTaskVideoId,model:a?.model,status:a?.status,progress:a?.progress}).then(a=>{eh(e=>i9(e,t.id,a,n,t.metadata?.startedAt||Date.now(),{width:t.width,height:t.height})),e(a.status,a.video_url||a.url)&&Y.useWalletStore.getState().triggerWalletSync()}).catch(()=>void 0).finally(()=>{a_.current.delete(t.id)}))}),aw.current.filter(e=>(0,ec.IM)(e.type)&&e.metadata?.status===iM&&!e.metadata.content&&e.metadata.imageTaskId).forEach(t=>{!aT.current.has(t.id)&&t.metadata?.imageTaskId&&(aT.current.add(t.id),(0,R.Wr)(t.metadata.imageTaskId).then(a=>{eh(e=>ra(e,t.id,a,t.metadata?.startedAt||Date.now(),{width:t.width,height:t.height})),eC(e=>ro(e,t.id,a)),e(a.status,a.image_url||a.url)&&Y.useWalletStore.getState().triggerWalletSync()}).catch(()=>void 0).finally(()=>{aT.current.delete(t.id)}))}),aw.current.filter(e=>e.type===ev.p.Audio&&e.metadata?.status===iM&&!e.metadata.content&&e.metadata.audioTaskId).forEach(t=>{!aP.current.has(t.id)&&t.metadata?.audioTaskId&&(aP.current.add(t.id),(0,$.Nm)(t.metadata.audioTaskId).then(a=>{eh(e=>rn(e,t.id,a,t.metadata?.startedAt||Date.now())),e(a.status,a.audio_url||a.url)&&Y.useWalletStore.getState().triggerWalletSync()}).catch(()=>void 0).finally(()=>{aP.current.delete(t.id)}))})};e();let t=window.setInterval(e,L.Rc);return()=>window.clearInterval(t)},[z,P,tM]),(0,n.useEffect)(()=>{if(!aE)return;av(Date.now());let e=window.setInterval(()=>av(Date.now()),1e3);return()=>window.clearInterval(e)},[aE]),(0,n.useEffect)(()=>{tD||tE(!1)},[tD]),(0,n.useEffect)(()=>{if(tM)return w.current&&clearTimeout(w.current),w.current=setTimeout(()=>{en(e,{viewport:aN.current}),w.current=null},500),()=>{w.current&&clearTimeout(w.current)}},[e,tM,en,eO]),(0,n.useEffect)(()=>{if(tM)return k.current&&clearTimeout(k.current),k.current=setTimeout(()=>{en(e,{sidePanel:tf,agentPanel:t8}),k.current=null},500),()=>{k.current&&clearTimeout(k.current)}},[e,tM,tf,t8,en]),(0,n.useLayoutEffect)(()=>{aw.current=eg,aj.current=ef,aC.current=eY,aN.current=eO,aI.current=e4,aS.current=e6,aM.current=e7},[eg,ef,eY,eO,e4,e6,e7]),(0,n.useLayoutEffect)(()=>{aA.current=ta},[ta]),(0,n.useEffect)(()=>{let e=u.current;if(!e)return;let t=()=>{let t=e.getBoundingClientRect();eX({width:t.width,height:t.height}),I.current||(I.current=!0,eB({x:t.width/2,y:t.height/2,k:1}))};t();let a=new ResizeObserver(t);return a.observe(e),()=>a.disconnect()},[]);let aU=(0,n.useCallback)((e,t)=>{let a=u.current?.getBoundingClientRect(),o=aN.current,n=e-(a?.left||0),i=t-(a?.top||0);return{x:(n-o.x)/o.k,y:(i-o.y)/o.k}},[]),aK=(0,n.useCallback)(()=>{let e=u.current?.getBoundingClientRect();return aU((e?.left||0)+(e?.width||eH.width)/2+360*Math.random()-180,(e?.top||0)+(e?.height||eH.height)/2+240*Math.random()-120)},[aU,eH.height,eH.width]),aW=(0,n.useCallback)(e=>{aI.current=e,e3(e),e||(aS.current=null,e8(null))},[]),aO=(0,n.useCallback)(e=>{!_.current&&!tP&&aC.current.has(e)&&tz(e)},[tP]),aB=(0,n.useCallback)(()=>{},[]),aq=(0,n.useCallback)((e,t)=>{if(e.nodeId===t)return;let a=i7(e.nodeId,t,aw.current,e.handleType);if(!a)return void d.warning("配置节点之间不能连接");let{fromNodeId:o,toNodeId:n}=a;aj.current.some(e=>e.fromNodeId===o&&e.toNodeId===n)||eC(e=>[...e,{id:`conn-${Date.now()}`,fromNodeId:o,toNodeId:n}]),ti(null)},[d]),aH=(0,n.useCallback)((e,t)=>{let a=e===ev.p.Config?{model:z.imageModel||z.model,size:z.size,count:i8(z.canvasImageCount||z.count)}:void 0,o=iR(e,t.position,a),n=i7(t.connection.nodeId,o.id,[...aw.current,o],t.connection.handleType);n?(eh(e=>[...e,o]),eC(e=>[...e,{id:(0,K.Ak)(),...n}]),eJ(new Set([o.id])),e1(null),e!==ev.p.Text&&e!==ev.p.Audio&&e!==ev.p.Director&&tR(o.id),e9(null),aW(null)):d.warning("配置节点之间不能连接")},[z.canvasImageCount,z.count,z.imageModel,z.model,z.size,d,aW]),aX=(0,n.useCallback)(()=>{e9(null),aW(null)},[aW]),aY=(0,n.useCallback)((e,t,a)=>{let o=aU(e,t),n=Math.max(aN.current.k,.05),i=32/n,r=40/n,s=!1,l=null,d=1/0;return[...aw.current].filter(e=>!rx(e,aw.current)).reverse().forEach(e=>{var t;let n=(t=e,{x:"source"===a.handleType?t.position.x:t.position.x+t.width,y:t.position.y+t.height/2}),c=o.x-n.x,u=o.y-n.y,m=c*c+u*u<=r*r,p=o.x>=e.position.x&&o.x<=e.position.x+e.width&&o.y>=e.position.y&&o.y<=e.position.y+e.height,g=o.x>=e.position.x-i&&o.x<=e.position.x+e.width+i&&o.y>=e.position.y-i&&o.y<=e.position.y+e.height+i;if(!m&&!p&&!g||(s=!0,e.id===a.nodeId||!i7(a.nodeId,e.id,aw.current,a.handleType)))return;let h=p?0:m?1:2;h<d&&(l=e.id,d=h)}),{nodeId:l,isNearNode:s}},[aU]),aJ=(0,n.useMemo)(()=>{let e=u.current?.getBoundingClientRect(),t=e?.width||eH.width,a=e?.height||eH.height,o=-eO.x/eO.k-280,n=-eO.y/eO.k-280,i=o+t/eO.k+560,r=n+a/eO.k+560;return eg.filter(e=>!rx(e,eg,as)&&e.position.x+e.width>o&&e.position.x<i&&e.position.y+e.height>n&&e.position.y<r)},[as,eg,eH.height,eH.width,eO.k,eO.x,eO.y]),aZ=(0,n.useMemo)(()=>new Map(eg.map(e=>[e.id,e])),[eg]),a0=tT&&aZ.get(tT)||null,a1=tF&&aZ.get(tF)||null,a2=tU&&aZ.get(tU)||null,a5=tW&&aZ.get(tW)||null,a4=a5?rm(z,a5,"image"):null,a6=tB||a4?.model||"",a8=tG||a4?.imageChannelId||"",a7=tX&&aZ.get(tX)||null,a9=tJ&&aZ.get(tJ)||null,oe=tZ&&aZ.get(tZ)||null,ot=t1&&aZ.get(t1)||null,oo=tn?.type==="node"&&aZ.get(tn.nodeId)||null,on=t5&&aZ.get(t5)||null,oi=t$&&aZ.get(t$)||null,or=eY.size>1?null:e2||(1===eY.size?Array.from(eY)[0]:null),os=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{t.metadata?.isBatchRoot&&e.set(t.id,t.metadata.batchChildIds?.length||0)}),e},[eg]),ol=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{let a=t.metadata?.groupId;a&&e.set(a,(e.get(a)||0)+1)}),e},[eg]),od=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{let a=t.metadata?.batchRootId;if(!a)return;let o=aZ.get(a),n=o?.metadata?.batchChildIds?.indexOf(t.id)??0,i=o?o.position.x+34+14*n:t.position.x,r=o?o.position.y+14+8*n:t.position.y;e.set(t.id,{x:i-t.position.x,y:r-t.position.y,index:Math.max(n,0)})}),e},[aZ,eg]),oc=(0,n.useMemo)(()=>{let e=new Set,t=new Set;return or&&(e.add(or),ef.forEach(a=>{(a.fromNodeId===or||a.toNodeId===or)&&(t.add(a.id),e.add(a.fromNodeId),e.add(a.toNodeId))})),{nodeIds:e,connectionIds:t}},[or,ef]),ou=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{t.type===ev.p.Config&&e.set(t.id,oA(t.id,eg,ef))}),e},[ef,eg]),om=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{t.type===ev.p.Director&&e.set(t.id,[])}),ef.forEach(t=>{let a=aZ.get(t.toNodeId),o=aZ.get(t.fromNodeId);a?.type===ev.p.Director&&(0,ec.IM)(o?.type)&&o?.metadata?.content&&e.get(a.id)?.push({edgeId:t.id,sourceNodeId:o.id,imageUrl:o.metadata.content,fileName:o.title||"画布图片.png",projectionMode:"equirectangular"===o.metadata.panoramaProjection?"equirectangular":"backdrop"})}),e},[ef,aZ,eg]),op=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>e.set(t.id,(0,az.hY)(t,eg,ef))),e},[ef,eg]),og=(0,n.useMemo)(()=>{let e=new Map;return ef.forEach(t=>{let a=aZ.get(t.fromNodeId);if(!a||!(0,az.Qw)(a))return;let o=e.get(t.toNodeId);o?o.push(a):e.set(t.toNodeId,[a])}),e},[ef,aZ]),of=(0,n.useMemo)(()=>new Set([ah,...ah&&og.get(ah)?.map(e=>e.id)||[]].filter(e=>!!e)),[og,ah]),ox=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{if(t.type!==ev.p.Video&&t.type!==ev.p.Config)return;let a=ef.flatMap(e=>{if(e.toNodeId!==t.id)return[];let a=aZ.get(e.fromNodeId);return(0,ec.IM)(a?.type)&&a?.metadata?.content?[{nodeId:a.id,label:a.title||"图片节点",previewUrl:a.metadata.content}]:[]});e.set(t.id,a)}),e},[ef,aZ,eg]),ov=(0,n.useMemo)(()=>{let e=new Map;return eg.forEach(t=>{if(t.type!==ev.p.Video&&t.type!==ev.p.Config&&t.type!==ev.p.Audio)return;let a=ef.flatMap(e=>{if(e.toNodeId!==t.id)return[];let a=aZ.get(e.fromNodeId);if(!a)return[];let o=a.title||a.id;if(a.type===ev.p.Text){let e=a.metadata?.content||a.metadata?.prompt||"";return e.trim()?[{nodeId:a.id,kind:"text",label:o,text:e}]:[]}return(0,ec.IM)(a.type)&&a.metadata?.content?[{nodeId:a.id,kind:"image",label:o,previewUrl:a.metadata.content}]:a.type===ev.p.Video&&a.metadata?.content?[{nodeId:a.id,kind:"video",label:o,previewUrl:a.metadata.content}]:a.type===ev.p.Audio&&a.metadata?.content?[{nodeId:a.id,kind:"audio",label:o}]:[]});e.set(t.id,a)}),e},[ef,aZ,eg]),oy=(0,n.useCallback)((e,t,a,o)=>{let n=t||aK(),i=e===ev.p.Config?{model:z.imageModel||z.model,size:z.size,count:i8(z.canvasImageCount||z.count)}:void 0,r=iR(e,n,e===ev.p.Text&&void 0!==a?{content:a,status:i_}:i,o);e===ev.p.Text&&void 0!==a&&(r.title=a.slice(0,32)||"Assistant Text"),eh(e=>[...e,r]),eJ(new Set([r.id])),e1(null),e!==ev.p.Text&&e!==ev.p.Audio&&e!==ev.p.Director&&tR(r.id)},[z.canvasImageCount,z.count,z.imageModel,z.model,z.size,aK]),ob=(0,n.useCallback)(t=>{(0,D.wh)(e,t).catch(()=>void 0)},[e]),ow=(0,n.useCallback)(t=>{if(!t.size)return;let a=new Set(t);aw.current.forEach(e=>{t.has(e.id)&&e.metadata?.batchChildIds?.forEach(e=>a.add(e))}),aw.current.forEach(e=>{e.metadata?.isBatchRoot&&e.metadata?.batchChildIds&&e.metadata.batchChildIds.every(e=>a.has(e))&&a.add(e.id)}),ob([...a]);let o=aw.current.filter(e=>a.has(e.id)),n=aw.current.filter(e=>!a.has(e.id)),i=(0,V.collectImageStorageKeys)(o),r=(0,V.collectImageStorageKeys)({nodes:n,assets:G.useAssetStore.getState().assets,history:x.current,lastHistory:v.current}),s=[...i].filter(e=>!r.has(e));eR(e=>e.map(e=>({...e,messages:e.messages.map(e=>({...e,references:e.references?.map(e=>a.has(e.id)?{...e,dataUrl:void 0,url:void 0,storageKey:void 0}:e)}))}))),s.length&&(0,V.deleteStoredImages)(s).catch(e=>d.error(e instanceof Error?e.message:"图片文件删除失败"));let l=n.map(e=>{let t=e.metadata?.groupId&&a.has(e.metadata.groupId)?{...e,metadata:{...e.metadata,groupId:void 0}}:e,o=t.metadata?.batchChildIds?.filter(e=>!a.has(e));if(!t.metadata?.isBatchRoot||o?.length===t.metadata.batchChildIds?.length)return t;let i=o?.includes(t.metadata.primaryImageId||"")?t.metadata.primaryImageId:o?.[0],r=n.find(e=>e.id===i);return{...t,metadata:{...t.metadata,batchChildIds:o,primaryImageId:i,content:r?.metadata?.content||t.metadata.content,naturalWidth:r?.metadata?.naturalWidth||t.metadata.naturalWidth,naturalHeight:r?.metadata?.naturalHeight||t.metadata.naturalHeight,panoramaProjection:r?.metadata?.panoramaProjection||t.metadata.panoramaProjection}}}),c=aj.current.filter(e=>!a.has(e.fromNodeId)&&!a.has(e.toNodeId));aw.current=l,aj.current=c,aC.current=new Set,eh(l),eC(c),eJ(new Set),e1(null),e5(e=>e&&a.has(e)?null:e),tz(e=>e&&a.has(e)?null:e),tR(e=>e&&a.has(e)?null:e),tV(e=>e&&a.has(e)?null:e),tK(e=>e&&a.has(e)?null:e),tO(e=>e&&a.has(e)?null:e),t2(e=>e&&a.has(e)?null:e),t6(e=>e&&a.has(e)?null:e),td(e=>e&&a.has(e)?null:e),af(e=>e&&a.has(e)?null:e),ti(e=>e?.type==="node"&&a.has(e.nodeId)?null:e),a$({projectId:e,nodes:l,chatSessions:eI})},[eI,a$,ob,e]),ok=(0,n.useCallback)(e=>{let t=aj.current.filter(t=>t.id!==e);aj.current=t,eC(t),e1(t=>t===e?null:t),ti(t=>t?.type==="connection"&&t.connectionId===e?null:t)},[]),oC=(0,n.useCallback)(()=>{aX(),eJ(new Set),e1(null),ti(null),to(null),e5(null),tz(null),tR(null)},[aX]),oN=(0,n.useCallback)(()=>{ob(),eh([]),eC([]),tV(null),tK(null),tO(null),t2(null),t6(null),td(null),af(null),oC(),tk(!1),a$({projectId:e,nodes:[],chatSessions:[]})},[a$,ob,oC,e]),oS=(0,n.useCallback)(e=>{let t=aw.current.find(t=>t.id===e);if(!t)return;let a=`${t.type}-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,o={...t,id:a,title:`${t.title} Copy`,position:{x:t.position.x+36,y:t.position.y+36}};eh(e=>[...e,o]),eJ(new Set([a])),e1(null),tR(a)},[]),oT=(0,n.useCallback)(e=>{let t=new Set(e||Array.from(aC.current)),a=aw.current.filter(e=>t.has(e.id));if(a.length<2||a.some(e=>e.type===ev.p.Group||e.metadata?.groupId))return null;let o=ey(a),n=o.right-o.left+48,i=o.bottom-o.top+48,r=iR(ev.p.Group,{x:o.left-24+n/2,y:o.top-24+i/2});r.width=n,r.height=i,r.position={x:o.left-24,y:o.top-24};let s=[...aw.current.map(e=>t.has(e.id)?{...e,metadata:{...e.metadata,groupId:r.id}}:e),r];return aw.current=s,aC.current=new Set([r.id]),eh(s),eJ(new Set([r.id])),e1(null),tR(null),r.id},[]),oz=(0,n.useCallback)(()=>{let e=aC.current;if(!e.size)return;let t=new Set(e);aw.current.forEach(a=>{a.type===ev.p.Group&&e.has(a.id)&&aw.current.forEach(e=>{e.metadata?.groupId===a.id&&t.add(e.id)})});let a=aw.current.filter(e=>t.has(e.id)).map(e=>({...e,position:{...e.position},metadata:e.metadata?{...e.metadata}:void 0}));a.length&&(f.current={nodes:a,connections:aj.current.filter(e=>t.has(e.fromNodeId)&&t.has(e.toNodeId)).map(e=>({...e}))})},[]),oP=(0,n.useCallback)(()=>{let e=f.current;if(!e?.nodes.length)return!1;let t=aK(),a=e.nodes.reduce((e,t)=>({left:Math.min(e.left,t.position.x),top:Math.min(e.top,t.position.y),right:Math.max(e.right,t.position.x+t.width),bottom:Math.max(e.bottom,t.position.y+t.height)}),{left:1/0,top:1/0,right:-1/0,bottom:-1/0}),o=t.x-(a.left+a.right)/2,n=t.y-(a.top+a.bottom)/2,i=new Map,r=e.nodes.map((e,t)=>{let a=`${e.type}-${Date.now()}-${t}-${Math.random().toString(36).slice(2,7)}`;return i.set(e.id,a),{...e,id:a,title:e.title.endsWith(" Copy")?e.title:`${e.title} Copy`,position:{x:e.position.x+o,y:e.position.y+n},metadata:e.metadata?{...e.metadata}:void 0}}).map(e=>{let t=e.metadata?.groupId,a=t?i.get(t):void 0;return!t||a?a?{...e,metadata:{...e.metadata,groupId:a}}:e:{...e,metadata:{...e.metadata,groupId:void 0}}}),s=e.connections.flatMap((e,t)=>{let a=i.get(e.fromNodeId),o=i.get(e.toNodeId);return a&&o?[{...e,id:`conn-${Date.now()}-${t}-${Math.random().toString(36).slice(2,7)}`,fromNodeId:a,toNodeId:o}]:[]});return eh(e=>[...e,...r]),eC(e=>[...e,...s]),eJ(new Set(r.map(e=>e.id))),e1(null),ti(null),tR(r[0]?.type===ev.p.Group?null:r[0]?.id||null),!0},[aK]),oE=(0,n.useCallback)(()=>{eB({x:eH.width/2,y:eH.height/2,k:1}),ti(null)},[eH.height,eH.width]),oD=(0,n.useCallback)(e=>{let t=Math.min(Math.max(e,.05),5);eB(e=>({x:eH.width/2-(eH.width/2-e.x)/e.k*t,y:eH.height/2-(eH.height/2-e.y)/e.k*t,k:t})),ti(null)},[eH.height,eH.width]),oR=(0,n.useCallback)(e=>{y.current&&(clearTimeout(y.current),y.current=null),C.current=!0,eh(e.nodes),eC(e.connections),tp(e.backgroundMode),th(e.showImageInfo),eJ(new Set),e1(null),ti(null),af(null),setTimeout(()=>{v.current=e,C.current=!1,ar({canUndo:x.current.past.length>0,canRedo:x.current.future.length>0})})},[]),o$=(0,n.useCallback)(()=>{let e=x.current.past.pop(),t=v.current;e&&t&&(x.current.future.push(t),oR(e))},[oR]),oL=(0,n.useCallback)(()=>{let e=x.current.future.pop(),t=v.current;e&&t&&(x.current.past.push(t),oR(e))},[oR]),oF=(0,n.useCallback)(()=>{let e=ea(`新项目 ${iS.useCanvasStore.getState().projects.length+1}`);c.push(`/canvas/${e}`)},[ea,c]),oV=(0,n.useCallback)(()=>{(0,D.GY)([e]).catch(()=>void 0),ob(),ed([e]),Z(),c.push("/canvas")},[Z,ob,ed,e,c]),oU=(0,n.useCallback)(e=>{if(ti(null),ts(null),e5(null),tz(null),tR(null),aM.current&&aX(),0!==e.button)return;eZ(e=>({...e,nodeId:null}));let t=aU(e.clientX,e.clientY),a={startWorldX:t.x,startWorldY:t.y,currentWorldX:t.x,currentWorldY:t.y,additive:e.shiftKey,initialSelectedNodeIds:e.shiftKey?Array.from(aC.current):[]};aA.current=a,to(a),e.shiftKey||eJ(new Set),e1(null)},[aX,aU]),oK=(0,n.useCallback)((e,t)=>{e.stopPropagation(),0===e.button&&eZ(e=>({nodeId:t,version:e.version+1})),ti(null),e5(null),tz(null),e1(null),aw.current.find(e=>e.id===t)?.type===ev.p.Group&&tR(null);let a=aC.current,o=aw.current,n=new Set(a);e.shiftKey||e.metaKey||e.ctrlKey?n.has(t)?n.delete(t):n.add(t):n.has(t)||(n.clear(),n.add(t)),eJ(n),tz(1===n.size&&n.has(t)?t:null);let i=new Set(n);o.forEach(e=>{n.has(e.id)&&(e.metadata?.batchChildIds?.forEach(e=>i.add(e)),e.type===ev.p.Group&&o.forEach(t=>{t.metadata?.groupId===e.id&&i.add(t.id)}))}),T.current={isDraggingNode:!0,hasMoved:!1,clickedGroupId:o.find(e=>e.id===t)?.type===ev.p.Group?t:null,startX:e.clientX,startY:e.clientY,initialSelectedNodes:o.filter(e=>i.has(e.id)).map(e=>({id:e.id,x:e.position.x,y:e.position.y}))},N.current=!0,_.current=!0,am(!0)},[]),oW=(0,n.useCallback)((e,t)=>{if(S.current&&(cancelAnimationFrame(S.current),S.current=null),!T.current.isDraggingNode)return void ag(null);let a=!T.current.hasMoved&&1===T.current.initialSelectedNodes.length,o=T.current.clickedGroupId||T.current.initialSelectedNodes[0]?.id,n=aN.current,i=null==e?0:(e-T.current.startX)/n.k,r=null==t?0:(t-T.current.startY)/n.k,s=T.current.initialSelectedNodes;if(N.current=!1,_.current=!1,am(!1),T.current.hasMoved&&null!=e&&null!=t){let e=new Set(s.map(e=>e.id));eh(t=>{let a=t.map(e=>{let t=s.find(t=>t.id===e.id);return t?{...e,position:{x:t.x+i,y:t.y+r}}:e}),o=eb(e,a);return o?function(e,t,a){let o=t.filter(t=>e.has(t.id)&&t.type!==ev.p.Group);if(!o.length)return t;let n=ey(o),i=a.position.x+24,r=a.position.y+24,s=a.position.x+a.width-24,l=a.position.y+a.height-24,d=n.left<i?i-n.left:n.right>s?s-n.right:0,c=n.top<r?r-n.top:n.bottom>l?l-n.bottom:0;return t.map(t=>e.has(t.id)&&t.type!==ev.p.Group?{...t,position:{x:t.position.x+d,y:t.position.y+c},metadata:{...t.metadata,groupId:a.id}}:t)}(e,a,o):a.map(t=>{let o,n;if(!e.has(t.id)||t.type===ev.p.Group)return t;let i=(o=t.position.x+t.width/2,n=t.position.y+t.height/2,[...a].reverse().find(e=>e.type===ev.p.Group&&o>=e.position.x&&o<=e.position.x+e.width&&n>=e.position.y&&n<=e.position.y+e.height)?.id);return t.metadata?.groupId===i?t:{...t,metadata:{...t.metadata,groupId:i}}})})}if(T.current.isDraggingNode=!1,T.current.hasMoved=!1,T.current.clickedGroupId=null,T.current.initialSelectedNodes=[],ag(null),a&&o){let e=aw.current.find(e=>e.id===o);e?.type===ev.p.Group?tR(null):e?.type===ev.p.Text?tR(e=>e===o?e:null):tR(o)}},[]),oO=(0,n.useCallback)(e=>{let t=aN.current;if(T.current.isDraggingNode){let a=(e.clientX-T.current.startX)/t.k,o=(e.clientY-T.current.startY)/t.k,n=T.current.initialSelectedNodes;(Math.abs(e.clientX-T.current.startX)>3||Math.abs(e.clientY-T.current.startY)>3)&&(T.current.hasMoved=!0);let i=new Set(n.map(e=>e.id)),r=aw.current.map(e=>{let t=n.find(t=>t.id===e.id);return t?{...e,position:{x:t.x+a,y:t.y+o}}:e});ag(eb(i,r)?.id||null),S.current&&cancelAnimationFrame(S.current),S.current=requestAnimationFrame(()=>{eh(e=>e.map(e=>{let t=n.find(t=>t.id===e.id);return t?{...e,position:{x:t.x+a,y:t.y+o}}:e})),S.current=null});return}if(aI.current&&!aM.current){let t=aY(e.clientX,e.clientY,aI.current);aS.current=t.nodeId,e8(t.nodeId),tt(aU(e.clientX,e.clientY))}},[oW,aY,aU]),oB=(0,n.useCallback)(e=>{let t=aA.current;if(!t)return;if(0===e.buttons){aA.current=null,to(null);return}let a=aU(e.clientX,e.clientY),o=Math.min(t.startWorldX,a.x),n=Math.min(t.startWorldY,a.y),i=Math.abs(a.x-t.startWorldX),r=Math.abs(a.y-t.startWorldY),s=new Set(t.additive?t.initialSelectedNodeIds:[]);aw.current.filter(e=>!rx(e,aw.current)).forEach(e=>{o<e.position.x+e.width&&o+i>e.position.x&&n<e.position.y+e.height&&n+r>e.position.y&&s.add(e.id)});let l={...t,currentWorldX:a.x,currentWorldY:a.y};aA.current=l,to(l),eJ(s)},[aU]),oq=(0,n.useCallback)(e=>{if(oW(e.clientX,e.clientY),aA.current=null,to(null),aM.current)return;let t=aI.current;if(t){let a=aY(e.clientX,e.clientY,t);a.nodeId?(aq(t,a.nodeId),aW(null)):a.isNearNode?aW(null):(tt(aU(e.clientX,e.clientY)),e9({connection:t,position:aU(e.clientX,e.clientY)}))}},[aq,oW,aY,aU,aW]);(0,n.useEffect)(()=>{let e=e=>oW(e.clientX,e.clientY),t=()=>oW();return window.addEventListener("mousemove",oO),window.addEventListener("mouseup",oq),window.addEventListener("pointerup",e),window.addEventListener("pointercancel",t),window.addEventListener("blur",t),window.addEventListener("pointermove",oB),()=>{window.removeEventListener("mousemove",oO),window.removeEventListener("mouseup",oq),window.removeEventListener("pointerup",e),window.removeEventListener("pointercancel",t),window.removeEventListener("blur",t),window.removeEventListener("pointermove",oB)}},[oW,oO,oq,oB]);let oG=(0,n.useCallback)((e,t,a,o)=>{let n=o===ev.p.Panorama,i=n?ec.D9:er(e.width,e.height),r=o+"-"+Date.now()+"-"+Math.random().toString(36).slice(2,7),s={id:r,type:o,title:t,position:{x:a.x-i.width/2,y:a.y-i.height/2},width:i.width,height:i.height,metadata:n?{...iH(e),size:ec.A9,panoramaProjection:"equirectangular"}:iH(e)};eh(e=>[...e,s]),eJ(new Set([r])),e1(null),tR(r)},[]),oH=(0,n.useCallback)(async(e,t,a=!1)=>{let o=d.loading("正在上传图片...",0);try{let o=await (0,V.uploadImage)(e);if(a&&o.width===2*o.height)return void tA({image:o,title:e.name,position:t});oG(o,e.name,t,ev.p.Image)}catch(e){console.error("Upload image node failed:",e),d.error("图片上传失败")}finally{o()}},[oG,d]),oX=(0,n.useCallback)(e=>{tS&&(tA(null),oG(tS.image,tS.title,tS.position,e))},[oG,tS]),oY=(0,n.useCallback)(async(e,t)=>{let a=d.loading("正在上传视频...",0);try{let a=await (0,U.uploadMediaFile)(e,"video"),o=iY(a,e.name,t);eh(e=>[...e,o]),eJ(new Set([o.id])),e1(null),tR(o.id)}catch(e){console.error("Upload video node failed:",e),d.error("视频上传失败")}finally{a()}},[d]),oJ=(0,n.useCallback)(async(e,t)=>{let a=d.loading("正在上传音频...",0);try{let a=await (0,U.uploadMediaFile)(e,"audio"),o=eT[ev.p.Audio],n=`audio-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;eh(i=>[...i,{id:n,type:ev.p.Audio,title:e.name,position:{x:t.x-o.width/2,y:t.y-o.height/2},width:o.width,height:o.height,metadata:iQ(a)}]),eJ(new Set([n])),e1(null)}catch(e){console.error("Upload audio node failed:",e),d.error("音频上传失败")}finally{a()}},[d]),oQ=(0,n.useCallback)(e=>{let t=e.trim();if(!t)return!1;let a={...iR(ev.p.Text,aK(),{content:t,status:i_}),title:t.slice(0,32)||"剪切板文本"};return eh(e=>[...e,a]),eJ(new Set([a.id])),e1(null),ti(null),tR(a.id),!0},[aK]),oZ=(0,n.useCallback)(async()=>{if(!navigator.clipboard)return;let e=(await navigator.clipboard.read()).find(e=>e.types.some(e=>e.startsWith("image/")));if(e){let t=e.types.find(e=>e.startsWith("image/"));if(!t)return;oH(new File([await e.getType(t)],"clipboard-image.png",{type:t}),aK()),d.success("已从剪切板添加图片");return}oQ(await navigator.clipboard.readText())&&d.success("已从剪切板添加文本")},[oH,oQ,aK,d]);(0,n.useEffect)(()=>{let e=e=>{let t=e.target instanceof Element?e.target:null,a=t?.closest("[data-node-id]")?.dataset.nodeId,o=e.target instanceof HTMLVideoElement&&!!(a&&aC.current.has(a));if(e.target instanceof HTMLInputElement||e.target instanceof HTMLTextAreaElement||e.target instanceof HTMLSelectElement||t?.closest("[contenteditable='true']")||t?.closest("[data-canvas-no-zoom]")&&!o)return;let n=e.key.toLowerCase(),i=e.metaKey||e.ctrlKey;if(i&&!e.altKey&&"z"===n){e.preventDefault(),e.shiftKey?oL():o$();return}if(i&&!e.altKey&&"y"===n){e.preventDefault(),oL();return}if(i&&!e.altKey&&"a"===n){e.preventDefault(),eJ(new Set(aw.current.map(e=>e.id))),e1(null),ti(null),to(null);return}if(i&&!e.altKey&&"g"===n){e.preventDefault(),oT();return}if(i&&!e.altKey&&"c"===n){let t=window.getSelection();if(t&&!t.isCollapsed&&t.toString())return;e.preventDefault(),oz();return}if(i&&!e.altKey&&"v"===n){e.preventDefault(),oP()||oZ();return}("Delete"===e.key||"Backspace"===e.key)&&(aC.current.size?ow(new Set(aC.current)):e0&&ok(e0)),"Escape"===e.key&&(eJ(new Set),e1(null),ti(null),ts(null),to(null),aW(null),e5(null),tz(null),tR(null),tV(null),tK(null),tO(null),e9(null))};return window.addEventListener("keydown",e),()=>window.removeEventListener("keydown",e)},[oz,oT,ok,ow,oP,oZ,oL,e0,aW,o$]);let o0=(0,n.useCallback)((e,t,a)=>{e.stopPropagation(),tt(aU(e.clientX,e.clientY)),aW({nodeId:t,handleType:a}),aS.current=null,e8(null),e1(null)},[aU,aW]),o1=(0,n.useCallback)((e,t,a,o)=>{eh(n=>n.map(n=>n.id===e?{...n,width:t,height:a,position:o||n.position}:n))},[]),o4=(0,n.useCallback)(e=>{eh(t=>t.map(t=>{if(t.id!==e)return t;let a=!t.metadata?.freeResize;if(a||!(0,ec.IM)(t.type))return{...t,metadata:{...t.metadata,freeResize:a}};let o=(t.metadata?.naturalWidth||t.width)/(t.metadata?.naturalHeight||t.height||1),n=t.width/o;return{...t,height:n,position:{x:t.position.x,y:t.position.y+t.height/2-n/2},metadata:{...t.metadata,freeResize:a}}}))},[]),o3=(0,n.useCallback)((e,t)=>{eh(a=>a.map(a=>a.id===e?{...a,metadata:{...a.metadata,content:t}}:a))},[]),o8=(0,n.useCallback)((e,t)=>{eh(a=>a.map(a=>a.id===e?{...a,title:t}:a))},[]),o9=(0,n.useCallback)(e=>{aw.current.find(t=>t.id===e)?.metadata?.imageBatchExpanded?(al(t=>new Set(t).add(e)),window.setTimeout(()=>{al(t=>{let a=new Set(t);return a.delete(e),a})},320)):(ac(t=>new Set(t).add(e)),window.setTimeout(()=>{ac(t=>{let a=new Set(t);return a.delete(e),a})},260)),eh(t=>t.map(t=>t.id!==e?t:{...t,metadata:{...t.metadata,imageBatchExpanded:!t.metadata?.imageBatchExpanded}}))},[]),ne=(0,n.useCallback)(e=>{let t=e.metadata?.batchRootId;t&&e.metadata?.content&&eh(a=>a.map(a=>a.id===t?{...a,width:e.width,height:e.height,metadata:{...a.metadata,content:e.metadata?.content,primaryImageId:e.id,naturalWidth:e.metadata?.naturalWidth,naturalHeight:e.metadata?.naturalHeight,freeResize:e.metadata?.freeResize,panoramaProjection:e.metadata?.panoramaProjection}}:a))},[]),nt=(0,n.useCallback)((e,t)=>{eh(a=>a.map(a=>a.id===e?{...a,metadata:a.type===ev.p.Panorama?{...a.metadata,prompt:t,panoramaSourcePrompt:t}:{...a.metadata,prompt:t}}:a))},[]),na=(0,n.useCallback)((e,t)=>{eh(a=>a.map(a=>{var o;let n,i,r,s,l;return a.id===e?(o=a,n=t||{},i=(0,ec.sK)(o.type),r={...o,metadata:{...o.metadata,...n,...i?{size:ec.A9}:{}}},s=i?eT[ev.p.Panorama]:o.type===ev.p.Video?eT[ev.p.Video]:eT[ev.p.Image],(l=i||"string"!=typeof n.size||o.metadata?.content?null:es(n.size,s.width,s.height))&&((0,ec.IM)(o.type)||o.type===ev.p.Video)?{...r,...l,position:{x:o.position.x+o.width/2-l.width/2,y:o.position.y+o.height/2-l.height/2}}:r):a}))},[]),no=(0,n.useCallback)(e=>{t$&&eh(t=>t.map(t=>t.id===t$&&t.type===ev.p.Director?{...t,metadata:{...t.metadata,directorProject:e}}:t))},[t$]),nn=(0,n.useCallback)(({edgeId:e,sourceNodeId:t})=>{if(!t$)return;let a=aj.current.find(a=>a.id===e&&a.fromNodeId===t&&a.toNodeId===t$);a&&eC(e=>e.filter(e=>e.id!==a.id))},[t$]),ni=(0,n.useCallback)(async(e,t)=>{let a=aw.current.find(t=>t.id===e&&t.type===ev.p.Director);if(!a||0===t.length)return;let o=d.loading(t.length>1?"正在发送 "+t.length+" 张截图到画布...":"正在发送截图到画布...",0);try{let e=await Promise.all(t.map(async e=>{let t=await (0,V.uploadImage)(e.dataUrl,{localOnly:!0});return{id:(0,K.Ak)(),title:e.fileName,size:er(t.width,t.height),metadata:iH(t)}})),o=iJ(a,aw.current,aj.current),n=e.map(e=>{let t={id:e.id,type:ev.p.Image,title:e.title,position:{x:a.position.x+a.width+96,y:o},width:e.size.width,height:e.size.height,metadata:e.metadata};return o+=t.height+36,t});eh(e=>[...e,...n]),eC(e=>[...e,...n.map(e=>({id:(0,K.Ak)(),fromNodeId:a.id,toNodeId:e.id}))]),eJ(new Set(n.map(e=>e.id))),e1(null),d.success(t.length>1?"已发送 "+t.length+" 张截图到画布":"截图已发送到画布")}catch(e){console.error("Send director captures to canvas failed:",e),d.error("截图发送到画布失败")}finally{o()}},[d]),nr=(0,n.useCallback)(async(e,t)=>{let a=aw.current.find(t=>t.id===e&&t.type===ev.p.Director);if(!a)return;let o=d.loading("正在发送视频到画布...",0);try{let e=await (0,U.uploadMediaFile)(t.blob,"video"),o={...e,width:e.width||t.width,height:e.height||t.height,durationMs:e.durationMs||Math.round(1e3*t.durationSeconds)},n=iJ(a,aw.current,aj.current),i=er(o.width,o.height,420,420),r=iY(o,t.fileName,{x:a.position.x+a.width+96+i.width/2,y:n+i.height/2});eh(e=>[...e,r]),eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:a.id,toNodeId:r.id}]),eJ(new Set([r.id])),e1(null),tR(r.id),d.success("视频已发送到画布")}catch(e){console.error("Send director video to canvas failed:",e),d.error("视频发送到画布失败")}finally{o()}},[d]),ns=(0,n.useCallback)(async e=>{var t;if(!(0,ec.IM)(e.type)&&e.type!==ev.p.Video&&e.type!==ev.p.Audio||!e.metadata?.content)return;let a=e.type===ev.p.Video?"mp4":e.type===ev.p.Audio?iG(e.metadata.mimeType):(t=e.metadata.content,t.match(/^data:image[/]([^;]+)/)?.[1]||t.match(/image[/]([^;]+)/)?.[1]||"png"),o=`canvas-${e.type}-${e.id}.${a}`,n=e.metadata.content;if(e.type===ev.p.Video&&/\/videos\/[^/]+\/content(?:[?#]|$)/i.test(n)){let t=d.loading("正在准备视频下载...",0);try{let t=n.match(/\/videos\/([^/?#]+)\/content/i),a=(t?t[1]:"")||e.metadata?.videoTaskId||"",i=e.metadata?.model||z.videoModel||z.model||"",r=X.k.getState().token,s=r?{Authorization:`Bearer ${r}`}:{},l=a?`/api/v1/videos/${encodeURIComponent(a)}/content?model=${encodeURIComponent(i)}`:n,d=await fetch(l,{headers:s});if(!d.ok)throw Error(`下载失败: ${d.status}`);let c=await d.blob();(0,E.saveAs)(c,o)}catch(e){d.error(e instanceof Error?e.message:"视频下载失败")}finally{t()}return}(0,E.saveAs)(n,o)},[z.model,z.videoModel,d]),nd=(0,n.useCallback)((e,t)=>{eC(a=>a.filter(a=>a.fromNodeId!==e||a.toNodeId!==t))},[]),nc=(0,n.useCallback)(e=>{af(e),eJ(new Set([e])),e1(null),ti(null),tz(null),tR(null)},[]),nu=(0,n.useCallback)(()=>{ah&&(eJ(new Set([ah])),tR(ah),af(null))},[ah]),nm=(0,n.useCallback)(e=>{if(!ah||of.has(e))return;let t=aw.current.find(t=>t.id===e);t&&(0,az.Qw)(t)&&eC(t=>[...t,{id:(0,K.Ak)(),fromNodeId:e,toNodeId:ah}])},[of,ah]);(0,n.useEffect)(()=>{if(!ah)return;let e=e=>{"Escape"===e.key&&(e.preventDefault(),e.stopImmediatePropagation(),nu())};return window.addEventListener("keydown",e,!0),()=>window.removeEventListener("keydown",e,!0)},[nu,ah]);let np=(0,n.useCallback)(async(e,t)=>{ti(null);let a=aw.current.find(t=>t.id===e),o=u.current?.querySelector(`[data-node-id="${CSS.escape(e)}"] video`);if(a?.type!==ev.p.Video||!a.metadata?.content||!o)return d.error("无法截取该画面，请重试");try{let e=await (0,V.uploadImage)(await el(a.metadata.content,t,o.currentTime)),n=er(e.width,e.height,420,420),i=(0,K.Ak)(),r=a.position.x+a.width+96,s=a.position.y+a.height/2-n.height/2;for(;aw.current.some(e=>e.id!==a.id&&e.position.x<r+n.width&&e.position.x+e.width>r&&e.position.y<s+n.height&&e.position.y+e.height>s);)s+=n.height+24;let l="first"===t?"首帧":"last"===t?"尾帧":"当前帧",c={id:i,type:ev.p.Image,title:`${a.title||"视频"} ${l}`,position:{x:r,y:s},...n,metadata:iH(e)};eh(e=>[...e,c]),eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:a.id,toNodeId:i}]),eJ(new Set([i])),e1(null),tR(i),d.success("已生成图片节点")}catch{d.error("无法截取该画面，请重试")}},[d]),ng=(0,n.useCallback)(async e=>{if(e.type!==ev.p.Video&&e.type!==ev.p.Audio||!e.metadata?.content||e.metadata.storageKey?.startsWith("server:")||A.current.has(e.id))return;A.current.add(e.id);let t=e.type===ev.p.Audio,a=t?"音频":"视频",o=d.loading(`正在上传${a}至云存储...`,0);try{let o=await (0,U.aN)(e.metadata.storageKey,e.metadata.content),n=`canvas-${e.type}-${e.id}.${t?iG(e.metadata.mimeType):"mp4"}`,i=await (0,U.iU)(o,n);eh(t=>t.map(t=>t.id===e.id?{...t,metadata:{...t.metadata,content:i.url,storageKey:i.storageKey,bytes:i.bytes,mimeType:i.mimeType,naturalWidth:i.width||t.metadata?.naturalWidth,naturalHeight:i.height||t.metadata?.naturalHeight}}:t)),d.success(`${a}已上传至云存储`)}catch(t){let e=t instanceof Error?t.message:"";e.includes("服务端对象存储未启用")||e.includes("用户对象存储配置不完整")?d.error("未添加云存储"):d.error(e||`${a}上传失败`)}finally{o(),A.current.delete(e.id)}},[d]),nh=(0,n.useCallback)(async e=>{if(!(0,ec.IM)(e.type)||!e.metadata?.content||e.metadata.storageKey?.startsWith("server:")||M.current.has(e.id))return;M.current.add(e.id);let t=d.loading("正在上传图片至云存储...",0);try{let t=await (0,V.resolveImageUrl)(e.metadata.storageKey,e.metadata.content),a=await (0,V.uploadRemoteImageToServer)(t,"canvas-image-"+e.id+".png");eh(t=>t.map(t=>t.id===e.id?{...t,metadata:{...t.metadata,content:a.url,storageKey:a.storageKey,bytes:a.bytes,mimeType:a.mimeType,naturalWidth:a.width||t.metadata?.naturalWidth,naturalHeight:a.height||t.metadata?.naturalHeight}}:t)),eR(t=>i6(t,[{...e,metadata:{...e.metadata,content:a.url,storageKey:a.storageKey,mimeType:a.mimeType}}])),d.success("图片已上传至云存储")}catch(t){let e=t instanceof Error?t.message:"";e.includes("服务端对象存储未启用")||e.includes("用户对象存储配置不完整")?d.error("未添加云存储"):d.error(e||"图片上传失败")}finally{t(),M.current.delete(e.id)}},[d]),nf=(0,n.useCallback)(async e=>{if(e.type===ev.p.Text){let t=e.metadata?.content?.trim();return t?(q({kind:"text",title:e.metadata?.prompt?.slice(0,24)||"画布文本",coverUrl:"",tags:[],source:"Canvas",data:{content:t},metadata:{source:"canvas",nodeId:e.id}}),void d.success("已加入我的素材")):d.error("没有可保存的文本")}if(e.type===ev.p.Video)return e.metadata?.content?(q({kind:"video",title:e.metadata?.prompt?.slice(0,24)||"画布视频",coverUrl:"",tags:[],source:"Canvas",data:{url:e.metadata.content,storageKey:e.metadata.storageKey,width:e.width,height:e.height,bytes:e.metadata.bytes||0,mimeType:e.metadata.mimeType||"video/mp4"},metadata:{source:"canvas",nodeId:e.id,prompt:e.metadata?.prompt}}),void d.success("已加入我的素材")):d.error("没有可保存的视频");if(!e.metadata?.content)return d.error("没有可保存的图片");try{let t=!e.metadata.storageKey&&e.metadata.content.startsWith("blob:")?await (0,V.uploadImage)(e.metadata.content,{localOnly:!0}):null,a=t?.url||e.metadata.content,o=t?.storageKey||e.metadata.storageKey,n=o?"":a;q({kind:"image",title:e.metadata?.prompt?.slice(0,24)||"画布图片",coverUrl:a,tags:[],source:"Canvas",data:{dataUrl:n,storageKey:o,width:t?.width||e.metadata.naturalWidth||e.width,height:t?.height||e.metadata.naturalHeight||e.height,bytes:t?.bytes||e.metadata.bytes||(0,W.P0)(n),mimeType:t?.mimeType||e.metadata.mimeType||"image/png"},metadata:{source:"canvas",nodeId:e.id,prompt:e.metadata?.prompt}}),d.success("已加入我的素材")}catch(e){d.error(e instanceof Error?`图片加入素材失败：${e.message}`:"图片加入素材失败")}},[q,d]),nx=(0,n.useCallback)(e=>{if(!(0,ec.IM)(e.type)||!e.metadata?.content)return void d.warning("图片节点为空，无法反推提示词");let t=eT[ev.p.Text],a=eT[ev.p.Config],o=e.position.y+e.height/2,n={...iR(ev.p.Text,{x:e.position.x+e.width+96+t.width/2,y:o},{content:iE,prompt:iE,status:i_,fontSize:14}),title:"反推提示词"},i={...iR(ev.p.Config,{x:n.position.x+n.width+96+a.width/2,y:o},{generationMode:"text",model:z.textModel||z.model||F.defaultConfig.textModel,count:1,composerContent:`参考图片：@[node:${e.id}]
任务说明：@[node:${n.id}]`}),title:"反推提示词配置"};eh(e=>[...e,n,i]),eC(t=>[...t,{id:(0,K.Ak)(),fromNodeId:e.id,toNodeId:i.id},{id:(0,K.Ak)(),fromNodeId:n.id,toNodeId:i.id}]),eJ(new Set([i.id])),e1(null),tR(i.id),ti(null)},[z.model,z.textModel,d]),nv=(0,n.useCallback)(async(e,t)=>{if(!e.metadata?.content)return;let a=await J(e.metadata.content,t),o=await (0,V.uploadImage)(a),n=Math.min(e.width,Math.max(220,o.width)),i=(0,K.Ak)(),r={id:i,type:ev.p.Image,title:"Cropped Image",position:{x:e.position.x+e.width+96,y:e.position.y},width:n,height:n*(o.height/o.width),metadata:{...iH(o),prompt:e.metadata?.prompt}};eh(e=>[...e,r]),eC(t=>[...t,{id:(0,K.Ak)(),fromNodeId:e.id,toNodeId:i}]),eJ(new Set([i])),tR(i),tK(null)},[]),ny=(0,n.useCallback)(async(e,t)=>{if(!e.metadata?.content)return;tY(null);let a=d.loading("正在处理切图...",0),o=[];try{let a=await Q(e.metadata.content,t),n=t.horizontalLines.length+1,i=t.verticalLines.length+1,r=e.width/i,s=e.height/n,l=e.position.x+e.width+96,c=e.position.y,u=await Promise.allSettled(a.map(async e=>({piece:e,image:await (0,V.uploadImage)(e.dataUrl)}))),m=u.flatMap(e=>"fulfilled"===e.status?[e.value]:[]);o=m.map(({image:e})=>e);let p=u.find(e=>"rejected"===e.status);if(p?.status==="rejected")throw p.reason;let g=m.map(({piece:t,image:a})=>({id:(0,K.Ak)(),type:ev.p.Image,title:`${e.title||"图片"} ${t.row+1}-${t.column+1}`,position:{x:l+t.column*(r+16),y:c+t.row*(s+16)},width:r,height:s,metadata:{...iH(a),prompt:e.metadata?.prompt}}));eh(e=>[...e,...g]),eC(t=>[...t,...g.map(t=>({id:(0,K.Ak)(),fromNodeId:e.id,toNodeId:t.id}))]),eJ(new Set(g.map(e=>e.id))),e1(null),tR(null),o=[],d.success(`已切分为 ${g.length} 个子节点`)}catch(a){let e=!1;if(o.length)try{await (0,V.deleteStoredImages)(o.map(e=>e.storageKey))}catch{e=!0}let t=a instanceof Error?a.message:"切图失败";d.error(e?`${t}；部分临时图片清理失败`:t)}finally{a()}},[d]),nb=(0,n.useCallback)(async(t,a)=>{if(!t.metadata?.content)return;let o=rm(z,t,"image"),n={...o,model:a.model||o.model,activeChannelId:a.channelId||o.imageChannelId||o.activeChannelId,imageChannelId:a.channelId||o.imageChannelId,count:"1",size:t.metadata?.size||"auto"};if(!P(n,n.model))return void B(!0);let i=a.prompt.trim(),r=`参考图中蓝色高亮覆盖区域是需要修改的位置，蓝色只是编辑标记，不要保留在最终图像中。只修改蓝色高亮区域，其他区域的构图、人物、文字、光影和风格保持不变。修改要求：${i}`,s=(0,K.Ak)(),l=`client_image_task_${s}`,c={id:`${t.id}-marked`,name:`image-${t.id}-marked.png`,type:"image/png",dataUrl:a.markedDataUrl},u=iZ("edit",n,1,[c]),m={id:s,type:ev.p.Image,title:i.slice(0,32)||"局部编辑结果",position:{x:t.position.x+t.width+96,y:t.position.y},width:t.width,height:t.height,metadata:{prompt:r,status:iM,startedAt:Date.now(),progress:0,imageTaskId:l,...u}};tO(null),td(s),eh(e=>[...e,m]),eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:t.id,toNodeId:s}]),eJ(new Set([s])),e1(null),tR(s);try{let a=await (0,R.vE)(n,r,[c],{nodeId:s,sourceId:e,clientTaskId:l});eh(e=>ra(e,s,a,m.metadata?.startedAt||Date.now(),{width:t.width,height:t.height})),eC(e=>ro(e,s,a))}catch(t){let e=t instanceof Error?t.message:"局部修改失败";d.error(e),eh(t=>t.map(t=>t.id===s?{...t,metadata:{...t.metadata,status:iT,errorDetails:e}}:t))}finally{td(null)}},[z,P,d,B,e]),nw=(0,n.useCallback)(async(e,t)=>{if(!e.metadata?.content)return;tQ(null);let a=d.loading("正在放大图片...",0);try{let a=await ee(e.metadata.content,t),o=await (0,V.uploadImage)(a),n=er(o.width,o.height),i=(0,K.Ak)(),r={id:i,type:ev.p.Image,title:"Upscaled Image",position:{x:e.position.x+e.width+96,y:e.position.y},width:n.width,height:n.height,metadata:{...iH(o),prompt:e.metadata?.prompt}};eh(e=>[...e,r]),eC(t=>[...t,{id:(0,K.Ak)(),fromNodeId:e.id,toNodeId:i}]),eJ(new Set([i])),tR(i)}catch(e){d.error(e instanceof Error?e.message:"图片放大失败")}finally{a()}},[d]),nk=(0,n.useCallback)(async(t,a)=>{var o;if(!t.metadata?.content)return;let n={...rm(z,t,"image"),count:"1"};if(!P(n,n.model))return void B(!0);let i=(0,K.Ak)(),r=eT[ev.p.Image],s=ry(a),l=(o=a,`基于参考图重新生成同一主体的新视角，保持主体、颜色、材质和画面风格一致，不要只做透视变形。${ry(o)}。`),d=[{id:t.id,name:`image-${t.id}.png`,type:t.metadata.mimeType||"image/png",dataUrl:t.metadata.content,storageKey:t.metadata.storageKey}],c=iZ("edit",n,1,d),u=`client_image_task_${i}`,m=Date.now();t2(null),td(i),eh(e=>[...e,{id:i,type:ev.p.Image,title:s,position:{x:t.position.x+t.width+96,y:t.position.y},width:r.width,height:r.height,metadata:{prompt:l,status:iM,imageTaskId:u,startedAt:m,progress:0,...c}}]),eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:t.id,toNodeId:i}]),eJ(new Set([i])),tR(i);try{let t=await (0,R.vE)(n,l,d,{nodeId:i,sourceId:e,clientTaskId:u});eh(e=>ra(e,i,t,m,{width:r.width,height:r.height})),eC(e=>ro(e,i,t))}catch(t){let e=t instanceof Error?t.message:"生成失败";eh(t=>t.map(t=>t.id===i?{...t,metadata:{...t.metadata,status:iT,errorDetails:e}}:t))}finally{td(null)}},[z,d,B,e]),nj=(0,n.useCallback)((e,t)=>{eh(a=>a.map(a=>a.id===e?{...a,metadata:{...a.metadata,fontSize:t}}:a))},[]),nC=(0,n.useCallback)((e,t)=>{h.current={nodeId:e,position:t},m.current?.click()},[]),nN=(0,n.useCallback)(async e=>{let t=e.target.files?.[0],a=h.current;if(!t||!t.type.startsWith("image/")&&!t.type.startsWith("video/")&&!rf(t))return;let o=a?.nodeId?aw.current.find(e=>e.id===a.nodeId):null;if((0,ec.sK)(o?.type)&&!t.type.startsWith("image/")){d.warning("全景图节点仅支持上传图片作为参考"),h.current=null,e.target.value="";return}if(a?.nodeId){let e=d.loading(rf(t)?"正在上传音频...":t.type.startsWith("video/")?"正在上传视频...":"正在上传图片...",0);try{if(rf(t)){let e=await (0,U.uploadMediaFile)(t,"audio"),o=eT[ev.p.Audio];eh(n=>n.map(n=>n.id===a.nodeId?{...n,type:ev.p.Audio,title:t.name,position:{x:n.position.x+n.width/2-o.width/2,y:n.position.y+n.height/2-o.height/2},width:o.width,height:o.height,metadata:{...n.metadata,...iQ(e),errorDetails:void 0}}:n)),eJ(new Set([a.nodeId])),e1(null)}else if(t.type.startsWith("video/")){let e=await (0,U.uploadMediaFile)(t,"video"),o=er(e.width||1280,e.height||720,420,420);eh(n=>n.map(n=>n.id===a.nodeId?{...n,type:ev.p.Video,title:t.name,position:{x:n.position.x+n.width/2-o.width/2,y:n.position.y+n.height/2-o.height/2},width:o.width,height:o.height,metadata:{...n.metadata,...iX(e),errorDetails:void 0}}:n)),eJ(new Set([a.nodeId])),e1(null),tR(a.nodeId)}else{let e=await (0,V.uploadImage)(t),o=er(e.width,e.height);eh(n=>n.map(n=>{if(n.id!==a.nodeId)return n;let i=(0,ec.sK)(n.type),r=i?ec.D9:o;return{...n,type:i?ev.p.Panorama:ev.p.Image,title:i?n.title:t.name,position:i?{x:n.position.x+n.width/2-r.width/2,y:n.position.y+n.height/2-r.height/2}:n.position,width:r.width,height:r.height,metadata:{...n.metadata,...iH(e),errorDetails:void 0,freeResize:!1,isBatchRoot:void 0,batchRootId:void 0,batchChildIds:void 0,batchUsesReferenceImages:void 0,generationType:void 0,model:i?n.metadata?.model:void 0,size:i?ec.A9:void 0,quality:i?n.metadata?.quality:void 0,count:i?n.metadata?.count:void 0,references:void 0,primaryImageId:void 0,imageBatchExpanded:void 0,imageTaskId:void 0,imageTaskResultId:void 0,panoramaSourcePrompt:i?n.metadata?.panoramaSourcePrompt:void 0,panoramaFinalPrompt:void 0,panoramaProjection:void 0}}})),eJ(new Set([a.nodeId])),e1(null),tR(a.nodeId)}}catch(e){console.error("Upload node file failed:",e),d.error("上传失败")}finally{e()}}else{let e=a?.position||aU((u.current?.getBoundingClientRect().left||0)+eH.width/2,(u.current?.getBoundingClientRect().top||0)+eH.height/2);rf(t)?oJ(t,e):t.type.startsWith("video/")?oY(t,e):oH(t,e,!0)}h.current=null,e.target.value=""},[oJ,oH,oY,aU,eH.height,eH.width]);function nI(e,t,a){let o=t||aU((u.current?.getBoundingClientRect().left||0)+eH.width/2,(u.current?.getBoundingClientRect().top||0)+eH.height/2);if("text"===e.kind)return void oy(ev.p.Text,t,e.content,a);if("video"===e.kind){let t=eT[ev.p.Video],n=a||`video-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,i=er(e.width||t.width,e.height||t.height,420,420);eh(t=>[...t,{id:n,type:ev.p.Video,title:e.title,position:{x:o.x-i.width/2,y:o.y-i.height/2},width:i.width,height:i.height,metadata:{content:e.url,storageKey:e.storageKey,status:i_,naturalWidth:e.width,naturalHeight:e.height}}]),eJ(new Set([n])),e1(null);return}if("audio"===e.kind){let t=eT[ev.p.Audio],n=a||`audio-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;eh(a=>[...a,{id:n,type:ev.p.Audio,title:e.title,position:{x:o.x-t.width/2,y:o.y-t.height/2},width:t.width,height:t.height,metadata:{content:e.url,storageKey:e.storageKey,status:i_,bytes:e.bytes,mimeType:e.mimeType||"audio/mpeg",durationMs:e.durationMs}}]),eJ(new Set([n])),e1(null);return}return nV({id:a||`asset-${Date.now()}`,prompt:e.title,dataUrl:e.dataUrl,storageKey:e.storageKey,source:e.source},t,a)}let nS=(0,n.useCallback)(e=>{e.preventDefault();let t=g.current;if(e.dataTransfer.getData(ii)&&t)return void nI(t,aU(e.clientX,e.clientY));let a=Array.from(e.dataTransfer.files).find(e=>e.type.startsWith("image/")||e.type.startsWith("video/")||rf(e));if(!a)return;let o=aU(e.clientX,e.clientY);rf(a)?oJ(a,o):a.type.startsWith("video/")?oY(a,o):oH(a,o,!0)},[oJ,oH,oY,nI,aU]),nA=(0,n.useCallback)(e=>{oH(e,aU((u.current?.getBoundingClientRect().left||0)+eH.width/2,(u.current?.getBoundingClientRect().top||0)+eH.height/2)),d.success("已从剪切板添加图片")},[oH,d,aU,eH.height,eH.width]),nM=(0,n.useCallback)((e,t)=>{eR(e),eL(t)},[]),nT=(0,n.useCallback)(e=>{eU(t=>({...t||ay,...e}))},[ay]),nz=(0,n.useCallback)(()=>{an(eu?.title||"未命名画布"),aa(!0)},[eu?.title]),nP=(0,n.useCallback)(()=>{let t=ao.trim();t&&ei(e,t),aa(!1)},[e,ei,ao]),nE=(0,n.useCallback)(e=>{e.target.closest("[data-node-id]")||(e.preventDefault(),ti(null))},[]),nD=(0,n.useCallback)(async(t,a,o)=>{if(!Y.useWalletStore.getState().checkBalanceOrIntercept(()=>{d.warning("当前账户算力余额不足，请先充值算力后再体验创作")}))return;let n=aw.current.find(e=>e.id===t),i=rm(z,n,a);if(!P(i,i.model))return void B(!0);td(t);let r=n?.type===ev.p.Text&&n.metadata?.content?.trim()||"",s="text"===a&&!!r,l=await o_(oI(t,aw.current,aj.current,s?`请根据要求修改以下文本。

原文：
${r}

修改要求：
${o}`:o)),c=l.prompt.trim(),u="video"!==a&&("image"!==a||(0,ec.sK)(n?.type))?c:ex(c,n?.metadata?.cameraControl),m=!(0,ec.IM)(n?.type)&&!s,p=n?.type===ev.p.Config?c:o;if(!c&&("text"===a||"audio"===a))return void td(null);let g=[],h=Date.now();m&&eh(e=>e.map(e=>e.id===t?{...e,metadata:{...e.metadata,prompt:p,status:iM,startedAt:h,durationMs:void 0,errorDetails:void 0}}:e));try{if("image"===a&&(0,ec.sK)(n?.type)){let a=o.trim(),r=n?.metadata?.content?[{id:n.id,name:`image-${n.id}.png`,type:n.metadata.mimeType||"image/png",dataUrl:n.metadata.content,storageKey:n.metadata.storageKey}]:[],s=[...l.referenceImages,...r],u=(0,ec.cs)(c,s.length>0),m={...i,size:ec.A9},p=i8(m.count),f=!n?.metadata?.content,x=eT[ev.p.Panorama],v=n?.position||{x:0,y:0},y=f?t:(0,K.Ak)(),b=p>1?Array.from({length:p},()=>(0,K.Ak)()):[],w=p>1?b:[y],k=Object.fromEntries(w.map(e=>[e,"client_image_task_"+e])),j=w[0];g=f?b:[y,...b];let C={id:y,type:ev.p.Panorama,title:n?.title||"全景图",position:{x:f?v.x:v.x+x.width+96,y:v.y+x.height/2-x.height/2},width:f&&n?.width||x.width,height:f&&n?.height||x.height,metadata:{...iZ(s.length?"edit":"generation",m,p,s),prompt:a,panoramaSourcePrompt:a,panoramaFinalPrompt:u,panoramaProjection:void 0,status:iM,startedAt:h,progress:0,imageTaskId:j?k[j]:void 0,primaryImageId:p>1?j:void 0,isBatchRoot:p>1,batchChildIds:p>1?b:void 0,batchUsesReferenceImages:s.length>0,imageBatchExpanded:p>1||void 0}},N=b.map((e,t)=>({id:e,type:ev.p.Panorama,title:n?.title||"全景图",position:{x:C.position.x+C.width+120+t%2*(x.width+36),y:C.position.y+Math.floor(t/2)*(x.height+36)},width:x.width,height:x.height,metadata:{...iZ(s.length?"edit":"generation",m,p,s),prompt:a,panoramaSourcePrompt:a,panoramaFinalPrompt:u,panoramaProjection:void 0,status:iM,startedAt:h,progress:0,imageTaskId:k[e],batchRootId:p>1?y:void 0}})),I=[...f?[]:[{id:(0,K.Ak)(),fromNodeId:t,toNodeId:y}],...b.map(e=>({id:(0,K.Ak)(),fromNodeId:y,toNodeId:e}))];eh(e=>[...e.map(e=>e.id===t?f?{...e,position:C.position,width:C.width,height:C.height,title:C.title,metadata:{...e.metadata,...C.metadata,errorDetails:void 0}}:{...e,metadata:{...e.metadata,status:i_,errorDetails:void 0}}:e),...f?[]:[C],...N]),eC(e=>[...e,...I]),eJ(new Set([t])),e1(null),tR(t);let S=await Promise.all(w.map(async t=>{try{let a=await (0,R.vE)({...m,count:"1",quality:"auto"===m.quality?"medium":m.quality},u,s,{nodeId:t,sourceId:e,clientTaskId:k[t]});if(a.image_url||a.url)return eh(e=>{let o=e.find(e=>e.id===y),n=ra(e,t,a,h,{width:x.width,height:x.height});return t!==y&&o?.metadata?.primaryImageId===t&&(n=ra(n,y,a,h,{width:x.width,height:x.height})),n}),!0;return eh(e=>{let o=e.find(e=>e.id===y);return e.map(e=>e.id!==t&&e.id!==y?e:e.id!==y||t!==y&&o?.metadata?.primaryImageId?e.id===t?{...e,metadata:{...e.metadata,status:iM,imageTaskId:a.id,imageTaskResultId:void 0,startedAt:rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||h,progress:a.progress||0,errorDetails:void 0}}:e:{...e,metadata:{...e.metadata,status:iM,imageTaskId:a.id,imageTaskResultId:void 0,primaryImageId:t,startedAt:rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||h,progress:a.progress||0,errorDetails:void 0}})}),!0}catch(a){let e=a instanceof Error?a.message:"全景图生成失败";return eh(a=>a.map(a=>a.id===t?{...a,metadata:{...a.metadata,status:iT,errorDetails:e}}:a)),!1}})),A=S.some(Boolean);S.some(e=>!e)&&d.error(A?"部分全景图任务创建失败":"全部全景图任务创建失败"),eh(e=>e.map(e=>e.id!==y||A?e:{...e,metadata:{...e.metadata,status:iT,errorDetails:"全部全景图任务创建失败"}})),Y.useWalletStore.getState().triggerWalletSync();return}if("image"===a){let a=(0,e_.$)(i.model)?1:i8(i.count),r=n?.type===ev.p.Config,s=n?.type===ev.p.Image,m=s&&!n?.metadata?.content,p=s&&n?.metadata?.content?[{id:n.id,name:`image-${n.id}.png`,type:n.metadata.mimeType||"image/png",dataUrl:n.metadata.content,storageKey:n.metadata.storageKey}]:[],f=[...l.referenceImages,...p],x=f.length?"edit":"generation",v=iZ(x,i,a,f),y=eT[r?ev.p.Config:s?ev.p.Image:ev.p.Text],b=eT[ev.p.Image],w=es(i.size,b.width,b.height)||b,k=n?.position||{x:0,y:0},j=m?t:(0,K.Ak)(),C=a>1?Array.from({length:a},()=>(0,K.Ak)()):[],N=a>1?C:[j],I=Object.fromEntries(N.map(e=>[e,`client_image_task_${e}`])),S=N[0];g=m?C:[j,...C];let A={id:j,type:ev.p.Image,title:c.slice(0,32)||"Generated Image",position:{x:m?k.x:k.x+y.width+96,y:k.y+y.height/2-w.height/2},width:m&&n?.width||w.width,height:m&&n?.height||w.height,metadata:{prompt:c,cameraControl:n?.metadata?.cameraControl,status:iM,startedAt:h,progress:0,imageTaskId:S?I[S]:void 0,primaryImageId:a>1?S:void 0,isBatchRoot:a>1,batchChildIds:a>1?C:void 0,batchUsesReferenceImages:f.length>0,...v,imageBatchExpanded:a>1||void 0}},M=C.map((e,t)=>({id:e,type:ev.p.Image,title:c.slice(0,32)||"Generated Image",position:{x:A.position.x+A.width+120+t%2*(w.width+36),y:A.position.y+Math.floor(t/2)*(w.height+36)},width:w.width,height:w.height,metadata:{prompt:c,cameraControl:n?.metadata?.cameraControl,status:iM,startedAt:h,progress:0,imageTaskId:I[e],batchRootId:a>1?j:void 0,...v}})),_=[...m?[]:[{id:(0,K.Ak)(),fromNodeId:t,toNodeId:j}],...C.map(e=>({id:(0,K.Ak)(),fromNodeId:j,toNodeId:e}))];eh(e=>[...e.map(e=>e.id===t?r?{...e,metadata:{...e.metadata,prompt:c,status:iM,startedAt:h,durationMs:void 0,errorDetails:void 0}}:m?{...e,position:A.position,width:A.width,height:A.height,title:A.title,metadata:{...e.metadata,...A.metadata,errorDetails:void 0}}:s?{...e,metadata:{...e.metadata,status:i_,errorDetails:void 0}}:{...e,type:ev.p.Text,title:o.slice(0,32)||"Prompt",width:y.width,height:y.height,metadata:{...e.metadata,content:o,prompt:o,status:i_,fontSize:14,errorDetails:void 0}}:e),...m?[]:[A],...M]),eC(e=>[...e,..._]),eJ(new Set([t])),e1(null),tR(t);let T=await Promise.all(N.map(async a=>{try{let o=await (0,R.vE)({...i,count:"1"},u,f,{nodeId:a,sourceId:e,clientTaskId:I[a]});if(o.image_url||o.url)return eh(e=>{let t=e.find(e=>e.id===j),n=ra(e,a,o,h,{width:w.width,height:w.height});return a!==j&&t?.metadata?.primaryImageId===a&&(n=ra(n,j,o,h,{width:w.width,height:w.height})),n}),eC(e=>ro(e,a,o)),!0;return eh(e=>{let t=e.find(e=>e.id===j);return e.map(e=>e.id!==a&&e.id!==j?e:e.id!==j||a!==j&&t?.metadata?.primaryImageId?e.id===a?{...e,metadata:{...e.metadata,status:iM,imageTaskId:o.id,imageTaskResultId:void 0,startedAt:rr(o.started_at??o.startedAt??o.created_at??o.createdAt)||h,progress:o.progress||0,errorDetails:void 0}}:e:{...e,metadata:{...e.metadata,status:iM,imageTaskId:o.id,imageTaskResultId:void 0,primaryImageId:a,startedAt:rr(o.started_at??o.startedAt??o.created_at??o.createdAt)||h,progress:o.progress||0,errorDetails:void 0}})}),r&&eh(e=>e.map(e=>e.id===t?{...e,metadata:{...e.metadata,status:i_,errorDetails:void 0}}:e)),!0}catch(t){let e=t instanceof Error?t.message:"生成失败";return eh(t=>t.map(t=>t.id===a?{...t,metadata:{...t.metadata,status:iT,errorDetails:e}}:t)),!1}})),z=T.some(Boolean);T.some(e=>!e)&&d.error(z?"部分图片任务创建失败":"全部图片任务创建失败"),eh(e=>e.map(e=>e.id===t&&r?{...e,metadata:{...e.metadata,status:z?i_:iT,errorDetails:z?void 0:"全部图片任务创建失败"}}:e.id!==j||z?e:{...e,metadata:{...e.metadata,status:iT,errorDetails:"全部图片任务创建失败"}})),Y.useWalletStore.getState().triggerWalletSync();return}if("video"===a){var f;let e=i5(i,l),a=(0,eN.TQ)(e.model,(0,F.channelProtocolForConfig)(e)),o=a?l.firstFrame:null,r=a?l.lastFrame:null,s=a?l.referenceImages:[...l.referenceImages,...[l.firstFrame,l.lastFrame].filter(e=>!!e)],d=es(e.size,eT[ev.p.Video].width,eT[ev.p.Video].height)||eT[ev.p.Video],m=n?.type===ev.p.Video&&!n.metadata?.content,p=m?t:(0,K.Ak)(),x=`client_video_task_${p}`,v=n?.position||{x:0,y:0},y={id:p,type:ev.p.Video,title:c.slice(0,32)||"Generated Video",position:m?n.position:{x:v.x+(n?.width||d.width)+96,y:v.y},width:m?n.width:d.width,height:m?n.height:d.height,metadata:{prompt:c,cameraControl:n?.metadata?.cameraControl,status:iM,model:e.model,channelId:e.videoChannelId||e.activeChannelId,size:e.size,seconds:e.videoSeconds,vquality:e.vquality,mode:e.videoMode,negativePrompt:e.videoNegativePrompt,multiShot:e.videoMultiShot,shotType:e.videoShotType,generateAudio:e.videoGenerateAudio,characterOrientation:e.videoCharacterOrientation,watermark:e.videoWatermark,references:[(f={...l,referenceImages:s,firstFrame:o,lastFrame:r}).firstFrame?i2(f.firstFrame):null,f.lastFrame?i2(f.lastFrame):null,...f.referenceImages.map(i2).filter(e=>!!e),...f.referenceVideos.map(e=>e.storageKey||e.url).filter(e=>!!e),...(f.referenceAudios||[]).map(e=>e.storageKey||e.url).filter(e=>!!e)].filter(e=>!!e),firstFrameNodeId:n?.metadata?.firstFrameNodeId,lastFrameNodeId:n?.metadata?.lastFrameNodeId,klingImageNodeIds:n?.metadata?.klingImageNodeIds,klingMultiPrompt:n?.metadata?.klingMultiPrompt,klingElementList:n?.metadata?.klingElementList,startedAt:h,progress:0,videoTaskId:x}};g=[p],eh(e=>m?e.map(e=>e.id===t?{...e,...y}:e):[...e.map(e=>e.id===t?{...e,metadata:{...e.metadata,status:i_}}:e),y]),m||eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:t,toNodeId:p}]);let b=await (0,L.rs)(e,u,{references:s,firstFrame:o,lastFrame:r,videoReferences:l.referenceVideos,audioReferences:l.referenceAudios},void 0,{clientTaskId:x,source:"canvas",sourceId:p});eh(t=>i9(t,p,b.task,e,h,d)),Y.useWalletStore.getState().triggerWalletSync();return}if("audio"===a){let a=i1(i,n?.metadata,l.referenceAudios),o=eT[ev.p.Audio],r=n?.type===ev.p.Audio&&!n.metadata?.content,s=r?t:(0,K.Ak)(),d=`client_audio_task_${s}`,u=n?.position||{x:0,y:0},m={id:s,type:ev.p.Audio,title:c.slice(0,32)||"Generated Audio",position:r?n.position:{x:u.x+(n?.width||o.width)+96,y:u.y+((n?.height||o.height)-o.height)/2},width:r?n.width:o.width,height:r?n.height:o.height,metadata:{prompt:c,status:iM,startedAt:h,progress:0,audioTaskId:d,...i0(i,n?.metadata)}};g=[s],eh(e=>r?e.map(e=>e.id===t?{...e,...m}:e):[...e.map(e=>e.id===t?{...e,metadata:{...e.metadata,status:i_}}:e),m]),r||eC(e=>[...e,{id:(0,K.Ak)(),fromNodeId:t,toNodeId:s}]);let p=await (0,$.O_)(i,c,{nodeId:s,sourceId:e,clientTaskId:d},a);eh(e=>rn(e,s,p,h)),Y.useWalletStore.getState().triggerWalletSync();return}let r="",m=n?.type===ev.p.Config,p=m?i8(i.count):1,x=eT[m?ev.p.Config:ev.p.Text],v=eT[ev.p.Text],y=n?.position||{x:0,y:0},b=m||s?Array.from({length:p},()=>(0,K.Ak)()):[];if(g=b,m||s){let e=b.map((e,t)=>({id:e,type:ev.p.Text,title:c.slice(0,32)||"Generated Text",position:{x:y.x+x.width+96,y:y.y+x.height/2-v.height/2+(t-(p-1)/2)*(v.height+36)},width:v.width,height:v.height,metadata:{prompt:c,status:iM,fontSize:14}}));eh(a=>[...a.map(e=>e.id===t&&m?{...e,metadata:{...e.metadata,prompt:c,status:iM,errorDetails:void 0}}:e),...e]),eC(e=>[...e,...b.map(e=>({id:(0,K.Ak)(),fromNodeId:t,toNodeId:e}))])}let w=await Promise.all((b.length?b:[t]).map(e=>{let t="";return(0,R.bC)(i,oM({...l,prompt:c}),a=>{t=a,r=a,eh(t=>t.map(t=>t.id===e?{...t,type:ev.p.Text,metadata:{...t.metadata,content:a,status:iM}}:t))}).then(a=>({nodeId:e,content:a||t}))})),k=new Map(w.map(e=>[e.nodeId,e.content]));eh(e=>e.map(e=>b.includes(e.id)?{...e,metadata:{...e.metadata,content:k.get(e.id)||r,status:i_}}:e.id===t&&m?{...e,metadata:{...e.metadata,status:i_}}:e.id!==t||s?e:{...e,type:ev.p.Text,title:o.slice(0,32)||"Generated Text",metadata:{...e.metadata,content:k.get(e.id)||r,status:i_}}))}catch(a){let e=a instanceof Error?a.message:"生成失败";d.error(e),eh(a=>a.map(a=>(a.id===t||g.includes(a.id))&&(a.id!==t||m)?{...a,metadata:{...a.metadata,status:iT,errorDetails:e}}:a))}finally{td(null),Y.useWalletStore.getState().triggerWalletSync()}},[z,B]),nR=(0,n.useCallback)(t=>{var a;let o,n,i,r,s,l,d;return n=new Set([...o=Array.from((a={projectId:e,projectTitle:eu?.title||"未命名画布",nodes:aw.current,connections:aj.current,selectedNodeIds:aC.current,config:ab,autoGenerateMedia:ay.autoGenerateMedia,agentState:t}).selectedNodeIds),...a.agentState.approvedNodeIds,...a.agentState.referenceNodeIds]),a.connections.forEach(e=>{(n.has(e.fromNodeId)||n.has(e.toNodeId))&&(n.add(e.fromNodeId),n.add(e.toNodeId))}),a.nodes.forEach(e=>{(e.metadata?.status==="loading"||e.metadata?.status==="error")&&n.add(e.id)}),r=new Set((i=[...a.nodes.filter(e=>n.has(e.id)),...a.nodes.filter(e=>!n.has(e.id))].slice(0,120)).map(e=>e.id)),s=a.config.videoModel||a.config.model,l=a.config.audioModel,d=(0,eA.DW)({...a.config,model:l},l),{project:{id:a.projectId,title:a.projectTitle,nodeCount:a.nodes.length,connectionCount:a.connections.length},agentState:a.agentState,selectedNodeIds:o,nodes:i.map(t4),connections:a.connections.filter(e=>r.has(e.fromNodeId)&&r.has(e.toNodeId)),generation:{autoGenerateMedia:a.autoGenerateMedia,textModel:a.config.textModel||a.config.model,imageModel:a.config.imageModel||a.config.model,videoModel:s,audioModel:l,imageQuality:a.config.quality,imageSize:a.config.size,videoQuality:a.config.vquality,videoSize:a.config.videoSize,imageCount:a.config.canvasImageCount||a.config.count,videoSeconds:a.config.videoSeconds,videoGenerateAudio:a.config.videoGenerateAudio,videoSupportsAudio:(0,eN.oD)(s),audioVoice:(0,eM.MP)(l)&&(0,eM.Uh)({...a.config,model:l},l)?a.config.geminiTtsVoice:(0,eS.vI)(l)?a.config.glmTtsVoice:d?a.config.grokTtsVoice:a.config.audioVoice,audioLanguage:d?a.config.grokTtsLanguage:"",audioFormat:(0,eS.vI)(l)?a.config.glmTtsFormat:d?a.config.grokTtsFormat:a.config.audioFormat,audioSpeed:(0,eS.vI)(l)?a.config.glmTtsSpeed:d?a.config.grokTtsSpeed:a.config.audioSpeed},tasks:i.flatMap(e=>{let t=t3(e);return t?[{nodeId:e.id,type:e.type,status:e.metadata?.status||"idle",taskId:t,progress:e.metadata?.progress,error:e.metadata?.errorDetails}]:[]})}},[ab,eu?.title,e,ay.autoGenerateMedia]),n$=(0,n.useCallback)(async(t,a)=>{let o=t.arguments,n=e=>"string"==typeof o[e]?o[e].trim():"",i=e=>Array.isArray(o[e])?[...new Set(o[e].filter(e=>"string"==typeof e).map(e=>e.trim()).filter(Boolean))]:[],r=e=>aw.current.find(t=>t.id===e),s=e=>({ok:!1,code:"node_not_found",message:"找不到节点 "+e}),l=e=>e.find(e=>!r(e))||"",d=e=>{let t=new Set([e]);aC.current=t,eJ(t),e1(null)},c=e=>{aw.current=e,eh(e)},u=e=>{aj.current=e,eC(e)},m=(e,t,a)=>{let o=a?{...ez[e],...a}:ez[e],n=aw.current.filter(e=>e.type!==ev.p.Group&&e.type!==ev.p.Config&&e.type!==ev.p.Director&&!e.metadata?.groupId&&!e.metadata?.excludeUpstreamText),i=t.length?t:n,r=i.length?i.reduce((e,t)=>t.position.x+t.width>e.position.x+e.width?t:e):null,s=aK(),l=r?r.position.x+r.width+96+o.width/2:s.x,d=r?r.position.y+o.height/2:s.y,c=(e,t)=>{let a=e-o.width/2,n=e+o.width/2,i=t-o.height/2,r=t+o.height/2;return aw.current.some(e=>a<e.position.x+e.width+72&&n+72>e.position.x&&i<e.position.y+e.height+72&&r+72>e.position.y)},u=Math.max(30,(aw.current.length+1)*6);for(let e=0;e<u;e+=1){let t=l+e%3*(o.width+72),a=d+Math.floor(e/3)*(o.height+72);if(!c(t,a))return{x:t,y:a}}return{x:l,y:Math.max(s.y,...aw.current.map(e=>e.position.y+e.height+72+o.height/2))}},p="generate_image"===t.name||"edit_image"===t.name||"generate_video"===t.name||"generate_audio"===t.name||"create_text_node"===t.name||"update_text_node"===t.name||"update_node"===t.name||"delete_node"===t.name||"create_connection"===t.name||"delete_connection"===t.name||"create_group"===t.name||"arrange_nodes"===t.name,g=iS.useCanvasStore.getState().projects.find(t=>t.id===e)?.autoTitlePending===!0;g&&"create_primary_script_node"!==t.name&&p&&en(e,{autoTitlePending:!1});try{if("set_agent_state"===t.name){let e=[...i("approvedNodeIds"),...i("referenceNodeIds")],t=l(e);return t?s(t):{ok:!0}}if("get_canvas_summary"===t.name)return{ok:!0,project:{id:e,title:eu?.title||"未命名画布"},selectedNodeIds:Array.from(aC.current),nodes:aw.current.slice(0,120).map(rs),connections:aj.current.slice(0,240)};if("get_selected_nodes"===t.name)return{ok:!0,nodes:aw.current.filter(e=>aC.current.has(e.id)).map(rs)};if("query_canvas_nodes"===t.name){let e=n("nodeId"),t=n("keyword").toLowerCase(),a=n("type"),i=Math.max(1,Math.floor(Number(o.page)||1)),r=Math.max(1,Math.min(50,Math.floor(Number(o.pageSize)||20))),s=aw.current.filter(o=>{if(e&&o.id!==e||a&&o.type!==a)return!1;if(!t)return!0;let n=(0,ec.IM)(o.type)||o.type===ev.p.Video||o.type===ev.p.Audio?"":o.metadata?.content||"";return`${o.title} ${n} ${o.metadata?.prompt||""}`.toLowerCase().includes(t)});return{ok:!0,items:s.slice((i-1)*r,i*r).map(e=>({id:e.id,type:e.type,title:e.title,status:e.metadata?.status,groupId:e.metadata?.groupId})),total:s.length,page:i,pageSize:r}}if("get_generation_config"===t.name){let e=ab.videoModel||ab.model,t=ab.audioModel,a=(0,eA.DW)({...ab,model:t},t);return{ok:!0,models:{text:ab.textModel||ab.model,image:ab.imageModel||ab.model,video:e,audio:ab.audioModel},imageQuality:ab.quality,imageSize:ab.size,videoQuality:ab.vquality,videoSize:ab.videoSize,autoGenerateMedia:ay.autoGenerateMedia,imageCount:1,videoSeconds:ab.videoSeconds,videoGenerateAudio:ab.videoGenerateAudio,videoSupportsAudio:(0,eN.oD)(e),videoDuration:rd(e),audioVoice:(0,eM.MP)(t)&&(0,eM.Uh)({...ab,model:t},t)?ab.geminiTtsVoice:(0,eS.vI)(t)?ab.glmTtsVoice:a?ab.grokTtsVoice:ab.audioVoice,audioLanguage:a?ab.grokTtsLanguage:"",audioFormat:(0,eS.vI)(t)?ab.glmTtsFormat:a?ab.grokTtsFormat:ab.audioFormat,audioSpeed:(0,eS.vI)(t)?ab.glmTtsSpeed:a?ab.grokTtsSpeed:ab.audioSpeed}}if("get_node"===t.name){let e=n("nodeId"),t=r(e);return t?{ok:!0,node:rs(t)}:s(e)}if("get_upstream_nodes"===t.name||"get_downstream_nodes"===t.name||"get_connected_nodes"===t.name){let e=n("nodeId");if(!r(e))return s(e);let a=aj.current.filter(t=>t.toNodeId===e).map(e=>e.fromNodeId),o=aj.current.filter(t=>t.fromNodeId===e).map(e=>e.toNodeId),i=aw.current.filter(e=>a.includes(e.id)).map(rs),l=aw.current.filter(e=>o.includes(e.id)).map(rs);if("get_upstream_nodes"===t.name)return{ok:!0,nodes:i};if("get_downstream_nodes"===t.name)return{ok:!0,nodes:l};return{ok:!0,upstream:i,downstream:l}}if("get_generation_task"===t.name||"get_media_task_status"===t.name){let e=n("nodeId"),t=r(e);if(!t)return s(e);if(![ev.p.Image,ev.p.Panorama,ev.p.Video,ev.p.Audio].includes(t.type))return{ok:!1,code:"not_media_node",message:"节点 "+e+" 不是媒体节点"};return{ok:!0,...rl(t)}}if("create_primary_script_node"===t.name||"create_text_node"===t.name){let a=i("sourceNodeIds"),o=l(a);if(o)return s(o);let p=a.map(e=>r(e)),h=n("content"),f="create_primary_script_node"===t.name?iz:void 0,x=m(ev.p.Text,p,f),v=iR(ev.p.Text,x,{content:h,prompt:h,status:i_});f&&(v.position={x:x.x-f.width/2,y:x.y-f.height/2},v.width=f.width,v.height=f.height),v.title=n("title")||h.slice(0,32)||"文本";let y=a.map(e=>({id:(0,K.Ak)(),fromNodeId:e,toNodeId:v.id}));c([...aw.current,v]),u([...aj.current,...y]),d(v.id);let b=n("projectTitle");return"create_primary_script_node"===t.name&&g&&ei(e,b),{ok:!0,nodeId:v.id,connectionIds:y.map(e=>e.id),node:rs(v)}}if("update_text_node"===t.name){let e=n("nodeId"),t=r(e);if(!t)return s(e);if(t.type!==ev.p.Text)return{ok:!1,code:"invalid_node_type",message:"只能用 update_text_node 修改文本节点"};let a=n("title"),o=n("content"),i=aw.current.map(t=>t.id===e?{...t,title:a||t.title,metadata:o?{...t.metadata,content:o,prompt:o,status:i_,errorDetails:void 0}:t.metadata}:t);return c(i),{ok:!0,nodeId:e,node:rs(i.find(t=>t.id===e))}}if("update_node"===t.name){let e=n("nodeId");if(!r(e))return s(e);let t=aw.current.map(t=>t.id===e?{...t,title:n("title")||t.title}:t);return c(t),{ok:!0,nodeId:e,node:rs(t.find(t=>t.id===e))}}if("delete_node"===t.name){let e=n("nodeId");if(!r(e))return s(e);let t=aw.current.map(e=>e.id);ow(new Set([e]));let a=new Set(aw.current.map(e=>e.id));return{ok:!0,deletedNodeIds:t.filter(e=>!a.has(e))}}if("create_connection"===t.name){let e=n("fromNodeId"),t=n("toNodeId"),a=r(e),o=r(t);if(!a)return s(e);if(!o)return s(t);if(e===t)return{ok:!1,code:"self_connection",message:"节点不能连接到自身"};if(a.type===ev.p.Config&&o.type===ev.p.Config)return{ok:!1,code:"invalid_connection",message:"配置节点之间不能连接"};let i=aj.current.find(a=>a.fromNodeId===e&&a.toNodeId===t);if(i)return{ok:!0,connectionId:i.id,alreadyExists:!0};let l={id:(0,K.Ak)(),fromNodeId:e,toNodeId:t};return u([...aj.current,l]),{ok:!0,connectionId:l.id}}if("delete_connection"===t.name){let e=n("connectionId");if(!aj.current.some(t=>t.id===e))return{ok:!1,code:"connection_not_found",message:"找不到连线 "+e};return ok(e),{ok:!0,deletedConnectionId:e}}if("create_group"===t.name){let e=i("nodeIds"),t=l(e);if(t)return s(t);let a=oT(e);if(!a)return{ok:!1,code:"invalid_group",message:"分组至少需要两个未分组的普通节点"};let o=n("title");if(o){let e=aw.current.map(e=>e.id===a?{...e,title:o}:e);c(e)}return{ok:!0,groupId:a,nodeIds:e}}if("arrange_nodes"===t.name){let e=i("nodeIds"),t=l(e);if(t)return s(t);let a=e.length?e.map(e=>r(e)):aw.current.filter(e=>!e.metadata?.groupId&&!e.metadata?.batchRootId);if(!a.length)return{ok:!0,arrangedNodeIds:[]};let o=Math.min(...a.map(e=>e.position.x)),n=Math.min(...a.map(e=>e.position.y)),d=new Map,u=o,m=n,p=0;a.forEach((e,t)=>{t>0&&t%4==0&&(u=o,m+=p+72,p=0),d.set(e.id,{x:u,y:m}),u+=e.width+72,p=Math.max(p,e.height)}),a.filter(e=>e.type===ev.p.Group).forEach(e=>{let t=d.get(e.id);if(!t)return;let a=t.x-e.position.x,o=t.y-e.position.y;aw.current.filter(t=>t.metadata?.groupId===e.id&&!d.has(t.id)).forEach(e=>d.set(e.id,{x:e.position.x+a,y:e.position.y+o}))});let g=aw.current.map(e=>d.has(e.id)?{...e,position:d.get(e.id)}:e);return c(g),{ok:!0,arrangedNodeIds:a.map(e=>e.id)}}if("generate_image"===t.name||"edit_image"===t.name||"generate_video"===t.name||"generate_audio"===t.name){let e="generate_video"===t.name?"video":"generate_audio"===t.name?"audio":"image",p="video"===e?ev.p.Video:"audio"===e?ev.p.Audio:ev.p.Image,g=Object.prototype.hasOwnProperty.call(o,"sourceNodeIds")?i("sourceNodeIds"):a,h=l(g);if(h)return s(h);let f=g.map(e=>r(e));if("edit_image"===t.name&&!f.some(e=>(0,ec.IM)(e.type)&&!!e.metadata?.content))return{ok:!1,code:"image_reference_required",message:"图片编辑需要至少一个已有内容的图片节点"};let x=n("model"),v="video"===e?f.find(e=>e.type===ev.p.Video)?.metadata?.model:void 0,y="image"===e?f.find(e=>(0,ec.IM)(e.type))?.metadata?.model:void 0,b=x||v||y,w={...rm(ab,void 0,e),...b?{model:b,..."video"===e?{videoModel:b}:{},..."image"===e?{imageModel:b}:{}}:{}};if(!w.model||!P(w,w.model))return{ok:!1,code:"model_not_configured",message:"请先在全局配置中完成"+("video"===e?"视频":"audio"===e?"音频":"图片")+"模型配置"};let k=n("prompt"),j={prompt:k,excludeUpstreamText:!0,status:"idle",model:w.model,channelId:"video"===e?w.videoChannelId:"audio"===e?w.audioChannelId:w.imageChannelId,size:n("size")||w.size};if("image"===e&&(j.quality=w.quality,j.count="number"==typeof o.count?Math.max(1,Math.floor(o.count)):1),"video"===e){j.vquality=w.vquality;let e="number"==typeof o.seconds?o.seconds:Number(w.videoSeconds),t=function(e,t){if(!Number.isFinite(t))return"视频时长无效，请先向用户确认单镜头时长";let a=(0,eN.B0)(e);return(0,eN.Rf)(a)&&5!==t&&10!==t?"当前 CogVideoX-3 模型仅支持 5 或 10 秒":a.includes("seedance")&&-1!==t&&(t<4||t>15)?"当前 Seedance 模型仅支持智能时长或 4-15 秒":rc(a)&&(t<3||t>15)?"当前 Kling 3 模型仅支持 3-15 秒":ru(a)&&5!==t&&10!==t?"当前 Kling 2.6 模型仅支持 5 或 10 秒":!a.includes("seedance")&&!a.includes("kling")&&(t<1||t>30)?"当前视频模型仅支持 1-30 秒":""}(w.model,e);if(t)return{ok:!1,code:"unsupported_duration",message:t,supported:rd(w.model)};let a="boolean"==typeof o.generateAudio?o.generateAudio:"true"===w.videoGenerateAudio;if(a&&!(0,eN.oD)(w.model))return{ok:!1,code:"video_audio_not_supported",message:"当前全局视频模型不支持视频原生声音"};j.seconds=String(e),j.generateAudio=String(a)}"audio"===e&&((0,eM.MP)(w.model)&&(0,eM.Uh)(w,w.model)?j.geminiTtsVoice=n("voice")||w.geminiTtsVoice:(0,eS.vI)(w.model)?(j.glmTtsVoice=n("voice")||w.glmTtsVoice,j.glmTtsFormat=w.glmTtsFormat,j.glmTtsSpeed=w.glmTtsSpeed):(0,eA.DW)(w,w.model)?(j.grokTtsVoice=n("voice")||w.grokTtsVoice,j.grokTtsLanguage=w.grokTtsLanguage,j.grokTtsFormat=w.grokTtsFormat,j.grokTtsSpeed=w.grokTtsSpeed):(j.audioVoice=n("voice")||w.audioVoice,j.audioInstructions=n("instructions")||w.audioInstructions));let C="image"===e?[]:"video"===e?aw.current.filter(e=>!e.metadata?.groupId&&(e.type===ev.p.Text||(0,ec.IM)(e.type)||e.type===ev.p.Group)):f,N=iR(p,m(p,C),j);N.title=n("title")||k.slice(0,32)||("video"===e?"视频":"audio"===e?"音频":"图片");let I=g.map(e=>({id:(0,K.Ak)(),fromNodeId:e,toNodeId:N.id}));if(c([...aw.current,N]),u([...aj.current,...I]),d(N.id),!ay.autoGenerateMedia)return{ok:!0,message:"媒体节点已创建并完成参数配置，尚未提交生成",submitted:!1,nodeId:N.id,createdNodeIds:[N.id],connectionIds:I.map(e=>e.id),type:N.type,status:"idle"};await nD(N.id,e,k),await new Promise(e=>setTimeout(e,0));let S=r(N.id)||N,A=[N.id,...aj.current.filter(e=>e.fromNodeId===N.id).map(e=>e.toNodeId)].filter((e,t,a)=>a.indexOf(e)===t&&!!r(e)),M=rl(S);if(S.metadata?.status===iT)return{ok:!1,code:"generation_failed",message:S.metadata.errorDetails||"生成失败",nodeId:N.id,createdNodeIds:A,connectionIds:I.map(e=>e.id),...M};return{ok:!0,submitted:!0,nodeId:N.id,createdNodeIds:A,connectionIds:I.map(e=>e.id),...M}}if("create_video_montage"===t.name){let t=i("videoNodeIds"),a=[];if(t.length>0)a=t.map(e=>r(e)).filter(e=>!!(e&&e.type===ev.p.Video&&e.metadata?.content));else{let e=Array.from(aC.current).map(e=>r(e)).filter(e=>!!(e&&e.type===ev.p.Video&&e.metadata?.content));a=(0,eP.k)(e,aj.current)}if(!a.length)return{ok:!1,code:"no_valid_video_nodes",message:"未在画布中找到已生成完成的有效视频镜头，请确认指定或选中的节点已生成视频内容"};let o=n("title")||`${eu?.title||"画布"} 视频剪辑成片`,s=n("aspectRatio"),l=a.map(e=>e.id).join(","),d=`/editor?projectId=${encodeURIComponent(e)}&batchNodes=${l}&title=${encodeURIComponent(o)}`;s&&["16:9","9:16","1:1","4:3"].includes(s)&&(d+=`&aspectRatio=${encodeURIComponent(s)}`),eJ(new Set(a.map(e=>e.id)));let c=!1;try{let e=window.open(d,"_blank");e&&!e.closed&&(c=!0)}catch{c=!1}let u=c?"已自动在新窗口打开剪辑台":"若浏览器拦截了新标签页弹窗，可直接点击剪辑台链接进入";return{ok:!0,message:`已为您自动将 ${a.length} 个视频镜头按时间顺序编排进多轨视频剪辑台（${u}），已准备就绪供您剪辑、调速调音、加对白字幕与极速导出。`,editorUrl:d,windowOpened:c,aspectRatio:s||"16:9",clipCount:a.length,clips:a.map(e=>({id:e.id,title:e.title||"视频分镜"}))}}return{ok:!1,code:"unsupported_tool",message:"未实现工具 "+t.name}}catch(e){return{ok:!1,code:"tool_error",message:e instanceof Error?e.message:"画布工具执行失败"}}},[ab,oT,eu?.title,ok,ow,aK,nD,P,e,ei,ay.autoGenerateMedia,en]),nL=(0,n.useCallback)(async t=>{var a;if(!Y.useWalletStore.getState().checkBalanceOrIntercept(()=>{d.warning("当前账户算力余额不足，请先充值算力后再重试")}))return;let o=function(e,t,a){let o=a.filter(t=>t.toNodeId===e).map(e=>e.fromNodeId),n=new Set;for(;o.length;){let e=o.shift();if(n.has(e))continue;n.add(e);let i=t.find(t=>t.id===e);if(i?.type===ev.p.Config)return i;a.filter(t=>t.toNodeId===e).forEach(e=>o.push(e.fromNodeId))}return null}(t.id,aw.current,aj.current)||t,n=(0,ec.sK)(t.type),i=t.metadata?.batchRootId?aw.current.find(e=>e.id===t.metadata?.batchRootId):null,r=(0,ec.IM)(t.type)?{...i?.metadata,...t.metadata}:void 0,s=!!r?.generationType,l=s&&r?{...z,model:r.model||z.imageModel||z.model,imageChannelId:r.channelId||z.imageChannelId,activeChannelId:r.channelId||z.imageChannelId,quality:r.quality||z.quality,size:n?ec.A9:r.size||z.size,count:"1"}:{...rm(z,o,t.type===ev.p.Text?"text":t.type===ev.p.Video?"video":t.type===ev.p.Audio?"audio":"image"),count:"1"},c=t.metadata?.model?.trim(),u={...l,...c?{model:c,...t.type===ev.p.Video?{videoModel:c}:{},...(0,ec.IM)(t.type)?{imageModel:c}:{},...t.type===ev.p.Audio?{audioModel:c}:{},...t.type===ev.p.Text?{textModel:c}:{}}:{}};if(!P(u,u.model))return void B(!0);let m=s?null:await o_(oI(o.id,aw.current,aj.current,o.metadata?.prompt||t.metadata?.prompt||"")),p=(n?r?.panoramaFinalPrompt||"":r?.prompt||m?.prompt||"").trim(),g=n?p:ex(p,r?.cameraControl||t.metadata?.cameraControl);if(!p)return void d.warning("找不到提示词，无法重试");let h=r?.generationType,f=h?"edit"===h:!!m?.referenceImages.length,x=s&&r?await i4(r):f?m?.referenceImages.length?m.referenceImages:(a=i||o)&&(0,ec.IM)(a.type)&&a.metadata?.content?[{id:a.id,name:`image-${a.id}.png`,type:a.metadata.mimeType||"image/png",dataUrl:a.metadata.content,storageKey:a.metadata.storageKey}]:[]:[];if(f&&!x){d.error("参考图片已丢失，无法继续重试"),eh(e=>e.map(e=>e.id===t.id?{...e,metadata:{...e.metadata,status:iT,errorDetails:"参考图片已丢失，无法继续重试"}}:e));return}let v=x||[];td(t.id);let y=Date.now(),b=t.type===ev.p.Video?`client_video_task_${t.id}`:"",w=(0,ec.IM)(t.type)?`client_image_task_${t.id}`:"",k=t.type===ev.p.Audio?`client_audio_task_${t.id}`:"";eh(e=>e.map(e=>e.id===t.id?{...e,metadata:{...e.metadata,model:u.model,status:iM,errorDetails:void 0,content:void 0,storageKey:"",progress:0,startedAt:y,...e.type===ev.p.Video?{videoTaskId:b,videoTaskVideoId:void 0}:{},...(0,ec.IM)(e.type)?{imageTaskId:w,imageTaskResultId:void 0}:{},...e.type===ev.p.Audio?{audioTaskId:k,audioTaskResultId:void 0}:{}}}:e));try{if(t.type===ev.p.Text){if(!m)return;let e="",a=await (0,R.bC)(u,oM({...m,prompt:p}),a=>{e=a,eh(e=>e.map(e=>e.id===t.id?{...e,type:ev.p.Text,metadata:{...e.metadata,content:a,status:iM}}:e))});eh(o=>o.map(o=>o.id===t.id?{...o,type:ev.p.Text,metadata:{...o.metadata,content:a||e,prompt:p,status:i_}}:o));return}if(t.type===ev.p.Video){let e=m?i5(u,m):u,a=(0,eN.TQ)(e.model,(0,F.channelProtocolForConfig)(e)),o=a&&m?.firstFrame||null,n=a&&m?.lastFrame||null,i=a?v:[...v,...[m?.firstFrame,m?.lastFrame].filter(e=>!!e)],r=await (0,L.rs)(e,g,{references:i,firstFrame:o,lastFrame:n,videoReferences:m?.referenceVideos||[],audioReferences:m?.referenceAudios||[]},void 0,{clientTaskId:b,source:"canvas",sourceId:t.id});eh(a=>i9(a,t.id,r.task,e,y,{width:t.width,height:t.height})),Y.useWalletStore.getState().triggerWalletSync();return}if(t.type===ev.p.Audio){let a=i1(u,o?.metadata,m?.referenceAudios||[]),n=await (0,$.O_)(u,p,{nodeId:t.id,sourceId:e,clientTaskId:k},a);eh(e=>rn(e.map(e=>e.id===t.id?{...e,metadata:{...e.metadata,prompt:p,...i0(u,o?.metadata)}}:e),t.id,n,y)),Y.useWalletStore.getState().triggerWalletSync();return}let a=await (0,R.vE)({...u,quality:n&&"auto"===u.quality?"medium":u.quality},g,f?v:[],{nodeId:t.id,sourceId:e,clientTaskId:w}),i=r?.generationType?{generationType:r.generationType,model:u.model,channelId:u.imageChannelId||u.activeChannelId,size:u.size,quality:u.quality,count:r.count||1,references:r.references}:iZ(f?"edit":"generation",u,1,v);eh(e=>{let o=e.map(e=>e.id===t.id?{...e,type:(0,ec.sK)(e.type)?ev.p.Panorama:ev.p.Image,metadata:{...e.metadata,...(0,ec.sK)(e.type)?{prompt:e.metadata?.panoramaSourcePrompt||e.metadata?.prompt||"",panoramaSourcePrompt:e.metadata?.panoramaSourcePrompt||e.metadata?.prompt||"",panoramaFinalPrompt:p,panoramaProjection:void 0}:{prompt:p},...i,imageTaskId:a.id,imageTaskResultId:void 0,startedAt:rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||y,progress:a.progress||0,errorDetails:void 0}}:e);return a.image_url||a.url?ra(o,t.id,a,y,{width:t.width,height:t.height}):o}),(a.image_url||a.url)&&eC(e=>ro(e,t.id,a))}catch(a){let e=a instanceof Error?a.message:"生成失败";d.error(e),eh(a=>a.map(a=>a.id===t.id?{...a,metadata:{...a.metadata,status:iT,errorDetails:e}}:a))}finally{td(null)}},[z,d,B,e]),nF=(0,n.useCallback)(e=>{let t=(e.metadata?.content||e.metadata?.prompt||"").trim();if(!t)return void d.warning("文本节点为空，无法生图");let a=aw.current.find(t=>t.id===e.id);if(!a)return;let o=ez[ev.p.Config],n=iR(ev.p.Config,{x:a.position.x+a.width+96+o.width/2,y:a.position.y+a.height/2},{prompt:"",model:z.imageModel||z.model,size:z.size,count:i8(z.canvasImageCount||z.count)}),i={id:(0,K.Ak)(),fromNodeId:a.id,toNodeId:n.id},r=aw.current.map(e=>e.id===a.id?{...e,metadata:{...e.metadata,content:t,prompt:t,status:i_}}:e).concat(n),s=[...aj.current,i];aw.current=r,aj.current=s,eh(r),eC(s),eJ(new Set([n.id])),e1(null),tR(n.id)},[z.canvasImageCount,z.count,z.imageModel,z.model,z.size,d]),nV=(0,n.useCallback)(async(e,t,a)=>{let o={url:e.dataUrl,storageKey:e.storageKey||"",width:1,height:1,bytes:0,mimeType:"image/png"},n=1===o.width&&1===o.height?await (0,W.xL)(o.url):o,i=er(n.width,n.height),r=t||aU((u.current?.getBoundingClientRect().left||0)+eH.width/2,(u.current?.getBoundingClientRect().top||0)+eH.height/2),s=a||`image-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,l={id:s,type:ev.p.Image,title:e.prompt.slice(0,32)||"Generated Image",position:{x:r.x-i.width/2,y:r.y-i.height/2},width:i.width,height:i.height,metadata:{...iH({...o,width:n.width,height:n.height}),prompt:e.prompt}};eh(e=>[...e,l]),eJ(new Set([s])),e1(null),tR(s)},[aU,eH.height,eH.width]),nU=(0,n.useRef)(nI);(0,n.useLayoutEffect)(()=>{nU.current=nI}),(0,n.useEffect)(()=>{if(!tM||ak.current===e)return;let t=iS.useCanvasStore.getState().projects.find(t=>t.id===e)?.pendingAgentRequest;t&&(ak.current=e,(async()=>{let a=aK(),o=[];for(let[e,n]of t.assets.entries()){let i=n.payload;if("image"===i.kind&&i.storageKey){let e=await (0,V.resolveImageUrl)(i.storageKey,i.dataUrl);i={...i,dataUrl:e}}else if(("video"===i.kind||"audio"===i.kind)&&i.storageKey){let e=await (0,U.aN)(i.storageKey,i.url);i={...i,url:e}}let r={x:a.x+(e-(t.assets.length-1)/2)*360,y:a.y};await nU.current(i,r,n.nodeId),o.push("image"===i.kind?{...n.reference,dataUrl:i.dataUrl}:"video"===i.kind||"audio"===i.kind?{...n.reference,url:i.url}:n.reference)}en(e,{pendingAgentRequest:void 0}),eW({prompt:t.prompt,references:o})})().catch(e=>{ak.current=null,d.error(e instanceof Error?e.message:"首页素材插入失败")}))},[aK,d,e,tM,en]);let nK=(0,n.useCallback)(e=>{let t=p.current||void 0;p.current=null,nU.current(e,t),tC(!1)},[]),nW=(0,n.useCallback)(e=>{let t=aw.current.find(t=>t.id===e);if(!t)return;let a=t.metadata?.batchRootId;a&&!aw.current.find(e=>e.id===a)?.metadata?.imageBatchExpanded&&o9(a);let o=t.position.x+t.width/2,n=t.position.y+t.height/2,i=Math.min(Math.max(Math.min(.6*eH.width/t.width,.6*eH.height/t.height),.05),1),r={x:eH.width/2-o*i,y:eH.height/2-n*i,k:i};eJ(new Set([t.id])),e1(null),ti(null),j.current&&cancelAnimationFrame(j.current);let s={...aN.current},l=null,d=e=>{l||(l=e);let t=Math.min(1,(e-l)/450),a=1-Math.pow(1-t,3),o={x:s.x+(r.x-s.x)*a,y:s.y+(r.y-s.y)*a,k:s.k+(r.k-s.k)*a};aN.current=o,eB(o),j.current=t<1?requestAnimationFrame(d):null};j.current=requestAnimationFrame(d)},[eH.height,eH.width,o9]);return((0,n.useEffect)(()=>()=>{j.current&&cancelAnimationFrame(j.current)},[]),tM)?(0,o.jsxs)("main",{className:"flex h-full min-h-0 overflow-hidden",style:{background:ep.canvas.background,color:ep.node.text},onPointerDownCapture:e=>{let t=document.querySelector("[data-canvas-agent-panel]"),a=window.getSelection();a?.toString()&&t?.contains(a.anchorNode)&&!t.contains(e.target)&&a.removeAllRanges()},children:[(0,o.jsx)(im,{nodes:eg,selectedNodeIds:eY,open:tf.open,width:tf.width,onWidthChange:e=>tv(t=>({...t,width:e})),onFocusNode:nW,onAssetDragStart:e=>{g.current=e},onAssetDragEnd:()=>{window.setTimeout(()=>{g.current=null},0)},onInsertAsset:nK}),(0,o.jsxs)("section",{className:"relative min-w-0 flex-1 overflow-hidden",children:[(0,o.jsx)(iO,{title:eu?.title||"未命名画布",sidePanelOpen:tf.open,onToggleSidePanel:()=>tv(e=>({...e,open:!e.open})),titleDraft:ao,isTitleEditing:at,onTitleDraftChange:an,onStartTitleEditing:nz,onFinishTitleEditing:nP,onCancelTitleEditing:()=>aa(!1),canUndo:ai.canUndo,canRedo:ai.canRedo,onHome:()=>c.push("/"),onProjects:()=>c.push("/canvas"),onCreateProject:oF,onDeleteProject:oV,onImportImage:()=>nC(),onUndo:o$,onRedo:oL,assistantCollapsed:!t8.open,onExpandAssistant:()=>{ae(!0),t7(e=>({...e,open:!0}))}}),(0,o.jsxs)(o6,{containerRef:u,viewport:eO,tool:eq,backgroundMode:tm,onViewportChange:e=>{eB(e),ti(null)},onCanvasMouseDown:e=>{ah||oU(e)},onCanvasDeselect:ah?void 0:oC,onCanvasDoubleClick:e=>{ah||(ti(null),ts(aU(e.clientX,e.clientY)))},onContextMenu:nE,onDrop:nS,children:[(0,o.jsxs)("svg",{className:"absolute left-0 top-0 h-[10000px] w-[10000px] overflow-visible",style:{pointerEvents:"none",transform:"translateZ(0)",zIndex:6},children:[ef.filter(e=>{let t=aZ.get(e.fromNodeId),a=aZ.get(e.toNodeId);return!!(t&&a&&!rv(t,eg)&&!rv(a,eg))}).map(e=>{let t=aZ.get(e.fromNodeId),a=aZ.get(e.toNodeId);return t&&a?(0,o.jsx)(eE,{connection:e,from:t,to:a,active:e0===e.id||oc.connectionIds.has(e.id),onSelect:()=>{e1(e.id),eJ(new Set),tz(null),ti(null)},onContextMenu:t=>{e1(e.id),eJ(new Set),tz(null),ti({type:"connection",x:t.clientX,y:t.clientY,connectionId:e.id})}},e.id):null}),e4?(0,o.jsx)(eD,{node:aZ.get(e4.nodeId),handle:e4,mouseWorld:te,target:e6?aZ.get(e6):void 0}):null]}),aJ.map(e=>(0,o.jsx)(nl,{data:e,scale:eO.k,isSelected:eY.has(e.id),isRelated:oc.nodeIds.has(e.id),isFocusRelated:or===e.id,isConnectionTarget:e6===e.id,isConnecting:!!e4,referenceSelectionState:ah?e.id===ah?"target":of.has(e.id)||!(0,az.Qw)(e)?"disabled":"available":void 0,showPanel:tD===e.id&&!ta,batchCount:os.get(e.id)||0,groupChildCount:ol.get(e.id)||0,isGroupDropTarget:ap===e.id,batchExpanded:!!e.metadata?.imageBatchExpanded,batchClosing:!!(e.metadata?.batchRootId&&as.has(e.metadata.batchRootId)),batchOpening:ad.has(e.id),batchRecovering:as.has(e.id),batchMotion:od.get(e.id),showImageInfo:tg,mentionReferences:op.get(e.id)||[],now:e.metadata?.status===iM&&!e.metadata.content&&(e.type===ev.p.Video||(0,ec.IM)(e.type)||e.type===ev.p.Audio)?ax:void 0,renderPanel:e=>e.type===ev.p.Config?(0,o.jsx)(eF,{value:e.metadata?.composerContent??e.metadata?.prompt??"",inputs:ou.get(e.id)||[],onChange:t=>na(e.id,{composerContent:t}),onClose:()=>tR(null)}):e.type===ev.p.Director?null:(0,o.jsx)(n_,{node:e,isRunning:tl===e.id,mentionReferences:op.get(e.id)||[],connectedNodes:og.get(e.id)||[],videoFrameOptions:ox.get(e.id)||[],videoResourceOptions:ov.get(e.id)||[],onPromptChange:nt,onConfigChange:na,onGenerate:nD,onDisconnectReference:nd,onStartReferenceSelection:nc,onImageSettingsOpenChange:e=>{tE(e),e&&tz(null)}}),renderNodeContent:e=>{var t;return e.type===ev.p.Director?(0,o.jsx)(tb,{onOpen:()=>tL(e.id)}):(0,o.jsx)(tx,{node:e,isRunning:tl===e.id,inputSummary:{textCount:(t=ou.get(e.id)||[]).filter(e=>"text"===e.type).length,imageCount:t.filter(e=>"image"===e.type).length,videoCount:t.filter(e=>"video"===e.type).length,audioCount:t.filter(e=>"audio"===e.type).length},videoFrameOptions:ox.get(e.id)||[],videoResourceOptions:ov.get(e.id)||[],onConfigChange:na,onComposerToggle:()=>tR(t=>t===e.id?null:e.id),onGenerate:e=>{let t=aw.current.find(t=>t.id===e);nD(e,t?.metadata?.generationMode||"image",t?.metadata?.composerContent??t?.metadata?.prompt??"")}})},onMouseDown:oK,onHoverStart:e=>{_.current||e5(e)},onHoverEnd:e=>{e5(t=>t===e?null:t)},onConnectStart:o0,onResize:o1,onContentChange:o3,onTitleChange:o8,onToggleBatch:o9,onSetBatchPrimary:ne,onRetry:e=>void nL(e),onViewImage:e=>t6(e.id),onSelectReference:nm,onContextMenu:(e,t)=>{e.preventDefault(),e.stopPropagation(),ti({type:"node",x:e.clientX,y:e.clientY,nodeId:t})}},e.id)),ta?(0,o.jsx)("svg",{className:"pointer-events-none absolute z-[100] overflow-visible",style:{left:Math.min(ta.startWorldX,ta.currentWorldX),top:Math.min(ta.startWorldY,ta.currentWorldY),width:Math.abs(ta.currentWorldX-ta.startWorldX),height:Math.abs(ta.currentWorldY-ta.startWorldY)},children:(0,o.jsx)("rect",{width:"100%",height:"100%",fill:ep.canvas.selectionFill,stroke:ep.canvas.selectionStroke,strokeWidth:1.5/eO.k,strokeDasharray:`${10/eO.k} ${6/eO.k}`})}):null,e7?(0,o.jsx)(iF,{pending:e7,onCreate:e=>aH(e,e7),onClose:aX}):null,tr?(0,o.jsx)(iU,{position:tr,onCreate:e=>{oy(e,tr),ts(null)},onUpload:()=>{nC(void 0,tr),ts(null)},onOpenAssetLibrary:()=>{p.current=tr,ts(null),tI("library"),tC(!0)},onClose:()=>ts(null)}):null]}),ah?(0,o.jsx)("button",{type:"button",className:"absolute left-1/2 top-4 z-[90] -translate-x-1/2 rounded-full border px-4 py-2 text-sm font-medium shadow-lg backdrop-blur",style:{background:ep.toolbar.panel,borderColor:ep.toolbar.border},onClick:nu,children:"从画布选择参考 \xb7 ESC 返回输入框"}):null,oi?.type===ev.p.Director?(0,o.jsx)(ty,{nodeId:oi.id,project:oi.metadata?.directorProject,panoramas:om.get(oi.id)||[],theme:em,onClose:()=>tL(null),onProjectChange:no,onPanoramaRemoved:nn,onCapturesSent:ni,onVideoSent:nr}):null,(0,o.jsx)(o2,{node:au||tP?null:a0,viewport:eO,onKeep:aO,onLeave:aB,onInfo:e=>tV(e.id),onDecreaseFont:e=>nj(e.id,Math.max(10,(e.metadata?.fontSize||14)-2)),onIncreaseFont:e=>nj(e.id,Math.min(32,(e.metadata?.fontSize||14)+2)),onToggleDialog:e=>tR(t=>t===e.id?null:e.id),onGenerateImage:nF,onUpload:e=>nC(e.id),onDownload:ns,onSaveAsset:e=>void nf(e),onUploadMediaToCloud:e=>void ng(e),onUploadImageToCloud:e=>void nh(e),onMaskEdit:e=>{let t=rm(z,e,"image");tq(t.model),tH(t.imageChannelId||t.activeChannelId||""),tO(e.id)},onCrop:e=>tK(e.id),onSplit:e=>tY(e.id),onUpscale:e=>tQ(e.id),onSuperResolve:e=>t0(e.id),onAngle:e=>t2(e.id),onViewImage:e=>t6(e.id),onReversePrompt:nx,onRetry:e=>void nL(e),onToggleFreeResize:e=>o4(e.id),onDelete:e=>ow(new Set([e.id])),projectId:e}),(0,o.jsx)(nO,{selectedCount:eY.size,canvasTool:eq,canUndo:ai.canUndo,canRedo:ai.canRedo,backgroundMode:tm,showImageInfo:tg,onAddImage:()=>oy(ev.p.Image),onAddVideo:()=>oy(ev.p.Video),onAddAudio:()=>oy(ev.p.Audio),onAddText:()=>oy(ev.p.Text),onAddPanorama:()=>oy(ev.p.Panorama),onAddDirector:()=>oy(ev.p.Director),onAddConfig:()=>oy(ev.p.Config),onUndo:o$,onRedo:oL,onUpload:()=>nC(),onDelete:()=>ow(new Set(eY)),onClear:()=>tk(!0),onCanvasToolChange:eG,onBackgroundModeChange:tp,onShowImageInfoChange:th,onOpenAssetLibrary:()=>{tI("library"),tC(!0)},onOpenMyAssets:()=>{tI("my-assets"),tC(!0)},onOpenVideoEditor:()=>{if(!X.k.getState().user)return void X.k.getState().openLoginModal();let t=Array.from(eY).map(e=>aw.current.find(t=>t.id===e)).filter(e=>!!(e&&e.type===ev.p.Video&&e.metadata?.content)),a=(0,eP.k)(t,aj.current);if(a.length>0){let t=a.map(e=>e.id).join(",");window.open(`/editor?projectId=${encodeURIComponent(e)}&batchNodes=${t}`,"_blank")}else window.open(`/editor?projectId=${encodeURIComponent(e)}`,"_blank")}}),tc?(0,o.jsx)(o7,{nodes:eg,viewport:eO,viewportSize:eH,onViewportChange:eB}):null,(0,o.jsx)(n0,{scale:eO.k,onScaleChange:oD,onReset:oE,isMiniMapOpen:tc,onToggleMiniMap:()=>tu(e=>!e)}),tn?(0,o.jsx)(aG,{menu:tn,canCaptureVideoFrame:oo?.type===ev.p.Video&&!!oo.metadata?.content,onClose:()=>ti(null),onOpenVideoEditor:()=>{"node"!==tn.type||(X.k.getState().user?(ti(null),window.open(`/editor?projectId=${encodeURIComponent(e)}&nodeId=${encodeURIComponent(tn.nodeId)}`,"_blank")):X.k.getState().openLoginModal())},onCaptureVideoFrame:e=>{"node"===tn.type&&np(tn.nodeId,e)},onDuplicate:()=>{"node"===tn.type&&(oS(tn.nodeId),ti(null))},onDelete:()=>{"node"===tn.type?ow(new Set([tn.nodeId])):ok(tn.connectionId),ti(null)}}):null,tS?(0,o.jsxs)("div",{className:"fixed left-1/2 top-1/2 z-[130] w-56 -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg border shadow-xl backdrop-blur",style:{background:ep.toolbar.panel,borderColor:ep.toolbar.border},onMouseDown:e=>e.stopPropagation(),onPointerDown:e=>e.stopPropagation(),children:[(0,o.jsx)("button",{type:"button",className:"flex h-10 w-full items-center px-3 text-left text-sm transition-colors",style:{color:ep.toolbar.item},onClick:()=>oX(ev.p.Panorama),onMouseEnter:e=>{e.currentTarget.style.background=ep.toolbar.itemHover},onMouseLeave:e=>{e.currentTarget.style.background="transparent"},children:"作为全景图导入"}),(0,o.jsx)("div",{className:"h-px",style:{background:ep.toolbar.border}}),(0,o.jsx)("button",{type:"button",className:"flex h-10 w-full items-center px-3 text-left text-sm transition-colors",style:{color:ep.toolbar.item},onClick:()=>oX(ev.p.Image),onMouseEnter:e=>{e.currentTarget.style.background=ep.toolbar.itemHover},onMouseLeave:e=>{e.currentTarget.style.background="transparent"},children:"作为普通图片导入"})]}):null,(0,o.jsx)("input",{ref:m,type:"file",accept:"image/*,video/*,audio/mpeg,audio/wav,audio/x-wav,.mp3,.wav",className:"hidden",onChange:nN}),(0,o.jsx)(o5,{node:a1,open:!!a1,onClose:()=>tV(null)}),a2?.metadata?.content?(0,o.jsx)(a3,{dataUrl:a2.metadata.content,open:!!a2,onClose:()=>tK(null),onConfirm:e=>nv(a2,e)}):null,a5?.metadata?.content&&a4?(0,o.jsx)(oa,{dataUrl:a5.metadata.content,open:!!a5,config:{...a4,model:a6,imageChannelId:a8},model:a6,channelId:a8,onModelChange:(e,t)=>{tq(e),tH(t||"")},onMissingConfig:()=>B(!0),onClose:()=>{tO(null),tq(""),tH("")},onConfirm:e=>void nb(a5,e)}):null,a7?.metadata?.content?(0,o.jsx)(oh,{dataUrl:a7.metadata.content,open:!!a7,onClose:()=>tY(null),onConfirm:e=>ny(a7,e)}):null,a9?.metadata?.content?(0,o.jsx)(oj,{dataUrl:a9.metadata.content,open:!!a9,onClose:()=>tQ(null),onConfirm:e=>void nw(a9,e)}):null,(0,o.jsx)(ek.A,{title:"AI 超分",open:!!oe?.metadata?.content,centered:!0,footer:null,onCancel:()=>t0(null),children:(0,o.jsx)("div",{className:"py-8 text-center text-base font-medium",children:"暂未实现"})}),ot?.metadata?.content?(0,o.jsx)(aQ,{dataUrl:ot.metadata.content,open:!!ot,onClose:()=>t2(null),onConfirm:e=>void nk(ot,e)}):null,on?.metadata?.content?(t=aL(on),a=on.metadata?.isBatchRoot&&(t.find(e=>e.id===on.metadata?.primaryImageId)||t[0])||on,i=t.findIndex(e=>e.id===a.id),l=(s=a.type===ev.p.Video)?(0,L.gB)(a.metadata?.content,a.metadata?.model):a.metadata?.content||"",(0,o.jsx)(iW,{src:l,alt:a.title||(s?"视频":"图片"),isVideo:s,isPanorama:a.type===ev.p.Panorama,proxyGeneratedPanorama:a.type===ev.p.Panorama&&!!(a.metadata?.imageTaskId||a.metadata?.imageTaskResultId)&&!a.metadata?.storageKey,onDownload:()=>ns(a),onClose:()=>t6(null),hasPrev:i>0,hasNext:i<t.length-1,onPrev:()=>t6(t[i-1].id),onNext:()=>t6(t[i+1].id)})):null,(0,o.jsx)(ek.A,{title:"清空画布？",open:tw,centered:!0,onCancel:()=>tk(!1),footer:(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)(ej.Ay,{onClick:()=>tk(!1),children:"取消"}),(0,o.jsx)(ej.Ay,{danger:!0,type:"primary",onClick:oN,children:"清空"})]}),children:(0,o.jsx)("p",{className:"text-sm opacity-60",children:"这会删除当前画布上的所有节点和连线。"})}),(0,o.jsx)(nY.w,{open:tj,defaultTab:tN,onInsert:nK,onClose:()=>{p.current=null,tC(!1)}})]}),t9?(0,o.jsx)(aD,{nodes:eg,selectedNodeIds:eY,referenceNodeClick:eQ,sessions:eI,activeSessionId:e$,agentConfig:ay,width:t8.width,onWidthChange:e=>t7(t=>({...t,width:e})),onSessionsChange:nM,onAgentConfigChange:nT,onPasteImage:nA,onOpenUpload:()=>nC(),onOpenAssets:()=>{p.current=null,tI("my-assets"),tC(!0)},getAgentContext:nR,onExecuteAction:n$,onCollapseStart:()=>t7(e=>({...e,open:!1})),onCollapse:()=>ae(!1),initialRequest:eK,onInitialRequestConsumed:()=>eW(null)}):null]}):(0,o.jsx)(iL,{})}function iW({src:e,alt:t,isVideo:a,isPanorama:i,proxyGeneratedPanorama:r=!1,onDownload:s,onClose:l,hasPrev:d,hasNext:c,onPrev:u,onNext:m}){let[p,g]=(0,n.useState)(1),[h,N]=(0,n.useState)({x:0,y:0}),[I,S]=(0,n.useState)(!1),[A,M]=(0,n.useState)(0),[_,T]=(0,n.useState)(0),[z,P]=(0,n.useState)(!1),[E,D]=(0,n.useState)(1),R=(0,n.useRef)({x:0,y:0,panX:0,panY:0}),$=(0,n.useRef)(null),L=(0,n.useRef)(null),F=(0,n.useRef)(null),V=()=>{let e=L.current;e&&(e.paused?e.play():e.pause())};(0,n.useEffect)(()=>{if(!a)return;let e=document.activeElement instanceof HTMLElement?document.activeElement:null;return L.current?.focus({preventScroll:!0}),()=>e?.focus({preventScroll:!0})},[a]),(0,n.useEffect)(()=>{let e=$.current;if(e)return e.addEventListener("wheel",U,{passive:!1}),()=>e.removeEventListener("wheel",U)});let U=e=>{e.stopPropagation(),e.preventDefault(),g(t=>{let a=Math.max(.2,Math.min(8,t-.001*e.deltaY));return a<=1&&N({x:0,y:0}),a})};return(0,o.jsxs)("div",{className:"fixed inset-0 z-[2000] flex items-center justify-center bg-black/80 backdrop-blur-sm","data-canvas-no-zoom":i?"":void 0,onClick:l,children:[d||c?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("button",{type:"button",disabled:!d,onClick:e=>{e.stopPropagation(),u?.()},onPointerDown:e=>e.stopPropagation(),className:"absolute left-4 top-1/2 z-[2010] -translate-y-1/2 flex size-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-all hover:bg-white/10 hover:scale-105 active:scale-95 disabled:opacity-20 disabled:cursor-not-allowed",children:(0,o.jsx)(f.A,{className:"size-6"})}),(0,o.jsx)("button",{type:"button",disabled:!c,onClick:e=>{e.stopPropagation(),m?.()},onPointerDown:e=>e.stopPropagation(),className:"absolute right-4 top-1/2 z-[2010] -translate-y-1/2 flex size-10 items-center justify-center rounded-full border border-white/10 bg-white/5 text-white transition-all hover:bg-white/10 hover:scale-105 active:scale-95 disabled:opacity-20 disabled:cursor-not-allowed",children:(0,o.jsx)(x.A,{className:"size-6"})})]}):null,i?(0,o.jsx)("div",{className:"h-[85vh] w-[85vw] supports-[height:round(1px,1px)]:h-[round(85vh,1px)] supports-[height:round(1px,1px)]:w-[round(85vw,1px)] overflow-hidden rounded-2xl shadow-[0_24px_72px_rgba(0,0,0,0.4)]",onClick:e=>e.stopPropagation(),children:(0,o.jsx)(iA,{src:e,alt:t,proxyGeneratedPanorama:r,immersive:!0})}):a?(0,o.jsxs)("div",{ref:F,className:"relative flex max-h-[85vh] max-w-[85vw] items-center justify-center overflow-hidden rounded-2xl bg-black shadow-[0_24px_72px_rgba(0,0,0,0.4)] fullscreen:h-screen fullscreen:w-screen fullscreen:max-h-none fullscreen:max-w-none fullscreen:rounded-none [&:fullscreen>video]:h-screen [&:fullscreen>video]:w-screen [&:fullscreen>video]:max-h-none [&:fullscreen>video]:max-w-none",onClick:e=>e.stopPropagation(),onKeyDownCapture:e=>{"Space"===e.code&&(e.preventDefault(),e.stopPropagation(),V())},"data-canvas-no-zoom":!0,children:[(0,o.jsx)("video",{ref:L,src:e,"aria-label":t,tabIndex:-1,playsInline:!0,preload:"metadata",onLoadStart:()=>{M(0),T(0),P(!1)},onDurationChange:e=>M(e.currentTarget.duration),onTimeUpdate:e=>T(e.currentTarget.currentTime),onPlay:()=>P(!0),onPause:()=>P(!1),onVolumeChange:e=>D(e.currentTarget.muted?0:e.currentTarget.volume),onDoubleClick:e=>{e.preventDefault(),e.stopPropagation()},className:"block max-h-[85vh] max-w-[85vw] object-contain outline-none"}),(0,o.jsx)("button",{type:"button","aria-label":"关闭预览",onClick:l,className:"absolute right-4 top-4 z-20 flex size-9 items-center justify-center rounded-lg text-white transition-colors hover:bg-black/25",children:(0,o.jsx)(v.A,{className:"size-6"})}),(0,o.jsxs)("div",{className:"pointer-events-none absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-black/85 via-black/40 to-transparent px-5 pb-3 pt-24",children:[(0,o.jsxs)("div",{className:"mb-2 flex justify-between text-xs font-medium tabular-nums text-white",children:[(0,o.jsx)("span",{children:iD(_)}),(0,o.jsx)("span",{children:iD(A)})]}),(0,o.jsx)("input",{type:"range",min:0,max:A||0,step:"0.01",value:Math.min(_,A||0),"aria-label":"视频进度",onChange:e=>{let t=Number(e.currentTarget.value);L.current&&(L.current.currentTime=t),T(t)},onPointerUp:()=>L.current?.focus({preventScroll:!0}),className:"pointer-events-auto block h-1 w-full cursor-pointer appearance-none rounded-full focus-visible:outline-none [&::-moz-range-thumb]:size-3 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white [&::-webkit-slider-thumb]:size-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white",style:{background:`linear-gradient(to right, #67e8f9 ${A?100*Math.min(_/A,1):0}%, rgba(255,255,255,0.35) 0)`}}),(0,o.jsxs)("div",{className:"pointer-events-auto mt-2 flex items-center justify-between",children:[(0,o.jsxs)("div",{className:"flex items-center gap-1",children:[(0,o.jsx)("button",{type:"button","aria-label":z?"暂停":"播放",onPointerDown:e=>e.preventDefault(),onClick:V,className:iP,children:z?(0,o.jsx)(y.A,{className:"size-5"}):(0,o.jsx)(b.A,{className:"size-5"})}),(0,o.jsxs)("div",{className:"group/volume flex items-center",children:[(0,o.jsx)("button",{type:"button","aria-label":0===E?"恢复声音":"静音",onPointerDown:e=>e.preventDefault(),onClick:()=>{L.current&&(L.current.muted=!L.current.muted)},className:iP,children:0===E?(0,o.jsx)(w.A,{className:"size-5"}):(0,o.jsx)(k.A,{className:"size-5"})}),(0,o.jsx)("input",{type:"range",min:0,max:1,step:"0.01",value:E,"aria-label":"音量",onChange:e=>{let t=Number(e.currentTarget.value);L.current&&(0===t?L.current.muted=!0:(L.current.volume=t,L.current.muted=!1))},onPointerUp:()=>L.current?.focus({preventScroll:!0}),className:"h-1 w-0 pointer-events-none cursor-pointer appearance-none rounded-full opacity-0 transition-[width,opacity] duration-200 focus-visible:outline-none group-hover/volume:mx-1 group-hover/volume:w-20 group-hover/volume:pointer-events-auto group-hover/volume:opacity-100 [&::-moz-range-thumb]:size-2 [&::-moz-range-thumb]:rounded-full [&::-moz-range-thumb]:border-0 [&::-moz-range-thumb]:bg-white [&::-webkit-slider-thumb]:size-2 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-white",style:{background:`linear-gradient(to right, white ${100*E}%, rgba(255,255,255,0.35) 0)`}})]})]}),(0,o.jsxs)("div",{className:"flex items-center gap-1",children:[(0,o.jsx)("button",{type:"button","aria-label":"下载视频",onPointerDown:e=>e.preventDefault(),onClick:s,className:iP,children:(0,o.jsx)(j.A,{className:"size-5"})}),(0,o.jsx)("button",{type:"button","aria-label":"全屏播放",onPointerDown:e=>e.preventDefault(),onClick:()=>{document.fullscreenElement?document.exitFullscreen():F.current?.requestFullscreen()},className:iP,children:(0,o.jsx)(C.A,{className:"size-5"})})]})]})]})]}):(0,o.jsx)("img",{ref:$,src:e,alt:t,draggable:!1,onPointerDown:e=>{e.stopPropagation(),e.preventDefault(),e.currentTarget.setPointerCapture(e.pointerId),S(!0),R.current={x:e.clientX,y:e.clientY,panX:h.x,panY:h.y}},onPointerMove:e=>{I&&(e.preventDefault(),N({x:R.current.panX+(e.clientX-R.current.x),y:R.current.panY+(e.clientY-R.current.y)}))},onPointerUp:e=>{S(!1),e.currentTarget.releasePointerCapture(e.pointerId)},className:`max-h-[85vh] max-w-[85vw] object-contain rounded-2xl shadow-[0_24px_72px_rgba(0,0,0,0.4)] ${p>1?"cursor-grab active:cursor-grabbing":"cursor-default"}`,onClick:e=>e.stopPropagation(),onDragStart:e=>e.preventDefault(),style:{transform:`translate(${h.x}px, ${h.y}px) scale(${p})`,transition:I?"none":"transform 0.12s cubic-bezier(0.25, 0.46, 0.45, 0.94)"}})]})}function iO({title:e,sidePanelOpen:t,onToggleSidePanel:a,titleDraft:i,isTitleEditing:r,onTitleDraftChange:s,onStartTitleEditing:l,onFinishTitleEditing:d,onCancelTitleEditing:c,canUndo:u,canRedo:m,onHome:p,onProjects:f,onCreateProject:x,onDeleteProject:v,onImportImage:y,onUndo:b,onRedo:w,assistantCollapsed:k,onExpandAssistant:j}){let C=(0,H.C)(e=>e.theme),E=O.$[C],D=(0,n.useRef)(null),R=(0,n.useRef)(null),[$,L]=(0,n.useState)(!1),[F,V]=(0,n.useState)(!1);return(0,n.useEffect)(()=>{if(!r)return;let e=e=>{D.current?.contains(e.target)||d()};return document.addEventListener("pointerdown",e,!0),()=>document.removeEventListener("pointerdown",e,!0)},[r,d]),(0,n.useEffect)(()=>{if(!F)return;let e=e=>{R.current?.contains(e.target)||V(!1)};return document.addEventListener("pointerdown",e,!0),()=>document.removeEventListener("pointerdown",e,!0)},[F]),(0,o.jsxs)(o.Fragment,{children:[(0,o.jsxs)("div",{className:"pointer-events-none absolute left-0 right-0 top-0 z-50 flex h-16 items-center justify-between px-4",children:[(0,o.jsxs)("div",{className:"pointer-events-auto flex min-w-0 items-center gap-3",children:[(0,o.jsx)("button",{type:"button",onClick:a,className:"grid size-7 place-items-center rounded-full transition hover:bg-black/5 dark:hover:bg-white/10",style:{color:E.node.text},"aria-label":t?"收起左侧面板":"展开左侧面板",children:t?(0,o.jsx)(N.A,{className:"size-4"}):(0,o.jsx)(I.A,{className:"size-4"})}),(0,o.jsx)(eC.A,{trigger:["click"],menu:{items:[{key:"home",icon:(0,o.jsx)(S.A,{className:"size-4"}),label:"主页",onClick:p},{key:"projects",icon:(0,o.jsx)(h.A,{className:"size-4"}),label:"我的画布",onClick:f},{type:"divider"},{key:"new",icon:(0,o.jsx)(A.A,{className:"size-4"}),label:"新建画布",onClick:x},{key:"delete",danger:!0,icon:(0,o.jsx)(M.A,{className:"size-4"}),label:"删除当前画布",onClick:v},{type:"divider"},{key:"import",icon:(0,o.jsx)(g.A,{className:"size-4"}),label:"导入素材",onClick:y},{type:"divider"},{key:"undo",disabled:!u,icon:(0,o.jsx)(_.A,{className:"size-4"}),label:(0,o.jsx)(iB,{text:"撤销",shortcut:"⌘ Z"}),onClick:b},{key:"redo",disabled:!m,icon:(0,o.jsx)(T.A,{className:"size-4"}),label:(0,o.jsx)(iB,{text:"重做",shortcut:"⌘ ⇧ Z / ⌘ Y"}),onClick:w}]},children:(0,o.jsx)("button",{type:"button",className:"grid size-9 place-items-center rounded-full transition hover:bg-black/5 dark:hover:bg-white/10",style:{color:E.node.text},"aria-label":"打开画布菜单",children:(0,o.jsx)(z.A,{className:"size-5"})})}),(0,o.jsx)("div",{ref:D,className:"flex min-w-0 items-center gap-2",children:r?(0,o.jsx)("input",{autoFocus:!0,value:i,onChange:e=>s(e.target.value),onBlur:d,onKeyDown:e=>{"Enter"===e.key&&d(),"Escape"===e.key&&c()},className:"max-w-[280px] bg-transparent p-0 text-left text-lg font-semibold tracking-normal outline-none",style:{color:E.node.text}}):(0,o.jsx)("button",{type:"button",className:"max-w-[280px] truncate border-b border-dashed border-transparent text-left text-lg font-semibold tracking-normal transition hover:border-current",onDoubleClick:l,title:"双击修改画布名称",children:e})})]}),(0,o.jsxs)("div",{className:"pointer-events-auto flex items-center gap-1.5",children:[(0,o.jsx)(B.R,{variant:"canvas",accountOpen:F,onAccountOpenChange:V,accountRef:R,getPopupContainer:e=>e.parentElement||document.body,onOpenShortcuts:()=>{L(!0),V(!1)}}),k?(0,o.jsxs)(o.Fragment,{children:[(0,o.jsx)("span",{className:"h-6 w-px",style:{background:E.toolbar.border}}),(0,o.jsx)(ej.Ay,{type:"text",className:"!h-10 !rounded-xl !px-3 !font-medium",style:{background:E.toolbar.panel,color:E.node.text,boxShadow:"0 10px 30px rgba(28,25,23,.10)"},icon:(0,o.jsx)(P.A,{className:"size-4"}),onClick:j,children:"Agent"})]}):null]})]}),(0,o.jsx)(ek.A,{title:"快捷键",open:$,onCancel:()=>L(!1),footer:null,centered:!0,children:(0,o.jsxs)("div",{className:"space-y-2 border-t pt-4 text-sm",style:{borderColor:E.node.stroke},children:[(0,o.jsx)(iq,{keys:["Space","拖动"],value:"临时反转选择/移动工具"}),(0,o.jsx)(iq,{keys:["滚轮"],value:"缩放画布"}),(0,o.jsx)(iq,{keys:["拖动"],value:"使用当前工具操作画布"}),(0,o.jsx)(iq,{keys:["Shift / Ctrl / Cmd","点击"],value:"追加选择节点"}),(0,o.jsx)(iq,{keys:["Ctrl / Cmd","G"],value:"创建组"}),(0,o.jsx)(iq,{keys:["Ctrl / Cmd","C / V"],value:"复制 / 粘贴节点，或粘贴剪切板文本/图片"}),(0,o.jsx)(iq,{keys:["Ctrl / Cmd","Z"],value:"撤销"}),(0,o.jsx)(iq,{keys:["Ctrl / Cmd","Shift","Z"],value:"重做"}),(0,o.jsx)(iq,{keys:["Delete / Backspace"],value:"删除选中"}),(0,o.jsx)(iq,{keys:["Esc"],value:"取消选择并关闭浮层"}),(0,o.jsx)(iq,{keys:["拖入图片/视频/音频"],value:"上传到画布"})]})})]})}function iB({text:e,shortcut:t}){return(0,o.jsxs)("span",{className:"flex min-w-36 items-center justify-between gap-8",children:[(0,o.jsx)("span",{children:e}),(0,o.jsx)("span",{className:"text-xs opacity-45",children:t})]})}function iq({keys:e,value:t}){return(0,o.jsxs)("div",{className:"grid grid-cols-[minmax(0,1fr)_120px] items-center gap-6 rounded-lg px-1 py-1.5",children:[(0,o.jsx)("span",{className:"flex min-w-0 flex-wrap items-center gap-1.5",children:e.map((e,t)=>(0,o.jsxs)("span",{className:"flex items-center gap-1.5",children:[t?(0,o.jsx)("span",{className:"text-xs opacity-35",children:"+"}):null,(0,o.jsx)("kbd",{className:"min-w-9 rounded-md border px-2.5 py-1.5 text-center text-xs font-medium leading-none shadow-[inset_0_-1px_0_rgba(0,0,0,.08),0_1px_2px_rgba(0,0,0,.06)]",style:{borderColor:"rgba(120,113,108,.28)",background:"linear-gradient(#fff, rgba(245,245,244,.92))",color:"rgb(68,64,60)"},children:e})]},`${e}-${t}`))}),(0,o.jsx)("span",{className:"text-right text-sm opacity-55",children:t})]})}function iG(e){return e?.includes("wav")?"wav":e?.includes("opus")?"opus":e?.includes("aac")?"aac":e?.includes("flac")?"flac":e?.includes("pcm")?"pcm":"mp3"}function iH(e){return{content:e.url,storageKey:e.storageKey,status:"success",naturalWidth:e.width,naturalHeight:e.height,bytes:e.bytes,mimeType:e.mimeType}}function iX(e){return{content:e.url,storageKey:e.storageKey,status:"success",naturalWidth:e.width,naturalHeight:e.height,bytes:e.bytes,mimeType:e.mimeType||"video/mp4",durationMs:e.durationMs}}function iY(e,t,a){let o=er(e.width||1280,e.height||720,420,420);return{id:`video-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,type:ev.p.Video,title:t,position:{x:a.x-o.width/2,y:a.y-o.height/2},width:o.width,height:o.height,metadata:iX(e)}}function iJ(e,t,a){return a.reduce((a,o)=>{if(o.fromNodeId!==e.id)return a;let n=t.find(e=>e.id===o.toNodeId);return n?.type===ev.p.Image||n?.type===ev.p.Video?Math.max(a,n.position.y+n.height+36):a},e.position.y)}function iQ(e){return{content:e.url,storageKey:e.storageKey,status:"success",bytes:e.bytes,mimeType:e.mimeType||"audio/mpeg",durationMs:e.durationMs}}function iZ(e,t,a,o){return{generationType:e,model:t.model,channelId:t.imageChannelId||t.activeChannelId,size:t.size,quality:t.quality,count:a,references:o.map(i2).filter(e=>!!e)}}function i0(e,t){return{model:e.model,channelId:e.audioChannelId||e.activeChannelId,audioVoice:e.audioVoice,audioFormat:e.audioFormat,audioSpeed:e.audioSpeed,audioInstructions:e.audioInstructions,grokTtsVoice:e.grokTtsVoice,grokTtsLanguage:e.grokTtsLanguage,grokTtsFormat:e.grokTtsFormat,grokTtsSpeed:e.grokTtsSpeed,glmTtsVoice:e.glmTtsVoice,glmTtsFormat:e.glmTtsFormat,glmTtsSpeed:e.glmTtsSpeed,mimoTtsVoice:e.mimoTtsVoice,mimoTtsFormat:e.mimoTtsFormat,mimoVoiceDesignPrompt:e.mimoVoiceDesignPrompt,geminiTtsVoice:e.geminiTtsVoice,mimoVoiceCloneAudioNodeId:t?.mimoVoiceCloneAudioNodeId}}function i1(e,t,a){if(!(0,eI.TR)(e.model||e.audioModel))return;let o=t?.mimoVoiceCloneAudioNodeId||"";if(o){let e=a.find(e=>e.id===o);if(e)return e}if(1===a.length)return a[0];if(!a.length)throw Error("请连接参考音频节点");throw Error("已连接多个音频节点，请在音频设置中选择参考音频")}function i2(e){return e.storageKey||e.url||(e.dataUrl.startsWith("data:")?void 0:e.dataUrl)}function i5(e,t){let a=(0,q.ew)(e,e.model||e.videoModel),o=(0,q.Dd)(e,e.model||e.videoModel);return{...e,videoNegativePrompt:a?"":e.videoNegativePrompt,videoMultiShot:"transformation"===o?"false":e.videoMultiShot,videoShotType:a&&!o?"intelligence":e.videoShotType,videoMultiPrompt:t.videoMultiPrompt.length?t.videoMultiPrompt:e.videoMultiPrompt,videoElementList:t.videoElementList.length?t.videoElementList:e.videoElementList}}async function i4(e){if("edit"!==e.generationType)return[];if(!e.references?.length)return null;let t=await Promise.all(e.references.map(async(e,t)=>{let a=e.startsWith("image:")?await (0,V.resolveImageUrl)(e,""):e;return a?{id:`${t}`,name:`reference-${t}.png`,type:"image/png",dataUrl:a,storageKey:e.startsWith("image:")?e:void 0}:null}));return t.every(Boolean)?t:null}async function i3(e){return Promise.all(e.map(async e=>{let t=e.metadata?.content;if((e.type===ev.p.Video||e.type===ev.p.Audio)&&e.metadata?.storageKey)return{...e,metadata:{...e.metadata,content:await (0,U.aN)(e.metadata.storageKey,t)}};if(e.type===ev.p.Video&&t&&/\/videos\/[^/]+\/content(?:[?#]|$)/i.test(t))try{let a=X.k.getState().token,o=t.match(/\/videos\/([^/?#]+)\/content/i),n=(o?o[1]:"")||e.metadata?.videoTaskId||"",i=e.metadata?.model||"",r=n?`/api/v1/videos/${encodeURIComponent(n)}/content?model=${encodeURIComponent(i)}`:t,s=await fetch(r,{headers:a?{Authorization:`Bearer ${a}`}:{}});if(s.ok){let t=await s.blob(),a=await (0,U.uploadMediaFile)(t,"generated-video");return{...e,metadata:{...e.metadata,content:a.url,storageKey:a.storageKey,videoTaskId:n||e.metadata?.videoTaskId}}}}catch{}return(0,ec.IM)(e.type)&&t?e.metadata?.storageKey?{...e,metadata:{...e.metadata,content:await (0,V.resolveImageUrl)(e.metadata.storageKey,t)}}:t.startsWith("data:image/")?{...e,metadata:{...e.metadata,...iH(await (0,V.uploadImage)(t,{localOnly:!0}))}}:e:e}))}function i6(e,t,a=!1){let o=new Map(t.map(e=>[e.id,e]));return e.map(e=>({...e,messages:e.messages.map(e=>{let t=a&&("thinking"===e.status||"running"===e.status);return{...e,text:t&&!e.text?"上次 Agent 执行因页面关闭而中断；已提交的媒体任务会继续恢复，你可以让我从当前画布继续。":e.text,status:t?"waiting":e.status,activity:t?void 0:e.activity,references:e.references?.map(e=>{let t=o.get(e.id),a=t&&(0,az.nr)(t);return a?{...e,...a}:e})}})}))}function i8(e){return Math.max(1,Math.min(15,Math.floor(Math.abs(Number(e))||1)))}function i7(e,t,a,o){let n=a.find(t=>t.id===e),i=a.find(e=>e.id===t);return n&&i&&n.id!==i.id&&n.type!==ev.p.Group&&i.type!==ev.p.Group?i.type===ev.p.Director?(0,ec.IM)(n.type)?"target"===o?{fromNodeId:i.id,toNodeId:n.id}:{fromNodeId:n.id,toNodeId:i.id}:null:n.type===ev.p.Director?(0,ec.IM)(i.type)?"target"===o?{fromNodeId:i.id,toNodeId:n.id}:{fromNodeId:n.id,toNodeId:i.id}:null:n.type===ev.p.Config&&i.type===ev.p.Config?null:i.type===ev.p.Config?{fromNodeId:n.id,toNodeId:i.id}:n.type===ev.p.Config&&"target"===o?{fromNodeId:i.id,toNodeId:n.id}:(n.type===ev.p.Config,{fromNodeId:n.id,toNodeId:i.id}):null}function i9(e,t,a,o,n,i){return e.map(e=>{var r,s,l;let d;if(e.id!==t)return e;let c="number"==typeof a.progress?Math.max(0,Math.min(100,a.progress)):e.metadata?.progress||0,u=a.video_url||a.url||"",m=!!((r=a).video_url||r.url)||["completed","complete","done","succeeded","success"].includes((r.status||"").toLowerCase()),p=["failed","fail","error","cancelled","canceled"].includes((a.status||"").toLowerCase())||m&&!u,g=rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||n,h={...e.metadata,status:p?iT:m?i_:iM,errorDetails:p?a.error?.message||(m?"视频生成完成但没有返回视频地址":"视频生成失败"):void 0,model:a.model||o.model,size:a.size||e.metadata?.size||o.size,seconds:a.seconds||e.metadata?.seconds||o.videoSeconds,vquality:e.metadata?.vquality||o.vquality,mode:e.metadata?.mode||o.videoMode,negativePrompt:e.metadata?.negativePrompt||o.videoNegativePrompt,generateAudio:e.metadata?.generateAudio||o.videoGenerateAudio,characterOrientation:e.metadata?.characterOrientation||o.videoCharacterOrientation,watermark:e.metadata?.watermark||o.videoWatermark,startedAt:g,durationMs:Date.now()-g,progress:c,videoTaskId:a.task_id||a.id||e.metadata?.videoTaskId,videoTaskVideoId:a.video_id||e.metadata?.videoTaskVideoId};if(!m||!u)return{...e,metadata:h};let f=(s=a.size,l=i,{width:(d="string"==typeof s?s.match(/^(\d+)x(\d+)$/):null)?Number(d[1]):l.width,height:d?Number(d[2]):l.height}),x=er(f.width,f.height,420,420);return{...e,width:x.width,height:x.height,position:{x:e.position.x+e.width/2-x.width/2,y:e.position.y+e.height/2-x.height/2},metadata:{...h,content:u,storageKey:a.storageKey||"",status:i_,naturalWidth:f.width,naturalHeight:f.height,bytes:0,mimeType:"video/mp4",progress:100}}})}function re(e){return[...new Set([...e.image_urls||[],e.image_url||e.url||""].map(e=>e.trim()).filter(Boolean))]}function rt(e,t){return re(t).map((t,a)=>`${e}-result-${a}`)}function ra(e,t,a,o,n){let i=re(a),r=e.map(e=>{if(e.id!==t)return e;let r="number"==typeof a.progress?Math.max(0,Math.min(100,a.progress)):e.metadata?.progress||0,s=i[0]||"",l=rg(a.status)||!!s,d=rh(a.status)||l&&!s,c=rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||o,u={...e.metadata,status:d?iT:l?i_:iM,errorDetails:d?a.error?.message||"图片生成失败":void 0,startedAt:c,durationMs:Date.now()-c,progress:r,imageTaskId:a.id||e.metadata?.imageTaskId};if(!l||!s)return{...e,metadata:u};let m=(0,ec.sK)(e.type),p=es(e.metadata?.size||"",n.width,n.height),g=a.width||p?.width||n.width||e.width,h=a.height||p?.height||n.height||e.height,f=m?ec.D9:er(g,h,eT[ev.p.Image].width,eT[ev.p.Image].height);return{...e,width:f.width,height:f.height,position:{x:e.position.x+e.width/2-f.width/2,y:e.position.y+e.height/2-f.height/2},metadata:{...u,content:s,storageKey:a.storageKey||"",status:i_,naturalWidth:g,naturalHeight:h,bytes:a.bytes||0,mimeType:a.mimeType||"image/png",progress:100,imageTaskResultId:a.id,panoramaProjection:m?"equirectangular":void 0}}}),s=r.find(e=>e.id===t);if(!s||s.type!==ev.p.Image||!(0,e_.$)(a.model)||i.length<2)return r;let l=rt(t,a),d=i.map((e,o)=>{let n=l[o];return{...s,id:n,position:{x:s.position.x+s.width+120+o%2*(s.width+36),y:s.position.y+Math.floor(o/2)*(s.height+36)},metadata:{...s.metadata,content:e,status:i_,progress:100,storageKey:"",mimeType:"image/png",bytes:0,imageTaskId:void 0,imageTaskResultId:a.id,isBatchRoot:void 0,batchChildIds:void 0,primaryImageId:void 0,imageBatchExpanded:void 0,batchRootId:t}}});return[...r.filter(e=>!l.includes(e.id)).map(e=>e.id===t?{...e,metadata:{...e.metadata,isBatchRoot:!0,batchChildIds:l,primaryImageId:l[0],imageBatchExpanded:!0,count:i.length}}:e.metadata?.batchRootId===t?{...e,metadata:{...e.metadata,batchRootId:void 0}}:e),...d]}function ro(e,t,a){if(!(0,e_.$)(a.model))return e;let o=rt(t,a);if(o.length<2)return e;let n=new Set(e.map(e=>`${e.fromNodeId}:${e.toNodeId}`));return[...e,...o.flatMap(e=>n.has(`${t}:${e}`)?[]:[{id:`${t}-connection-${e}`,fromNodeId:t,toNodeId:e}])]}function rn(e,t,a,o){return e.map(e=>{if(e.id!==t)return e;let n="number"==typeof a.progress?Math.max(0,Math.min(100,a.progress)):e.metadata?.progress||0,i=a.audio_url||a.url||"",r=rg(a.status)||!!i,s=rh(a.status)||r&&!i,l=rr(a.started_at??a.startedAt??a.created_at??a.createdAt)||o,d={...e.metadata,status:s?iT:r?i_:iM,errorDetails:s?a.error?.message||"音频生成失败":void 0,startedAt:l,durationMs:Date.now()-l,progress:n,audioTaskId:a.id||e.metadata?.audioTaskId};return r&&i?{...e,metadata:{...d,content:i,storageKey:a.storageKey||"",status:i_,bytes:a.bytes||0,mimeType:a.mimeType||"audio/mpeg",progress:100,audioTaskResultId:a.id}}:{...e,metadata:d}})}function ri(e){return e?.videoTaskVideoId||e?.videoTaskId||""}function rr(e){if("number"==typeof e)return e>1e11?e:1e3*e;if("string"!=typeof e||!e.trim())return 0;let t=Number(e);if(Number.isFinite(t))return t>1e11?t:1e3*t;let a=Date.parse(e);return Number.isFinite(a)?a:0}function rs(e){let t=e.metadata?.content||"",a=e.type===ev.p.Text;return{id:e.id,type:e.type,title:e.title,text:a?t.slice(0,4e3):void 0,mediaUrl:a||!t||t.startsWith("data:")?void 0:t,hasMedia:a?void 0:!!t,status:e.metadata?.status||"idle",prompt:e.metadata?.prompt?.slice(0,4e3),model:e.metadata?.model,size:e.metadata?.size,seconds:e.metadata?.seconds,generateAudio:e.metadata?.generateAudio,taskId:rp(e)||void 0,progress:e.metadata?.progress,error:e.metadata?.errorDetails,groupId:e.metadata?.groupId}}function rl(e){let t=e.metadata?.content||"";return{type:e.type,status:e.metadata?.status||"idle",taskId:rp(e)||void 0,progress:e.metadata?.progress,error:e.metadata?.errorDetails,mediaUrl:t&&!t.startsWith("data:")?t:void 0}}function rd(e){let t=(0,eN.B0)(e);return(0,eN.Rf)(t)?{values:[5,10],range:"仅 5 或 10 秒"}:t.includes("seedance")?{values:[-1,4,5,6,8,10,12,15],range:"智能或 4-15 秒"}:rc(t)?{values:[3,15],range:"3-15 秒"}:ru(t)?{values:[5,10],range:"仅 5 或 10 秒"}:{values:[6,10,12,16,20],range:"1-30 秒"}}function rc(e){return e.includes("kling-v3")||e.includes("kling-3-0")}function ru(e){return e.includes("kling-v2-6")||e.includes("kling-2-6")}function rm(e,t,a){let o="image"===a?e.imageModel:"video"===a?e.videoModel:"audio"===a?e.audioModel:e.textModel,n=t?.metadata?.channelId||"",i="image"===a&&n||e.imageChannelId,r="video"===a&&n||e.videoChannelId,s="text"===a&&n||e.textChannelId,l="audio"===a&&n||e.audioChannelId,d="image"===a?i:"video"===a?r:"text"===a?s:"audio"===a&&l||e.activeChannelId,c="text"===a?(0,F.resolveModelForCapability)(e,t?.metadata?.model,"text"):t?.metadata?.model||o||("audio"===a?F.defaultConfig.audioModel:e.model||F.defaultConfig.model);return{...e,model:c,..."video"===a?{videoModel:c}:{},..."image"===a?{imageModel:c}:{},..."audio"===a?{audioModel:c}:{},..."text"===a?{textModel:c}:{},activeChannelId:d,imageChannelId:i,videoChannelId:r,textChannelId:s,audioChannelId:l,quality:t?.metadata?.quality||e.quality||F.defaultConfig.quality,size:(0,ec.sK)(t?.type)?ec.A9:t?.metadata?.size||("video"===a?e.videoSize||F.defaultConfig.videoSize:e.size||F.defaultConfig.size),videoSeconds:t?.metadata?.seconds||e.videoSeconds||F.defaultConfig.videoSeconds,vquality:t?.metadata?.vquality||e.vquality||F.defaultConfig.vquality,videoMode:t?.metadata?.mode||e.videoMode||F.defaultConfig.videoMode,videoNegativePrompt:t?.metadata?.negativePrompt||e.videoNegativePrompt||F.defaultConfig.videoNegativePrompt,videoMultiShot:t?.metadata?.multiShot||e.videoMultiShot||F.defaultConfig.videoMultiShot,videoShotType:t?.metadata?.shotType||e.videoShotType||F.defaultConfig.videoShotType,videoGenerateAudio:t?.metadata?.generateAudio||e.videoGenerateAudio||F.defaultConfig.videoGenerateAudio,videoCharacterOrientation:t?.metadata?.characterOrientation||e.videoCharacterOrientation||F.defaultConfig.videoCharacterOrientation,videoWatermark:t?.metadata?.watermark||e.videoWatermark||F.defaultConfig.videoWatermark,audioVoice:t?.metadata?.audioVoice||e.audioVoice||F.defaultConfig.audioVoice,audioFormat:t?.metadata?.audioFormat||e.audioFormat||F.defaultConfig.audioFormat,audioSpeed:t?.metadata?.audioSpeed||e.audioSpeed||F.defaultConfig.audioSpeed,audioInstructions:t?.metadata?.audioInstructions||e.audioInstructions||F.defaultConfig.audioInstructions,grokTtsVoice:t?.metadata?.grokTtsVoice||e.grokTtsVoice||F.defaultConfig.grokTtsVoice,grokTtsLanguage:t?.metadata?.grokTtsLanguage||e.grokTtsLanguage||F.defaultConfig.grokTtsLanguage,grokTtsFormat:t?.metadata?.grokTtsFormat||e.grokTtsFormat||F.defaultConfig.grokTtsFormat,grokTtsSpeed:t?.metadata?.grokTtsSpeed||e.grokTtsSpeed||F.defaultConfig.grokTtsSpeed,glmTtsVoice:t?.metadata?.glmTtsVoice||e.glmTtsVoice||F.defaultConfig.glmTtsVoice,glmTtsFormat:t?.metadata?.glmTtsFormat||e.glmTtsFormat||F.defaultConfig.glmTtsFormat,glmTtsSpeed:t?.metadata?.glmTtsSpeed||e.glmTtsSpeed||F.defaultConfig.glmTtsSpeed,mimoTtsVoice:t?.metadata?.mimoTtsVoice||e.mimoTtsVoice||F.defaultConfig.mimoTtsVoice,mimoTtsFormat:t?.metadata?.mimoTtsFormat||e.mimoTtsFormat||F.defaultConfig.mimoTtsFormat,mimoVoiceDesignPrompt:t?.metadata?.mimoVoiceDesignPrompt||e.mimoVoiceDesignPrompt||F.defaultConfig.mimoVoiceDesignPrompt,geminiTtsVoice:t?.metadata?.geminiTtsVoice||e.geminiTtsVoice||F.defaultConfig.geminiTtsVoice,count:String(t?.metadata?.count||"image"===a&&e.canvasImageCount||e.count||F.defaultConfig.count)}}function rp(e){return e.type===ev.p.Video?ri(e.metadata):(0,ec.IM)(e.type)?e.metadata?.imageTaskId||"":e.type===ev.p.Audio&&e.metadata?.audioTaskId||""}function rg(e){return["completed","complete","done","succeeded","success"].includes((e||"").toLowerCase())}function rh(e){return["failed","fail","error","cancelled","canceled"].includes((e||"").toLowerCase())}function rf(e){return e.type.startsWith("audio/")||/\.(mp3|wav)$/i.test(e.name)}function rx(e,t,a){let o=e.metadata?.batchRootId;if(!o)return!1;let n=t.find(e=>e.id===o);return!(n&&a?.has(o))&&!!(n&&!n.metadata?.imageBatchExpanded)}function rv(e,t){let a=e.metadata?.batchRootId;if(!a)return!1;let o=t.find(e=>e.id===a);return!!(o&&!o.metadata?.imageBatchExpanded)}function ry(e){let t=0===e.horizontalAngle?"正面视角":e.horizontalAngle>0?`向右旋转 ${e.horizontalAngle} 度`:`向左旋转 ${Math.abs(e.horizontalAngle)} 度`,a=0===e.pitchAngle?"水平视角":e.pitchAngle>0?`俯视 ${e.pitchAngle} 度`:`仰视 ${Math.abs(e.pitchAngle)} 度`;return`AI 多角度：${t}，${a}，镜头距离 ${e.cameraDistance.toFixed(1)}，${e.wideAngle?"广角":"标准"}镜头`}},9940:(e,t,a)=>{"use strict";function o(e,t=[]){if(!Array.isArray(e)||e.length<=1)return e||[];let a=new Map,n=new Set;e.forEach(e=>{a.set(e.id,e),n.add(e.id)});let i=new Map,r=new Map;e.forEach(e=>{i.set(e.id,[]),r.set(e.id,0)});let s=!1;if(t.forEach(e=>{n.has(e.fromNodeId)&&n.has(e.toNodeId)&&e.fromNodeId!==e.toNodeId&&(i.get(e.fromNodeId)?.push(e.toNodeId),r.set(e.toNodeId,(r.get(e.toNodeId)||0)+1),s=!0)}),s){let t=[];r.forEach((e,a)=>{0===e&&t.push(a)});let o=[];for(;t.length>0;){t.sort((e,t)=>{let o=a.get(e),n=a.get(t);return o.position.x-n.position.x});let e=t.shift();o.push(e),i.get(e)?.forEach(e=>{let a=(r.get(e)||1)-1;r.set(e,a),0===a&&t.push(e)})}if(o.length===e.length)return o.map(e=>a.get(e))}let l=/(?:分镜|镜头|镜|shot|scene|#)?\s*0*([1-9]\d*)/i,d=e.map(e=>{let t=(e.title||"").match(l);return t?parseInt(t[1],10):null}),c=d.every(e=>null!==e),u=new Set(d.filter(e=>null!==e));if(c&&u.size===e.length)return[...e].sort((e,t)=>parseInt((e.title||"").match(l)[1],10)-parseInt((t.title||"").match(l)[1],10));let m=Math.max(120,.5*(e.reduce((e,t)=>e+(t.height||240),0)/e.length));return[...e].sort((e,t)=>{let a=e.position.y-t.position.y;return Math.abs(a)>m?a:e.position.x-t.position.x})}a.d(t,{k:()=>o})},19822:(e,t,a)=>{"use strict";a.r(t),a.d(t,{mergeAssets:()=>y,useAssetStore:()=>x});var o=a(58302),n=a(94478),i=a(70556),r=a(88962),s=a(80387),l=a(58960),d=a(30037),c=a(58573);function u(e){let t=c.k.getState().user;return`${e}:${t?.id||"guest"}`}let m="",p=!1,g=!1,h=null;async function f(e){if("video"===e.kind&&e.data.storageKey||"audio"===e.kind&&e.data.storageKey)return{...e,data:{...e.data,url:await (0,l.aN)(e.data.storageKey,e.data.url)}};if("image"!==e.kind)return e;if(e.data.storageKey)return{...e,coverUrl:e.coverUrl.startsWith("blob:")?await (0,s.resolveImageUrl)(e.data.storageKey,e.coverUrl):e.coverUrl,data:{...e.data,dataUrl:await (0,s.resolveImageUrl)(e.data.storageKey,e.data.dataUrl)}};if(!e.data.dataUrl.startsWith("data:image/"))return e;let t=await (0,s.uploadImage)(e.data.dataUrl);return{...e,coverUrl:e.coverUrl.startsWith("data:image/")?t.url:e.coverUrl,data:{...e.data,dataUrl:t.url,storageKey:t.storageKey,bytes:t.bytes,mimeType:t.mimeType}}}let x=(0,o.v)()((0,n.Zr)((e,t)=>({assets:[],addAsset:a=>{let o=new Date().toISOString(),n=(0,i.Ak)();return e(e=>({assets:[{...a,id:n,createdAt:o,updatedAt:o},...e.assets]})),v(t),n},updateAsset:(a,o)=>e(e=>{let n=e.assets.map(e=>e.id===a?{...e,...o,updatedAt:new Date().toISOString()}:e);return window.setTimeout(()=>v(t),0),{assets:n}}),removeAsset:o=>e(e=>{let n=e.assets.find(e=>e.id===o),i=e.assets.filter(e=>e.id!==o);if(n&&"text"!==n.kind&&n.data.storageKey){let e=n.data.storageKey;window.setTimeout(async()=>{let{useCanvasStore:t}=await a.e(4328).then(a.bind(a,89566)),o=new Set;i.forEach(e=>{"text"!==e.kind&&e.data.storageKey&&o.add(e.data.storageKey)});let n=t.getState().projects,{collectImageStorageKeys:r}=await Promise.resolve().then(a.bind(a,80387)),{collectMediaStorageKeys:s}=await Promise.resolve().then(a.bind(a,58960));r(n,o),s(n,o);try{let e=(await Promise.resolve().then(a.t.bind(a,9444,23))).default.createInstance({name:"infinite-canvas",storeName:"image_generation_logs"});await e.iterate(e=>{e&&(Array.isArray(e.images)&&e.images.forEach(e=>{e&&e.storageKey&&o.add(e.storageKey)}),Array.isArray(e.references)&&e.references.forEach(e=>{e&&e.storageKey&&o.add(e.storageKey)}))})}catch(e){console.error("Error iterating image_generation_logs",e)}try{let e=(await Promise.resolve().then(a.t.bind(a,9444,23))).default.createInstance({name:"infinite-canvas",storeName:"video_generation_logs"});await e.iterate(e=>{e&&(e.video&&e.video.storageKey&&o.add(e.video.storageKey),Array.isArray(e.references)&&e.references.forEach(e=>{e&&e.storageKey&&o.add(e.storageKey)}))})}catch(e){console.error("Error iterating video_generation_logs",e)}if(!o.has(e)){if(e.startsWith("image:")||e.startsWith("server:")){let{deleteStoredImages:t}=await Promise.resolve().then(a.bind(a,80387));await t([e])}if(e.startsWith("file:")||e.startsWith("video:")||e.startsWith("server:")){let{deleteStoredMedia:t}=await Promise.resolve().then(a.bind(a,58960));await t([e])}}},0)}return window.setTimeout(()=>v(t),0),{assets:i}}),hydrateAccountAssets:async(a,o=!1)=>{if(a){m=a,p=o,g=!0;try{let n=await (0,d.yG)(a),i=await Promise.all((Array.isArray(n?.assets)?n.assets:[]).map(e=>"image"===e.kind&&e.data.storageKey?.startsWith("image:")?f(e):e));o?e({assets:i}):!(t().assets.length>0)&&i.length&&e({assets:i})}finally{g=!1}}},syncAccountAssets:async e=>{e&&p&&await (0,d.n_)(e,{assets:t().assets})},stopAccountAssetSync:()=>{m="",h&&window.clearTimeout(h),h=null},reset:()=>{m="",h&&window.clearTimeout(h),h=null,e({assets:[]})},cleanupImages:e=>{window.setTimeout(async()=>{let{useCanvasStore:o}=await a.e(4328).then(a.bind(a,89566)),{loadLocalAgentSkills:n,useAgentSkillStore:i}=await a.e(8771).then(a.bind(a,78771)),r=[];try{let e=(await Promise.resolve().then(a.t.bind(a,9444,23))).default,t=e.createInstance({name:"infinite-canvas",storeName:"image_generation_logs"});await t.iterate(e=>{e&&(Array.isArray(e.images)&&e.images.forEach(e=>{e&&e.storageKey&&r.push(e.storageKey)}),Array.isArray(e.references)&&e.references.forEach(e=>{e&&e.storageKey&&r.push(e.storageKey)}))});let o=e.createInstance({name:"infinite-canvas",storeName:"video_generation_logs"});await o.iterate(e=>{e&&(e.video&&e.video.storageKey&&r.push(e.video.storageKey),Array.isArray(e.references)&&e.references.forEach(e=>{e&&e.storageKey&&r.push(e.storageKey)}))})}catch(e){console.error("Error gathering log keys in cleanupImages",e)}try{await i.getState().loadSkills();let a=i.getState(),l=c.k.getState().token?await n():[];await (0,s.cleanupUnusedImages)({assets:t().assets,projects:o.getState().projects,skills:[...a.systemSkills,...a.userSkills,...l],extra:e,logKeys:r})}catch(e){console.error("Error gathering Skill keys in cleanupImages",e)}await (0,l.XQ)({assets:t().assets,projects:o.getState().projects,extra:e,logKeys:r})},0)}}),{name:"infinite-canvas:asset_store",storage:{getItem:async e=>{let t=u(e),a=await r.$.getItem(t);if(!a)return null;let o=JSON.parse(a);return o.state.assets=await Promise.all(o.state.assets.map(f)),o},setItem:(e,t)=>r.$.setItem(u(e),JSON.stringify(t)),removeItem:e=>r.$.removeItem(u(e))},partialize:e=>({assets:e.assets})}));function v(e){!g&&m&&p&&(h&&window.clearTimeout(h),h=window.setTimeout(()=>{e().syncAccountAssets(m).catch(()=>{})},600))}function y(e,t){let a=new Map;return[...t,...e].forEach(e=>{let t=a.get(e.id);(!t||Date.parse(e.updatedAt||"")>=Date.parse(t.updatedAt||""))&&a.set(e.id,e)}),Array.from(a.values()).sort((e,t)=>Date.parse(t.updatedAt||"")-Date.parse(e.updatedAt||""))}},30037:(e,t,a)=>{"use strict";a.d(t,{EE:()=>g,Gh:()=>i,JL:()=>s,KQ:()=>p,St:()=>u,kh:()=>r,kx:()=>l,mx:()=>m,n_:()=>c,yG:()=>d});var o=a(38908),n=a(80387);async function i(e){return(0,o.Vg)("/api/v1/user-config",void 0,e)}async function r(e,t){return(0,o.$P)("/api/v1/user-config/model",{config:t},e)}async function s(e,t){return(0,o.$P)("/api/v1/user-config/storage",{provider:{...t.s3?{s3:(0,n.toProviderPayload)(t.s3)}:{},...t.webdav?{webdav:(0,n.toProviderPayload)(t.webdav)}:{}}},e)}async function l(e,t){return(0,o.$P)("/api/v1/storage/measure",{provider:(0,n.toProviderPayload)(t)},e)}async function d(e){return(0,o.Vg)("/api/v1/user-data/assets",void 0,e)}async function c(e,t){return(0,o.$P)("/api/v1/user-data/assets",{data:t},e)}async function u(e){return(0,o.Vg)("/api/v1/workflows",void 0,e)}async function m(e,t){return(0,o.$P)("/api/v1/workflows",t,e)}async function p(e,t){return(0,o.Al)(`/api/v1/workflows/${encodeURIComponent(t)}`,e)}async function g(e,t){return(0,o.$P)("/api/v1/workflows/agent-draft",t,e)}},32118:(e,t,a)=>{"use strict";a.d(t,{DW:()=>s,H3:()=>i,SF:()=>l,_L:()=>r,nY:()=>c,zu:()=>d});var o=a(98888);let n=new Set(["grok-voice-latest","grok-voice-think-fast-2.0","grok-voice-think-fast-1.0"]),i=[{value:"auto",label:"自动识别"},{value:"en",label:"英语"},{value:"zh",label:"中文"},{value:"ja",label:"日语"},{value:"ko",label:"韩语"},{value:"fr",label:"法语"},{value:"de",label:"德语"},{value:"hi",label:"印地语"},{value:"id",label:"印度尼西亚语"},{value:"it",label:"意大利语"},{value:"ru",label:"俄语"},{value:"tr",label:"土耳其语"},{value:"vi",label:"越南语"},{value:"bn",label:"孟加拉语"},{value:"pt-BR",label:"葡萄牙语（巴西）"},{value:"pt-PT",label:"葡萄牙语（葡萄牙）"},{value:"es-MX",label:"西班牙语（墨西哥）"},{value:"es-ES",label:"西班牙语（西班牙）"},{value:"ar-EG",label:"阿拉伯语（埃及）"},{value:"ar-SA",label:"阿拉伯语（沙特）"},{value:"ar-AE",label:"阿拉伯语（阿联酋）"}],r=[{value:"mp3",label:"MP3"},{value:"wav",label:"WAV"}];function s(e,t){let a;return a=t.trim().toLowerCase().split("/").pop()||"",n.has(a)&&"grok2api"===(0,o.channelProtocolForConfig)({...e,model:t,audioModel:t})}function l(e){return i.some(t=>t.value===e)?e:"auto"}function d(e){return r.some(t=>t.value===e)?e:"mp3"}function c(e){let t=Number(e);return Number.isFinite(t)?String(Math.max(.7,Math.min(1.5,Number(t.toFixed(2))))):"1"}},37385:(e,t,a)=>{"use strict";a.d(t,{W:()=>u});var o=a(80020),n=a(6501),i=a(71821),r=a(10306),s=a(67854),l=a(99726),d=a(10430),c=a(12854);function u({prompt:e,onClose:t,onCopy:a,onSaveAsset:m}){let p=e?.preview.replace(/!\[[^\]]*]\([^)]+\)/g,"").trim()||"";return(0,o.jsx)(o.Fragment,{children:(0,o.jsx)(r.A,{title:e?.title,open:!!e,onCancel:t,footer:null,width:860,children:e?(0,o.jsx)(o.Fragment,{children:(0,o.jsxs)("div",{className:"grid gap-5 md:grid-cols-[300px_minmax(0,1fr)]",children:[(0,o.jsxs)("div",{className:"space-y-3",children:[(0,o.jsx)("img",{src:e.coverUrl,alt:e.title,className:"aspect-[4/3] w-full rounded-lg object-cover"}),p?(0,o.jsx)("pre",{className:"max-h-60 overflow-auto whitespace-pre-wrap rounded-lg bg-stone-100 p-3 text-xs leading-5 text-stone-600 dark:bg-stone-900 dark:text-stone-300",children:p}):null]}),(0,o.jsxs)("div",{className:"min-w-0",children:[(0,o.jsx)("div",{className:"flex flex-wrap gap-1.5",children:e.tags.map(e=>(0,o.jsx)(s.A,{className:"m-0",children:e},e))}),(0,o.jsx)("p",{className:"mt-4 whitespace-pre-wrap text-sm leading-7 text-stone-800 dark:text-stone-300",children:e.prompt}),(0,o.jsxs)("div",{className:"mt-4 text-xs text-stone-500 dark:text-stone-400",children:["创建：",(0,c.Ip)(e.createdAt)," \xb7 更新：",(0,c.Ip)(e.updatedAt)]}),(0,o.jsxs)(l.A,{wrap:!0,className:"mt-5",children:[(0,o.jsx)(d.Ay,{type:"primary",icon:(0,o.jsx)(n.A,{className:"size-4"}),onClick:()=>a(e.prompt),children:"复制提示词"}),m?(0,o.jsx)(d.Ay,{icon:(0,o.jsx)(i.A,{className:"size-4"}),onClick:()=>m(e),children:"加入我的素材"}):null]})]})]})}):null})})}},37530:(e,t,a)=>{"use strict";a.d(t,{C_:()=>d,Dn:()=>m,Gp:()=>i,HP:()=>o,O5:()=>p,OL:()=>c,Qf:()=>n,Sn:()=>u,W_:()=>f,Zv:()=>l,cU:()=>x,dI:()=>h,hs:()=>v,s:()=>g,vI:()=>s,zL:()=>r});let o=[{value:"alloy",label:"Alloy"},{value:"ash",label:"Ash"},{value:"ballad",label:"Ballad"},{value:"coral",label:"Coral"},{value:"echo",label:"Echo"},{value:"fable",label:"Fable"},{value:"nova",label:"Nova"},{value:"onyx",label:"Onyx"},{value:"sage",label:"Sage"},{value:"shimmer",label:"Shimmer"},{value:"verse",label:"Verse"},{value:"marin",label:"Marin"},{value:"cedar",label:"Cedar"}],n=[{value:"mp3",label:"MP3"},{value:"wav",label:"WAV"},{value:"opus",label:"Opus"},{value:"aac",label:"AAC"},{value:"flac",label:"FLAC"},{value:"pcm",label:"PCM"}],i=[{value:"tongtong",label:"彤彤"},{value:"chuichui",label:"锤锤"},{value:"xiaochen",label:"小陈"},{value:"jam",label:"Jam"},{value:"kazi",label:"Kazi"},{value:"douji",label:"Douji"},{value:"luodo",label:"Luodo"}],r=[{value:"wav",label:"WAV"},{value:"pcm",label:"PCM"}];function s(e){return"glm-tts"===e.trim().toLowerCase()}function l(e){return i.some(t=>t.value===e)?e:"tongtong"}function d(e){return r.some(t=>t.value===e)?e:"wav"}function c(e){let t=Number(e);return Number.isFinite(t)?String(Math.max(.5,Math.min(2,Number(t.toFixed(2))))):"1"}function u(e){let t=l(e);return i.find(e=>e.value===t)?.label||t}function m(e){return o.some(t=>t.value===e)?e:"alloy"}function p(e){return n.some(t=>t.value===e)?e:"mp3"}function g(e){let t=Number(e);return Number.isFinite(t)?String(Math.max(.25,Math.min(4,Number(t.toFixed(2))))):"1"}function h(e){let t=m(e);return o.find(e=>e.value===t)?.label||t}function f(e){let t=p(e);return n.find(e=>e.value===t)?.label||t}function x(e){return`${g(e)}x`}function v(e){return"wav"===e?"audio/wav":"opus"===e?"audio/opus":"aac"===e?"audio/aac":"flac"===e?"audio/flac":"pcm"===e?"audio/pcm":"audio/mpeg"}},39230:(e,t,a)=>{"use strict";a.d(t,{Kd:()=>i,Z$:()=>o,sE:()=>n});let o=["Zephyr","Puck","Charon","Kore","Fenrir","Leda","Orus","Aoede","Callirrhoe","Autonoe","Enceladus","Iapetus","Umbriel","Algieba","Despina","Erinome","Algenib","Rasalgethi","Laomedeia","Achernar","Alnilam","Schedar","Gacrux","Pulcherrima","Achird","Zubenelgenubi","Vindemiatrix","Sadachbia","Sadaltager","Sulafat"].map(e=>({label:e,value:e}));function n(e){return o.some(t=>t.value===e)?e:"Kore"}function i(e){let t=atob(e),a=new Uint8Array(t.length);for(let e=0;e<t.length;e+=1)a[e]=t.charCodeAt(e);let o=new ArrayBuffer(44),n=new DataView(o);return r(n,0,"RIFF"),n.setUint32(4,36+a.byteLength,!0),r(n,8,"WAVEfmt "),n.setUint32(16,16,!0),n.setUint16(20,1,!0),n.setUint16(22,1,!0),n.setUint32(24,24e3,!0),n.setUint32(28,48e3,!0),n.setUint16(32,2,!0),n.setUint16(34,16,!0),r(n,36,"data"),n.setUint32(40,a.byteLength,!0),new Blob([o,a],{type:"audio/wav"})}function r(e,t,a){for(let o=0;o<a.length;o+=1)e.setUint8(t+o,a.charCodeAt(o))}},53715:(e,t,a)=>{"use strict";a.d(t,{W:()=>i,y:()=>n});let o=null;async function n(e,t,a){await (!o&&(o=fetch("/api/anonymous/files/session",{method:"POST",credentials:"same-origin"}).then(e=>{if(!e.ok)throw Error("匿名存储会话创建失败")}).catch(e=>{throw o=null,e})),o);let n=new FormData;n.append("file",e,t),n.append("provider",JSON.stringify(a));let i=await fetch("/api/anonymous/files",{method:"POST",body:n,credentials:"same-origin"}),r=await i.json().catch(()=>null);if(!i.ok||r?.code!==0||!r.data)throw Error(r?.msg||"匿名存储上传失败");return r.data}async function i(e,t){let a=await fetch(`/api/anonymous/files/${encodeURIComponent(e)}`,{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({provider:t}),credentials:"same-origin"}),o=await a.json().catch(()=>null);if(!a.ok||o?.code!==0)throw Error(o?.msg||"匿名存储删除失败")}},58960:(e,t,a)=>{"use strict";a.d(t,{XQ:()=>S,aN:()=>k,cK:()=>j,collectMediaStorageKeys:()=>A,deleteStoredMedia:()=>I,iU:()=>f,rD:()=>w,up:()=>C,uploadAssetMediaFile:()=>g,uploadMediaFile:()=>p,zx:()=>h});var o=a(9444),n=a.n(o),i=a(70556),r=a(53715),s=a(38908),l=a(80387),d=a(58573);let c=n().createInstance({name:"infinite-canvas",storeName:"media_files"}),u=new Map,m=null;async function p(e,t="file"){let a="string"==typeof e?await (await fetch(e)).blob():e,o=`${t}:${(0,i.Ak)()}`;await c.setItem(o,a);let n=URL.createObjectURL(a);u.set(o,n);let r=a.type.startsWith("video/")?await M(n):{};return{url:n,storageKey:o,bytes:a.size,mimeType:a.type||"application/octet-stream",...r}}async function g(e,t="asset-media"){try{return await x(e,e.name||`${t}-${(0,i.Ak)()}`)}catch(a){if(a instanceof Error&&!a.message.includes("服务端对象存储未启用"))throw a;return p(e,t)}}async function h(e){let t=await fetch((0,l.getProxyUrl)(e));if(!t.ok)throw Error(`媒体下载失败：${t.status}`);let a=await t.blob();if(a.type.includes("json")||a.type.startsWith("text/")){let e=await a.text().catch(()=>""),t="";try{let a=JSON.parse(e);t=a.msg||a.message||""}catch{t=e}throw Error(t||"媒体下载失败")}return a}async function f(e,t){return x(await h(e),t)}async function x(e,t){let a=await b().catch(()=>null),o=a?.allowUserProvider?(0,l.loadUserStorageProvider)():null;if(!a||!(0,l.canUseGlobalStorage)(a)&&!o)throw Error("服务端对象存储未启用");let n=d.k.getState().token;if(o?.type==="webdav"){let a=await v(e,t,o);if(a)return a}if(!n){if(!o)throw Error("请先登录后再同步媒体");return y(await (0,r.y)(e,t,(0,l.toProviderPayload)(o)),e)}let i=new FormData;i.append("file",e,t),o&&i.append("provider",JSON.stringify((0,l.toProviderPayload)(o)));let s=await fetch("/api/v1/files",{method:"POST",headers:{Authorization:`Bearer ${n}`},body:i}),c=await s.json().catch(()=>null);if(!s.ok||c?.code!==0||!c.data)throw Error(c?.msg||"媒体同步失败");let u=c.data.mimeType?.startsWith("video/")?await M(c.data.url):{};return{...c.data,bytes:c.data.bytes||e.size,mimeType:c.data.mimeType||e.type||"application/octet-stream",...u}}async function v(e,t,o){let n=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611)),i=await n.persistDirectWebDAV(o,e,t);return i?y(i,e):null}async function y(e,t){await c.setItem(e.storageKey,t);let a=URL.createObjectURL(t);u.set(e.storageKey,a);let o=t.type.startsWith("video/")?await M(a):{};return{...e,url:a,bytes:e.bytes||t.size,mimeType:e.mimeType||t.type||"application/octet-stream",...o}}async function b(){return m||=(0,s.Vg)("/api/storage/config")}function w(){m=null}async function k(e,t=""){if(!e)return t;let o=u.get(e);if(o)return o;let n=await c.getItem(e).catch(()=>null);if(n){let t=URL.createObjectURL(n);return u.set(e,t),t}if(e.startsWith("server:webdav:")){let o=(0,l.loadUserStorageProvider)();if(o?.type!=="webdav")return t;let n=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611));return n.directWebDAVMediaUrl(o,n.directWebDAVObjectKey(e))}if(e.startsWith("server:")){let o=e.slice(7);if(t&&!t.startsWith("blob:")&&!t.includes("direct=1")&&!t.startsWith("/webdav-media/"))return t;let{getStorageObjectInfo:n}=await a.e(3056).then(a.bind(a,13056)),i=await n(o).catch(()=>null);if(!i)return t;let r=(0,l.loadUserStorageProvider)();if(i.direct&&r?.type==="webdav"){let e=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611));try{return await e.directWebDAVMediaUrl(r,i.objectKey)}catch(t){if(!d.k.getState().token||!e.isWebDAVDirectUnavailable(t))throw t}}return i.publicUrl||`/api/files/${encodeURIComponent(o)}/content`}return t}async function j(e){return c.getItem(e)}async function C(e,t){await c.setItem(e,t);let a=URL.createObjectURL(t);return u.set(e,a),a}async function N(e){let t=e.slice(7);if(!t)return;let o=d.k.getState().token,n=(0,l.loadUserStorageProvider)();if(e.startsWith("server:webdav:")&&n?.type!=="webdav")return;if(n?.type==="webdav"){let t=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611));if(await t.deletePersistedDirectWebDAV(n,e)){let t=u.get(e);t&&URL.revokeObjectURL(t),u.delete(e),await c.removeItem(e);return}}if(!o){if(!n)return;await (0,r.W)(t,(0,l.toProviderPayload)(n));let a=u.get(e);a&&URL.revokeObjectURL(a),u.delete(e),await c.removeItem(e);return}let i=await fetch(`/api/v1/files/${encodeURIComponent(t)}`,{method:"DELETE",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify(n?{provider:(0,l.toProviderPayload)(n)}:{})}),s=await i.json().catch(()=>null);if(!i.ok||s?.code!==0)throw Error(s?.msg||"删除服务端视频失败")}async function I(e){let{useAssetStore:t}=await a.e(9822).then(a.bind(a,19822)),o=new Set(t.getState().assets.map(e=>"video"===e.kind||"audio"===e.kind?e.data.storageKey:null).filter(e=>!!e));await Promise.all(Array.from(new Set(e)).map(async e=>{if(o.has(e))return;if(e.startsWith("server:"))return void await N(e);let t=u.get(e);t&&URL.revokeObjectURL(t),u.delete(e),await c.removeItem(e)}))}async function S(e){let t=A(e),a=[];await c.iterate((e,o)=>{t.has(o)||a.push(o)}),await Promise.all(a.map(e=>c.removeItem(e)))}function A(e,t=new Set){return e&&"object"==typeof e&&("storageKey"in e&&"string"==typeof e.storageKey&&e.storageKey.includes(":")&&t.add(e.storageKey),Object.values(e).forEach(e=>Array.isArray(e)?e.forEach(e=>A(e,t)):A(e,t))),t}function M(e){return new Promise(t=>{let a=document.createElement("video"),o=()=>t({width:a.videoWidth||1280,height:a.videoHeight||720});a.onloadedmetadata=o,a.onerror=o,a.src=e})}},62598:(e,t,a)=>{"use strict";function o(e){if(!Number.isFinite(e)||e<=0)return"";let t=["B","KB","MB","GB"],a=e,o=0;for(;a>=1024&&o<t.length-1;)a/=1024,o+=1;return`${a>=10||0===o?a.toFixed(0):a.toFixed(1)} ${t[o]}`}function n(e){let t=Math.max(0,Math.floor(e/1e3)),a=Math.floor(t/60),o=t%60;return a?`${a}分${String(o).padStart(2,"0")}秒`:`${o}秒`}function i(e){let t=e.split(",",2)[1];if(!t)return 0;let a=t.endsWith("==")?2:+!!t.endsWith("=");return Math.max(0,Math.floor(3*t.length/4)-a)}function r(e){return new Promise((t,a)=>{let o=new FileReader;o.onload=()=>t(String(o.result||"")),o.onerror=()=>a(Error("读取图片失败")),o.readAsDataURL(e)})}function s(e){return new Promise(t=>{let a=new Image,o=()=>t({width:a.naturalWidth||1024,height:a.naturalHeight||1024,mimeType:e.match(/^data:([^;]+)/)?.[1]||"image/png"});a.onload=o,a.onerror=o,setTimeout(o,3e3),a.src=e})}function l(e){var t,a;let o,[n,i]=e.dataUrl.split(",",2),r=n.match(/data:(.*?);base64/)?.[1]||e.type||"image/png",s=atob(i||""),l=new Uint8Array(s.length);for(let e=0;e<s.length;e+=1)l[e]=s.charCodeAt(e);let d=l.length>=3&&255===l[0]&&216===l[1]&&255===l[2]?{mimeType:"image/jpeg",extension:".jpg"}:l.length>=8&&137===l[0]&&80===l[1]&&78===l[2]&&71===l[3]&&13===l[4]&&10===l[5]&&26===l[6]&&10===l[7]?{mimeType:"image/png",extension:".png"}:l.length>=12&&82===l[0]&&73===l[1]&&70===l[2]&&70===l[3]&&87===l[8]&&69===l[9]&&66===l[10]&&80===l[11]?{mimeType:"image/webp",extension:".webp"}:null;return new File([l],d?(t=e.name,a=d.extension,o=t?.trim()||"reference",`${o.replace(/\.[^./\\]+$/,"")||"reference"}${a}`):e.name||"reference.png",{type:d?.mimeType||r})}a.d(t,{KQ:()=>r,P0:()=>i,a3:()=>n,bX:()=>l,xL:()=>s,z3:()=>o})},66629:(e,t,a)=>{"use strict";a.d(t,{s:()=>i});var o=a(20978),n=a(2092);function i(){let{message:e}=o.A.useApp();return(t,a="已复制")=>{(0,n.A)(t),e.success(a)}}},66997:(e,t,a)=>{"use strict";a.d(t,{m:()=>y});var o=a(80020),n=a(91641),i=a(72344),r=a(20978),s=a(34728),l=a(10306),d=a(83252),c=a(62794),u=a(99726),m=a(10430),p=a(43458),g=a(67854),h=a(62598),f=a(58960),x=a(80387),v=a(19822);function y({open:e,asset:t=null,onClose:a}){let{message:b}=r.A.useApp(),[w]=s.A.useForm(),k=(0,i.useRef)(null),j=(0,i.useRef)(null),C=(0,i.useRef)(null),N=(0,v.useAssetStore)(e=>e.addAsset),I=(0,v.useAssetStore)(e=>e.updateAsset),[S,A]=(0,i.useState)("text"),[M,_]=(0,i.useState)(null),[T,z]=(0,i.useState)(null),P=s.A.useWatch("coverUrl",w)||"",E=s.A.useWatch("title",w)||"",D=s.A.useWatch("tags",w)||[],R=s.A.useWatch("content",w)||"";(0,i.useLayoutEffect)(()=>{e&&(A(t?.kind||"text"),_(t?.kind==="image"?t.data:null),z(t?.kind==="video"||t?.kind==="audio"?t.data:null),w.setFieldsValue(t?{kind:t.kind,title:t.title,coverUrl:t.coverUrl,tags:t.tags||[],source:t.source,note:t.note,content:"text"===t.kind?t.data.content:"image"===t.kind?t.data.dataUrl:t.data.url}:{kind:"text",title:"",coverUrl:"",tags:[],source:"手动添加",note:"",content:""}))},[t,w,e]);let $=async()=>{let e=await w.validateFields(),o={title:e.title.trim(),coverUrl:e.coverUrl?.trim()||("image"===e.kind&&M?M.dataUrl:""),tags:e.tags||[],source:e.source?.trim(),note:e.note?.trim(),metadata:t?.metadata||{source:"manual"}};if("text"===e.kind){let a={...o,kind:"text",data:{content:(e.content||"").trim()}};t?I(t.id,a):N(a)}else if("image"===e.kind){let a=(e.content||"").trim();if(!M&&!a)return void b.error("请选择图片文件或填写图片 URL");let n=M||{dataUrl:a,width:0,height:0,bytes:0,mimeType:"image/*"},i={...o,coverUrl:o.coverUrl||n.dataUrl,kind:"image",data:n};t?I(t.id,i):N(i)}else if("video"===e.kind){let a=(e.content||"").trim();if(!T&&!a)return void b.error("请选择视频文件或填写视频 URL");let n=T||{url:a,width:0,height:0,bytes:0,mimeType:"video/mp4"},i={...o,kind:"video",data:n};t?I(t.id,i):N(i)}else{let a=(e.content||"").trim();if(!T&&!a)return void b.error("请选择音频文件或填写音频 URL");let n=T||{url:a,mimeType:"audio/mpeg"},i={...o,kind:"audio",data:n};t?I(t.id,i):N(i)}b.success(t?"素材已更新":"素材已保存"),a()},L=async e=>{if(!e)return;let t=await (0,h.KQ)(e);w.setFieldValue("coverUrl",t)},F=async e=>{if(!e||!e.type.startsWith("image/"))return;let t=await (0,x.uploadImage)(e),a={dataUrl:t.url,storageKey:t.storageKey,width:t.width,height:t.height,bytes:t.bytes,mimeType:t.mimeType};_(a),w.setFieldValue("content",a.dataUrl),w.getFieldValue("coverUrl")||w.setFieldValue("coverUrl",a.dataUrl),w.getFieldValue("title")||w.setFieldValue("title",e.name)},V=async e=>{if(!e||"video"===S&&!e.type.startsWith("video/")||"audio"===S&&!e.type.startsWith("audio/")&&!/\.(mp3|wav)$/i.test(e.name))return;let t=await (0,f.uploadAssetMediaFile)(e,"audio"===S?"asset-audio":"asset-video");z("audio"===S?{url:t.url,storageKey:t.storageKey,bytes:t.bytes,mimeType:t.mimeType}:{url:t.url,storageKey:t.storageKey,width:t.width||0,height:t.height||0,bytes:t.bytes,mimeType:t.mimeType}),w.setFieldValue("content",t.url),w.getFieldValue("title")||w.setFieldValue("title",e.name)};return(0,o.jsxs)(l.A,{title:t?"编辑素材":"新增素材",open:e,width:980,onCancel:a,onOk:()=>void $(),okText:"保存",cancelText:"取消",destroyOnHidden:!0,children:[(0,o.jsxs)("div",{className:"grid gap-6 pt-1 lg:grid-cols-[minmax(0,1fr)_320px]",children:[(0,o.jsxs)(s.A,{form:w,layout:"vertical",requiredMark:!1,initialValues:{kind:"text",tags:[]},children:[(0,o.jsx)(s.A.Item,{name:"kind",label:"类型",children:(0,o.jsx)(d.A,{options:[{label:"文本",value:"text"},{label:"图片",value:"image"},{label:"视频",value:"video"},{label:"音频",value:"audio"}],onChange:e=>{A(e),_(null),z(null),w.setFieldValue("content","")}})}),(0,o.jsx)(s.A.Item,{name:"title",label:"标题",rules:[{required:!0,message:"请输入标题"}],children:(0,o.jsx)(c.A,{size:"large",placeholder:"给素材起一个容易检索的名字"})}),(0,o.jsx)(s.A.Item,{name:"coverUrl",label:"封面 URL",children:(0,o.jsxs)(u.A.Compact,{className:"w-full",children:[(0,o.jsx)(c.A,{placeholder:"可粘贴图片 URL，也可以上传本地封面"}),(0,o.jsx)(m.Ay,{icon:(0,o.jsx)(n.A,{className:"size-3.5"}),onClick:()=>k.current?.click(),children:"上传"})]})}),(0,o.jsx)(s.A.Item,{name:"tags",label:"标签",children:(0,o.jsx)(d.A,{mode:"tags",tokenSeparators:[",","，"],placeholder:"输入标签后回车"})}),(0,o.jsxs)("div",{className:"grid gap-4 sm:grid-cols-2",children:[(0,o.jsx)(s.A.Item,{name:"source",label:"来源",children:(0,o.jsx)(c.A,{placeholder:"手动添加 / 画布 / 提示词库"})}),(0,o.jsx)(s.A.Item,{name:"note",label:"备注",children:(0,o.jsx)(c.A,{placeholder:"可选"})})]}),"text"===S?(0,o.jsx)(s.A.Item,{name:"content",label:"文本内容",rules:[{required:!0,message:"请输入文本内容"}],children:(0,o.jsx)(c.A.TextArea,{rows:8,placeholder:"保存提示词、说明文案、参考描述等文本素材"})}):(0,o.jsx)(s.A.Item,{name:"content",label:"image"===S?"图片内容":"video"===S?"视频内容":"音频内容",required:!0,children:(0,o.jsxs)("div",{className:"rounded-lg border border-dashed border-stone-300 p-4 dark:border-stone-700",children:[(0,o.jsxs)(u.A.Compact,{className:"w-full",children:[(0,o.jsx)(c.A,{placeholder:"image"===S?"填写图片 URL，或选择本地图片文件":"video"===S?"填写视频 URL，或选择本地视频文件":"填写音频 URL，或选择本地音频文件"}),(0,o.jsx)(m.Ay,{icon:(0,o.jsx)(n.A,{className:"size-4"}),onClick:()=>"image"===S?j.current?.click():C.current?.click(),children:"上传"})]}),(0,o.jsx)("div",{className:"mt-2",children:"image"===S&&M?(0,o.jsxs)(p.A.Text,{type:"secondary",className:"text-xs",children:[M.width,"x",M.height," \xb7 ",(0,h.z3)(M.bytes)]}):("video"===S||"audio"===S)&&T?(0,o.jsxs)(p.A.Text,{type:"secondary",className:"text-xs",children:["width"in T?`${T.width}x${T.height} \xb7 `:"","number"==typeof T.bytes?(0,h.z3)(T.bytes):""," \xb7 ",T.mimeType]}):(0,o.jsx)(p.A.Text,{type:"secondary",className:"text-xs",children:"未选择文件"})})]})})]}),(0,o.jsxs)("div",{className:"rounded-xl border border-stone-200 bg-stone-50 p-4 dark:border-stone-800 dark:bg-stone-950",children:[(0,o.jsx)(p.A.Text,{strong:!0,children:"预览"}),(0,o.jsxs)("div",{className:"mt-3 overflow-hidden rounded-lg border border-stone-200 bg-background dark:border-stone-800",children:[P||M?.dataUrl?(0,o.jsx)("img",{src:P||M?.dataUrl,alt:"",className:"aspect-[4/3] w-full object-cover"}):"video"===S&&(T?.url||R)?(0,o.jsx)("video",{src:T?.url||R,className:"aspect-[4/3] w-full bg-black object-contain",controls:!0}):"audio"===S&&(T?.url||R)?(0,o.jsx)("div",{className:"flex aspect-[4/3] items-center justify-center bg-stone-100 p-5 dark:bg-stone-900",children:(0,o.jsx)("audio",{src:T?.url||R,controls:!0,className:"w-full"})}):(0,o.jsx)("div",{className:"flex aspect-[4/3] items-center justify-center bg-stone-100 p-5 text-center text-sm text-stone-500 dark:bg-stone-900",children:R||"暂无封面"}),(0,o.jsxs)("div",{className:"p-4",children:[(0,o.jsx)(p.A.Text,{strong:!0,ellipsis:!0,className:"block",children:E||"未命名素材"}),(0,o.jsx)("div",{className:"mt-2 flex flex-wrap gap-1.5",children:D.length?D.map(e=>(0,o.jsx)(g.A,{className:"m-0",children:e},e)):(0,o.jsx)(g.A,{className:"m-0",children:"未打标签"})})]})]})]})]}),(0,o.jsx)("input",{ref:k,type:"file",accept:"image/*",className:"hidden",onChange:e=>{L(e.target.files?.[0]),e.target.value=""}}),(0,o.jsx)("input",{ref:j,type:"file",accept:"image/*",className:"hidden",onChange:e=>{F(e.target.files?.[0]),e.target.value=""}}),(0,o.jsx)("input",{ref:C,type:"file",accept:"audio"===S?"audio/mpeg,audio/wav,audio/x-wav,.mp3,.wav":"video/*",className:"hidden",onChange:e=>{V(e.target.files?.[0]),e.target.value=""}})]})}},76047:(e,t,a)=>{"use strict";a.d(t,{Nm:()=>j,O_:()=>k,Ye:()=>y});var o=a(48933),n=a(70556),i=a(37530),r=a(32118),s=a(61863),l=a(74662),d=a(39230),c=a(58960),u=a(98888),m=a(58573),p=a(48967);let g=new Map;function h(e){let t=m.k.getState().token;return"remote"===e.channelMode||"local"===e.channelMode&&!!t}function f(e,t){if(h(e))return`/api/v1${t}`;let a=(0,u.localChannelForActiveModel)(e);return(0,u.buildApiUrl)(a?.baseUrl||e.baseUrl,t)}function x(e){let t=m.k.getState().token;return"remote"===e.channelMode?{...t?{Authorization:`Bearer ${t}`}:{},...(0,u.channelIdForActiveModel)(e)?{"X-Model-Channel-ID":(0,u.channelIdForActiveModel)(e)}:{},"Content-Type":"application/json"}:t?{Authorization:`Bearer ${t}`,...(0,u.channelIdForActiveModel)(e)?{"X-User-Model-Channel-ID":(0,u.channelIdForActiveModel)(e)}:{},"Content-Type":"application/json"}:(0,l.Uh)(e)?(0,l.Lq)(e):{Authorization:`Bearer ${(0,u.localChannelForActiveModel)(e)?.apiKey||e.apiKey}`,"Content-Type":"application/json"}}function v(e){h(e)&&(m.k.getState().hydrateUser(),p.useWalletStore.getState().triggerWalletSync())}function y(e,t){let a={...e,model:t,audioModel:t},n=`${f(a,"/tts/voices")}|${(0,u.channelIdForActiveModel)(a)}|${t}`,i=g.get(n);if(i)return i;let r=o.A.get(f(a,"/tts/voices"),{headers:x(a),params:{model:t}}).then(e=>Array.isArray(e.data.voices)?e.data.voices.filter(e=>!!e.voice_id):[]).finally(()=>g.delete(n));return g.set(n,r),r}async function b(e,t,a){let n=(e.model||e.audioModel).trim();_(e,n);try{if((0,l.MP)(n)&&(0,l.Uh)(e,n)){if(a)throw Error("Gemini TTS 不支持参考音频");let i=I(e,t),r=h(e)?{model:n,...i}:i,s=(0,u.localChannelForActiveModel)(e),c=await o.A.post(h(e)?"/api/v1/audio/speech":(0,l.Bk)(s?.baseUrl||e.baseUrl,n,"generateContent"),r,{headers:h(e)?x(e):(0,l.Lq)(e)});return v(e),function(e){let t=e.candidates?.flatMap(e=>e.content?.parts||[]).find(e=>!!e.inlineData?.data)?.inlineData;if(!t?.data)throw Error((0,l.lJ)(e,"Gemini TTS 没有返回音频数据"));return(0,d.Kd)(t.data)}(c.data)}if((0,s.Ht)(n)&&!h(e)){let r=(0,s.AN)(e.mimoTtsFormat),l=await S(e,n,t,a),d=await o.A.post(f(e,"/chat/completions"),l,{headers:x(e)});return function(e,t){let a=e.choices?.[0]?.message?.audio?.data?.trim()||"";if(!a)throw Error("MiMo 没有返回音频数据");let o=atob(a),n=new Uint8Array(o.length);for(let e=0;e<o.length;e+=1)n[e]=o.charCodeAt(e);return new Blob([n],{type:(0,i.hs)(t)})}(d.data,r)}let r=N(e,n),c=await C(e,n,t,a),m=await o.A.post(f(e,"/audio/speech"),c,{headers:x(e),responseType:"blob"});return await T(m.data),v(e),m.data.type.startsWith("audio/")?m.data:new Blob([m.data],{type:(0,i.hs)(r)})}catch(e){throw Error(function(e,t){if(o.A.isAxiosError(e)){let a=e.response?.data;return a?.msg||a?.error?.message||P(e.response?.status,t)}return e instanceof Error?e.message:t}(e,"音频生成失败"))}}async function w(e,t="mp3"){let a=e.type.startsWith("audio/")?e:new Blob([e],{type:(0,i.hs)(t)});return(0,c.uploadMediaFile)(a,"audio")}async function k(e,t,a={},o){let i=(e.model||e.audioModel).trim();if(_(e,i),!h(e)||(0,l.MP)(i)&&(0,l.Uh)(e,i)){let r=await b(e,t,o),s=N(e,i),l=await w(r,s),d=new Date().toISOString();return{id:a.clientTaskId||`local_audio_task_${(0,n.Ak)()}`,status:"completed",progress:100,url:l.url,audio_url:l.url,storageKey:l.storageKey,mimeType:l.mimeType,bytes:l.bytes,started_at:d,startedAt:d,created_at:d,createdAt:d,completed_at:d}}let r=await fetch("/api/v1/canvas/audio-tasks",{method:"POST",headers:x(e),body:JSON.stringify({endpoint:"/audio/speech",nodeId:a.nodeId||"",sourceId:a.sourceId||"",clientTaskId:a.clientTaskId||"",prompt:t,request:await C(e,i,t,o)})});if(!r.ok)throw Error(await z(r,"音频任务创建失败"));let s=await r.json();if(0!==s.code||!s.data)throw Error(s.msg||"音频任务创建失败");return v(e),s.data}async function j(e){let t=m.k.getState().token;if(!t)throw Error("请先登录后再使用云端渠道");let a=await fetch(`/api/v1/canvas/audio-tasks/${encodeURIComponent(e)}`,{headers:{Authorization:`Bearer ${t}`}});if(!a.ok)throw Error(await z(a,"读取音频任务失败"));let o=await a.json();if(0!==o.code||!o.data)throw Error(o.msg||"读取音频任务失败");return o.data}async function C(e,t,a,o){if((0,l.MP)(t)&&(0,l.Uh)(e,t)){if(o)throw Error("Gemini TTS 不支持参考音频");return{model:t,...I(e,a)}}if((0,i.vI)(t)){if(a.length>1024)throw Error("GLM-TTS 文本不能超过 1024 个字符");return{model:t,input:a,voice:(0,i.Zv)(e.glmTtsVoice),response_format:(0,i.C_)(e.glmTtsFormat),speed:Number((0,i.OL)(e.glmTtsSpeed))}}if((0,s.Ht)(t)){let n=e.audioInstructions.trim();return{model:t,input:a,...(0,s.c0)(t)?{voice:(0,s.De)(e.mimoTtsVoice)}:{},...(0,s.Cb)(t)?{mimo_voice_design_prompt:e.mimoVoiceDesignPrompt.trim()}:{},...(0,s.TR)(t)?{mimo_voice_clone_audio:await A(o)}:{},...((0,s.c0)(t)||(0,s.TR)(t))&&n?{instructions:n}:{},response_format:(0,s.AN)(e.mimoTtsFormat)}}if((0,r.DW)(e,t))return{model:t,input:a,voice_id:e.grokTtsVoice||"eve",language:(0,r.SF)(e.grokTtsLanguage),output_format:{codec:(0,r.zu)(e.grokTtsFormat)},speed:Number((0,r.nY)(e.grokTtsSpeed))};let n=e.audioInstructions.trim();return{model:t,input:a,voice:(0,i.Dn)(e.audioVoice),response_format:(0,i.O5)(e.audioFormat),speed:Number((0,i.s)(e.audioSpeed)),...n?{instructions:n}:{}}}function N(e,t){return(0,l.MP)(t)&&(0,l.Uh)(e,t)?"wav":(0,i.vI)(t)?(0,i.C_)(e.glmTtsFormat):(0,s.Ht)(t)?(0,s.AN)(e.mimoTtsFormat):(0,r.DW)(e,t)?(0,r.zu)(e.grokTtsFormat):(0,i.O5)(e.audioFormat)}function I(e,t){return{contents:[{role:"user",parts:[{text:t}]}],generationConfig:{responseModalities:["AUDIO"],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:(0,d.sE)(e.geminiTtsVoice)}}}}}}async function S(e,t,a,o){let n=[],i=e.audioInstructions.trim();if((0,s.Cb)(t)){let t=e.mimoVoiceDesignPrompt.trim();if(!t)throw Error("请填写音色描述");n.push({role:"user",content:t})}else i&&((0,s.c0)(t)||(0,s.TR)(t))&&n.push({role:"user",content:i});return n.push({role:"assistant",content:a}),{model:t,messages:n,audio:{format:(0,s.AN)(e.mimoTtsFormat),...(0,s.c0)(t)?{voice:(0,s.De)(e.mimoTtsVoice)}:{},...(0,s.TR)(t)?{voice:await A(o)}:{}}}}async function A(e){var t;if(!e)throw Error("请连接并选择参考音频节点");let a=await (0,c.aN)(e.storageKey,e.url);if(!a)throw Error("参考音频不可用");let o=await fetch(a);if(!o.ok)throw Error(`读取参考音频失败（${o.status}）`);let n=await o.blob(),i=M(n.type)||M(e.type);if(!i)throw Error("参考音频仅支持 MP3 或 WAV");let r=await (t=n,new Promise((e,a)=>{let o=new FileReader;o.onerror=()=>a(Error("读取参考音频失败")),o.onload=()=>{let t="string"==typeof o.result?o.result:"",a=t.indexOf(",");e(a>=0?t.slice(a+1):t)},o.readAsDataURL(t)}));if(r.length>0xa00000)throw Error("参考音频 Base64 编码后不能超过 10MB");return`data:${i};base64,${r}`}function M(e){let t=e.trim().toLowerCase().split(";")[0];return"audio/mpeg"===t||"audio/mp3"===t?"audio/mpeg":"audio/wav"===t||"audio/x-wav"===t||"audio/wave"===t?"audio/wav":""}function _(e,t){if(!t)throw Error("请先配置音频模型");if("local"!==e.channelMode)return;if(!(0,s.Ht)(t)&&!(0,l.Uh)(e,t)){if(!e.baseUrl.trim())throw Error("请先配置 Base URL");if(!e.apiKey.trim())throw Error("请先配置 API Key");return}let a=(0,u.localChannelForActiveModel)(e);if(!(a?.baseUrl||e.baseUrl).trim())throw Error("请先配置 Base URL");if(!(a?.apiKey||e.apiKey).trim())throw Error("请先配置 API Key")}async function T(e){let t;if(e.type.includes("json")){try{t=JSON.parse(await e.text())}catch{return}if("number"==typeof t.code&&0!==t.code)throw Error(t.msg||"音频生成失败");if(t.error?.message)throw Error(t.error.message)}}async function z(e,t){try{let a=await e.json();return a.msg||a.error?.message||P(e.status,t)}catch{return P(e.status,t)}}function P(e,t){return 401===e||403===e?"鉴权失败，请检查 API Key、套餐权限或模型权限":429===e?"请求被限流或额度不足，请稍后重试":e?`${t}（${e}）`:t}},80387:(e,t,a)=>{"use strict";a.r(t),a.d(t,{USER_STORAGE_PROVIDER_KEY:()=>p,USER_WEBDAV_STORAGE_PROVIDER_KEY:()=>g,canUseGlobalStorage:()=>f,cleanupUnusedImages:()=>z,clearGuestStorageProviders:()=>$,clearStorageConfigCache:()=>b,collectImageStorageKeys:()=>P,defaultUserStorageProvider:()=>E,defaultUserWebDAVStorageProvider:()=>D,deleteStoredImages:()=>T,getImageBlob:()=>A,getProxyUrl:()=>x,imageToDataUrl:()=>_,loadStorageConfig:()=>I,loadUserS3StorageProvider:()=>L,loadUserStorageProvider:()=>V,loadUserWebDAVStorageProvider:()=>F,resolveImageUrl:()=>w,saveUserStorageProvider:()=>U,saveUserWebDAVStorageProvider:()=>K,setImageBlob:()=>M,toProviderPayload:()=>W,uploadImage:()=>v,uploadRemoteImageToServer:()=>y});var o=a(9444),n=a.n(o),i=a(70556),r=a(62598),s=a(53715),l=a(38908),d=a(58573);let c=n().createInstance({name:"infinite-canvas",storeName:"image_files"}),u=new Map,m=new Map,p="infinite-canvas:user_storage_provider",g="infinite-canvas:user_webdav_storage_provider",h=null;function f(e){let t=d.k.getState().user;return"server_sqlite_s3"===e.mode&&!!(t&&"guest"!==t.role&&("admin"===t.role||e.allowUserGlobalProvider))}function x(e){if(!e.startsWith("http://")&&!e.startsWith("https://"))return e;try{let t=new URL(e);if(function(e){let t=e.toLowerCase().replace(/^\[|\]$/g,"");if("localhost"===t||t.endsWith(".localhost")||t.endsWith(".local")||"host.docker.internal"===t||"::1"===t||t.includes(":")&&(t.startsWith("fc")||t.startsWith("fd")||/^fe[89ab]/.test(t)))return!0;let a=t.split(".").map(Number);if(4!==a.length||a.some(e=>!Number.isInteger(e)||e<0||e>255))return!1;let[o,n]=a;return 10===o||127===o||172===o&&n>=16&&n<=31||192===o&&168===n||169===o&&254===n}(t.hostname)||t.host===window.location.host)return e}catch{return e}return`/api/proxy-image?url=${encodeURIComponent(e)}`}async function v(e,t={}){let a,o="string"==typeof e?x(e):e;if("string"==typeof o){let e=await fetch(o);if(!e.ok){let t=await e.json().catch(()=>null);throw Error(t?.msg||`代理图片拉取失败：${e.status}`)}if((e.headers.get("content-type")||"").includes("application/json")){let t=await e.json().catch(()=>null);throw Error(t?.msg||"代理图片下载失败")}a=await e.blob()}else a=o;if(!t.localOnly){let e=await j(a);if(e)return e}let n=`image:${(0,i.Ak)()}`;await c.setItem(n,a);let s=URL.createObjectURL(a);u.set(n,s);let l=await (0,r.xL)(s);return{url:s,storageKey:n,width:l.width,height:l.height,bytes:a.size,mimeType:a.type||l.mimeType}}async function y(e,t){let a=await fetch(x(e));if(!a.ok){let e=await a.json().catch(()=>null);throw Error(e?.msg||"代理图片拉取失败："+a.status)}let o=await a.blob(),n=await I(),l=n.allowUserProvider?V():null;if(!f(n)&&!l)throw Error("服务端对象存储未启用");let c=d.k.getState().token;if(l?.type==="webdav"){let e=await C(o,t||`image-${(0,i.Ak)()}.${S(o.type)}`,l);if(e)return e}if(!c){if(!l)throw Error("服务端存储需要先登录");return N(await (0,s.y)(o,t||"image-"+(0,i.Ak)()+"."+S(o.type),W(l)),o)}let u=new FormData;u.append("file",o,t||"image-"+(0,i.Ak)()+"."+S(o.type)),l&&u.append("provider",JSON.stringify(W(l)));let p=await fetch("/api/v1/files",{method:"POST",headers:{Authorization:"Bearer "+c},body:u}),g=await p.json().catch(()=>null);if(!p.ok||g?.code!==0||!g.data)throw Error(g?.msg||"服务端图片上传失败");let h=await (0,r.xL)(g.data.url);return g.data.storageKey?.startsWith("server:")&&m.set(g.data.storageKey.slice(7),g.data.url),{...g.data,width:g.data.width||h.width,height:g.data.height||h.height,mimeType:g.data.mimeType||o.type||"image/png",bytes:g.data.bytes||o.size}}function b(){h=null}async function w(e,t=""){if(!e)return t;if(e.startsWith("server:webdav:")){let o=await k(e).catch(()=>"");if(o)return o;let n=V();if(n?.type!=="webdav")return t;let i=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611)),r=await i.readDirectWebDAV(n,i.directWebDAVObjectKey(e));return M(e,r)}if(e.startsWith("server:")){let o=e.slice(7);if(t&&!t.startsWith("blob:")&&!t.includes("direct=1"))return t;let n=await k(e).catch(()=>"");if(n)return n;let i=m.get(o);if(i)return i;let{getStorageObjectInfo:r}=await a.e(3056).then(a.bind(a,13056)),s=await r(o).catch(()=>null);if(!s)return t;let l=V();if(s.direct&&l?.type==="webdav"){let t=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611));try{let a=await t.readDirectWebDAV(l,s.objectKey,s.mimeType);return M(e,a)}catch(e){if(!d.k.getState().token||!t.isWebDAVDirectUnavailable(e))throw e}}let c=s.publicUrl||`/api/files/${encodeURIComponent(o)}/content`;return m.set(o,c),c}return await k(e)||t}async function k(e){let t=u.get(e);if(t)return t;let a=await c.getItem(e);if(!a)return"";let o=URL.createObjectURL(a);return u.set(e,o),o}async function j(e){let t=await I().catch(()=>null),a=t?.allowUserProvider?V():null,o=!!t&&f(t),n=o||!!a;if(!t||!n)return null;let l=d.k.getState().token;if(a?.type==="webdav"){let t=await C(e,`image-${(0,i.Ak)()}.${S(e.type)}`,a);if(t)return t}if(!l){if(!a){if(o)throw Error("服务端存储需要先登录");return null}try{let t=await (0,s.y)(e,`image-${(0,i.Ak)()}.${S(e.type)}`,W(a));return N(t,e)}catch{return null}}let c=new FormData;c.append("file",e,`image-${(0,i.Ak)()}.${S(e.type)}`),a&&c.append("provider",JSON.stringify(W(a)));let u=await fetch("/api/v1/files",{method:"POST",headers:{Authorization:`Bearer ${l}`},body:c}),p=await u.json().catch(()=>null);if(!u.ok||p?.code!==0||!p.data){if(!o)return null;throw Error(p?.msg||"服务端图片上传失败")}let g=await (0,r.xL)(p.data.url);return p.data.storageKey?.startsWith("server:")&&m.set(p.data.storageKey.slice(7),p.data.url),{...p.data,width:p.data.width||g.width,height:p.data.height||g.height,mimeType:p.data.mimeType||e.type||"image/png",bytes:p.data.bytes||e.size}}async function C(e,t,o){let n=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611)),i=await n.persistDirectWebDAV(o,e,t);return i?N({...i,width:0,height:0},e):null}async function N(e,t){await c.setItem(e.storageKey,t);let a=URL.createObjectURL(t);u.set(e.storageKey,a),e.storageKey.startsWith("server:")&&e.url&&!e.url.includes("direct=1")&&m.set(e.storageKey.slice(7),e.url);let o=await (0,r.xL)(a);return{...e,url:a,width:e.width||o.width,height:e.height||o.height,mimeType:e.mimeType||t.type||o.mimeType,bytes:e.bytes||t.size}}async function I(){return h||=(0,l.Vg)("/api/storage/config")}function S(e){return"image/jpeg"===e?"jpg":"image/webp"===e?"webp":"png"}async function A(e){return c.getItem(e)}async function M(e,t){await c.setItem(e,t);let a=URL.createObjectURL(t);return u.set(e,a),a}async function _(e){let t=e.storageKey?.startsWith("server:")?e.storageKey.slice(7):"",a=e.storageKey?.startsWith("server:webdav:"),o=[e.dataUrl,e.url].some(e=>!!(e&&!e.startsWith("blob:"))),n=!d.k.getState().token&&t&&e.storageKey&&!o?await k(e.storageKey).catch(()=>""):"",i=e.storageKey?await w(e.storageKey,e.url||e.dataUrl||""):"",r=[e.dataUrl&&!e.dataUrl.startsWith("blob:")?e.dataUrl:"",e.url&&!e.url.startsWith("blob:")?e.url:"",n,i,t&&!a?`/api/files/${encodeURIComponent(t)}/content`:""].filter((e,t,a)=>!!e&&a.indexOf(e)===t);if(!r.length)return"";let s="";for(let e of r){if(e.startsWith("data:"))return e;try{let t=x(e),a=await fetch(t);if(!a.ok){s=`读取参考图失败：${a.status}`;continue}return function(e){return new Promise((t,a)=>{let o=new FileReader;o.onload=()=>t(String(o.result||"")),o.onerror=()=>a(Error("读取图片失败")),o.readAsDataURL(e)})}(await a.blob())}catch(e){s=e instanceof Error?e.message:"读取参考图失败"}}throw Error(s||"读取参考图失败")}async function T(e){let{useAssetStore:t}=await a.e(3390).then(a.bind(a,19822)),o=new Set(t.getState().assets.map(e=>"text"!==e.kind?e.data.storageKey:null).filter(e=>!!e));await Promise.all(Array.from(new Set(e)).map(async e=>{if(o.has(e))return;if(e.startsWith("server:"))return void await O(e);let t=u.get(e);t&&URL.revokeObjectURL(t),u.delete(e),await c.removeItem(e)}))}async function z(e){let t=P(e),a=[];await c.iterate((e,o)=>{t.has(o)||a.push(o)}),await T(a)}function P(e,t=new Set){return"string"==typeof e?(e.startsWith("image:")||e.startsWith("server:"))&&t.add(e):e&&"object"==typeof e&&("storageKey"in e&&"string"==typeof e.storageKey&&(e.storageKey.startsWith("image:")||e.storageKey.startsWith("server:"))&&t.add(e.storageKey),Object.values(e).forEach(e=>Array.isArray(e)?e.forEach(e=>P(e,t)):P(e,t))),t}function E(){return{enabled:!1,name:"我的 R2",type:"s3",endpoint:"",region:"auto",bucket:"",accessKeyId:"",secretAccessKey:"",publicBaseUrl:"",pathPrefix:"canvas"}}function D(){return{enabled:!1,name:"我的 WebDAV",type:"webdav",endpoint:"",pathPrefix:"canvas",username:"",password:""}}function R(e){let t=d.k.getState().user;return`${e}:${t?.id||"guest"}`}function $(){try{window.localStorage.removeItem(`${p}:guest`),window.localStorage.removeItem(`${g}:guest`),window.localStorage.removeItem(p),window.localStorage.removeItem(g)}catch{}}function L(){try{let e=R(p),t=JSON.parse(window.localStorage.getItem(e)||"null");return t?{...E(),...t,type:"s3"}:null}catch{return null}}function F(){try{let e=R(g),t=JSON.parse(window.localStorage.getItem(e)||"null");return t?{...D(),...t,type:"webdav"}:null}catch{return null}}function V(){var e,t;let a=L(),o=F();return a?.enabled&&o?.enabled?null:a?.enabled&&(e=a).endpoint&&e.bucket&&e.accessKeyId&&e.secretAccessKey?a:o?.enabled&&(t=o).endpoint&&t.username&&t.password?o:null}function U(e){let t=R(p);window.localStorage.setItem(t,JSON.stringify({...E(),...e,type:"s3"}))}function K(e){let t=R(g);window.localStorage.setItem(t,JSON.stringify({...D(),...e,type:"webdav"}))}function W(e){return"webdav"===e.type?{enabled:e.enabled,name:e.name,type:"webdav",endpoint:e.endpoint,pathPrefix:e.pathPrefix,username:e.username,password:e.password}:{enabled:e.enabled,name:e.name,type:"s3",endpoint:e.endpoint,region:e.region||"auto",bucket:e.bucket,accessKeyId:e.accessKeyId,secretAccessKey:e.secretAccessKey,publicBaseUrl:e.publicBaseUrl,pathPrefix:e.pathPrefix}}async function O(e){let t=e.slice(7);if(!t)return;let o=d.k.getState().token;m.delete(t);let n=V();if(e.startsWith("server:webdav:")&&n?.type!=="webdav")return;if(n?.type==="webdav"){let t=await Promise.all([a.e(8888),a.e(611)]).then(a.bind(a,30611));if(await t.deletePersistedDirectWebDAV(n,e)){let t=u.get(e);t&&URL.revokeObjectURL(t),u.delete(e),await c.removeItem(e);return}}if(!o){if(!n)return;await (0,s.W)(t,W(n));let a=u.get(e);a&&URL.revokeObjectURL(a),u.delete(e),await c.removeItem(e);return}let i=await fetch(`/api/v1/files/${encodeURIComponent(t)}`,{method:"DELETE",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify(n?{provider:W(n)}:{})}),r=await i.json().catch(()=>null);if(!i.ok||r?.code!==0)throw Error(r?.msg||"删除服务端图片失败")}},88962:(e,t,a)=>{"use strict";a.d(t,{$:()=>i});var o=a(9444),n=a.n(o);n().config({name:"infinite-canvas",storeName:"app_state"});let i={getItem:async e=>{try{return await n().getItem(e)||null}catch{return window.localStorage.getItem(e)}},setItem:async(e,t)=>{try{await n().setItem(e,t)}catch{window.localStorage.setItem(e,t)}},removeItem:async e=>{try{await n().removeItem(e)}catch{window.localStorage.removeItem(e)}}}},98888:(e,t,a)=>{"use strict";a.r(t),a.d(t,{CONFIG_STORE_KEY:()=>l,buildApiUrl:()=>C,channelIdForActiveModel:()=>I,channelProtocolForConfig:()=>A,defaultConfig:()=>d,directAIProviderForConfig:()=>M,filterChannelModelsByCapability:()=>v,filterModelsByCapability:()=>x,localChannelForActiveModel:()=>S,modelMatchesCapability:()=>f,normalizeLocalChannels:()=>N,normalizeModelList:()=>k,resolveModelForCapability:()=>b,selectableModelsByCapability:()=>y,useConfigStore:()=>w,useEffectiveConfig:()=>j});var o=a(72344),n=a(58302),i=a(94478),r=a(38908),s=a(58573);let l="infinite-canvas:ai_config_store",d={channelMode:"local",baseUrl:"https://api.openai.com",apiKey:"",model:"gpt-image-2-1k",imageModel:"gpt-image-2-1k",videoModel:"sd4-seedance-2.0-fast",textModel:"gpt-5.6-sol",audioModel:"gpt-4o-mini-tts",audioVoice:"alloy",audioFormat:"mp3",audioSpeed:"1",audioInstructions:"",grokTtsVoice:"eve",grokTtsLanguage:"auto",grokTtsFormat:"mp3",grokTtsSpeed:"1",glmTtsVoice:"tongtong",glmTtsFormat:"wav",glmTtsSpeed:"1",mimoTtsVoice:"冰糖",mimoTtsFormat:"wav",mimoVoiceDesignPrompt:"",geminiTtsVoice:"Kore",videoSeconds:"6",videoMode:"std",videoNegativePrompt:"",videoMultiShot:"false",videoShotType:"intelligence",videoMultiPrompt:[{prompt:"",duration:"1"}],videoElementList:[{name:"",description:"",references:[]}],vquality:"720",videoGenerateAudio:"false",videoWatermark:"false",videoCharacterOrientation:"video",systemPrompt:"",models:[],imageModels:[],videoModels:[],textModels:[],audioModels:[],quality:"auto",size:"1:1",videoSize:"1280x720",count:"1",canvasImageCount:"1",timeout:"600",apiMode:"images",streamImages:"",streamPartialImages:"1",responseFormatB64Json:"",codexCli:"",systemPrompts:{image:"",video:"",text:"",workflow:"",workflowAgent:""},localChannels:[],publicChannels:[],syncStorageConfig:!1,syncWebDAVStorageConfig:!1,activeChannelId:"",imageChannelId:"",videoChannelId:"",textChannelId:"",audioChannelId:""};function c(e,t){return t.includes(e)?e:""}function u(e,t){return e.find(t)||""}function m(e){let t=e.toLowerCase();return!t.startsWith("minimax-m")&&"minimax-m3"!==t&&(t.includes("video")||t.includes("seedance")||t.includes("sora")||t.includes("veo")||t.includes("kling")||t.includes("hailuo")||t.includes("minimax-h3")||t.includes("minimax")&&!t.includes("-m")||t.includes("skyreels")||t.includes("happyhorse")||t.includes("happyhouse")||t.includes("runway")||t.includes("aleph")||t.includes("vidu")||t.includes("pixverse")||t.includes("omni-flash")||t.includes("omni-fast")||t.includes("omni-v2v")||t.includes("gemini-omni-video")||t.includes("veo3.1")||t.includes("veo-3.1")||t.includes("infinitalk")||t.includes("wan2-5")||t.includes("wan2.5")||t.includes("wan2-6")||t.includes("wan2.6")||t.includes("wan2-7")||t.includes("wan2.7")||t.includes("wan2-7-r2v")||t.includes("wan2.7-r2v")||t.includes("wan2-7-videoedit")||t.includes("wan2.7-videoedit")||t.includes("wan/2-5")||t.includes("wan/2-6")||t.includes("wan/2-7-text-to-video")||t.includes("wan/2-7-image-to-video")||t.includes("wan/2-7-videoedit")||t.includes("wan/2-7-r2v")||t.includes("grok-imagine")&&(t.includes("/upscale")||t.includes("/extend")))}function p(e){let t=e.toLowerCase();return!m(e)&&!g(e)&&(t.includes("image")||t.includes("nano-banana")||t.includes("seedream")||t.includes("gpt-image")||t.includes("cogview")||t.includes("dall-e")||t.includes("dalle")||t.includes("imagen")||t.includes("gemini-2.5-flash")||t.includes("gemini-3-pro")||t.includes("gemini-3.1-flash")||t.includes("flux")||t.includes("kontext")||t.includes("4o-image")||t.includes("4o image")||t.includes("gpt-4o-image")||t.includes("z-image")||t.includes("qwen/image")||t.includes("qwen2/image")||t.includes("qwen/text-to-image")||t.includes("qwen2/text-to-image")||t.includes("ideogram")||t.includes("recraft")||t.includes("sdxl")||t.includes("stable-diffusion")||t.includes("midjourney")||t.includes("wan2-7-image")||t.includes("wan2.7-image")||t.includes("wan/2-7-image")||t.includes("topaz/image")||t.includes("gemini-omni-character")||t.includes("grok-imagine")&&!t.includes("video"))}function g(e){let t=e.toLowerCase();return t.includes("audio")||t.includes("tts")||t.includes("speech")||t.includes("voice")||t.includes("music")||t.includes("sound")||t.includes("elevenlabs")||t.includes("suno")||t.includes("lyrics")||t.includes("vocal")||t.includes("midi")||t.includes("wav")}function h(e){return!p(e)&&!m(e)&&!g(e)}function f(e,t,a=""){if(!t)return!0;if("gemini"===a){let a=e.toLowerCase(),o=/^models\/veo-|^veo-/.test(a),n=a.includes("tts"),i=!o&&!n&&a.includes("image");return"video"===t?o:"audio"===t?n:"image"===t?i:!o&&!n&&!i}return"image"===t?p(e):"video"===t?m(e):"audio"===t?g(e):h(e)}function x(e,t,a=""){return t?e.filter(e=>f(e,t,a)):e}function v(e,t,a){let o=a?new Set(a):null;return k(e.flatMap(e=>x(e.models,t,e.protocol||""))).filter(e=>!o||o.has(e))}function y(e,t){let a=w.getState().publicSettings,o=a?.modelChannel?.availableModels||[],n=("remote"===e.channelMode?e.publicChannels.map(e=>({protocol:e.protocol,models:e.models||[]})):N(e)).map(e=>e.models.includes("*")||0===e.models.length?{...e,models:o.length?o:e.models.filter(e=>"*"!==e)}:e),i=e.models.length>0?e.models:o;return t?v(n,t,i.length>0?i:void 0):k(n.flatMap(e=>e.models))}function b(e,t,a){let o="image"===a?e.imageModel:"video"===a?e.videoModel:"audio"===a?e.audioModel:e.textModel,n="image"===a?d.imageModel:"video"===a?d.videoModel:"audio"===a?d.audioModel:d.textModel,i=y(e,a),r=e=>!!(e&&(i.length?i.includes(e):f(e,a)));return r(t)?t:r(o)?o:i[0]||n}let w=(0,n.v)()((0,i.Zr)((e,t)=>({config:d,publicSettings:null,isPublicSettingsLoading:!1,isConfigOpen:!1,shouldPromptContinue:!1,updateConfig:(t,a)=>e(e=>({config:{...e.config,[t]:a}})),loadPublicSettings:async()=>{if(!t().isPublicSettingsLoading){e({isPublicSettingsLoading:!0});try{e({publicSettings:await (0,r.Vg)("/api/settings")})}finally{e({isPublicSettingsLoading:!1})}}},isAiConfigReady:(e,t)=>{let a;return a=S({...e,model:t}),!!t.trim()&&("remote"===e.channelMode||!!(a?.baseUrl.trim()&&a?.apiKey.trim()))},openConfigDialog:(t=!1)=>e({isConfigOpen:!0,shouldPromptContinue:t}),setConfigDialogOpen:t=>e({isConfigOpen:t}),clearPromptContinue:()=>e({shouldPromptContinue:!1}),loadUserConfig:t=>{let a=t||s.k.getState().user?.id||"guest",o=`${l}:${a}`,n=window.localStorage.getItem(o);if(n)try{let t=JSON.parse(n),a=t.state?.config||t.config||{},o={...d,...a},i=N(o),r=k(i.flatMap(e=>e.models));e({config:{...o,localChannels:i,models:r}});return}catch{}e({config:d})},reset:()=>e({config:d})}),{name:l,storage:(0,i.KU)(()=>({getItem:e=>{let t=s.k.getState().user,a=`${e}:${t?.id||"guest"}`;return window.localStorage.getItem(a)},setItem:(e,t)=>{let a=s.k.getState().user,o=`${e}:${a?.id||"guest"}`;window.localStorage.setItem(o,t)},removeItem:e=>{let t=s.k.getState().user,a=`${e}:${t?.id||"guest"}`;window.localStorage.removeItem(a)}})),partialize:e=>({config:e.config}),merge:(e,t)=>{let a=(e||{}).config||{},o={...d,...a},n=N(o),i=k(n.flatMap(e=>e.models));return{...t,config:{...o,localChannels:n,models:i,baseUrl:n[0]?.baseUrl||o.baseUrl,apiKey:n[0]?.apiKey||o.apiKey,imageChannelId:o.imageChannelId||n[0]?.id||"",videoChannelId:o.videoChannelId||n[0]?.id||"",textChannelId:o.textChannelId||n[0]?.id||"",audioChannelId:o.audioChannelId||n[0]?.id||"",activeChannelId:o.activeChannelId||"",syncStorageConfig:!0===o.syncStorageConfig,syncWebDAVStorageConfig:!0===o.syncWebDAVStorageConfig,channelMode:o.channelMode||"remote",imageModel:o.imageModel||d.imageModel,videoModel:o.videoModel||d.videoModel,textModel:o.textModel||d.textModel,audioModel:o.audioModel||d.audioModel,audioVoice:o.audioVoice||d.audioVoice,audioFormat:o.audioFormat||d.audioFormat,audioSpeed:o.audioSpeed||d.audioSpeed,grokTtsVoice:o.grokTtsVoice||d.grokTtsVoice,grokTtsLanguage:o.grokTtsLanguage||d.grokTtsLanguage,grokTtsFormat:o.grokTtsFormat||d.grokTtsFormat,grokTtsSpeed:o.grokTtsSpeed||d.grokTtsSpeed,glmTtsVoice:o.glmTtsVoice||d.glmTtsVoice,glmTtsFormat:o.glmTtsFormat||d.glmTtsFormat,glmTtsSpeed:o.glmTtsSpeed||d.glmTtsSpeed,geminiTtsVoice:o.geminiTtsVoice||d.geminiTtsVoice,systemPrompts:o.systemPrompts?.image?o.systemPrompts:d.systemPrompts,audioInstructions:o.audioInstructions||"",videoSeconds:o.videoSeconds||"6",videoMode:o.videoMode||"std",videoNegativePrompt:o.videoNegativePrompt||"",videoMultiShot:o.videoMultiShot||"false",videoShotType:o.videoShotType||"intelligence",videoMultiPrompt:Array.isArray(o.videoMultiPrompt)&&o.videoMultiPrompt.length?o.videoMultiPrompt:d.videoMultiPrompt,videoElementList:Array.isArray(o.videoElementList)&&o.videoElementList.length?o.videoElementList:d.videoElementList,vquality:o.vquality||"720",videoGenerateAudio:o.videoGenerateAudio||"false",videoWatermark:o.videoWatermark||"false",videoCharacterOrientation:"image"===o.videoCharacterOrientation?"image":"video",canvasImageCount:o.canvasImageCount||"1",imageModels:v(n,"image"),videoModels:v(n,"video"),textModels:v(n,"text"),audioModels:v(n,"audio")}}}}));function k(e){return Array.from(new Set((e||[]).map(e=>e.trim()).filter(Boolean)))}function j(){let e=w(e=>e.config),t=w(e=>e.publicSettings?.modelChannel||null),a=(0,s.k)(e=>e.token),n=(0,s.k)(e=>e.user),i=!!(a&&n&&("admin"===n.role||t?.allowUserRemoteChannel===!0));return(0,o.useMemo)(()=>(function(e,t,a){let o=a?t?.allowCustomChannel?e.channelMode:"remote":"local",n=t?.availableModels?.length?t.availableModels:e.models,i=N(e).map(e=>"xyb-official-exclusive"===e.id||e.models.includes("*")||0===e.models.length?{...e,models:k([...e.models.filter(e=>"*"!==e),...n])}:e);if("local"===o||!t){let a=k(i.flatMap(e=>e.models)),r=a.length>0?a:n,s=v(i,"text",r),l=v(i,"image",r),f=v(i,"video",r),x=v(i,"audio",r),y=c(e.textModel,s)||u(s,h)||s[0]||d.textModel,b=c(e.model,s)||y,w=c(e.imageModel,l)||u(l,p)||d.imageModel,j=c(e.videoModel,f)||u(f,m)||d.videoModel,C=c(e.audioModel,x)||u(x,g)||d.audioModel;return{...e,channelMode:o,localChannels:i,models:r,imageModels:l,videoModels:f,textModels:s,audioModels:x,model:s.includes(e.model)?e.model:b,imageModel:l.includes(e.imageModel)?e.imageModel:w,videoModel:f.includes(e.videoModel)?e.videoModel:j,textModel:s.includes(e.textModel)?e.textModel:y||b,audioModel:x.includes(e.audioModel)?e.audioModel:C,publicChannels:t?.channels||[]}}let r=t.availableModels,s=t.channels.length?t.channels:i,l=v(s,"text",r),f=v(s,"image",r),x=v(s,"video",r),y=v(s,"audio",r),b=c(t.defaultTextModel,l)||u(l,h)||l[0]||"",w=c(t.defaultModel,l)||b,j=c(t.defaultImageModel,f)||u(f,p),C=c(t.defaultVideoModel,x)||u(x,m),I=u(y,g);return{...e,channelMode:o,models:r,imageModels:f,videoModels:x,textModels:l,audioModels:y,model:l.includes(e.model)?e.model:w,imageModel:f.includes(e.imageModel)?e.imageModel:j,videoModel:x.includes(e.videoModel)?e.videoModel:C,textModel:l.includes(e.textModel)?e.textModel:b||w,audioModel:y.includes(e.audioModel)?e.audioModel:I,systemPrompt:t.systemPrompt,publicChannels:t.channels||[]}})(e,t,i),[i,e,t])}function C(e,t){let a=e.trim().replace(/\/+$/,""),o=(a=function(e){try{let t=new URL(e),a=t.pathname.replace(/\/+$/,""),o=a.toLowerCase();for(let e of["/api/plan/v3","/api/paas/v4"]){let n=o.indexOf(e);if(n<0)continue;let i=n+e.length;if(o.length===i||"/"===o[i])return t.pathname=a.slice(0,i),t.search="",t.hash="",t.toString().replace(/\/+$/,"")}return e}catch{return e}}(a)).toLowerCase(),n=o.endsWith("/v1")||o.endsWith("/api/v3")||o.endsWith("/api/plan/v3")||o.endsWith("/api/paas/v4")?a:`${a}/v1`;return`${n}${t}`}function N(e){let t=(Array.isArray(e.localChannels)?e.localChannels:[]).map((e,t)=>({id:e.id||`local-${t+1}`,protocol:e.protocol||"openai",name:"string"==typeof e.name?e.name:`本地渠道 ${t+1}`,baseUrl:e.baseUrl||"",apiKey:e.apiKey||"",models:Array.isArray(e.models)?e.models.filter(Boolean):[]}));return t.length||t.push({id:"local-default",protocol:"openai",name:"本地直连",baseUrl:e.baseUrl||d.baseUrl,apiKey:e.apiKey||"",models:Array.isArray(e.models)?e.models.filter(Boolean):[]}),t}function I(e){let t="remote"===e.channelMode?e.publicChannels:N(e),a=e.model===e.imageModel?e.imageChannelId:e.model===e.videoModel?e.videoChannelId:e.model===e.audioModel?e.audioChannelId:e.model===e.textModel?e.textChannelId:"",o=t.find(e=>e.id===a);if(o?.protocol==="gemini")return a;if(!o){let a=t.find(t=>"gemini"===t.protocol&&(t.models||[]).includes(e.model));if(a)return a.id||""}return f(e.model,"image")&&e.imageChannelId?e.imageChannelId:f(e.model,"video")&&e.videoChannelId?e.videoChannelId:f(e.model,"audio")&&e.audioChannelId?e.audioChannelId:f(e.model,"text")&&e.textChannelId?e.textChannelId:e.activeChannelId?e.activeChannelId:e.model===e.videoModel?e.videoChannelId:e.model===e.textModel?e.textChannelId:e.model===e.audioModel?e.audioChannelId:e.imageChannelId}function S(e){let t=N(e),a=I(e);return t.find(t=>t.id===a&&t.models.includes(e.model))||t.find(t=>t.models.includes(e.model))||t.find(e=>e.id===a)||t[0]}function A(e){let t="remote"===e.channelMode?e.publicChannels.find(t=>t.id===I(e))||e.publicChannels[0]:S(e);return t?.protocol||"openai"}function M(e){let t=A(e);return"kie"===t||"apimart"===t?t:null}}},e=>{e.O(0,[430,777,9853,4155,5571,8358,344,5864,3458,4728,177,4714,3883,4758,15,5499,3140,5107,145,2147,9576,4291,1788,7805,9977,3200,6256,4387,4757,2387,3703,7829,636,7358],()=>e(e.s=2817)),_N_E=e.O()}]);